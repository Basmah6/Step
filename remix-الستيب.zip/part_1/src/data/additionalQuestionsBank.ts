import { QuizQuestion } from '../types';
import { EXTRA_GRAMMAR_QUESTIONS } from './extraQuestionsBank';
import { MODAL_VERBS_EASY_30 } from './modalVerbsEasy30';
import { MODAL_VERBS_MEDIUM_30 } from './modalVerbsMedium30';
import { MODAL_VERBS_HARD_30 } from './modalVerbsHard30';
import { PASSIVE_VOICE_EASY_30 } from './passiveVoiceEasy30';
import { PASSIVE_VOICE_MEDIUM_30 } from './passiveVoiceMedium30';
import { PASSIVE_VOICE_HARD_30 } from './passiveVoiceHard30';
import { ACTIVE_VOICE_EASY_30 } from './activeVoiceEasy30';
import { ACTIVE_VOICE_MEDIUM_30 } from './activeVoiceMedium30';
import { ACTIVE_VOICE_HARD_30 } from './activeVoiceHard30';
import { MIXED_CONDITIONALS_EASY_30 } from './mixedConditionalsEasy30';
import { MIXED_CONDITIONALS_MEDIUM_30 } from './mixedConditionalsMedium30';
import { MIXED_CONDITIONALS_HARD_30 } from './mixedConditionalsHard30';
import { CONDITIONALS_EASY_30 } from './conditionalsEasy30';
import { CONDITIONALS_MEDIUM_30 } from './conditionalsMedium30';
import { CONDITIONALS_HARD_30 } from './conditionalsHard30';
import { WISH_IF_ONLY_EASY_30 } from './wishIfOnlyEasy30';
import { WISH_IF_ONLY_MEDIUM_30 } from './wishIfOnlyMedium30';
import { WISH_IF_ONLY_HARD_30 } from './wishIfOnlyHard30';
import { REPORTED_SPEECH_EASY_30 } from './reportedSpeechEasy30';
import { REPORTED_SPEECH_MEDIUM_30 } from './reportedSpeechMedium30';
import { REPORTED_SPEECH_HARD_30 } from './reportedSpeechHard30';
import { DIRECT_SPEECH_EASY_30 } from './directSpeechEasy30';
import { DIRECT_SPEECH_MEDIUM_30 } from './directSpeechMedium30';
import { DIRECT_SPEECH_HARD_30 } from './directSpeechHard30';
import { QUESTION_TAGS_EASY_30 } from './questionTagsEasy30';
import { QUESTION_TAGS_MEDIUM_30 } from './questionTagsMedium30';
import { QUESTION_TAGS_HARD_30 } from './questionTagsHard30';
import { SUBJECT_VERB_AGREEMENT_EASY_30 } from './subjectVerbAgreementEasy30';
import { SUBJECT_VERB_AGREEMENT_MEDIUM_30 } from './subjectVerbAgreementMedium30';
import { SUBJECT_VERB_AGREEMENT_HARD_30 } from './subjectVerbAgreementHard30';
import { ARTICLES_EASY_30 } from './articlesEasy30';
import { ARTICLES_MEDIUM_30 } from './articlesMedium30';
import { ARTICLES_HARD_30 } from './articlesHard30';
import { COUNTABLE_NOUNS_EASY_30 } from './countableNounsEasy30';
import { COUNTABLE_NOUNS_MEDIUM_30 } from './countableNounsMedium30';
import { COUNTABLE_NOUNS_HARD_30 } from './countableNounsHard30';
import { QUANTIFIERS_EASY_30 } from './quantifiersEasy30';
import { QUANTIFIERS_MEDIUM_30 } from './quantifiersMedium30';
import { QUANTIFIERS_HARD_30 } from './quantifiersHard30';
import { COMPARATIVES_EASY_30 } from './comparativesEasy30';
import { COMPARATIVES_MEDIUM_30 } from './comparativesMedium30';
import { COMPARATIVES_HARD_30 } from './comparativesHard30';
import { ADJECTIVES_ADVERBS_EASY_30 } from './adjectivesAdverbsEasy30';
import { ADJECTIVES_ADVERBS_MEDIUM_30 } from './adjectivesAdverbsMedium30';
import { ADJECTIVES_ADVERBS_HARD_30 } from './adjectivesAdverbsHard30';
import { PREPOSITIONS_EASY_30 } from './prepositionsEasy30';
import { PREPOSITIONS_MEDIUM_30 } from './prepositionsMedium30';
import { PREPOSITIONS_HARD_30 } from './prepositionsHard30';
import { CONJUNCTIONS_EASY_30 } from './conjunctionsEasy30';
import { CONJUNCTIONS_MEDIUM_30 } from './conjunctionsMedium30';
import { CONJUNCTIONS_HARD_30 } from './conjunctionsHard30';
import { ELLIPSIS_SUBSTITUTION_EASY_30 } from './ellipsisSubstitutionEasy30';
import { ELLIPSIS_SUBSTITUTION_MEDIUM_30 } from './ellipsisSubstitutionMedium30';
import { ELLIPSIS_SUBSTITUTION_HARD_30 } from './ellipsisSubstitutionHard30';
import { PARALLEL_STRUCTURE_EASY_30 } from './parallelStructureEasy30';
import { PARALLEL_STRUCTURE_MEDIUM_30 } from './parallelStructureMedium30';
import { PARALLEL_STRUCTURE_HARD_30 } from './parallelStructureHard30';
import { WORD_ORDER_EASY_30 } from './wordOrderEasy30';
import { WORD_ORDER_MEDIUM_30 } from './wordOrderMedium30';
import { WORD_ORDER_HARD_30 } from './wordOrderHard30';
import { INVERSION_EASY_30 } from './inversionEasy30';
import { INVERSION_MEDIUM_30 } from './inversionMedium30';
import { INVERSION_HARD_30 } from './inversionHard30';
import { CLEFT_EASY_30 } from './cleftEasy30';
import { CLEFT_MEDIUM_30 } from './cleftMedium30';
import { CLEFT_HARD_30 } from './cleftHard30';
import { EMPHASIS_EASY_30 } from './emphasisEasy30';
import { EMPHASIS_MEDIUM_30 } from './emphasisMedium30';
import { EMPHASIS_HARD_30 } from './emphasisHard30';
import { PUNCTUATION_EASY_30 } from './punctuationEasy30';
import { PUNCTUATION_MEDIUM_30 } from './punctuationMedium30';
import { PUNCTUATION_HARD_30 } from './punctuationHard30';
import { COMMON_ERRORS_EASY_30 } from './commonErrorsEasy30';
import { COMMON_ERRORS_MEDIUM_30 } from './commonErrorsMedium30';
import { COMMON_ERRORS_HARD_30 } from './commonErrorsHard30';

const INITIAL_ADDITIONAL_QUESTIONS: QuizQuestion[] = [
  // ==========================================
  // 1. MODAL VERBS (90 Handcrafted Questions)
  // ==========================================
  ...MODAL_VERBS_EASY_30,
  ...MODAL_VERBS_MEDIUM_30,
  ...MODAL_VERBS_HARD_30,

  // ==========================================
  // 2. PASSIVE VOICE (90 Handcrafted Questions)
  // ==========================================
  ...PASSIVE_VOICE_EASY_30,
  ...PASSIVE_VOICE_MEDIUM_30,
  ...PASSIVE_VOICE_HARD_30,

  // ==========================================
  // 3. ACTIVE VOICE (90 Handcrafted Questions)
  // ==========================================
  ...ACTIVE_VOICE_EASY_30,
  ...ACTIVE_VOICE_MEDIUM_30,
  ...ACTIVE_VOICE_HARD_30,

  // ==========================================
  // 4. CONDITIONALS: 0, 1ST, 2ND, 3RD (90 Handcrafted Questions)
  // ==========================================
  ...CONDITIONALS_EASY_30,
  ...CONDITIONALS_MEDIUM_30,
  ...CONDITIONALS_HARD_30,

  // ==========================================
  // 5. MIXED CONDITIONALS (90 Handcrafted Questions)
  // ==========================================
  ...MIXED_CONDITIONALS_EASY_30,
  ...MIXED_CONDITIONALS_MEDIUM_30,
  ...MIXED_CONDITIONALS_HARD_30,

  // ==========================================
  // 6. WISH / IF ONLY (90 Handcrafted Questions)
  // ==========================================
  ...WISH_IF_ONLY_EASY_30,
  ...WISH_IF_ONLY_MEDIUM_30,
  ...WISH_IF_ONLY_HARD_30,

  // ==========================================
  // 7. REPORTED SPEECH (90 Handcrafted Questions)
  // ==========================================
  ...REPORTED_SPEECH_EASY_30,
  ...REPORTED_SPEECH_MEDIUM_30,
  ...REPORTED_SPEECH_HARD_30,

  // ==========================================
  // 8. DIRECT SPEECH (90 Handcrafted Questions)
  // ==========================================
  ...DIRECT_SPEECH_EASY_30,
  ...DIRECT_SPEECH_MEDIUM_30,
  ...DIRECT_SPEECH_HARD_30,

  // ==========================================
  // 9. QUESTIONS & QUESTION TAGS (90 Handcrafted Questions)
  // ==========================================
  ...QUESTION_TAGS_EASY_30,
  ...QUESTION_TAGS_MEDIUM_30,
  ...QUESTION_TAGS_HARD_30,

  // ==========================================
  // 10. SUBJECT–VERB AGREEMENT (90 Handcrafted Questions)
  // ==========================================
  ...SUBJECT_VERB_AGREEMENT_EASY_30,
  ...SUBJECT_VERB_AGREEMENT_MEDIUM_30,
  ...SUBJECT_VERB_AGREEMENT_HARD_30,

  // ==========================================
  // 11. ARTICLES: A, AN, THE, ZERO (90 Handcrafted Questions)
  // ==========================================
  ...ARTICLES_EASY_30,
  ...ARTICLES_MEDIUM_30,
  ...ARTICLES_HARD_30,

  // ==========================================
  // 12. COUNTABLE & UNCOUNTABLE NOUNS (90 Handcrafted Questions)
  // ==========================================
  ...COUNTABLE_NOUNS_EASY_30,
  ...COUNTABLE_NOUNS_MEDIUM_30,
  ...COUNTABLE_NOUNS_HARD_30,

  // ==========================================
  // 13. QUANTIFIERS (90 Handcrafted Questions)
  // ==========================================
  ...QUANTIFIERS_EASY_30,
  ...QUANTIFIERS_MEDIUM_30,
  ...QUANTIFIERS_HARD_30,

  // ==========================================
  // 14. COMPARATIVES & SUPERLATIVES (90 Handcrafted Questions)
  // ==========================================
  ...COMPARATIVES_EASY_30,
  ...COMPARATIVES_MEDIUM_30,
  ...COMPARATIVES_HARD_30,

  // ==========================================
  // 15. ADJECTIVES & ADVERBS (90 Handcrafted Questions)
  // ==========================================
  ...ADJECTIVES_ADVERBS_EASY_30,
  ...ADJECTIVES_ADVERBS_MEDIUM_30,
  ...ADJECTIVES_ADVERBS_HARD_30,

  // ==========================================
  // 16. PREPOSITIONS (90 Handcrafted Questions)
  // ==========================================
  ...PREPOSITIONS_EASY_30,
  ...PREPOSITIONS_MEDIUM_30,
  ...PREPOSITIONS_HARD_30,

  // ==========================================
  // 17. CONJUNCTIONS & LINKING WORDS (90 Handcrafted Questions)
  // ==========================================
  ...CONJUNCTIONS_EASY_30,
  ...CONJUNCTIONS_MEDIUM_30,
  ...CONJUNCTIONS_HARD_30,

  // ==========================================
  // 18. ELLIPSIS & SUBSTITUTION (90 Handcrafted Questions)
  // ==========================================
  ...ELLIPSIS_SUBSTITUTION_EASY_30,
  ...ELLIPSIS_SUBSTITUTION_MEDIUM_30,
  ...ELLIPSIS_SUBSTITUTION_HARD_30,

  // ==========================================
  // 19. PARALLEL STRUCTURE (90 Handcrafted Questions)
  // ==========================================
  ...PARALLEL_STRUCTURE_EASY_30,
  ...PARALLEL_STRUCTURE_MEDIUM_30,
  ...PARALLEL_STRUCTURE_HARD_30,

  // ==========================================
  // 20. WORD ORDER (90 Handcrafted Questions)
  // ==========================================
  ...WORD_ORDER_EASY_30,
  ...WORD_ORDER_MEDIUM_30,
  ...WORD_ORDER_HARD_30,

  // ==========================================
  // 21. INVERSION (90 Handcrafted Questions)
  // ==========================================
  ...INVERSION_EASY_30,
  ...INVERSION_MEDIUM_30,
  ...INVERSION_HARD_30,

  // ==========================================
  // 22. CLEFT SENTENCES (90 Handcrafted Questions)
  // ==========================================
  ...CLEFT_EASY_30,
  ...CLEFT_MEDIUM_30,
  ...CLEFT_HARD_30,

  // ==========================================
  // 23. EMPHASIS & FRONTING (90 Handcrafted Questions)
  // ==========================================
  ...EMPHASIS_EASY_30,
  ...EMPHASIS_MEDIUM_30,
  ...EMPHASIS_HARD_30,

  // ==========================================
  // 24. PUNCTUATION & CAPITALIZATION (90 Handcrafted Questions)
  // ==========================================
  ...PUNCTUATION_EASY_30,
  ...PUNCTUATION_MEDIUM_30,
  ...PUNCTUATION_HARD_30,

  // ==========================================
  // 25. COMMON GRAMMAR ERRORS (90 Handcrafted Questions)
  // ==========================================
  ...COMMON_ERRORS_EASY_30,
  ...COMMON_ERRORS_MEDIUM_30,
  ...COMMON_ERRORS_HARD_30,
];

export const ADDITIONAL_GRAMMAR_QUESTIONS: QuizQuestion[] = [
  ...INITIAL_ADDITIONAL_QUESTIONS,
  ...EXTRA_GRAMMAR_QUESTIONS,
];
