import React, { useState, useEffect } from 'react';
import { loadUserStats, saveUserStats, resetUserStats } from './utils/storage';
import { getSavedTheme, saveTheme, applyThemeToDocument, AppTheme } from './utils/theme';
import { UserStats, TenseId } from './types';
import { ALL_TENSES } from './data/tensesData';
import { Navbar } from './components/Navbar';
import { Dashboard } from './components/Dashboard';
import { ChecklistPage } from './components/ChecklistPage';
import { TenseLessonView } from './components/TenseLessonView';
import { PracticeStudio } from './components/PracticeStudio';
import { ErrorNotebook } from './components/ErrorNotebook';
import { playSound } from './utils/audio';

export function App() {
  const [userStats, setUserStats] = useState<UserStats>(() => loadUserStats());
  const [currentTheme, setCurrentTheme] = useState<AppTheme>(() => getSavedTheme());
  const [currentView, setCurrentView] = useState<'dashboard' | 'checklist' | 'lesson' | 'practice' | 'notebook'>('dashboard');
  const [activeTenseId, setActiveTenseId] = useState<TenseId>('present_simple');
  const [practiceInitialTense, setPracticeInitialTense] = useState<TenseId | null>(null);

  useEffect(() => {
    applyThemeToDocument(currentTheme);
  }, [currentTheme]);

  const handleThemeChange = (newTheme: AppTheme) => {
    setCurrentTheme(newTheme);
    saveTheme(newTheme);
  };

  const handleUpdateStats = (newStats: UserStats) => {
    setUserStats(newStats);
    saveUserStats(newStats);
  };

  const handleResetCourse = () => {
    const freshStats = resetUserStats();
    setUserStats(freshStats);
    setCurrentView('dashboard');
    setActiveTenseId('present_simple');
    setPracticeInitialTense(null);
    playSound('victory');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigate = (view: string, payload?: any) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (view === 'dashboard') {
      setCurrentView('dashboard');
    } else if (view === 'checklist') {
      setCurrentView('checklist');
    } else if (view === 'practice') {
      setPracticeInitialTense(payload?.tenseId || null);
      setCurrentView('practice');
    } else if (view === 'notebook') {
      setCurrentView('notebook');
    }
  };

  const handleSelectTense = (tenseId: TenseId) => {
    setActiveTenseId(tenseId);
    setCurrentView('lesson');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleStartPracticeForTense = (tenseId: TenseId) => {
    setPracticeInitialTense(tenseId);
    setCurrentView('practice');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const currentTenseInfo = ALL_TENSES.find(t => t.id === activeTenseId) || ALL_TENSES[0];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col selection:bg-indigo-500 selection:text-white antialiased transition-colors duration-200">
      {/* Sticky Minimal Navigation */}
      <Navbar
        currentView={currentView === 'lesson' ? 'dashboard' : currentView}
        onNavigate={handleNavigate}
        userStats={userStats}
        currentTheme={currentTheme}
        onThemeChange={handleThemeChange}
        onResetCourse={handleResetCourse}
        onUpdateStats={handleUpdateStats}
        onSelectTense={handleSelectTense}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {currentView === 'dashboard' && (
          <Dashboard
            userStats={userStats}
            onNavigate={handleNavigate}
            onSelectTense={handleSelectTense}
            onResetCourse={handleResetCourse}
            onUpdateStats={handleUpdateStats}
          />
        )}

        {currentView === 'checklist' && (
          <ChecklistPage
            userStats={userStats}
            onUpdateStats={handleUpdateStats}
            onSelectTense={handleSelectTense}
            onBackToDashboard={() => {
              setCurrentView('dashboard');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onResetCourse={handleResetCourse}
          />
        )}

        {currentView === 'lesson' && (
          <TenseLessonView
            tense={currentTenseInfo}
            userStats={userStats}
            onUpdateStats={handleUpdateStats}
            onBackToMap={() => {
              setCurrentView('dashboard');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onSelectTense={handleSelectTense}
            onStartPractice={handleStartPracticeForTense}
          />
        )}

        {currentView === 'practice' && (
          <PracticeStudio
            userStats={userStats}
            onUpdateStats={handleUpdateStats}
            initialTenseId={practiceInitialTense}
            onBackToMenu={() => {
              setCurrentView('dashboard');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {currentView === 'notebook' && (
          <ErrorNotebook
            userStats={userStats}
            onUpdateStats={handleUpdateStats}
            onBackToMenu={() => {
              setCurrentView('dashboard');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}
      </main>

      {/* Minimal Footer */}
      <footer className="border-t border-slate-200 bg-white py-8 text-center text-xs text-slate-500 space-y-1.5" dir="rtl">
        <div className="flex items-center justify-center gap-2 font-medium">
          <span className="font-bold text-slate-800">🕐 Tense Master</span>
          <span>—</span>
          <span>افهم الأزمنة الإنجليزية من خلال المعنى والخط الزمني</span>
        </div>
        <p className="text-[11px] text-slate-500">
          افهم → شاهد → جرّب → قارن → أتقن
        </p>
      </footer>
    </div>
  );
}

export default App;
