import React, { useState, useEffect, useRef } from 'react';
import { ALL_QUESTIONS } from '../data/questionsBank';
import { QuizQuestion, UserStats } from '../types';
import { playSound } from '../utils/audio';
import { recordAnswerResult } from '../utils/storage';
import confetti from 'canvas-confetti';
import { Zap, Timer, Flame, RotateCcw, Trophy } from 'lucide-react';

interface Rush60SecondsProps {
  userStats: UserStats;
  onUpdateStats: (newStats: UserStats) => void;
  onBackToMenu: () => void;
}

export const Rush60Seconds: React.FC<Rush60SecondsProps> = ({
  userStats,
  onUpdateStats,
  onBackToMenu,
}) => {
  const [timeLeft, setTimeLeft] = useState(60);
  const [isActive, setIsActive] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(1);
  const [correctCount, setCorrectCount] = useState(0);
  const [wrongCount, setWrongCount] = useState(0);
  const [isGameOver, setIsGameOver] = useState(false);
  const [questions] = useState<QuizQuestion[]>(() => {
    return [...ALL_QUESTIONS].sort(() => Math.random() - 0.5);
  });

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Timer countdown
  useEffect(() => {
    if (isActive && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft(t => {
          if (t <= 5 && t > 1) playSound('tick');
          if (t <= 1) {
            setIsActive(false);
            setIsGameOver(true);
            playSound('victory');
            try {
              confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
            } catch {}
            return 0;
          }
          return t - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive, timeLeft]);

  const handleStart = () => {
    playSound('click');
    setTimeLeft(60);
    setScore(0);
    setCombo(1);
    setCorrectCount(0);
    setWrongCount(0);
    setCurrentIndex(0);
    setIsGameOver(false);
    setIsActive(true);
  };

  const handleAnswer = (chosen: string) => {
    if (!isActive) return;
    const currentQ = questions[currentIndex % questions.length];
    const isCorrect = chosen.trim().toLowerCase() === currentQ.correctAnswer.trim().toLowerCase();

    if (isCorrect) {
      playSound('correct');
      const addedPoints = 10 * combo;
      setScore(s => s + addedPoints);
      setCorrectCount(c => c + 1);
      setCombo(c => Math.min(5, c + 1));
    } else {
      playSound('wrong');
      setWrongCount(w => w + 1);
      setCombo(1);
    }

    const { updatedStats } = recordAnswerResult(userStats, currentQ, chosen, isCorrect);
    onUpdateStats(updatedStats);

    setCurrentIndex(i => i + 1);
  };

  const currentQ = questions[currentIndex % questions.length];

  return (
    <div className="space-y-6 max-w-3xl mx-auto animate-fade-in" dir="rtl">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-amber-950 via-slate-900 to-yellow-950 border border-yellow-500/40 rounded-3xl p-6 md:p-8 shadow-2xl flex items-center justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-yellow-400 fill-current animate-bounce" />
            <h1 className="text-xl md:text-2xl font-black text-white">⚡ تحدي 60 ثانية (Speed Rush)</h1>
          </div>
          <p className="text-xs text-slate-300">أجب عن أكبر عدد من الأسئلة قبل نفاد الوقت!</p>
        </div>

        <button
          onClick={onBackToMenu}
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition-all"
        >
          خروج
        </button>
      </div>

      {/* Game Not Started */}
      {!isActive && !isGameOver && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-10 text-center space-y-6 shadow-2xl">
          <div className="w-20 h-20 bg-yellow-500/20 border-2 border-yellow-400 rounded-full flex items-center justify-center mx-auto text-4xl shadow-xl shadow-yellow-500/20">
            ⚡
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-black text-white">جاهز لسباق السرعة؟</h2>
            <p className="text-xs text-slate-300 max-w-md mx-auto">
              لديك دقيقة واحدة فقط. كل إجابة صحيحة متتالية تضاعف نقاطك حتى (x5)! أخطأت؟ يعود المضاعف إلى (x1).
            </p>
          </div>
          <button
            onClick={handleStart}
            className="px-8 py-4 bg-gradient-to-r from-yellow-500 to-amber-600 hover:from-yellow-400 hover:to-amber-500 text-slate-950 font-black text-sm rounded-2xl shadow-xl shadow-yellow-500/30 transition-all scale-105"
          >
            🚀 ابدأ الـ 60 ثانية الآن!
          </button>
        </div>
      )}

      {/* Active Game */}
      {isActive && currentQ && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl">
          {/* Stats Bar */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-2">
              <Timer className="w-5 h-5 text-yellow-400 animate-spin" />
              <span className={`text-2xl font-black font-english font-mono ${
                timeLeft <= 10 ? 'text-red-400 animate-ping' : 'text-yellow-400'
              }`}>
                {timeLeft}s
              </span>
            </div>

            <div className="flex items-center gap-4">
              <span className="text-xs font-bold text-amber-400 bg-amber-500/10 px-3 py-1 rounded-xl border border-amber-500/30 font-english">
                Combo: x{combo} 🔥
              </span>
              <span className="text-sm font-bold text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-xl border border-emerald-500/30 font-english">
                Score: {score}
              </span>
            </div>
          </div>

          {/* Time Progress Bar */}
          <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-yellow-500 to-red-500 transition-all duration-1000"
              style={{ width: `${(timeLeft / 60) * 100}%` }}
            />
          </div>

          {/* Question Text */}
          <div className="space-y-3">
            {currentQ.sentenceWithBlank && (
              <div className="bg-slate-950 rounded-2xl p-5 border border-slate-800 text-center" dir="ltr">
                <p className="text-lg md:text-xl font-bold text-white font-english">
                  {currentQ.sentenceWithBlank}
                </p>
              </div>
            )}
          </div>

          {/* Options */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {currentQ.options?.map((opt, idx) => (
              <button
                key={idx}
                onClick={() => handleAnswer(opt)}
                className="p-4 rounded-2xl bg-slate-950/80 hover:bg-yellow-500/20 border border-slate-800 hover:border-yellow-500/50 text-white font-english font-bold text-sm text-right transition-all"
              >
                {opt}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Game Over Screen */}
      {isGameOver && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 md:p-10 text-center space-y-6 shadow-2xl animate-fade-in">
          <Trophy className="w-16 h-16 text-yellow-400 mx-auto" />
          <div className="space-y-1">
            <h2 className="text-3xl font-black text-white">انتهى الوقت! 🎉</h2>
            <p className="text-slate-300 text-xs">أداء سريع وممتاز في تحدي الدقيقة!</p>
          </div>

          <div className="grid grid-cols-3 gap-3 max-w-md mx-auto">
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block">النقاط الكلية</span>
              <span className="text-2xl font-black text-yellow-400 font-english font-mono">{score}</span>
            </div>
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block">صحيحة</span>
              <span className="text-2xl font-black text-emerald-400 font-english font-mono">{correctCount}</span>
            </div>
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
              <span className="text-[11px] text-slate-400 block">خاطئة</span>
              <span className="text-2xl font-black text-rose-400 font-english font-mono">{wrongCount}</span>
            </div>
          </div>

          <div className="flex justify-center gap-3 pt-4">
            <button
              onClick={handleStart}
              className="px-6 py-3 bg-yellow-500 hover:bg-yellow-400 text-slate-950 font-bold text-xs rounded-2xl transition-all flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>إعادة التحدي</span>
            </button>
            <button
              onClick={onBackToMenu}
              className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-2xl transition-all"
            >
              العودة للقائمة
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
