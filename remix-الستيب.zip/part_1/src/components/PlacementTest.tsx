import React, { useState } from 'react';
import { ALL_QUESTIONS } from '../data/questionsBank';
import { QuizQuestion, UserStats, TenseId } from '../types';
import { playSound } from '../utils/audio';
import { ALL_TENSES } from '../data/tensesData';
import { Compass, CheckCircle2, ArrowRight, BookOpen, RotateCcw } from 'lucide-react';
import confetti from 'canvas-confetti';

interface PlacementTestProps {
  userStats: UserStats;
  onUpdateStats: (newStats: UserStats) => void;
  onFinishTest: () => void;
  onGoToTense: (tenseId: TenseId) => void;
}

export const PlacementTest: React.FC<PlacementTestProps> = ({
  userStats,
  onUpdateStats,
  onFinishTest,
  onGoToTense,
}) => {
  const [testQuestions] = useState<QuizQuestion[]>(() => {
    return [...ALL_QUESTIONS].slice(0, 10);
  });
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, { answer: string; isCorrect: boolean; tenseId: TenseId }>>({});
  const [selectedOpt, setSelectedOpt] = useState<string | null>(null);
  const [isTestDone, setIsTestDone] = useState(false);

  const currentQ = testQuestions[currentIndex];

  const handleSelect = (option: string) => {
    setSelectedOpt(option);
  };

  const handleNext = () => {
    if (!selectedOpt || !currentQ) return;
    playSound('click');

    const isCorrect = selectedOpt.trim().toLowerCase() === currentQ.correctAnswer.trim().toLowerCase();
    const updatedAnswers = {
      ...answers,
      [currentQ.id]: {
        answer: selectedOpt,
        isCorrect,
        tenseId: currentQ.tenseId,
      },
    };
    setAnswers(updatedAnswers);
    setSelectedOpt(null);

    if (currentIndex + 1 < testQuestions.length) {
      setCurrentIndex(i => i + 1);
    } else {
      // Finish
      setIsTestDone(true);
      playSound('victory');
      try {
        confetti({ particleCount: 120, spread: 80, origin: { y: 0.6 } });
      } catch {}

      // Calculate score & recommendations
      const answerList = Object.values(updatedAnswers) as { answer: string; isCorrect: boolean; tenseId: TenseId }[];
      const totalCorrect = answerList.filter(a => a.isCorrect).length;
      const scorePercent = Math.round((totalCorrect / testQuestions.length) * 100);

      // Find weak tenses
      const weakTenses: TenseId[] = [];
      answerList.forEach(item => {
        if (!item.isCorrect && !weakTenses.includes(item.tenseId)) {
          weakTenses.push(item.tenseId);
        }
      });

      const updatedUserStats: UserStats = {
        ...userStats,
        placementTaken: true,
        placementScore: scorePercent,
        suggestedFocusTenses: weakTenses.length > 0 ? weakTenses : ['present_perfect', 'past_perfect'],
        xp: userStats.xp + 100,
      };
      onUpdateStats(updatedUserStats);
    }
  };

  if (isTestDone) {
    const finalAnswerList = Object.values(answers) as { answer: string; isCorrect: boolean; tenseId: TenseId }[];
    const totalCorrect = finalAnswerList.filter(a => a.isCorrect).length;
    const scorePercent = Math.round((totalCorrect / testQuestions.length) * 100);
    const levelLabel =
      scorePercent >= 80 ? 'متقدم (Advanced) 🔥' : scorePercent >= 50 ? 'متوسط (Intermediate) 🟡' : 'مبتدئ (Beginner) 🟢';

    const weakTenses = finalAnswerList
      .filter(a => !a.isCorrect)
      .map(a => a.tenseId);

    return (
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 md:p-12 space-y-8 animate-fade-in shadow-2xl" dir="rtl">
        <div className="text-center space-y-3">
          <div className="w-20 h-20 bg-indigo-500/20 border-2 border-indigo-400 rounded-full flex items-center justify-center mx-auto text-4xl shadow-xl shadow-indigo-500/20">
            🎯
          </div>
          <h2 className="text-3xl font-black text-white">تقرير تحديد المستوى التشخيصي</h2>
          <p className="text-slate-300 text-sm">تم تحليل إجاباتك عبر مختلف العلاقات الزمنية بدقة</p>
        </div>

        {/* Level & Score Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-3xl mx-auto">
          <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 text-center">
            <span className="text-xs text-slate-400 block mb-1">المستوى المقترح</span>
            <span className="text-lg font-black text-indigo-400 font-bold">{levelLabel}</span>
          </div>
          <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 text-center">
            <span className="text-xs text-slate-400 block mb-1">الدرجة الكلية</span>
            <span className="text-2xl font-black text-emerald-400 font-english font-mono">{totalCorrect} / {testQuestions.length} ({scorePercent}%)</span>
          </div>
          <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 text-center">
            <span className="text-xs text-slate-400 block mb-1">مكافأة إتمام الاختبار</span>
            <span className="text-2xl font-black text-amber-400 font-english font-mono">+100 XP</span>
          </div>
        </div>

        {/* Suggested Learning Path */}
        <div className="bg-slate-950/80 border border-indigo-500/30 rounded-3xl p-6 space-y-4 max-w-3xl mx-auto">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-indigo-400" />
            <span>خطة الدراسة والتطوير المقترحة لك:</span>
          </h3>

          {weakTenses.length === 0 ? (
            <p className="text-xs text-emerald-300">
              ما شاء الله! لم ترتكب أي أخطاء في هذا الاختبار التشخيصي. يمكنك خوض تحديات الخبير و 60 ثانية!
            </p>
          ) : (
            <div className="space-y-3">
              <p className="text-xs text-slate-300">
                ننصحك بالتركيز ومراجعة هذه الأزمنة أولاً في قسم (اربطها في عقلك) وموسوعة الأزمنة:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {weakTenses.map(tId => {
                  const tenseInfo = ALL_TENSES.find(t => t.id === tId);
                  if (!tenseInfo) return null;
                  return (
                    <div
                      key={tId}
                      onClick={() => onGoToTense(tId)}
                      className="bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-indigo-500 rounded-2xl p-3.5 cursor-pointer flex items-center justify-between transition-all"
                    >
                      <div>
                        <span className="text-xs font-bold text-white block">{tenseInfo.nameAr}</span>
                        <span className="text-[10px] font-english text-indigo-400">{tenseInfo.nameEn}</span>
                      </div>
                      <span className="text-xs text-indigo-400 font-bold">دراسة ←</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        <div className="flex justify-center gap-4 pt-2">
          <button
            onClick={onFinishTest}
            className="px-8 py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl text-xs font-bold transition-all shadow-xl shadow-indigo-600/30"
          >
            الانتقال للوحة التحكم والتدريبات ←
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-3xl mx-auto animate-fade-in" dir="rtl">
      {/* Banner */}
      <div className="bg-gradient-to-r from-indigo-950 via-slate-900 to-purple-950 border border-indigo-500/40 rounded-3xl p-6 md:p-8 shadow-2xl flex items-center justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Compass className="w-5 h-5 text-indigo-400" />
            <h1 className="text-xl md:text-2xl font-black text-white">اختبار تحديد المستوى (Placement Test)</h1>
          </div>
          <p className="text-xs text-slate-300">10 أسئلة متنوعة لتشخيص نقاط قوتك وضعفك في الأزمنة</p>
        </div>

        <button
          onClick={onFinishTest}
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition-all"
        >
          تخطي
        </button>
      </div>

      {/* Test Question */}
      {currentQ && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <span className="text-xs font-bold text-indigo-400 font-mono">
              سؤال {currentIndex + 1} من {testQuestions.length}
            </span>
          </div>

          {currentQ.sentenceWithBlank && (
            <div className="bg-slate-950 rounded-2xl p-5 border border-slate-800 text-center" dir="ltr">
              <p className="text-lg md:text-xl font-bold text-white font-english">
                {currentQ.sentenceWithBlank}
              </p>
            </div>
          )}

          {/* Options */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {currentQ.options?.map((opt, idx) => (
              <button
                key={idx}
                onClick={() => handleSelect(opt)}
                className={`p-4 rounded-2xl border text-right font-english font-bold transition-all text-sm ${
                  selectedOpt === opt
                    ? 'bg-indigo-600 border-indigo-400 text-white shadow-md'
                    : 'bg-slate-950 hover:bg-slate-800 border-slate-800 text-slate-200'
                }`}
              >
                {opt}
              </button>
            ))}
          </div>

          <button
            onClick={handleNext}
            disabled={!selectedOpt}
            className="w-full py-3.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white rounded-2xl font-bold text-xs shadow-lg disabled:opacity-40 transition-all flex items-center justify-center gap-2"
          >
            <span>{currentIndex + 1 < testQuestions.length ? 'السؤال التالي ←' : 'إنهاء الاختبار وعرض التشخيص 🎯'}</span>
          </button>
        </div>
      )}
    </div>
  );
};
