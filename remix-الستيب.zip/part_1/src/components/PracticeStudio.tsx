import React, { useState } from 'react';
import { ALL_QUESTIONS } from '../data/questionsBank';
import { ALL_TENSES } from '../data/tensesData';
import { generatePracticeQuestions } from '../data/questionGenerator';
import { QuizQuestion, UserStats, TenseId } from '../types';
import { QuizEngine } from './QuizEngine';
import { playSound } from '../utils/audio';
import { Zap, Sparkles, Flame, CheckCircle2, ChevronRight, ShieldCheck } from 'lucide-react';

interface PracticeStudioProps {
  userStats: UserStats;
  onUpdateStats: (newStats: UserStats) => void;
  initialTenseId?: TenseId | null;
  onBackToMenu: () => void;
}

type PracticeLevel = 'easy' | 'medium' | 'hard' | 'gauntlet_12';

export const PracticeStudio: React.FC<PracticeStudioProps> = ({
  userStats,
  onUpdateStats,
  initialTenseId = null,
  onBackToMenu,
}) => {
  const [selectedLevel, setSelectedLevel] = useState<PracticeLevel>('easy');
  const [selectedTense, setSelectedTense] = useState<string>(initialTenseId || 'all');
  const [isPracticing, setIsPracticing] = useState(false);
  const [sessionQuestions, setSessionQuestions] = useState<QuizQuestion[]>([]);

  // Update selected tense if initialTenseId changes
  React.useEffect(() => {
    if (initialTenseId) {
      setSelectedTense(initialTenseId);
    }
  }, [initialTenseId]);

  const levelOptions: { id: PracticeLevel; label: string; desc: string; icon: string; count: number }[] = [
    {
      id: 'easy',
      label: 'مستوى سهل🌱 ',
      desc: '',
      icon: '',
      count: 50,
    },
    {
      id: 'medium',
      label: 'مستوى متوسط ⚖️',
      desc: '',
      icon: '',
      count: 50,
    },
    {
      id: 'hard',
      label: 'مستوى صعب 🧠',
      desc: '',
      icon: '',
      count: 50,
    },
    {
      id: 'gauntlet_12',
      label: '🔥 تحدي الأزمنة الـ12',
      desc: 'جولة شاملة مكونة من 50 سؤالاً متتالياً تغطي كافة الأزمنة الـ12.',
      icon: '👑',
      count: 50,
    },
  ];

  const handleStartSession = () => {
    playSound('click');

    const pool = generatePracticeQuestions(selectedLevel, selectedTense, 50);

    setSessionQuestions(pool);
    setIsPracticing(true);
  };

  if (isPracticing && sessionQuestions.length > 0) {
    const activeLevelMeta = levelOptions.find(l => l.id === selectedLevel);
    const tenseMeta = ALL_TENSES.find(t => t.id === selectedTense);

    return (
      <div className="space-y-6" dir="rtl">
        <div className="flex items-center justify-between">
          <button
            onClick={() => setIsPracticing(false)}
            className="flex items-center gap-1.5 text-xs text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-200 px-3.5 py-2 rounded-xl font-bold transition-colors shadow-2xs cursor-pointer"
          >
            <ChevronRight className="w-4 h-4" />
            <span>تغيير إعدادات التدريب</span>
          </button>

          <span className="text-xs text-indigo-700 font-mono font-bold bg-indigo-50 border border-indigo-100 px-3 py-1 rounded-xl">
            {activeLevelMeta?.label}
          </span>
        </div>

        <QuizEngine
          questions={sessionQuestions}
          userStats={userStats}
          onUpdateStats={onUpdateStats}
          titleAr={
            selectedLevel === 'gauntlet_12'
              ? '🔥 تحدي الأزمنة الـ12 الشامل'
              : `تدريب: ${tenseMeta ? tenseMeta.nameAr : 'جميع الأزمنة'}`
          }
          subtitleAr="أجب بناء على فهم المعنى والتسلسل الزمني للحدث"
          onFinish={() => setIsPracticing(false)}
        />
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-fade-in pb-12" dir="rtl">
      {/* Header */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 bg-indigo-50 border border-indigo-200 px-3.5 py-1 rounded-full text-indigo-700 text-xs font-bold font-mono shadow-2xs">
          <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
          <span>🧪 استوديو التدريب والاختبار</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900">
          تدرب واختبر فهمك
        </h1>
        <p className="text-sm text-slate-600 max-w-md mx-auto">
          اختر مستوى الصعوبة ونوع التحدي لتثبيت الفهم واكتشاف الفروق الزمنية الدقيقة.
        </p>
      </div>

      {/* ─── 1. Difficulty Level Selector ─── */}
      <div className="space-y-3">
        <label className="text-xs font-bold text-slate-500 uppercase font-mono block">
          1. اختر مستوى التحدي:
        </label>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {levelOptions.map(lvl => {
            const isSelected = selectedLevel === lvl.id;
            return (
              <button
                key={lvl.id}
                onClick={() => {
                  playSound('click');
                  setSelectedLevel(lvl.id);
                }}
                className={`text-right p-4 rounded-2xl border transition-all flex flex-col justify-between gap-2 cursor-pointer ${
                  isSelected
                    ? 'bg-indigo-50 border-indigo-600 text-slate-900 ring-2 ring-indigo-500/20 shadow-xs'
                    : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700 shadow-2xs'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <span className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    {lvl.icon ? <span>{lvl.icon}</span> : null}
                    <span>{lvl.label}</span>
                  </span>
                  <span className="text-[11px] text-slate-500 font-mono">
                    {lvl.count} أسئلة
                  </span>
                </div>
                {lvl.desc ? (
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {lvl.desc}
                  </p>
                ) : null}
              </button>
            );
          })}
        </div>
      </div>

      {/* ─── 2. Tense Scope Filter ─── */}
      {selectedLevel !== 'gauntlet_12' && (
        <div className="space-y-3">
          <label className="text-xs font-bold text-slate-500 uppercase font-mono block">
            2. نطاق الأزمنة المراد التدرب عليها:
          </label>

          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
            <select
              value={selectedTense}
              onChange={e => setSelectedTense(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 text-slate-900 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-indigo-500 font-medium cursor-pointer"
            >
              <option value="all">🌟 جميع الأزمنة والقواعد معاً (مختلط)</option>
              <optgroup label="⏰ الحاضر (Present Tenses)">
                {ALL_TENSES.filter(t => t.timeCategory === 'present').map(t => (
                  <option key={t.id} value={t.id}>
                    {t.nameAr} ({t.nameEn})
                  </option>
                ))}
              </optgroup>
              <optgroup label="⏰ الماضي (Past Tenses)">
                {ALL_TENSES.filter(t => t.timeCategory === 'past').map(t => (
                  <option key={t.id} value={t.id}>
                    {t.nameAr} ({t.nameEn})
                  </option>
                ))}
              </optgroup>
              <optgroup label="⏰ المستقبل (Future Tenses)">
                {ALL_TENSES.filter(t => t.timeCategory === 'future').map(t => (
                  <option key={t.id} value={t.id}>
                    {t.nameAr} ({t.nameEn})
                  </option>
                ))}
              </optgroup>
              <optgroup label="⚡ الأفعال الناقصة والمبني للمجهول والمعلوم">
                {ALL_TENSES.filter(t => t.categoryGroup === 'modals_and_voice').map(t => (
                  <option key={t.id} value={t.id}>
                    {t.nameAr} ({t.nameEn})
                  </option>
                ))}
              </optgroup>
              <optgroup label="🌲 الشرط والتمني والكلام المنقول والمباشر">
                {ALL_TENSES.filter(t => t.categoryGroup === 'conditionals_and_speech').map(t => (
                  <option key={t.id} value={t.id}>
                    {t.nameAr} ({t.nameEn})
                  </option>
                ))}
              </optgroup>
              <optgroup label="🔗 الروابط وحروف الجر وعبارات الوصل والاسم والظرف">
                {ALL_TENSES.filter(t => t.categoryGroup === 'clauses_and_connectors').map(t => (
                  <option key={t.id} value={t.id}>
                    {t.nameAr} ({t.nameEn})
                  </option>
                ))}
              </optgroup>
              <optgroup label="🛠️ المصادر والأفعال المركبة والسببية و Used to">
                {ALL_TENSES.filter(t => t.categoryGroup === 'verbs_and_structures').map(t => (
                  <option key={t.id} value={t.id}>
                    {t.nameAr} ({t.nameEn})
                  </option>
                ))}
              </optgroup>
              <optgroup label="📦 الأسماء والضمائر وأدوات التعريف والمحددات">
                {ALL_TENSES.filter(t => t.categoryGroup === 'nouns_and_pronouns').map(t => (
                  <option key={t.id} value={t.id}>
                    {t.nameAr} ({t.nameEn})
                  </option>
                ))}
              </optgroup>
              <optgroup label="⚖️ الصفات والظروف والمقارنة وتوافق الجملة والترتيب">
                {ALL_TENSES.filter(t => t.categoryGroup === 'modifiers_and_syntax').map(t => (
                  <option key={t.id} value={t.id}>
                    {t.nameAr} ({t.nameEn})
                  </option>
                ))}
              </optgroup>
              <optgroup label="🎓 الأساليب المتقدمة: القلب والتوكيد والترقيم والأخطاء الشائعة">
                {ALL_TENSES.filter(t => t.categoryGroup === 'advanced_grammar_mastery').map(t => (
                  <option key={t.id} value={t.id}>
                    {t.nameAr} ({t.nameEn})
                  </option>
                ))}
              </optgroup>
            </select>
          </div>
        </div>
      )}

      {/* ─── Main Start Button ─── */}
      <div className="pt-2">
        <button
          onClick={handleStartSession}
          className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-black text-base shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2.5 transition-all hover:scale-[1.01] cursor-pointer"
        >
          <Zap className="w-5 h-5 text-amber-300 fill-amber-300" />
          <span>ابدأ التدريب الآن ←</span>
        </button>
      </div>
    </div>
  );
};
