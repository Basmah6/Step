import React, { useState } from 'react';
import { DETECTIVE_CASES } from '../data/detectiveCases';
import { DetectiveCase, QuizQuestion, UserStats } from '../types';
import { playSound, speakEnglishText } from '../utils/audio';
import { recordAnswerResult } from '../utils/storage';
import { Search, Compass, FileText, CheckCircle, Volume2, ShieldAlert } from 'lucide-react';
import confetti from 'canvas-confetti';

interface TenseDetectiveProps {
  userStats: UserStats;
  onUpdateStats: (newStats: UserStats) => void;
  onBackToMenu: () => void;
}

export const TenseDetective: React.FC<TenseDetectiveProps> = ({
  userStats,
  onUpdateStats,
  onBackToMenu,
}) => {
  const [activeCaseIndex, setActiveCaseIndex] = useState(0);
  const [activeQuestionIndex, setActiveQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [caseSolved, setCaseSolved] = useState(false);

  const currentCase = DETECTIVE_CASES[activeCaseIndex] || DETECTIVE_CASES[0];
  const currentQ = currentCase.questions[activeQuestionIndex];

  const handleAnswerSubmit = (chosen: string) => {
    if (isAnswerSubmitted) return;

    setSelectedAnswer(chosen);
    const correct = chosen.trim().toLowerCase() === currentQ.correctAnswer.trim().toLowerCase();
    setIsCorrect(correct);
    setIsAnswerSubmitted(true);

    if (correct) {
      playSound('correct');
    } else {
      playSound('wrong');
    }

    const { updatedStats } = recordAnswerResult(userStats, currentQ, chosen, correct);
    onUpdateStats(updatedStats);
  };

  const handleNextStep = () => {
    playSound('click');
    setIsAnswerSubmitted(false);
    setSelectedAnswer(null);

    if (activeQuestionIndex + 1 < currentCase.questions.length) {
      setActiveQuestionIndex(i => i + 1);
    } else {
      setCaseSolved(true);
      playSound('victory');
      try {
        confetti({ particleCount: 120, spread: 80, origin: { y: 0.6 } });
      } catch {}
    }
  };

  return (
    <div className="space-y-8 animate-fade-in" dir="rtl">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-cyan-950 via-slate-900 to-indigo-950 border border-cyan-500/40 rounded-3xl p-6 md:p-8 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 bg-cyan-500/20 border border-cyan-500/40 px-3 py-1 rounded-full text-cyan-300 text-xs font-bold">
            <Search className="w-4 h-4 text-cyan-400" />
            <span>مكتب التحقيقات الجنائية الزمنية</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-black text-white">
            🔎 المحقق الزمني (Tense Detective)
          </h1>
          <p className="text-xs md:text-sm text-slate-300">
            حل ألغاز الجرائم والغموض عبر تحليل إفادات الشهود والتسلسل المنطقي للأزمنة!
          </p>
        </div>

        <button
          onClick={onBackToMenu}
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition-all"
        >
          العودة للرئيسية
        </button>
      </div>

      {/* Case Selector Tabs */}
      <div className="flex flex-wrap gap-3">
        {DETECTIVE_CASES.map((c, idx) => (
          <button
            key={c.id}
            onClick={() => {
              playSound('click');
              setActiveCaseIndex(idx);
              setActiveQuestionIndex(0);
              setIsAnswerSubmitted(false);
              setSelectedAnswer(null);
              setCaseSolved(false);
            }}
            className={`px-5 py-3 rounded-2xl text-xs font-bold transition-all border ${
              activeCaseIndex === idx
                ? 'bg-cyan-600 border-cyan-400 text-white shadow-lg shadow-cyan-600/30'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800'
            }`}
          >
            {c.titleAr}
          </button>
        ))}
      </div>

      {/* Active Case Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Side: Clues File */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-xl lg:col-span-1">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <FileText className="w-5 h-5 text-cyan-400" />
            <h2 className="text-base font-bold text-white">ملف القضية والأدلة</h2>
          </div>

          <div className="space-y-1">
            <span className="text-xs font-bold text-slate-400 block">المسرح:</span>
            <p className="text-xs text-slate-200">{currentCase.settingAr}</p>
          </div>

          <div className="space-y-1">
            <span className="text-xs font-bold text-slate-400 block">اللغز:</span>
            <p className="text-xs text-slate-300 leading-relaxed">{currentCase.mysteryAr}</p>
          </div>

          {/* Witness Statements List */}
          <div className="space-y-3 pt-3 border-t border-slate-800">
            <span className="text-xs font-bold text-amber-400 block">إفادات الشهود والتسلسل الزمني:</span>
            {currentCase.clues.map((clue, idx) => (
              <div key={idx} className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-3.5 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded-full font-mono">
                    {clue.timestampAr}
                  </span>
                  <button
                    onClick={() => speakEnglishText(clue.witnessStatementEn)}
                    className="p-1 text-slate-400 hover:text-white rounded"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                  </button>
                </div>
                <p className="text-xs font-bold text-white font-english" dir="ltr">{clue.witnessStatementEn}</p>
                <p className="text-[11px] text-slate-400">{clue.translationAr}</p>
                <p className="text-[10px] text-indigo-300 bg-indigo-500/10 p-1.5 rounded-lg">
                  💡 {clue.temporalClueAr}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Right Side: Detective Investigation Challenge */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 space-y-6 shadow-xl lg:col-span-2">
          {caseSolved ? (
            <div className="text-center py-10 space-y-4 animate-fade-in">
              <div className="w-16 h-16 bg-cyan-500/20 border-2 border-cyan-400 rounded-full flex items-center justify-center mx-auto text-3xl">
                🔎
              </div>
              <h2 className="text-2xl font-black text-white">تم إغلاق القضية بنجاح!</h2>
              <p className="text-sm text-slate-300 max-w-lg mx-auto leading-relaxed">
                {currentCase.conclusionAr}
              </p>
              <button
                onClick={() => {
                  playSound('click');
                  const nextIdx = (activeCaseIndex + 1) % DETECTIVE_CASES.length;
                  setActiveCaseIndex(nextIdx);
                  setActiveQuestionIndex(0);
                  setIsAnswerSubmitted(false);
                  setSelectedAnswer(null);
                  setCaseSolved(false);
                }}
                className="px-6 py-3 bg-cyan-600 hover:bg-cyan-500 text-white rounded-2xl text-xs font-bold transition-all shadow-lg"
              >
                الانتقال للقضية التالية ←
              </button>
            </div>
          ) : (
            currentQ && (
              <div className="space-y-6">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <span className="text-xs font-bold text-cyan-400 font-mono">
                    سؤال الاستجواب #{activeQuestionIndex + 1}
                  </span>
                </div>

                {currentQ.sentenceWithBlank && (
                  <div className="bg-slate-950 rounded-2xl p-5 border border-slate-800 text-center" dir="ltr">
                    <p className="text-lg md:text-xl font-bold text-white font-english">
                      {currentQ.sentenceWithBlank}
                    </p>
                  </div>
                )}

                {/* Options */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {currentQ.options?.map((opt, idx) => (
                    <button
                      key={idx}
                      disabled={isAnswerSubmitted}
                      onClick={() => handleAnswerSubmit(opt)}
                      className={`p-4 rounded-2xl border text-right font-english font-bold transition-all text-sm ${
                        isAnswerSubmitted
                          ? opt.trim().toLowerCase() === currentQ.correctAnswer.trim().toLowerCase()
                            ? 'bg-emerald-950 border-emerald-500 text-emerald-200'
                            : selectedAnswer === opt
                            ? 'bg-rose-950 border-rose-500 text-rose-200'
                            : 'opacity-40 bg-slate-950 border-slate-800 text-slate-500'
                          : 'bg-slate-950 hover:bg-slate-800 border-slate-800 text-slate-200'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>

                {/* Explanation on submit */}
                {isAnswerSubmitted && (
                  <div className="bg-slate-950 rounded-2xl p-4 border border-cyan-500/30 space-y-3 animate-fade-in">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-cyan-400">
                        {isCorrect ? 'استنتاج دقيق في محله! 👏' : 'استنتاج غير متطابق مع التوقيت!'}
                      </span>
                      <button
                        onClick={handleNextStep}
                        className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold"
                      >
                        متابعة التحقيق ←
                      </button>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {currentQ.explanation.whyCorrectAr}
                    </p>
                  </div>
                )}
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
};
