import React, { useState } from 'react';
import { UserStats, ErrorRecord } from '../types';
import { QuizEngine } from './QuizEngine';
import { playSound, speakEnglishText } from '../utils/audio';
import { ALL_TENSES } from '../data/tensesData';
import { BookMarked, RotateCcw, Volume2, Trash2, CheckCircle2, ChevronRight } from 'lucide-react';

interface ErrorNotebookProps {
  userStats: UserStats;
  onUpdateStats: (newStats: UserStats) => void;
  onBackToMenu: () => void;
}

export const ErrorNotebook: React.FC<ErrorNotebookProps> = ({
  userStats,
  onUpdateStats,
  onBackToMenu,
}) => {
  const [isRetryingErrors, setIsRetryingErrors] = useState(false);

  const errors = userStats.errorHistory || [];

  const handleClearErrors = () => {
    if (window.confirm('هل أنت متأكد من رغبتك في تفريغ دفتر الأخطاء؟')) {
      playSound('click');
      const updated: UserStats = {
        ...userStats,
        errorHistory: [],
      };
      onUpdateStats(updated);
    }
  };

  if (isRetryingErrors && errors.length > 0) {
    const errorQuestions = errors.map(e => e.question);
    return (
      <div className="space-y-6" dir="rtl">
        <div className="flex items-center justify-between">
          <button
            onClick={() => setIsRetryingErrors(false)}
            className="flex items-center gap-1.5 text-xs text-slate-700 hover:text-slate-900 bg-white border border-slate-200 px-3.5 py-1.5 rounded-xl font-bold cursor-pointer shadow-2xs"
          >
            <ChevronRight className="w-4 h-4" />
            <span>العودة للدفتر</span>
          </button>
          <span className="text-xs text-rose-700 font-bold font-mono">
            إعادة اختبار الأخطاء ({errorQuestions.length})
          </span>
        </div>

        <QuizEngine
          questions={errorQuestions}
          userStats={userStats}
          onUpdateStats={onUpdateStats}
          titleAr="إعادة التدرب على الأخطاء السابقة"
          subtitleAr="صحح المفاهيم وتأكد من استيعاب الفكرة بدقة"
          onFinish={() => setIsRetryingErrors(false)}
        />
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-fade-in pb-12" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <div className="inline-flex items-center gap-2 bg-rose-50 border border-rose-200 px-3 py-1 rounded-full text-rose-700 text-xs font-bold font-mono mb-2 shadow-2xs">
            <BookMarked className="w-3.5 h-3.5" />
            <span>دفتر المراجعة الذاتية</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900">
            دفتر أخطائي ({errors.length})
          </h1>
          <p className="text-xs text-slate-600 mt-1">
            الأسئلة التي أخطأت فيها تحفظ هنا تلقائياً لتتعلم من السبب وتتدرب عليها حتى الإتقان.
          </p>
        </div>

        {errors.length > 0 && (
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                playSound('click');
                setIsRetryingErrors(true);
              }}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-indigo-600/20 flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>إعادة التدرب على الكل</span>
            </button>

            <button
              onClick={handleClearErrors}
              className="p-2.5 bg-white hover:bg-rose-50 text-slate-500 hover:text-rose-600 border border-slate-200 rounded-xl transition-colors cursor-pointer shadow-2xs"
              title="تفريغ الدفتر"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Empty State */}
      {errors.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-3xl p-12 text-center space-y-4 shadow-xs">
          <div className="w-14 h-14 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-600 text-2xl flex items-center justify-center mx-auto">
            ✓
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-slate-900">دفتر الأخطاء فارغ تماماً! 🎉</h3>
            <p className="text-xs text-slate-600 max-w-sm mx-auto">
              أنت تسير بشكل رائع! كل خطأ ترتكبه في التدريبات سيتم تسجيله هنا لمراجعته.
            </p>
          </div>
        </div>
      ) : (
        /* Error List */
        <div className="space-y-4">
          {errors.map((err, idx) => {
            const tenseMeta = ALL_TENSES.find(t => t.id === err.question.tenseId);
            return (
              <div
                key={err.id || idx}
                className="bg-white border border-slate-200 rounded-2xl p-5 space-y-3 shadow-xs"
              >
                <div className="flex items-center justify-between text-xs border-b border-slate-100 pb-2.5">
                  <span className="font-bold text-indigo-700">
                    {tenseMeta ? tenseMeta.nameAr : err.question.tenseId}
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {new Date(err.timestamp).toLocaleDateString('ar-EG')}
                  </span>
                </div>

                {/* Sentence */}
                {err.question.sentenceWithBlank && (
                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 flex items-center justify-between gap-3" dir="ltr">
                    <p className="text-sm font-bold text-slate-900 font-english text-left">
                      {err.question.sentenceWithBlank}
                    </p>
                    <button
                      onClick={() => {
                        playSound('click');
                        speakEnglishText(err.question.sentenceWithBlank!.replace('___', 'blank'));
                      }}
                      className="text-slate-500 hover:text-slate-900 cursor-pointer"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                  </div>
                )}

                {/* Answers Diff */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="bg-rose-50 border border-rose-200 p-2.5 rounded-xl text-rose-800">
                    <span className="font-bold ml-1">❌ إجابتك:</span>
                    <span className="font-english font-bold text-rose-950">{err.userAnswer}</span>
                  </div>
                  <div className="bg-emerald-50 border border-emerald-200 p-2.5 rounded-xl text-emerald-800">
                    <span className="font-bold ml-1">✅ الصحيح:</span>
                    <span className="font-english font-bold text-emerald-950">{err.question.correctAnswer}</span>
                  </div>
                </div>

                {/* Reason */}
                <p className="text-xs text-slate-700 bg-slate-50 p-3 rounded-xl border border-slate-200 leading-relaxed">
                  💡 <strong className="text-indigo-800 ml-1">السبب:</strong>
                  {err.question.explanation.whyCorrectAr}
                </p>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
