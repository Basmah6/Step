import React, { useState } from 'react';
import { ALL_QUESTIONS } from '../data/questionsBank';
import { QuizQuestion, UserStats } from '../types';
import { playSound } from '../utils/audio';
import { recordAnswerResult } from '../utils/storage';
import confetti from 'canvas-confetti';
import { Swords, Shield, Heart, Zap, RotateCcw, Award } from 'lucide-react';

interface TenseBattleProps {
  userStats: UserStats;
  onUpdateStats: (newStats: UserStats) => void;
  onBackToMenu: () => void;
}

export const TenseBattle: React.FC<TenseBattleProps> = ({
  userStats,
  onUpdateStats,
  onBackToMenu,
}) => {
  const [playerHp, setPlayerHp] = useState(100);
  const [bossHp, setBossHp] = useState(100);
  const [currentRound, setCurrentRound] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [battleLogs, setBattleLogs] = useState<string[]>([
    '⚔️ دخلت ساحة معركة الأزمنة ضد العملاق "Chronos Titan"! أجب بدقة لتوجه ضربات قاضية!',
  ]);
  const [battleFinished, setBattleFinished] = useState<'won' | 'lost' | null>(null);

  // Shuffle questions for battle
  const [battleQuestions] = useState<QuizQuestion[]>(() => {
    return [...ALL_QUESTIONS].sort(() => Math.random() - 0.5);
  });

  const currentQ = battleQuestions[currentRound % battleQuestions.length];

  const handleAttack = (chosenOption: string) => {
    if (battleFinished || selectedAnswer !== null) return;

    setSelectedAnswer(chosenOption);
    const isCorrect = chosenOption.trim().toLowerCase() === currentQ.correctAnswer.trim().toLowerCase();

    if (isCorrect) {
      playSound('battle_hit');
      const damage = Math.floor(Math.random() * 15) + 25; // 25-40 damage
      const newBossHp = Math.max(0, bossHp - damage);
      setBossHp(newBossHp);

      const log = `💥 ضربة قوية! أجبت بشكل صحيح وسببت ${damage} ضرر للعملاق!`;
      setBattleLogs(prev => [log, ...prev.slice(0, 4)]);

      if (newBossHp <= 0) {
        setBattleFinished('won');
        playSound('victory');
        try {
          confetti({ particleCount: 150, spread: 90, origin: { y: 0.5 } });
        } catch {}
      }
    } else {
      playSound('wrong');
      const bossDamage = Math.floor(Math.random() * 10) + 20; // 20-30 damage
      const newPlayerHp = Math.max(0, playerHp - bossDamage);
      setPlayerHp(newPlayerHp);

      const log = `🛡️ إجابة غير دقيقة! هجم العملاق وسبب لك ${bossDamage} ضرر!`;
      setBattleLogs(prev => [log, ...prev.slice(0, 4)]);

      if (newPlayerHp <= 0) {
        setBattleFinished('lost');
      }
    }

    const { updatedStats } = recordAnswerResult(userStats, currentQ, chosenOption, isCorrect);
    onUpdateStats(updatedStats);

    setTimeout(() => {
      setSelectedAnswer(null);
      if (playerHp > 0 && bossHp > 0) {
        setCurrentRound(r => r + 1);
      }
    }, 1400);
  };

  const handleRestart = () => {
    setPlayerHp(100);
    setBossHp(100);
    setCurrentRound(0);
    setSelectedAnswer(null);
    setBattleFinished(null);
    setBattleLogs(['⚔️ بدأت معركة جديدة! استعد للاشتباك النحوي!']);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto animate-fade-in" dir="rtl">
      {/* Arena Header */}
      <div className="relative overflow-hidden bg-gradient-to-r from-red-950 via-slate-900 to-indigo-950 border border-red-500/30 rounded-3xl p-6 md:p-8 shadow-2xl">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-red-400">
              <Swords className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-black text-white">⚔️ معركة الأزمنة (Tense Battle)</h1>
              <p className="text-xs text-slate-300">اهزم حارس الزمن عبر إتقان التراكيب والعلاقات الزمنية</p>
            </div>
          </div>
          <button
            onClick={onBackToMenu}
            className="px-4 py-2 bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition-all"
          >
            الخروج من الساحة
          </button>
        </div>

        {/* Health Bars Comparison */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Player HP */}
          <div className="bg-slate-950/80 border border-emerald-500/30 rounded-2xl p-4 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-emerald-400">
              <span className="flex items-center gap-1">
                <Heart className="w-4 h-4 fill-current text-emerald-400" />
                <span>أنت (Tense Master)</span>
              </span>
              <span className="font-english font-mono">{playerHp} / 100 HP</span>
            </div>
            <div className="w-full h-3 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-300 rounded-full"
                style={{ width: `${playerHp}%` }}
              />
            </div>
          </div>

          {/* Boss HP */}
          <div className="bg-slate-950/80 border border-red-500/30 rounded-2xl p-4 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-red-400">
              <span className="flex items-center gap-1">
                <Shield className="w-4 h-4 fill-current text-red-400" />
                <span>العملاق (Chronos Titan)</span>
              </span>
              <span className="font-english font-mono">{bossHp} / 100 HP</span>
            </div>
            <div className="w-full h-3 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-red-600 to-orange-500 transition-all duration-300 rounded-full"
                style={{ width: `${bossHp}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Battle Log ticker */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3 text-xs text-slate-300 space-y-1 font-mono">
        {battleLogs.slice(0, 2).map((log, i) => (
          <div key={i} className="flex items-center gap-2">
            <span className="text-amber-400 font-bold">►</span>
            <span>{log}</span>
          </div>
        ))}
      </div>

      {/* Battle Arena Question or Victory/Defeat */}
      {battleFinished ? (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center space-y-6 animate-fade-in shadow-2xl">
          <div className="text-6xl mb-2">
            {battleFinished === 'won' ? '👑' : '💀'}
          </div>
          <h2 className="text-3xl font-black text-white">
            {battleFinished === 'won' ? 'نصر ساحق! لقد هزمت عملاق الأزمنة!' : 'سقطت في المعركة! حظاً أوفر في الجولة القادمة'}
          </h2>
          <p className="text-sm text-slate-300 max-w-md mx-auto">
            {battleFinished === 'won'
              ? 'أثبتّ تمكنك الكامل من العلاقات الزمنية وسرعة البديهة في ساحة المواجهة.'
              : 'راجع العلاقات الزمنية في قسم (اربطها في عقلك) ثم عاود التحدي!'}
          </p>
          <div className="flex justify-center gap-4 pt-2">
            <button
              onClick={handleRestart}
              className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl text-xs font-bold transition-all shadow-lg flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>خوض معركة جديدة</span>
            </button>
            <button
              onClick={onBackToMenu}
              className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-2xl text-xs font-bold transition-all"
            >
              العودة للقائمة
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 space-y-6 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <span className="text-xs font-bold text-amber-400 font-mono">الجولة #{currentRound + 1}</span>
          </div>

          {currentQ.sentenceWithBlank && (
            <div className="bg-slate-950 rounded-2xl p-5 border border-slate-800 text-center" dir="ltr">
              <p className="text-lg md:text-xl font-black text-white font-english">
                {currentQ.sentenceWithBlank}
              </p>
            </div>
          )}

          {/* Attack Options */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {currentQ.options?.map((option, idx) => (
              <button
                key={idx}
                disabled={selectedAnswer !== null}
                onClick={() => handleAttack(option)}
                className={`p-4 rounded-2xl border text-right font-english font-bold transition-all text-sm flex items-center justify-between ${
                  selectedAnswer === option
                    ? option.trim().toLowerCase() === currentQ.correctAnswer.trim().toLowerCase()
                      ? 'bg-emerald-950 border-emerald-500 text-emerald-200'
                      : 'bg-rose-950 border-rose-500 text-rose-200'
                    : 'bg-slate-950/90 hover:bg-indigo-950/50 border-slate-800 hover:border-indigo-500/50 text-slate-200'
                }`}
              >
                <span>{option}</span>
                <Zap className="w-4 h-4 text-indigo-400" />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
