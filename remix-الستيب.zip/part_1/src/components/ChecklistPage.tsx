import React, { useState } from 'react';
import { UserStats, TenseId, TenseInfo } from '../types';
import { ALL_TENSES } from '../data/tensesData';
import { playSound } from '../utils/audio';
import {
  Search,
  Check,
  RotateCcw,
  BookOpen,
  Sparkles,
  CheckCircle2,
  Filter,
  ArrowLeft,
  X,
  Layers,
  GraduationCap,
} from 'lucide-react';

interface ChecklistPageProps {
  userStats: UserStats;
  onUpdateStats: (newStats: UserStats) => void;
  onSelectTense: (tenseId: TenseId) => void;
  onBackToDashboard: () => void;
  onResetCourse: () => void;
}

export const ChecklistPage: React.FC<ChecklistPageProps> = ({
  userStats,
  onUpdateStats,
  onSelectTense,
  onBackToDashboard,
  onResetCourse,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'completed' | 'pending'>('all');
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const totalCount = ALL_TENSES.length;
  const masteryData = userStats.tenseMastery || {};
  
  const masteredCount = ALL_TENSES.filter(t => masteryData[t.id]?.mastered).length;
  const progressPercent = Math.round((masteredCount / totalCount) * 100);

  // Grouping categories
  const categories = [
    { id: 'all', label: 'الكل (55)' },
    { id: '12_tenses', label: 'الأزمنة الـ12 الأساسية' },
    { id: 'passive', label: 'المبني للمجهول (Passive)' },
    { id: 'conditionals', label: 'الجمل الشرطية (Conditionals)' },
    { id: 'modals', label: 'الأفعال الناقصة (Modals)' },
    { id: 'reported_speech', label: 'الكلام المنقول (Reported)' },
    { id: 'gerund_infinitive', label: 'المصدر واسم الفاعل (Gerund)' },
    { id: 'comparison', label: 'المقارنة والتفضيل' },
    { id: 'clauses_connectors', label: 'أدوات الربط والوصل' },
    { id: 'advanced_structures', label: 'قواعد متقدمة أخرى' },
  ];

  const getTenseCategory = (tense: TenseInfo): string => {
    const id = tense.id.toLowerCase();
    const name = (tense.nameEn + ' ' + tense.nameAr).toLowerCase();
    
    // Check 12 primary tenses
    if (
      [
        'present_simple', 'present_continuous', 'present_perfect', 'present_perfect_continuous',
        'past_simple', 'past_continuous', 'past_perfect', 'past_perfect_continuous',
        'future_simple', 'future_continuous', 'future_perfect', 'future_perfect_continuous'
      ].includes(tense.id)
    ) {
      return '12_tenses';
    }

    if (id.includes('passive') || name.includes('مجهول') || name.includes('passive')) return 'passive';
    if (id.includes('condition') || id.includes('wish') || name.includes('شرط') || name.includes('تمني')) return 'conditionals';
    if (id.includes('modal') || name.includes('ناقصة') || name.includes('modal') || id.includes('used_to')) return 'modals';
    if (id.includes('reported') || id.includes('indirect') || name.includes('منقول') || name.includes('غير مباشر')) return 'reported_speech';
    if (id.includes('gerund') || id.includes('infinitive') || name.includes('مصدر') || name.includes('gerund')) return 'gerund_infinitive';
    if (id.includes('comparative') || id.includes('superlative') || name.includes('مقارنة') || name.includes('تفضيل')) return 'comparison';
    if (id.includes('clause') || id.includes('conjunction') || id.includes('transition') || name.includes('ربط') || name.includes('وصل')) return 'clauses_connectors';
    
    return 'advanced_structures';
  };

  const filteredTenses = ALL_TENSES.filter(tense => {
    const isMastered = !!masteryData[tense.id]?.mastered;

    // Status filter
    if (statusFilter === 'completed' && !isMastered) return false;
    if (statusFilter === 'pending' && isMastered) return false;

    // Category filter
    if (categoryFilter !== 'all') {
      const cat = getTenseCategory(tense);
      if (cat !== categoryFilter) return false;
    }

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchNameAr = tense.nameAr.toLowerCase().includes(q);
      const matchNameEn = tense.nameEn.toLowerCase().includes(q);
      const matchSummary = (tense.shortSummaryAr || '').toLowerCase().includes(q);
      return matchNameAr || matchNameEn || matchSummary;
    }

    return true;
  });

  const handleToggleTense = (tenseId: TenseId) => {
    const isCurrentlyMastered = !!masteryData[tenseId]?.mastered;
    const nextMastered = !isCurrentlyMastered;

    if (nextMastered) {
      playSound('correct');
    } else {
      playSound('click');
    }

    const currentTenseRecord = masteryData[tenseId] || { attempted: 0, correct: 0, mastered: false };

    const updatedMastery = {
      ...masteryData,
      [tenseId]: {
        ...currentTenseRecord,
        mastered: nextMastered,
        attempted: nextMastered ? Math.max(1, currentTenseRecord.attempted || 1) : currentTenseRecord.attempted,
        correct: nextMastered ? Math.max(1, currentTenseRecord.correct || 1) : currentTenseRecord.correct,
      },
    };

    const newStats: UserStats = {
      ...userStats,
      tenseMastery: updatedMastery,
    };

    onUpdateStats(newStats);
  };

  const handleMarkAllVisible = (markAsCompleted: boolean) => {
    playSound(markAsCompleted ? 'victory' : 'click');
    const updatedMastery = { ...masteryData };

    filteredTenses.forEach(tense => {
      const current = updatedMastery[tense.id] || { attempted: 0, correct: 0, mastered: false };
      updatedMastery[tense.id] = {
        ...current,
        mastered: markAsCompleted,
        attempted: markAsCompleted ? Math.max(1, current.attempted || 1) : current.attempted,
        correct: markAsCompleted ? Math.max(1, current.correct || 1) : current.correct,
      };
    });

    const newStats: UserStats = {
      ...userStats,
      tenseMastery: updatedMastery,
    };

    onUpdateStats(newStats);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 sm:space-y-8 animate-fade-in pb-12" dir="rtl">
      {/* Top Header & Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              playSound('click');
              onBackToDashboard();
            }}
            className="p-2.5 rounded-2xl bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 hover:text-slate-900 transition-all shadow-2xs cursor-pointer flex items-center gap-1.5"
            title="العودة لخريطة الأزمنة"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-xs font-bold">الرئيسية</span>
          </button>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                قائمة تدقيق القواعد والأزمنة
              </h1>
              <span className="bg-indigo-100 text-indigo-800 text-xs font-bold px-2.5 py-0.5 rounded-full font-mono">
                {masteredCount}/{totalCount}
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              ضع علامة صح (✓) أمام كل قاعدة أو زمن أتممته لتحديث نسبة تقدمك الكلية
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={() => {
              playSound('click');
              setShowResetConfirm(true);
            }}
            className="px-3.5 py-2 rounded-2xl bg-white hover:bg-rose-50/70 border border-slate-200 hover:border-rose-200 text-slate-600 hover:text-rose-600 text-xs font-bold transition-all shadow-2xs cursor-pointer flex items-center gap-1.5"
            title="إعادة بدء الدورة من الصفر"
          >
            <RotateCcw className="w-3.5 h-3.5 shrink-0" />
            <span>إعادة بدء الدورة</span>
          </button>
        </div>
      </div>

      {/* Hero Progress Banner */}
      <section className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-indigo-600 font-bold text-xs font-mono">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>معدل إتقان الدورة الشاملة</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900">
              أنجزت <span className="text-indigo-600">{masteredCount}</span> من أصل <span className="text-slate-800">{totalCount}</span> قاعدة وزمن ({progressPercent}%)
            </h2>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-center px-4 py-2 bg-emerald-50 border border-emerald-100 rounded-2xl">
              <div className="text-lg font-black text-emerald-700 font-mono">{masteredCount}</div>
              <div className="text-[10px] text-emerald-600 font-bold">مكتملة ✓</div>
            </div>
            <div className="text-center px-4 py-2 bg-amber-50 border border-amber-100 rounded-2xl">
              <div className="text-lg font-black text-amber-700 font-mono">{totalCount - masteredCount}</div>
              <div className="text-[10px] text-amber-600 font-bold">متبقية ⏳</div>
            </div>
          </div>
        </div>

        {/* Large Progress Track */}
        <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden border border-slate-200/80">
          <div
            className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-500 rounded-full transition-all duration-500"
            style={{ width: `${Math.max(progressPercent, 0)}%` }}
          />
        </div>
      </section>

      {/* Filter and Search Bar */}
      <section className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="ابحث عن أي قاعدة أو زمن (مثال: المضارع المستمر، Passive، Conditionals، Modals...)"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-4 pr-10 py-2.5 bg-slate-50/60 border border-slate-200 rounded-2xl text-xs sm:text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none focus:border-indigo-500 focus:bg-white transition-all shadow-2xs font-medium"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Status Filter Tabs */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-2xl border border-slate-200 shrink-0">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                statusFilter === 'all'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              الكل ({totalCount})
            </button>
            <button
              onClick={() => setStatusFilter('completed')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                statusFilter === 'completed'
                  ? 'bg-emerald-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Check className="w-3.5 h-3.5" />
              <span>المكتملة ({masteredCount})</span>
            </button>
            <button
              onClick={() => setStatusFilter('pending')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                statusFilter === 'pending'
                  ? 'bg-amber-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              المتبقية ({totalCount - masteredCount})
            </button>
          </div>
        </div>

        {/* Categories Scrollable Filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto custom-h-scrollbar pb-1 text-xs">
          <span className="text-[11px] font-bold text-slate-400 shrink-0 flex items-center gap-1 pr-1">
            <Filter className="w-3.5 h-3.5" />
            <span>الأقسام:</span>
          </span>
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setCategoryFilter(cat.id)}
              className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition-all shrink-0 cursor-pointer ${
                categoryFilter === cat.id
                  ? 'bg-indigo-600 text-white font-bold shadow-xs'
                  : 'bg-slate-50 border border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Quick Batch Actions */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
          <span className="text-slate-500 font-medium">
            يتم عرض <strong className="text-slate-900 font-bold">{filteredTenses.length}</strong> من أصل {totalCount} قاعدة
          </span>
          <div className="flex items-center gap-3">
            <button
              onClick={() => handleMarkAllVisible(true)}
              className="text-indigo-600 hover:text-indigo-800 font-bold hover:underline cursor-pointer flex items-center gap-1"
            >
              <Check className="w-3.5 h-3.5" />
              <span>تحديد المعروض كمكتمل</span>
            </button>
            <span className="text-slate-300">|</span>
            <button
              onClick={() => handleMarkAllVisible(false)}
              className="text-slate-500 hover:text-rose-600 font-bold hover:underline cursor-pointer"
            >
              إلغاء تحديد المعروض
            </button>
          </div>
        </div>
      </section>

      {/* Grid of Checklist Rule Cards */}
      {filteredTenses.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-3xl p-12 text-center text-slate-400 space-y-3 shadow-xs">
          <Search className="w-10 h-10 mx-auto text-slate-300" />
          <h3 className="text-base font-bold text-slate-700">لم يتم العثور على قواعد مطابقة لبحثك</h3>
          <p className="text-xs text-slate-500">جرب كتابة كلمات بحث أخرى أو تغيير خيارات التصفية بالأعلى</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {filteredTenses.map((tense) => {
            const isMastered = !!masteryData[tense.id]?.mastered;

            return (
              <div
                key={tense.id}
                className={`group p-4 sm:p-5 rounded-3xl border transition-all flex items-center justify-between gap-4 select-none ${
                  isMastered
                    ? 'bg-emerald-50/40 border-emerald-200/90 shadow-2xs hover:shadow-xs'
                    : 'bg-white hover:bg-slate-50/80 border-slate-200 shadow-2xs hover:shadow-xs'
                }`}
              >
                {/* Interactive Checkbox & Details */}
                <div
                  onClick={() => handleToggleTense(tense.id)}
                  className="flex items-center gap-3.5 min-w-0 flex-1 cursor-pointer"
                >
                  {/* Checkbox Icon */}
                  <button
                    type="button"
                    className={`w-7 h-7 rounded-xl flex items-center justify-center transition-all shrink-0 cursor-pointer ${
                      isMastered
                        ? 'bg-emerald-600 text-white shadow-xs scale-105'
                        : 'bg-white border-2 border-slate-300 text-transparent hover:border-indigo-400'
                    }`}
                    title={isMastered ? 'تم إنجازها (اضغط لإلغاء التحديد)' : 'اضغط للتحديد كمكتمل'}
                  >
                    <Check className={`w-4 h-4 stroke-[3] ${isMastered ? 'opacity-100' : 'opacity-0'}`} />
                  </button>

                  {/* Tense Names & Details */}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3
                        className={`text-sm sm:text-base font-bold truncate transition-colors ${
                          isMastered ? 'text-emerald-950 line-through decoration-emerald-500/50' : 'text-slate-900'
                        }`}
                      >
                        {tense.nameAr}
                      </h3>
                      {isMastered && (
                        <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-md font-mono">
                          مكتمل ✓
                        </span>
                      )}
                    </div>
                    <p className="text-xs font-english text-indigo-600 font-mono mt-0.5 truncate font-medium">
                      {tense.nameEn}
                    </p>
                    {tense.shortSummaryAr && (
                      <p className="text-xs text-slate-500 line-clamp-1 mt-1 font-medium">
                        {tense.shortSummaryAr}
                      </p>
                    )}
                  </div>
                </div>

                {/* Lesson Navigation Button */}
                <button
                  onClick={() => {
                    playSound('click');
                    onSelectTense(tense.id);
                  }}
                  className="px-3 py-2 rounded-xl text-xs font-bold bg-slate-100 hover:bg-indigo-600 hover:text-white text-slate-700 transition-all shrink-0 flex items-center gap-1.5 cursor-pointer shadow-2xs"
                  title="الانتقال لشرح وتدريبات هذه القاعدة"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">عرض الدرس</span>
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* Reset Confirmation Modal */}
      {showResetConfirm && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in"
          dir="rtl"
          onClick={() => setShowResetConfirm(false)}
        >
          <div
            className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl space-y-4 animate-scale-in m-auto"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-rose-100 flex items-center justify-center text-rose-600 shrink-0">
                <RotateCcw className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-black text-slate-900">إعادة بدء الدورة من الصفر؟</h3>
                <p className="text-xs text-slate-500">سيتم تصفير كل تقدمك والبدء من البداية</p>
              </div>
            </div>

            <div className="bg-rose-50/70 border border-rose-200/80 rounded-2xl p-3.5 text-xs text-rose-800 space-y-1.5 leading-relaxed">
              <p className="font-bold flex items-center gap-1.5">
                <span>⚠️</span>
                <span>سيتم تصفير ما يلي:</span>
              </p>
              <ul className="list-disc list-inside space-y-0.5 text-[11px] text-rose-700 pr-1">
                <li>نسبة إتقان جميع الأزمنة الـ12 والقواعد (0%).</li>
                <li>سجل دفتر الأخطاء وإحصائيات الأسئلة المحلولة.</li>
                <li>إعادة ضبط السلسلة اليومية ونقاط الخبرة.</li>
              </ul>
            </div>

            <div className="flex items-center gap-2.5 pt-1">
              <button
                onClick={() => {
                  onResetCourse();
                  setShowResetConfirm(false);
                }}
                className="flex-1 py-2.5 sm:py-3 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl sm:rounded-2xl text-xs sm:text-sm shadow-md shadow-rose-600/25 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                <span>نعم، أعد البدء من الصفر</span>
              </button>

              <button
                onClick={() => setShowResetConfirm(false)}
                className="px-4 sm:px-5 py-2.5 sm:py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl sm:rounded-2xl text-xs sm:text-sm transition-colors cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
