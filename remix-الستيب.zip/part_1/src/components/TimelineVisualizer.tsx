import React from 'react';
import { TimelineData } from '../types';

interface TimelineVisualizerProps {
  timeline: TimelineData;
  className?: string;
  compact?: boolean;
}

export const TimelineVisualizer: React.FC<TimelineVisualizerProps> = ({
  timeline,
  className = '',
  compact = false,
}) => {
  const { eventMarker, eventPosition, eventEndPosition, referencePoint, labelAr, temporalMeaningAr } = timeline;

  return (
    <div className={`w-full bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 shadow-xs ${className}`} dir="rtl">
      {/* Header */}
      {!compact && (
        <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-indigo-600 animate-pulse" />
            <span className="text-xs font-bold text-indigo-700 font-mono">الخط الزمني (Timeline)</span>
          </div>
          <span className="text-xs text-slate-700 bg-slate-100 px-3 py-1 rounded-full border border-slate-200 font-medium">
            {labelAr}
          </span>
        </div>
      )}

      {/* Main Visual Stage */}
      <div className="relative w-full h-24 sm:h-28 bg-slate-50 rounded-xl p-3 sm:p-4 border border-slate-200 overflow-hidden flex flex-col justify-between" dir="ltr">
        {/* Three Zones Background */}
        <div className="absolute inset-0 grid grid-cols-3 pointer-events-none opacity-40">
          <div className="border-r border-sky-300 bg-sky-50/50" />
          <div className="border-r border-amber-300 bg-amber-50/50" />
          <div className="bg-rose-50/50" />
        </div>

        {/* Zone Labels (Top) */}
        <div className="relative z-10 flex justify-between text-[11px] sm:text-xs font-bold select-none px-1">
          <div className="flex items-center gap-1.5 text-sky-800">
            <span className="w-1.5 h-1.5 rounded-full bg-sky-600" />
            <span>PAST (الماضي)</span>
          </div>
          <div className="flex items-center gap-1.5 text-amber-900 bg-amber-100 px-2 py-0.5 rounded border border-amber-300">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-600 animate-ping" />
            <span>NOW (الآن)</span>
          </div>
          <div className="flex items-center gap-1.5 text-rose-800">
            <span>FUTURE (المستقبل)</span>
            <span className="w-1.5 h-1.5 rounded-full bg-rose-600" />
          </div>
        </div>

        {/* Central Axis Line */}
        <div className="relative w-full my-auto px-2">
          {/* Track Bar */}
          <div className="w-full h-1.5 bg-gradient-to-r from-sky-400 via-amber-400 to-rose-400 rounded-full" />

          {/* Center NOW Marker */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center z-10">
            <div className="w-3.5 h-3.5 bg-amber-500 rounded-full border-2 border-white shadow-md" />
          </div>

          {/* Reference Marker if present (e.g. for past perfect or future perfect) */}
          {referencePoint !== undefined && (
            <div
              className="absolute top-1/2 -translate-y-1/2 flex flex-col items-center z-10"
              style={{ left: `${referencePoint}%` }}
            >
              <div className="w-3 h-3 border-2 border-dashed border-amber-600 rounded-full bg-white" />
              <span className="text-[8px] text-amber-900 font-mono mt-1 bg-amber-50 px-1 rounded border border-amber-200">
                نقطة مرجعية
              </span>
            </div>
          )}

          {/* Duration Range Event */}
          {eventMarker === 'duration' && eventEndPosition && (
            <div
              className="absolute top-1/2 -translate-y-1/2 h-3 bg-gradient-to-r from-cyan-500 to-indigo-600 rounded-full shadow-md shadow-cyan-500/20 animate-pulse border border-cyan-300 z-20"
              style={{
                left: `${eventPosition}%`,
                width: `${eventEndPosition - eventPosition}%`,
              }}
            />
          )}

          {/* Ongoing Until Range Event */}
          {eventMarker === 'ongoing_until' && eventEndPosition && (
            <div
              className="absolute top-1/2 -translate-y-1/2 h-3 bg-gradient-to-r from-purple-500 via-pink-500 to-amber-500 rounded-full shadow-md shadow-pink-500/20 border border-purple-300 z-20"
              style={{
                left: `${eventPosition}%`,
                width: `${eventEndPosition - eventPosition}%`,
              }}
            >
              <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 w-3.5 h-3.5 bg-amber-400 rounded-full border border-white" />
            </div>
          )}

          {/* Completed Before Event Marker */}
          {eventMarker === 'completed_before' && (
            <div
              className="absolute top-1/2 -translate-y-1/2 flex items-center z-20"
              style={{ left: `${eventPosition}%` }}
            >
              <div className="w-4 h-4 bg-emerald-600 rounded-full border-2 border-white shadow-md flex items-center justify-center text-[9px] font-bold text-white">
                ✓
              </div>
              {referencePoint && (
                <div
                  className="h-0.5 border-t border-dotted border-emerald-600"
                  style={{ width: `${Math.max(12, Math.abs(referencePoint - eventPosition) * 2.2)}px` }}
                />
              )}
            </div>
          )}

          {/* Single Point Event Marker */}
          {eventMarker === 'point' && (
            <div
              className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 z-20 flex flex-col items-center"
              style={{ left: `${eventPosition}%` }}
            >
              <div className="w-4 h-4 bg-emerald-600 rounded-full border-2 border-white shadow-md ring-4 ring-emerald-500/20 animate-pulse" />
            </div>
          )}
        </div>

        {/* Bottom Time State Captions */}
        <div className="relative z-10 flex justify-between text-[10px] sm:text-[11px] text-slate-600 px-1 border-t border-slate-200 pt-1" dir="rtl">
          <span className="text-sky-800">{timeline.pastState}</span>
          <span className="text-amber-800 font-medium">{timeline.presentState}</span>
          <span className="text-rose-800">{timeline.futureState}</span>
        </div>
      </div>

      {/* Meaning Explanation Box */}
      {!compact && (
        <div className="mt-3 bg-slate-50 rounded-xl p-3 border border-slate-200 flex items-start gap-2.5">
          <span className="text-indigo-600 text-sm mt-0.5">💡</span>
          <p className="text-xs leading-relaxed text-slate-700">
            <strong className="text-indigo-800 ml-1 font-bold">المعنى الزمني:</strong>
            {temporalMeaningAr}
          </p>
        </div>
      )}
    </div>
  );
};
