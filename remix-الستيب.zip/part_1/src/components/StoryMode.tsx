import React, { useState } from 'react';
import { STORY_CHAPTERS } from '../data/storyChapters';
import { StoryChapter, UserStats } from '../types';
import { playSound, speakEnglishText } from '../utils/audio';
import { recordAnswerResult } from '../utils/storage';
import { BookOpen, Sparkles, Volume2, CheckCircle2, ChevronRight, Check } from 'lucide-react';
import confetti from 'canvas-confetti';

interface StoryModeProps {
  userStats: UserStats;
  onUpdateStats: (newStats: UserStats) => void;
  onBackToMenu: () => void;
}

export const StoryMode: React.FC<StoryModeProps> = ({
  userStats,
  onUpdateStats,
  onBackToMenu,
}) => {
  const [activeChapterIndex, setActiveChapterIndex] = useState(0);
  const [activeSegmentIndex, setActiveSegmentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);
  const [chapterCompleted, setChapterCompleted] = useState(false);

  const currentChapter = STORY_CHAPTERS[activeChapterIndex] || STORY_CHAPTERS[0];
  const currentSegment = currentChapter.narrativeSegments[activeSegmentIndex];
  const currentQ = currentSegment?.missingTenseChallenge;

  const handleSelectOption = (option: string) => {
    if (isAnswerSubmitted || !currentQ) return;

    setSelectedAnswer(option);
    const correct = option.trim().toLowerCase() === currentQ.correctAnswer.trim().toLowerCase();
    setIsAnswerSubmitted(true);

    if (correct) {
      playSound('correct');
    } else {
      playSound('wrong');
    }

    const { updatedStats } = recordAnswerResult(userStats, currentQ, option, correct);
    onUpdateStats(updatedStats);
  };

  const handleNextSegment = () => {
    playSound('click');
    setIsAnswerSubmitted(false);
    setSelectedAnswer(null);

    if (activeSegmentIndex + 1 < currentChapter.narrativeSegments.length) {
      setActiveSegmentIndex(s => s + 1);
    } else {
      setChapterCompleted(true);
      playSound('victory');
      try {
        confetti({ particleCount: 120, spread: 70, origin: { y: 0.6 } });
      } catch {}
    }
  };

  return (
    <div className="space-y-8 animate-fade-in" dir="rtl">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-purple-950 via-slate-900 to-indigo-950 border border-purple-500/40 rounded-3xl p-6 md:p-8 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 bg-purple-500/20 border border-purple-500/40 px-3 py-1 rounded-full text-purple-300 text-xs font-bold">
            <BookOpen className="w-4 h-4 text-purple-400" />
            <span>نمط السرد القصصي التفاعلي</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-black text-white">
            📖 نمط القصة (Story Mode)
          </h1>
          <p className="text-xs md:text-sm text-slate-300">
            أكمل الفراغات الزمنية لإعادة بناء فصول الرواية الممتعة!
          </p>
        </div>

        <button
          onClick={onBackToMenu}
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition-all"
        >
          العودة للرئيسية
        </button>
      </div>

      {/* Chapters Switcher */}
      <div className="flex flex-wrap gap-3">
        {STORY_CHAPTERS.map((ch, idx) => (
          <button
            key={ch.id}
            onClick={() => {
              playSound('click');
              setActiveChapterIndex(idx);
              setActiveSegmentIndex(0);
              setIsAnswerSubmitted(false);
              setSelectedAnswer(null);
              setChapterCompleted(false);
            }}
            className={`px-5 py-3 rounded-2xl text-xs font-bold transition-all border ${
              activeChapterIndex === idx
                ? 'bg-purple-600 border-purple-400 text-white shadow-lg shadow-purple-600/30'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800'
            }`}
          >
            {ch.titleAr}
          </button>
        ))}
      </div>

      {/* Chapter Content Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-10 space-y-8 shadow-2xl">
        {/* Intro */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-5 space-y-2">
          <span className="text-xs font-bold text-purple-400 block font-mono">مقدمة الفصل #{currentChapter.chapterNumber}:</span>
          <p className="text-sm text-slate-200 leading-relaxed">{currentChapter.introductionAr}</p>
        </div>

        {chapterCompleted ? (
          <div className="text-center py-10 space-y-4 animate-fade-in">
            <div className="w-16 h-16 bg-purple-500/20 border-2 border-purple-400 rounded-full flex items-center justify-center mx-auto text-3xl">
              🎉
            </div>
            <h2 className="text-2xl font-black text-white">اكتمل الفصل بنجاح!</h2>
            <p className="text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
              {currentChapter.chapterRecapAr}
            </p>
            <button
              onClick={() => {
                playSound('click');
                const nextIdx = (activeChapterIndex + 1) % STORY_CHAPTERS.length;
                setActiveChapterIndex(nextIdx);
                setActiveSegmentIndex(0);
                setIsAnswerSubmitted(false);
                setSelectedAnswer(null);
                setChapterCompleted(false);
              }}
              className="px-6 py-3 bg-purple-600 hover:bg-purple-500 text-white rounded-2xl text-xs font-bold transition-all shadow-lg"
            >
              الانتقال للفصل التالي ←
            </button>
          </div>
        ) : (
          currentSegment && currentQ && (
            <div className="space-y-6">
              {/* Narrative Segment with Missing Piece */}
              <div className="bg-slate-950 rounded-2xl p-6 border border-slate-800 space-y-4" dir="ltr">
                <p className="text-sm md:text-base font-english text-slate-300 leading-loose">
                  {currentSegment.paragraphBeforeEn}{' '}
                  <span className="inline-block px-3 py-1 bg-purple-950/80 border border-purple-500 rounded-lg text-purple-300 font-bold font-mono">
                    [ {isAnswerSubmitted ? currentQ.correctAnswer : '___?___'} ]
                  </span>{' '}
                  {currentSegment.paragraphAfterEn}
                </p>

                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between" dir="rtl">
                  <p className="text-xs text-emerald-300 font-medium leading-relaxed">
                    {currentSegment.narrativeArabicTranslation}
                  </p>
                  <button
                    onClick={() => speakEnglishText(`${currentSegment.paragraphBeforeEn} ${currentQ.correctAnswer} ${currentSegment.paragraphAfterEn}`)}
                    className="p-1.5 text-slate-400 hover:text-white rounded-lg bg-slate-900 shrink-0"
                    title="استمع للفقرة بالإنجليزية"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Tense Choice for this gap */}
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {currentQ.options?.map((opt, idx) => (
                    <button
                      key={idx}
                      disabled={isAnswerSubmitted}
                      onClick={() => handleSelectOption(opt)}
                      className={`p-4 rounded-2xl border text-right font-english font-bold transition-all text-sm ${
                        isAnswerSubmitted
                          ? opt.trim().toLowerCase() === currentQ.correctAnswer.trim().toLowerCase()
                            ? 'bg-emerald-950 border-emerald-500 text-emerald-200'
                            : selectedAnswer === opt
                            ? 'bg-rose-950 border-rose-500 text-rose-200'
                            : 'opacity-40 bg-slate-950 border-slate-800 text-slate-500'
                          : 'bg-slate-950 hover:bg-slate-800 border-slate-800 text-slate-200'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              {/* Feedback */}
              {isAnswerSubmitted && (
                <div className="bg-slate-950 rounded-2xl p-4 border border-purple-500/30 space-y-3 animate-fade-in">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-purple-400">
                      {selectedAnswer?.trim().toLowerCase() === currentQ.correctAnswer.trim().toLowerCase()
                        ? 'أحسنت! هذا هو الزمن الصحيح سياقياً! ✨'
                        : 'إجابة خاطئة — راجع التفسير الزمني:'}
                    </span>
                    <button
                      onClick={handleNextSegment}
                      className="px-4 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold"
                    >
                      متابعة القصة ←
                    </button>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">{currentQ.explanation.whyCorrectAr}</p>
                </div>
              )}
            </div>
          )
        )}
      </div>
    </div>
  );
};
