import React, { useState, useEffect } from 'react';
import { QuizQuestion, UserStats, TenseId } from '../types';
import { playSound, speakEnglishText } from '../utils/audio';
import { recordAnswerResult } from '../utils/storage';
import { ALL_TENSES } from '../data/tensesData';
import confetti from 'canvas-confetti';
import {
  CheckCircle2,
  XCircle,
  Volume2,
  ArrowRight,
  Sparkles,
  RotateCcw,
  Clock,
  Zap,
  HelpCircle,
  Languages,
} from 'lucide-react';
import { getArabicSentenceMeaning } from '../utils/sentenceTranslations';

interface QuizEngineProps {
  questions: QuizQuestion[];
  userStats: UserStats;
  onUpdateStats: (newStats: UserStats) => void;
  titleAr?: string;
  subtitleAr?: string;
  onFinish?: () => void;
}

export const QuizEngine: React.FC<QuizEngineProps> = ({
  questions,
  userStats,
  onUpdateStats,
  titleAr = 'جلسة تدريب',
  subtitleAr = 'أجب بناء على فهم المعنى والتسلسل الزمني للحدث',
  onFinish,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [wordOrderItems, setWordOrderItems] = useState<string[]>([]);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [score, setScore] = useState(0);
  const [streakCount, setStreakCount] = useState(0);
  const [earnedXpTotal, setEarnedXpTotal] = useState(0);
  const [lastEarnedXp, setLastEarnedXp] = useState(0);
  const [isQuizCompleted, setIsQuizCompleted] = useState(false);

  const currentQ = questions[currentIndex];

  useEffect(() => {
    if (currentQ && currentQ.type === 'word_order' && currentQ.orderedWords) {
      const shuffled = [...currentQ.orderedWords].sort(() => Math.random() - 0.5);
      setWordOrderItems(shuffled);
    } else {
      setWordOrderItems([]);
    }
    setSelectedAnswer(null);
    setIsAnswerSubmitted(false);
  }, [currentIndex, currentQ]);

  if (!currentQ) {
    return (
      <div className="bg-white border border-slate-200 rounded-3xl p-10 text-center space-y-4 shadow-xs" dir="rtl">
        <h3 className="text-xl font-bold text-slate-900">لا توجد أسئلة متوفرة حالياً</h3>
        {onFinish && (
          <button
            onClick={onFinish}
            className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer"
          >
            العودة للرئيسية
          </button>
        )}
      </div>
    );
  }

  const handleSubmitAnswer = (chosenAnswer: string) => {
    if (isAnswerSubmitted) return;

    const correct = chosenAnswer.trim().toLowerCase() === currentQ.correctAnswer.trim().toLowerCase();
    setSelectedAnswer(chosenAnswer);
    setIsCorrect(correct);
    setIsAnswerSubmitted(true);

    if (correct) {
      playSound('correct');
      const newStreak = streakCount + 1;
      setStreakCount(newStreak);
      setScore(s => s + 1);

      if (newStreak % 3 === 0) {
        playSound('streak');
        try {
          confetti({
            particleCount: 50,
            spread: 60,
            origin: { y: 0.7 },
          });
        } catch {}
      }
    } else {
      playSound('wrong');
      setStreakCount(0);
    }

    const { updatedStats, earnedXp } = recordAnswerResult(userStats, currentQ, chosenAnswer, correct);
    onUpdateStats(updatedStats);
    setLastEarnedXp(earnedXp);
    setEarnedXpTotal(x => x + earnedXp);
  };

  const handleNextQuestion = () => {
    playSound('click');
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setIsQuizCompleted(true);
      playSound('victory');
      try {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.6 },
        });
      } catch {}
    }
  };

  // Tense metadata lookup
  const tenseMeta = ALL_TENSES.find(t => t.id === currentQ.tenseId);

  // Completion Screen
  if (isQuizCompleted) {
    const percentage = Math.round((score / questions.length) * 100);
    return (
      <div className="max-w-xl mx-auto bg-white border border-slate-200 rounded-3xl p-8 text-center space-y-6 animate-fade-in shadow-md" dir="rtl">
        <div className="w-16 h-16 bg-gradient-to-tr from-indigo-600 to-purple-600 rounded-3xl mx-auto flex items-center justify-center text-3xl shadow-lg shadow-indigo-600/20">
          🏆
        </div>

        <div className="space-y-2">
          <h2 className="text-2xl font-black text-slate-900">انتهت الجلسة بنجاح!</h2>
          <p className="text-sm text-slate-600">
            أحسنت التدريب والتطبيق على فهم المعنى الزمني.
          </p>
        </div>

        {/* Score & XP Cards */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <span className="text-xs text-slate-500 block mb-1">النتيجة الدقيقة</span>
            <span className="text-2xl font-black text-slate-900 font-mono">
              {score} / {questions.length} ({percentage}%)
            </span>
          </div>

          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <span className="text-xs text-slate-500 block mb-1">نقاط الخبرة المكتسبة</span>
            <span className="text-2xl font-black text-amber-600 font-mono">
              +{earnedXpTotal} XP
            </span>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          <button
            onClick={() => {
              playSound('click');
              setCurrentIndex(0);
              setScore(0);
              setIsQuizCompleted(false);
            }}
            className="w-full sm:w-auto px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-2xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
          >
            <RotateCcw className="w-4 h-4" />
            <span>إعادة التدريب</span>
          </button>
          {onFinish && (
            <button
              onClick={() => {
                playSound('click');
                onFinish();
              }}
              className="w-full sm:w-auto px-8 py-3 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-2xl transition-all shadow-md shadow-indigo-600/20 cursor-pointer"
            >
              العودة للرئيسية ←
            </button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in" dir="rtl">
      {/* Top Header & Progress */}
      <div className="bg-white border border-slate-200 rounded-3xl p-5 md:p-6 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-indigo-700 bg-indigo-50 border border-indigo-200 px-3 py-0.5 rounded-full font-mono">
                {currentIndex + 1} / {questions.length}
              </span>
              <span className={`text-[11px] font-bold px-2 py-0.5 rounded-md ${
                currentQ.difficulty === 'easy' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' :
                currentQ.difficulty === 'medium' ? 'bg-amber-50 text-amber-800 border border-amber-200' : 'bg-rose-50 text-rose-800 border border-rose-200'
              }`}>
                {currentQ.difficulty === 'easy' && '🟢 سهل'}
                {currentQ.difficulty === 'medium' && '🟡 متوسط'}
                {currentQ.difficulty === 'hard' && '🔴 صعب'}
                {currentQ.difficulty === 'expert' && '🔥 تحدي'}
              </span>
              {tenseMeta && (
                <span className="text-xs text-slate-500 font-medium">
                  • {tenseMeta.nameAr}
                </span>
              )}
            </div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900">{titleAr}</h2>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-amber-800 bg-amber-50 border border-amber-200 px-3 py-1 rounded-xl font-mono">
              🔥 {streakCount} Streak
            </span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
          <div
            className="h-full bg-indigo-600 transition-all duration-300 rounded-full"
            style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Question Card */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xs space-y-6">
        {/* Scenario Context if present */}
        {currentQ.scenarioContextAr && (
          <div className="bg-slate-50 border border-indigo-200 rounded-2xl p-4 flex items-start gap-3">
            <span className="text-base">🎬</span>
            <div className="space-y-0.5">
              <span className="text-[11px] font-bold text-indigo-700 block font-mono">سياق الموقف:</span>
              <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-medium">
                {currentQ.scenarioContextAr}
              </p>
            </div>
          </div>
        )}



        {/* Sentence with Blank (English) */}
        {currentQ.sentenceWithBlank && (
          <div className="space-y-2.5">
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 flex items-center justify-between gap-4" dir="ltr">
              <p className="text-lg sm:text-xl font-black text-slate-900 font-english text-left leading-snug">
                {currentQ.sentenceWithBlank}
              </p>
              <button
                onClick={() => {
                  playSound('click');
                  speakEnglishText(currentQ.sentenceWithBlank!.replace('___', 'blank'));
                }}
                className="p-2.5 rounded-xl bg-white hover:bg-slate-100 text-slate-600 hover:text-slate-900 border border-slate-200 shrink-0 transition-colors cursor-pointer shadow-2xs"
                title="استمع للجملة"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>

            {/* Dedicated Arabic Translation Box */}
            {(() => {
              const meaning = getArabicSentenceMeaning(currentQ);
              if (!meaning) return null;
              return (
                <div className="bg-indigo-50/80 border border-indigo-100/90 rounded-2xl p-3.5 sm:p-4 flex items-start sm:items-center gap-2.5 text-right transition-all shadow-2xs" dir="rtl">
                  <span className="text-xs font-bold text-indigo-700 bg-indigo-100 px-2.5 py-1 rounded-lg shrink-0 flex items-center gap-1.5 font-mono shadow-2xs">
                    <Languages className="w-3.5 h-3.5 text-indigo-600" />
                    <span>الترجمة بالعربية:</span>
                  </span>
                  <p className="text-xs sm:text-sm text-slate-800 leading-relaxed font-semibold">
                    {meaning}
                  </p>
                </div>
              );
            })()}
          </div>
        )}

        {/* Sentence with Mistake (for Error Spotting) */}
        {currentQ.sentenceWithMistake && (
          <div className="space-y-2.5">
            <div className="bg-amber-50/60 border border-amber-200 rounded-2xl p-5 text-left" dir="ltr">
              <span className="text-[10px] text-amber-800 font-bold block mb-1 font-mono uppercase">
                Identify the incorrect part:
              </span>
              <p className="text-base sm:text-lg font-bold text-slate-900 font-english">
                {currentQ.sentenceWithMistake}
              </p>
            </div>

            {/* Dedicated Arabic Translation Box */}
            {(() => {
              const meaning = getArabicSentenceMeaning(currentQ);
              if (!meaning) return null;
              return (
                <div className="bg-indigo-50/80 border border-indigo-100/90 rounded-2xl p-3.5 sm:p-4 flex items-start sm:items-center gap-2.5 text-right transition-all shadow-2xs" dir="rtl">
                  <span className="text-xs font-bold text-indigo-700 bg-indigo-100 px-2.5 py-1 rounded-lg shrink-0 flex items-center gap-1.5 font-mono shadow-2xs">
                    <Languages className="w-3.5 h-3.5 text-indigo-600" />
                    <span>الترجمة بالعربية:</span>
                  </span>
                  <p className="text-xs sm:text-sm text-slate-800 leading-relaxed font-semibold">
                    {meaning}
                  </p>
                </div>
              );
            })()}
          </div>
        )}

        {/* Two Events Sequence Data */}
        {currentQ.twoEventsData && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-1.5 text-left" dir="ltr">
              <span className="text-[10px] text-slate-500 font-mono">Event A:</span>
              <p className="text-sm font-bold text-slate-900 font-english">{currentQ.twoEventsData.firstEventEn}</p>
              {currentQ.twoEventsData.firstEventAr && (
                <div className="pt-1.5 border-t border-slate-200 text-right" dir="rtl">
                  <p className="text-xs text-slate-600 font-medium">{currentQ.twoEventsData.firstEventAr}</p>
                </div>
              )}
            </div>
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-1.5 text-left" dir="ltr">
              <span className="text-[10px] text-slate-500 font-mono">Event B:</span>
              <p className="text-sm font-bold text-slate-900 font-english">{currentQ.twoEventsData.secondEventEn}</p>
              {currentQ.twoEventsData.secondEventAr && (
                <div className="pt-1.5 border-t border-slate-200 text-right" dir="rtl">
                  <p className="text-xs text-slate-600 font-medium">{currentQ.twoEventsData.secondEventAr}</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Question Type: Word Order */}
        {currentQ.type === 'word_order' && currentQ.orderedWords ? (
          <div className="space-y-4">
            {/* Built Sentence Container */}
            <div className="min-h-[56px] bg-slate-50 border border-indigo-200 rounded-2xl p-3 flex flex-wrap items-center gap-2 text-left" dir="ltr">
              {wordOrderItems.length === 0 ? (
                <span className="text-xs text-slate-400 italic">اضغط على الكلمات بالترتيب الصحيح لبناء الجملة...</span>
              ) : (
                wordOrderItems.map((word, idx) => (
                  <span
                    key={idx}
                    onClick={() => {
                      if (!isAnswerSubmitted) {
                        playSound('click');
                        setWordOrderItems(wordOrderItems.filter((_, i) => i !== idx));
                      }
                    }}
                    className="px-3 py-1.5 bg-indigo-600 text-white rounded-xl text-xs font-bold font-english cursor-pointer hover:bg-rose-600 transition-colors shadow-2xs"
                  >
                    {word} ✕
                  </span>
                ))
              )}
            </div>

            {/* Dedicated Arabic Translation Box */}
            {(() => {
              const meaning = getArabicSentenceMeaning(currentQ);
              if (!meaning) return null;
              return (
                <div className="bg-indigo-50/80 border border-indigo-100/90 rounded-2xl p-3.5 sm:p-4 flex items-start sm:items-center gap-2.5 text-right transition-all shadow-2xs" dir="rtl">
                  <span className="text-xs font-bold text-indigo-700 bg-indigo-100 px-2.5 py-1 rounded-lg shrink-0 flex items-center gap-1.5 font-mono shadow-2xs">
                    <Languages className="w-3.5 h-3.5 text-indigo-600" />
                    <span>الترجمة بالعربية:</span>
                  </span>
                  <p className="text-xs sm:text-sm text-slate-800 leading-relaxed font-semibold">
                    {meaning}
                  </p>
                </div>
              );
            })()}

            {/* Word Bank */}
            <div className="flex flex-wrap gap-2" dir="ltr">
              {currentQ.orderedWords.map((word, idx) => {
                const isUsed = wordOrderItems.includes(word);
                return (
                  <button
                    key={idx}
                    disabled={isUsed || isAnswerSubmitted}
                    onClick={() => {
                      playSound('click');
                      setWordOrderItems([...wordOrderItems, word]);
                    }}
                    className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold font-english transition-all cursor-pointer shadow-2xs ${
                      isUsed
                        ? 'opacity-30 bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                        : 'bg-white hover:bg-indigo-600 hover:text-white text-slate-800 border border-slate-200'
                    }`}
                  >
                    {word}
                  </button>
                );
              })}
            </div>

            {!isAnswerSubmitted && (
              <button
                onClick={() => handleSubmitAnswer(wordOrderItems.join(' '))}
                disabled={wordOrderItems.length === 0}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold text-xs shadow-md shadow-indigo-600/20 disabled:opacity-40 transition-all cursor-pointer"
              >
                تأكيد ترتيب الجملة ←
              </button>
            )}
          </div>
        ) : (
          /* Standard Multiple Choice Options */
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {currentQ.options?.map((option, idx) => {
              let optionStyle = 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800 shadow-2xs';

              if (isAnswerSubmitted) {
                if (option.trim().toLowerCase() === currentQ.correctAnswer.trim().toLowerCase()) {
                  optionStyle = 'bg-emerald-50 border-emerald-400 text-emerald-900 ring-2 ring-emerald-400/40 font-bold';
                } else if (selectedAnswer === option) {
                  optionStyle = 'bg-rose-50 border-rose-400 text-rose-900 ring-2 ring-rose-400/40 font-bold';
                } else {
                  optionStyle = 'opacity-40 bg-white border-slate-200 text-slate-400';
                }
              }

              return (
                <button
                  key={idx}
                  disabled={isAnswerSubmitted}
                  onClick={() => handleSubmitAnswer(option)}
                  className={`p-4 rounded-2xl border text-right transition-all font-english flex items-center justify-between gap-3 cursor-pointer ${optionStyle}`}
                >
                  <span className="text-sm sm:text-base font-bold leading-relaxed">{option}</span>
                  {isAnswerSubmitted && option.trim().toLowerCase() === currentQ.correctAnswer.trim().toLowerCase() && (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  )}
                  {isAnswerSubmitted && selectedAnswer === option && option.trim().toLowerCase() !== currentQ.correctAnswer.trim().toLowerCase() && (
                    <XCircle className="w-5 h-5 text-rose-600 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>
        )}

        {/* ─── Pedagogical Feedback Card (Exact Simplified Format) ─── */}
        {isAnswerSubmitted && (
          <div
            className={`rounded-3xl p-5 sm:p-7 space-y-4 border animate-fade-in ${
              isCorrect
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : 'bg-rose-50 border-rose-200 text-rose-900'
            }`}
          >
            {/* Header / Next button */}
            <div className="flex items-center justify-between border-b border-slate-200/80 pb-3">
              <div className="flex items-center gap-2.5">
                {isCorrect ? (
                  <span className="text-xl">✅</span>
                ) : (
                  <span className="text-xl">❌</span>
                )}
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    {isCorrect ? 'إجابة صحيحة ومتقنة!' : 'إجابة غير صحيحة — ركز في السبب:'}
                  </h3>
                  <span className="text-xs text-amber-700 font-mono font-bold">
                    +{lastEarnedXp} XP
                  </span>
                </div>
              </div>

              <button
                onClick={handleNextQuestion}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-indigo-600/20 flex items-center gap-1.5 cursor-pointer"
              >
                <span>{currentIndex + 1 < questions.length ? 'السؤال التالي' : 'عرض النتيجة'}</span>
                <ArrowRight className="w-4 h-4 rtl:rotate-180" />
              </button>
            </div>

            {/* If Wrong: Direct Comparison & Reason */}
            {!isCorrect && (
              <div className="bg-white rounded-2xl p-4 border border-rose-200 space-y-2 text-xs sm:text-sm shadow-2xs">
                <div className="flex items-center gap-2">
                  <span className="text-rose-700 font-bold">❌ إجابتك:</span>
                  <span className="font-english font-bold text-rose-900">{selectedAnswer}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-emerald-700 font-bold">✅ الصحيح:</span>
                  <span className="font-english font-bold text-emerald-900">{currentQ.correctAnswer}</span>
                </div>
              </div>
            )}

            {/* Explanation & Mental Reminder Rule */}
            <div className="space-y-2 text-xs sm:text-sm leading-relaxed text-slate-700">
              <p>
                <strong className="text-indigo-800 ml-1">لماذا؟</strong>
                {currentQ.explanation.whyCorrectAr}
              </p>

              {currentQ.explanation.temporalRelationshipAr && (
                <p className="text-slate-700">
                  <strong className="text-sky-800 ml-1">العلاقة الزمنية:</strong>
                  {currentQ.explanation.temporalRelationshipAr}
                </p>
              )}

              {tenseMeta && (
                <div className="bg-amber-50 p-3 rounded-xl border border-amber-200 text-amber-900 text-xs font-medium">
                  💡 <strong className="text-amber-950 ml-1">تذكّر:</strong>
                  {tenseMeta.nameAr} = {tenseMeta.shortSummaryAr}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
