import React, { useState } from 'react';
import { TenseInfo, TenseId, UserStats } from '../types';
import { ALL_TENSES } from '../data/tensesData';
import { ALL_QUESTIONS } from '../data/questionsBank';
import { TimelineVisualizer } from './TimelineVisualizer';
import { playSound, speakEnglishText } from '../utils/audio';
import { recordAnswerResult } from '../utils/storage';
import {
  Volume2,
  CheckCircle2,
  XCircle,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  HelpCircle,
  ArrowLeftRight,
  Check,
  ChevronRight,
  Zap,
} from 'lucide-react';

interface TenseLessonViewProps {
  tense: TenseInfo;
  userStats: UserStats;
  onUpdateStats: (newStats: UserStats) => void;
  onBackToMap: () => void;
  onSelectTense: (tenseId: TenseId) => void;
  onStartPractice: (tenseId: TenseId) => void;
}

export const TenseLessonView: React.FC<TenseLessonViewProps> = ({
  tense,
  userStats,
  onUpdateStats,
  onBackToMap,
  onSelectTense,
  onStartPractice,
}) => {
  const currentIndex = ALL_TENSES.findIndex(t => t.id === tense.id);
  const prevTense = currentIndex > 0 ? ALL_TENSES[currentIndex - 1] : null;
  const nextTense = currentIndex < ALL_TENSES.length - 1 ? ALL_TENSES[currentIndex + 1] : null;

  // Interactive Quick Check Questions for this specific tense
  const tenseQuestions = React.useMemo(() => {
    return ALL_QUESTIONS.filter(q => q.tenseId === tense.id).slice(0, 2);
  }, [tense.id]);

  const [activeQuestionIdx, setActiveQuestionIdx] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);

  // Reset quiz state when tense changes
  React.useEffect(() => {
    setActiveQuestionIdx(0);
    setSelectedAnswer(null);
    setIsAnswerSubmitted(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [tense.id]);

  const currentQ = tenseQuestions[activeQuestionIdx];

  const handleSelectAnswer = (option: string) => {
    if (isAnswerSubmitted || !currentQ) return;

    const correct = option.trim().toLowerCase() === currentQ.correctAnswer.trim().toLowerCase();
    setSelectedAnswer(option);
    setIsCorrect(correct);
    setIsAnswerSubmitted(true);

    if (correct) {
      playSound('correct');
    } else {
      playSound('wrong');
    }

    const { updatedStats } = recordAnswerResult(userStats, currentQ, option, correct);
    onUpdateStats(updatedStats);
  };

  const handleNextCheckQuestion = () => {
    playSound('click');
    if (activeQuestionIdx + 1 < tenseQuestions.length) {
      setActiveQuestionIdx(activeQuestionIdx + 1);
      setSelectedAnswer(null);
      setIsAnswerSubmitted(false);
    }
  };

  // Extract the primary example sentence
  const mainExample = tense.examples[0] || {
    en: 'She speaks English fluently.',
    ar: 'هي تتحدث الإنجليزية بطلاقة.',
    contextNoteAr: 'مثال توضيحي على استخدام هذا الزمن.',
  };

  // Primary rival comparison (show only the #1 most confusing rival)
  const primaryRival = tense.vsComparisons && tense.vsComparisons.length > 0 ? tense.vsComparisons[0] : null;

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in pb-12" dir="rtl">
      {/* Top Breadcrumb Navigation */}
      <div className="flex items-center justify-between text-xs text-slate-500">
        <button
          onClick={onBackToMap}
          className="flex items-center gap-1.5 text-slate-700 hover:text-slate-900 transition-colors bg-white hover:bg-slate-50 border border-slate-200 px-3.5 py-1.5 rounded-xl font-bold shadow-2xs cursor-pointer"
        >
          <ChevronRight className="w-4 h-4" />
          <span>العودة لخريطة الأزمنة</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="text-slate-500 font-mono text-[11px]">
            {currentIndex + 1} / {ALL_TENSES.length}
          </span>
          <span className="text-[10px] bg-indigo-50 text-indigo-700 font-bold px-2 py-0.5 rounded border border-indigo-100 uppercase font-mono">
            {tense.timeCategory === 'general_rules' ? 'قواعد إنجليزية شاملة' : `${tense.timeCategory} • ${tense.aspectCategory}`}
          </span>
        </div>
      </div>

      {/* Hero Header of Tense */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight flex items-center justify-center gap-3">
          <span>{tense.nameAr}</span>
          <span className="text-xl sm:text-2xl text-indigo-600 font-english font-bold">
            ({tense.nameEn})
          </span>
        </h1>
      </div>

      {/* ─── 1. الفكرة (The Core Idea) ─── */}
      <div className="bg-white border border-indigo-100 rounded-3xl p-6 sm:p-8 shadow-xs text-center space-y-3">
        <span className="text-[11px] font-bold tracking-widest text-indigo-700 uppercase font-mono bg-indigo-50 px-3 py-1 rounded-full border border-indigo-100 inline-block">
          1. الفكرة الأساسية
        </span>
        <p className="text-xl sm:text-2xl font-bold text-slate-900 leading-relaxed">
          "{tense.shortSummaryAr}"
        </p>
      </div>

      {/* ─── 2. اسأل نفسك (The Golden Question) ─── */}
      <div className="bg-amber-50/70 border border-amber-200 rounded-3xl p-6 sm:p-7 shadow-xs relative overflow-hidden">
        <div className="absolute top-0 right-0 w-2 h-full bg-amber-400" />
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-amber-800 text-xs font-bold font-mono">
            <HelpCircle className="w-4 h-4 text-amber-600" />
            <span>2. اسأل نفسك دائماً:</span>
          </div>
          <p className="text-lg sm:text-xl font-black text-slate-900 leading-relaxed pr-2">
            {tense.goldenQuestionAr}
          </p>
        </div>
      </div>

      {/* ─── 3. الخط الزمني البصري (Timeline) ─── */}
      <div className="space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-500 px-1 font-mono">
          <span>3. الخط الزمني (شاهد الحدث بصرياً)</span>
        </div>
        <TimelineVisualizer timeline={tense.timeline} />
      </div>

      {/* ─── 4. مثال حي وواضح (Example with Pronunciation) ─── */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 space-y-4 shadow-xs">
        <div className="flex items-center justify-between text-xs text-slate-500 border-b border-slate-100 pb-3">
          <span className="font-bold text-emerald-700 font-mono">4. مثال واقعي:</span>
          <span className="text-[11px] text-slate-400 font-english">Example Sentence</span>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between gap-4 bg-slate-50 p-4 sm:p-5 rounded-2xl border border-slate-200" dir="ltr">
            <div className="space-y-1 text-left">
              <p className="text-xl sm:text-2xl font-black text-slate-900 font-english">
                {mainExample.en}
              </p>
              <p className="text-sm sm:text-base text-slate-600 font-sans" dir="rtl">
                "{mainExample.ar}"
              </p>
            </div>

            <button
              onClick={() => {
                playSound('click');
                speakEnglishText(mainExample.en);
              }}
              className="p-3 bg-indigo-50 hover:bg-indigo-600 text-indigo-600 hover:text-white rounded-2xl border border-indigo-200 transition-all shrink-0 cursor-pointer shadow-2xs"
              title="استمع للنطق الإنجليزي"
            >
              <Volume2 className="w-5 h-5" />
            </button>
          </div>

          {mainExample.contextNoteAr && (
            <p className="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200 leading-relaxed">
              💡 <strong className="text-slate-800 ml-1">لماذا هذا الزمن؟</strong>
              {mainExample.contextNoteAr}
            </p>
          )}
        </div>
      </div>

      {/* ─── 5. التركيب والشرح المبسط (Formula & Simplified Explanation) ─── */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-xs space-y-5">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-indigo-700 font-mono">
              5. التركيب والقاعدة (Formula & Structure):
            </span>
          </div>
          <span className="text-[11px] text-slate-400 font-mono">
            {tense.nameEn}
          </span>
        </div>

        {/* Formulas for Affirmative, Negative, and Question */}
        <div className="grid grid-cols-1 gap-3">
          {/* Affirmative (الإثبات) */}
          <div className="bg-slate-50/70 border border-emerald-200 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center justify-center font-mono shrink-0">
                +
              </span>
              <span className="text-xs font-bold text-slate-800">الإثبات (Affirmative):</span>
            </div>
            <div className="bg-white px-4 py-2 rounded-xl border border-slate-200 text-emerald-800 font-english font-mono font-bold text-xs sm:text-sm text-left shadow-2xs" dir="ltr">
              {tense.formula.affirmative}
            </div>
          </div>

          {/* Negative (النفي) */}
          <div className="bg-slate-50/70 border border-rose-200 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-rose-100 text-rose-800 font-bold text-xs flex items-center justify-center font-mono shrink-0">
                −
              </span>
              <span className="text-xs font-bold text-slate-800">النفي (Negative):</span>
            </div>
            <div className="bg-white px-4 py-2 rounded-xl border border-slate-200 text-rose-800 font-english font-mono font-bold text-xs sm:text-sm text-left shadow-2xs" dir="ltr">
              {tense.formula.negative}
            </div>
          </div>

          {/* Question (السؤال) */}
          <div className="bg-slate-50/70 border border-indigo-200 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-indigo-100 text-indigo-800 font-bold text-xs flex items-center justify-center font-mono shrink-0">
                ?
              </span>
              <span className="text-xs font-bold text-slate-800">السؤال (Question):</span>
            </div>
            <div className="bg-white px-4 py-2 rounded-xl border border-slate-200 text-indigo-800 font-english font-mono font-bold text-xs sm:text-sm text-left shadow-2xs" dir="ltr">
              {tense.formula.question}
            </div>
          </div>
        </div>

        {/* Simplified Explanation & Notes (شرح مبسط لقواعد التركيب) */}
        {tense.formula.rulesNotesAr && tense.formula.rulesNotesAr.length > 0 && (
          <div className="bg-slate-50/80 border border-slate-200 rounded-2xl p-4 sm:p-5 space-y-2.5">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-800 font-mono">
              <span>💡 شرح مبسط للتركيب والقاعدة:</span>
            </div>
            <ul className="space-y-2 text-xs sm:text-sm text-slate-700 leading-relaxed list-disc list-inside">
              {tense.formula.rulesNotesAr.map((rule, idx) => (
                <li key={idx} className="marker:text-indigo-600">
                  <span className="text-slate-800">{rule}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* ─── 6. جرّب بنفسك (Try It Now Interactive Check) ─── */}
      {currentQ && (
        <div className="bg-white border border-indigo-200 rounded-3xl p-6 sm:p-8 space-y-5 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2 text-indigo-700 font-bold text-xs font-mono">
              <Sparkles className="w-4 h-4 text-indigo-600" />
              <span>6. جرّب بنفسك الآن (سؤال سريع):</span>
            </div>
            <span className="text-[11px] text-slate-600 bg-slate-100 px-2.5 py-0.5 rounded-full font-mono">
              {activeQuestionIdx + 1} / {tenseQuestions.length}
            </span>
          </div>

          <div className="space-y-4">
            {currentQ.scenarioContextAr && (
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs text-slate-700">
                💬 {currentQ.scenarioContextAr}
              </div>
            )}

            {currentQ.sentenceWithBlank && (
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 font-english text-base sm:text-lg font-bold text-slate-900 text-left" dir="ltr">
                {currentQ.sentenceWithBlank}
              </div>
            )}

            {/* Answer Options */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {currentQ.options?.map((option, idx) => {
                let btnStyle = 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800';

                if (isAnswerSubmitted) {
                  if (option.trim().toLowerCase() === currentQ.correctAnswer.trim().toLowerCase()) {
                    btnStyle = 'bg-emerald-50 border-emerald-400 text-emerald-900 ring-2 ring-emerald-400/40 font-bold';
                  } else if (selectedAnswer === option) {
                    btnStyle = 'bg-rose-50 border-rose-400 text-rose-900 ring-2 ring-rose-400/40 font-bold';
                  } else {
                    btnStyle = 'opacity-40 bg-white border-slate-200 text-slate-400';
                  }
                }

                return (
                  <button
                    key={idx}
                    disabled={isAnswerSubmitted}
                    onClick={() => handleSelectAnswer(option)}
                    className={`p-3.5 rounded-2xl border font-english text-left text-sm font-bold transition-all flex items-center justify-between gap-2 cursor-pointer shadow-2xs ${btnStyle}`}
                    dir="ltr"
                  >
                    <span>{option}</span>
                    {isAnswerSubmitted && option.trim().toLowerCase() === currentQ.correctAnswer.trim().toLowerCase() && (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    )}
                    {isAnswerSubmitted && selectedAnswer === option && option.trim().toLowerCase() !== currentQ.correctAnswer.trim().toLowerCase() && (
                      <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Pedagogical Feedback */}
            {isAnswerSubmitted && (
              <div className={`p-4 rounded-2xl border animate-fade-in space-y-2 ${
                isCorrect ? 'bg-emerald-50 border-emerald-200 text-emerald-900' : 'bg-rose-50 border-rose-200 text-rose-900'
              }`}>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black">
                    {isCorrect ? 'أحسنت! إجابة صحيحة ✓' : 'غير صحيح — انظر السبب 💡'}
                  </span>
                  {activeQuestionIdx + 1 < tenseQuestions.length && (
                    <button
                      onClick={handleNextCheckQuestion}
                      className="text-xs bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-3 py-1 rounded-xl transition-all shadow-xs cursor-pointer"
                    >
                      السؤال التالي ←
                    </button>
                  )}
                </div>
                <p className="text-xs leading-relaxed text-slate-700">
                  {currentQ.explanation.whyCorrectAr}
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ─── 7. قارن مع الزمن المنافس (Compare with #1 Rival) ─── */}
      {primaryRival && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 space-y-4 shadow-xs">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-800 font-mono border-b border-slate-100 pb-3">
            <ArrowLeftRight className="w-4 h-4 text-amber-600" />
            <span>7. قارن: أكثر زمن قد تلخبط بينه وبينه</span>
          </div>

          <div className="space-y-4">
            <p className="text-xs text-slate-700 leading-relaxed font-bold">
              {primaryRival.coreDifferenceAr}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3" dir="ltr">
              <div className="bg-slate-50 p-4 rounded-2xl border border-indigo-200 space-y-1 text-left">
                <span className="text-[10px] font-bold text-indigo-700 uppercase font-mono block">
                  {primaryRival.exampleA.tenseName}
                </span>
                <p className="text-sm font-bold text-slate-900 font-english">{primaryRival.exampleA.en}</p>
                <p className="text-xs text-slate-600 font-sans" dir="rtl">{primaryRival.exampleA.ar}</p>
              </div>

              <div className="bg-slate-50 p-4 rounded-2xl border border-amber-200 space-y-1 text-left">
                <span className="text-[10px] font-bold text-amber-800 uppercase font-mono block">
                  {primaryRival.exampleB.tenseName}
                </span>
                <p className="text-sm font-bold text-slate-900 font-english">{primaryRival.exampleB.en}</p>
                <p className="text-xs text-slate-600 font-sans" dir="rtl">{primaryRival.exampleB.ar}</p>
              </div>
            </div>

            <div className="bg-amber-50/80 p-3.5 rounded-xl border border-amber-200 text-xs text-amber-900 leading-relaxed">
              ⭐ <strong className="text-amber-950 ml-1">القاعدة الذهبية للتفريق:</strong>
              {primaryRival.keyRuleAr}
            </div>
          </div>
        </div>
      )}

      {/* ─── Bottom Navigation Actions ─── */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-200">
        <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-start">
          {prevTense ? (
            <button
              onClick={() => {
                playSound('click');
                onSelectTense(prevTense.id);
              }}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-white hover:bg-slate-100 text-slate-700 text-xs font-bold border border-slate-200 transition-all shadow-2xs cursor-pointer"
            >
              <ArrowRight className="w-4 h-4" />
              <span>{prevTense.nameAr}</span>
            </button>
          ) : (
            <div />
          )}

          {nextTense && (
            <button
              onClick={() => {
                playSound('click');
                onSelectTense(nextTense.id);
              }}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-white hover:bg-slate-100 text-slate-700 text-xs font-bold border border-slate-200 transition-all shadow-2xs cursor-pointer"
            >
              <span>{nextTense.nameAr}</span>
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}
        </div>

        <button
          onClick={() => {
            playSound('click');
            onStartPractice(tense.id);
          }}
          className="w-full sm:w-auto px-8 py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold text-sm shadow-md shadow-indigo-600/20 flex items-center justify-center gap-2 transition-all hover:scale-[1.02] cursor-pointer"
        >
          <Zap className="w-4 h-4" />
          <span>🧪 تدرب على هذا الزمن الآن</span>
        </button>
      </div>
    </div>
  );
};
