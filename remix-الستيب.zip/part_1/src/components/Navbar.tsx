import React, { useState, useEffect } from 'react';
import { UserStats, TenseId } from '../types';
import { playSound, isAudioMuted, toggleAudioMute } from '../utils/audio';
import { AppTheme, THEME_OPTIONS, ThemeOption } from '../utils/theme';
import { ALL_TENSES } from '../data/tensesData';
import {
  BookOpen,
  Zap,
  BookMarked,
  Volume2,
  VolumeX,
  Flame,
  Palette,
  Check,
  RotateCcw,
  ListChecks,
  X,
  Sparkles,
} from 'lucide-react';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string, payload?: any) => void;
  userStats: UserStats;
  currentTheme: AppTheme;
  onThemeChange: (theme: AppTheme) => void;
  onResetCourse: () => void;
  onUpdateStats?: (newStats: UserStats) => void;
  onSelectTense?: (tenseId: TenseId) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  userStats,
  currentTheme,
  onThemeChange,
  onResetCourse,
  onUpdateStats,
  onSelectTense,
}) => {
  const [muted, setMuted] = useState(isAudioMuted());
  const [isThemeOpen, setIsThemeOpen] = useState(false);
  const [showResetModal, setShowResetModal] = useState(false);

  const handleToggleMute = () => {
    const isNowMuted = toggleAudioMute();
    setMuted(isNowMuted);
  };

  // Close modals on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsThemeOpen(false);
        setShowResetModal(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Calculate course completion percentage
  const masteryValues = Object.values(userStats.tenseMastery || {}) as { attempted: number; correct: number; mastered: boolean }[];
  const masteredCount = masteryValues.filter(m => m.mastered).length;
  const totalTopicsCount = ALL_TENSES.length;
  const progressPercent = Math.round((masteredCount / totalTopicsCount) * 100);

  interface NavItem {
    id: string;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string;
    count?: number;
  }

  const navItems: NavItem[] = [
    { id: 'dashboard', label: 'خريطة الأزمنة', icon: BookOpen },
    { id: 'practice', label: '🧪 تدرب', icon: Zap },
    { id: 'notebook', label: 'دفتر أخطائي', icon: BookMarked, count: userStats.errorHistory?.length || 0 },
  ];

  const activeThemeMeta = THEME_OPTIONS.find(t => t.id === currentTheme) || THEME_OPTIONS[0];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs w-full" dir="rtl">
      <div className="max-w-6xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-18 gap-2 sm:gap-3 overflow-x-auto custom-h-scrollbar">
          {/* Logo */}
          <div
            id="navbar-logo-btn"
            onClick={() => {
              playSound('click');
              onNavigate('dashboard');
            }}
            className="flex items-center gap-2 sm:gap-2.5 cursor-pointer group select-none shrink-0"
          >
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white font-black text-xs sm:text-sm shadow-md shadow-indigo-600/25 group-hover:scale-105 transition-transform">
              TM
            </div>
            <div>
              <div className="flex items-center gap-1">
                <span className="font-black text-sm sm:text-base text-slate-900 tracking-tight whitespace-nowrap">
                  Tense Master
                </span>
              </div>
              <span className="text-[10px] text-slate-500 block -mt-0.5 font-medium hidden md:block">
                افهم الأزمنة الإنجليزية
              </span>
            </div>
          </div>

          {/* Central Nav Links */}
          <div className="mx-1 sm:mx-2 shrink-0">
            <nav className="flex items-center gap-1 sm:gap-2">
              {navItems.map(item => {
                const Icon = item.icon;
                const isActive = currentView === item.id;
                return (
                  <button
                    key={item.id}
                    id={`navbar-nav-${item.id}`}
                    onClick={() => {
                      playSound('click');
                      onNavigate(item.id);
                    }}
                    className={`px-2.5 sm:px-3.5 py-1.5 sm:py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/25'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5 shrink-0" />
                    <span>{item.label}</span>
                    {item.badge && (
                      <span className={`text-[9px] px-1.5 py-0.2 rounded-md font-mono font-bold ${
                        isActive ? 'bg-white/25 text-white' : 'bg-indigo-100 text-indigo-800'
                      }`}>
                        {item.badge}
                      </span>
                    )}
                    {typeof item.count === 'number' && item.count > 0 && (
                      <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                        isActive ? 'bg-white/25 text-white' : 'bg-rose-100 text-rose-700'
                      }`}>
                        {item.count}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Quick Controls: Streak, Course Progress Bar, Checklist Trigger, Reset Button, Theme & Sound */}
          <div className="flex items-center gap-1 sm:gap-2 shrink-0">
            {/* Daily Streak Flame (Consecutive Days) */}
            <div
              id="navbar-streak-indicator"
              className="flex items-center gap-1 bg-amber-50 border border-amber-200 px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-xl text-xs font-bold text-amber-800 font-mono shadow-2xs"
              title={`سلسلة الدخول اليومي المتتالي: ${userStats.streak} ${userStats.streak === 1 ? 'يوم' : 'أيام'}. ادخل يومياً للحفاظ عليها!`}
            >
              <Flame className="w-3.5 h-3.5 fill-amber-500 text-amber-500 shrink-0" />
              <span>{userStats.streak}d</span>
            </div>

            {/* Course Progress Bar with Click-to-open Checklist Page */}
            <button
              id="navbar-progress-btn"
              onClick={() => {
                playSound('click');
                onNavigate('checklist');
              }}
              className={`flex items-center gap-1.5 sm:gap-2 border px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-xl shadow-2xs transition-all cursor-pointer text-right ${
                currentView === 'checklist'
                  ? 'bg-indigo-50 border-indigo-300 ring-2 ring-indigo-200'
                  : 'bg-slate-50 hover:bg-indigo-50/70 border-slate-200 hover:border-indigo-200'
              }`}
              title="اضغط لفتح صفحة قائمة القواعد الشاملة (Checklist)"
            >
              <div className="flex flex-col gap-0.5 min-w-[55px] sm:min-w-[75px]">
                <div className="flex items-center justify-between text-[10px] font-bold text-slate-700 font-mono leading-none">
                  <span className="text-[9px] text-slate-500 font-medium hidden sm:inline">التقدم</span>
                  <span className="text-indigo-600">{progressPercent}%</span>
                </div>
                <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-indigo-500 to-emerald-500 rounded-full transition-all duration-500"
                    style={{ width: `${Math.max(progressPercent, 0)}%` }}
                  />
                </div>
              </div>
            </button>

            {/* Dedicated Checklist Trigger Button */}
            <button
              id="navbar-checklist-btn"
              onClick={() => {
                playSound('click');
                onNavigate('checklist');
              }}
              className={`px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-xl border transition-all shadow-2xs cursor-pointer flex items-center gap-1.5 ${
                currentView === 'checklist'
                  ? 'bg-indigo-600 text-white border-indigo-600'
                  : 'bg-indigo-50 hover:bg-indigo-100/90 border-indigo-200/90 text-indigo-700 hover:text-indigo-900'
              }`}
              title="الانتقال لصفحة قائمة تدقيق القواعد والأزمنة (Checklist)"
            >
              <ListChecks className={`w-3.5 h-3.5 shrink-0 ${currentView === 'checklist' ? 'text-white' : 'text-indigo-600'}`} />
              <span className="text-xs font-bold hidden md:inline">قائمة القواعد</span>
              <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded-md font-bold ${
                currentView === 'checklist' ? 'bg-white/20 text-white' : 'bg-indigo-200/70 text-indigo-900'
              }`}>
                {masteredCount}/{totalTopicsCount}
              </span>
            </button>

            {/* Reset Course Button */}
            <button
              id="navbar-reset-course-btn"
              onClick={() => {
                playSound('click');
                setShowResetModal(true);
              }}
              className="px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-xl bg-slate-100 hover:bg-rose-50 border border-slate-200 hover:border-rose-200 text-slate-600 hover:text-rose-600 transition-all shadow-2xs cursor-pointer flex items-center gap-1"
              title="إعادة بدء الدورة من الصفر"
            >
              <RotateCcw className="w-3.5 h-3.5 shrink-0" />
              <span className="hidden xl:inline text-xs font-bold">إعادة البدء</span>
            </button>

            {/* Theme Selector Trigger Button */}
            <button
              id="navbar-theme-selector-btn"
              onClick={() => {
                playSound('click');
                setIsThemeOpen(true);
              }}
              className="p-1.5 sm:p-2 rounded-xl bg-slate-100 hover:bg-slate-200/80 border border-slate-200 text-slate-700 hover:text-slate-900 transition-all flex items-center gap-1 sm:gap-1.5 shadow-2xs cursor-pointer"
              title="تغيير المظهر / الثيم"
            >
              <Palette className="w-3.5 sm:w-4 h-3.5 sm:h-4 text-indigo-600" />
              <span
                className="w-2 sm:w-2.5 h-2 sm:h-2.5 rounded-full border border-slate-300 shadow-xs shrink-0"
                style={{ backgroundColor: activeThemeMeta.iconColor }}
              />
            </button>

            {/* Sound Toggle */}
            <button
              id="navbar-sound-toggle-btn"
              onClick={handleToggleMute}
              className="p-1.5 sm:p-2 rounded-xl bg-slate-100 hover:bg-slate-200/80 border border-slate-200 text-slate-700 hover:text-slate-900 transition-colors shadow-2xs cursor-pointer"
              title={muted ? 'تفعيل الصوت' : 'كتم الصوت'}
            >
              {muted ? <VolumeX className="w-3.5 sm:w-4 h-3.5 sm:h-4 text-rose-500" /> : <Volume2 className="w-3.5 sm:w-4 h-3.5 sm:h-4 text-emerald-600" />}
            </button>
          </div>
        </div>
      </div>

      {/* Central Theme Modal Dialog in the Center of the Application */}
      {isThemeOpen && (
        <div
          id="theme-selection-modal-backdrop"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fade-in"
          dir="rtl"
          onClick={() => setIsThemeOpen(false)}
        >
          <div
            id="theme-selection-modal-card"
            className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 max-w-lg w-full shadow-2xl space-y-4 animate-scale-in m-auto max-h-[90vh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-3.5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shrink-0">
                  <Palette className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base sm:text-lg font-black text-slate-900">
                      تخصيص مظهر التطبيق
                    </h3>
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 font-mono">
                      {THEME_OPTIONS.length} ألوان
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">
                    اختر اللون والمظهر المناسب لراحتك أثناء الدراسة والتدريب
                  </p>
                </div>
              </div>

              <button
                id="theme-modal-close-btn"
                onClick={() => setIsThemeOpen(false)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center transition-colors cursor-pointer"
                title="إغلاق"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Themes Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
              {THEME_OPTIONS.map((theme: ThemeOption) => {
                const isSelected = currentTheme === theme.id;
                return (
                  <button
                    key={theme.id}
                    id={`theme-option-btn-${theme.id}`}
                    onClick={() => {
                      playSound('click');
                      onThemeChange(theme.id);
                    }}
                    className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex items-center justify-between group relative ${
                      isSelected
                        ? 'bg-indigo-50/80 border-indigo-400 ring-2 ring-indigo-300/60 shadow-sm'
                        : 'bg-slate-50 hover:bg-slate-100/90 border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {/* Color Swatch Dot */}
                      <div
                        className="w-7 h-7 rounded-xl border border-black/10 shadow-xs flex items-center justify-center shrink-0 transition-transform group-hover:scale-105"
                        style={{ backgroundColor: theme.iconColor }}
                      >
                        {isSelected && (
                          <Check className="w-4 h-4 text-white drop-shadow-xs" />
                        )}
                      </div>

                      <div className="min-w-0">
                        <div className="text-xs sm:text-sm font-bold text-slate-900 truncate">
                          {theme.nameAr}
                        </div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          {theme.id === 'light' ? 'الافتراضي المضيء' : theme.id === 'dark' ? 'داكن هادئ' : `مظهر ${theme.colorName}`}
                        </div>
                      </div>
                    </div>

                    {isSelected && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-600 text-white font-mono shrink-0 shadow-2xs">
                        مفعل
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Modal Footer / Quick Info */}
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                <span>يتم حفظ تفضيل المظهر تلقائياً لجلساتك القادمة</span>
              </div>
              <button
                id="theme-modal-done-btn"
                onClick={() => {
                  playSound('click');
                  setIsThemeOpen(false);
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-sm shadow-indigo-600/25 transition-all cursor-pointer shrink-0"
              >
                تم
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Course Reset Confirmation Modal */}
      {showResetModal && (
        <div
          id="reset-course-modal-backdrop"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in"
          dir="rtl"
          onClick={() => setShowResetModal(false)}
        >
          <div
            id="reset-course-modal-card"
            className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl space-y-4 animate-scale-in m-auto"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-rose-100 flex items-center justify-center text-rose-600 shrink-0">
                <RotateCcw className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-black text-slate-900">إعادة بدء الدورة من الصفر؟</h3>
                <p className="text-xs text-slate-500">سيتم تصفير كل تقدمك والبدء من البداية</p>
              </div>
            </div>

            <div className="bg-rose-50/70 border border-rose-200/80 rounded-2xl p-3.5 text-xs text-rose-800 space-y-1.5 leading-relaxed">
              <p className="font-bold flex items-center gap-1.5">
                <span>⚠️</span>
                <span>سيتم تصفير ما يلي:</span>
              </p>
              <ul className="list-disc list-inside space-y-0.5 text-[11px] text-rose-700 pr-1">
                <li>نسبة إتقان جميع الأزمنة الـ12 والقواعد (0%).</li>
                <li>سجل دفتر الأخطاء وإحصائيات الأسئلة المحلولة.</li>
                <li>إعادة ضبط السلسلة اليومية ونقاط الخبرة.</li>
              </ul>
            </div>

            <div className="flex items-center gap-2.5 pt-1">
              <button
                id="confirm-reset-course-btn"
                onClick={() => {
                  onResetCourse();
                  setShowResetModal(false);
                }}
                className="flex-1 py-2.5 sm:py-3 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl sm:rounded-2xl text-xs sm:text-sm shadow-md shadow-rose-600/25 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                <span>نعم، أعد البدء من الصفر</span>
              </button>

              <button
                id="cancel-reset-course-btn"
                onClick={() => setShowResetModal(false)}
                className="px-4 sm:px-5 py-2.5 sm:py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl sm:rounded-2xl text-xs sm:text-sm transition-colors cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

