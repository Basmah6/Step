import React, { useState } from 'react';
import { ALL_TENSES } from '../data/tensesData';
import { TenseId, TenseInfo, TimeCategory, AspectCategory } from '../types';
import { TimelineVisualizer } from './TimelineVisualizer';
import { playSound, speakEnglishText } from '../utils/audio';
import {
  Search,
  Filter,
  Volume2,
  HelpCircle,
  AlertTriangle,
  ArrowLeftRight,
  Sparkles,
  CheckCircle2,
  X,
  Play,
  BookOpen,
  Layers,
} from 'lucide-react';

interface TenseExplorerProps {
  onStartPractice: (tenseId?: TenseId) => void;
  selectedTenseId?: TenseId | null;
  onCloseSelectedTense?: () => void;
}

export const TenseExplorer: React.FC<TenseExplorerProps> = ({
  onStartPractice,
  selectedTenseId,
  onCloseSelectedTense,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [timeFilter, setTimeFilter] = useState<'all' | TimeCategory>('all');
  const [aspectFilter, setAspectFilter] = useState<'all' | AspectCategory>('all');
  const [activeModalTense, setActiveModalTense] = useState<TenseInfo | null>(() => {
    if (selectedTenseId) {
      return ALL_TENSES.find(t => t.id === selectedTenseId) || null;
    }
    return null;
  });
  const [formulaTab, setFormulaTab] = useState<'affirmative' | 'negative' | 'question'>('affirmative');

  // Update modal if prop changes
  React.useEffect(() => {
    if (selectedTenseId) {
      const found = ALL_TENSES.find(t => t.id === selectedTenseId);
      if (found) setActiveModalTense(found);
    }
  }, [selectedTenseId]);

  const filteredTenses = ALL_TENSES.filter(tense => {
    const matchesSearch =
      tense.nameAr.includes(searchTerm) ||
      tense.nameEn.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tense.shortSummaryAr.includes(searchTerm) ||
      tense.tags.some(tag => tag.includes(searchTerm));

    const matchesTime = timeFilter === 'all' || tense.timeCategory === timeFilter;
    const matchesAspect = aspectFilter === 'all' || tense.aspectCategory === aspectFilter;

    return matchesSearch && matchesTime && matchesAspect;
  });

  return (
    <div className="space-y-8" dir="rtl">
      {/* Header & Search Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-xl space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-black text-white flex items-center gap-2.5">
              <BookOpen className="w-7 h-7 text-indigo-400" />
              <span>موسوعة الأزمنة الـ12 (The 12 Tenses Explorer)</span>
            </h1>
            <p className="text-sm text-slate-400 mt-1">
              دليل شامل ومفصل لكل زمن مع السؤال الذهبي، التركيب، الخط الزمني، المقارنات، والأخطاء الشائعة.
            </p>
          </div>

          {/* Search Input */}
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="ابحث بالاسم أو الكلمة الدلالية..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full bg-slate-950/80 border border-slate-700/80 focus:border-indigo-500 rounded-2xl pr-10 pl-4 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none transition-all"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-4 pt-4 border-t border-slate-800/80">
          {/* Time Filter */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-400">الوقت:</span>
            <div className="flex gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800">
              {[
                { id: 'all', label: 'الكل' },
                { id: 'past', label: 'الماضي' },
                { id: 'present', label: 'الحاضر' },
                { id: 'future', label: 'المستقبل' },
              ].map(t => (
                <button
                  key={t.id}
                  onClick={() => {
                    playSound('click');
                    setTimeFilter(t.id as typeof timeFilter);
                  }}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                    timeFilter === t.id
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          {/* Aspect Filter */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-400">الوجه (Aspect):</span>
            <div className="flex flex-wrap gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800">
              {[
                { id: 'all', label: 'الكل' },
                { id: 'simple', label: 'Simple' },
                { id: 'continuous', label: 'Continuous' },
                { id: 'perfect', label: 'Perfect' },
                { id: 'perfect_continuous', label: 'Perfect Continuous' },
              ].map(a => (
                <button
                  key={a.id}
                  onClick={() => {
                    playSound('click');
                    setAspectFilter(a.id as typeof aspectFilter);
                  }}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                    aspectFilter === a.id
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {a.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Tenses Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredTenses.map(tense => (
          <div
            key={tense.id}
            onClick={() => {
              playSound('click');
              setActiveModalTense(tense);
            }}
            className="group relative bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-indigo-500/50 rounded-3xl p-6 cursor-pointer shadow-lg hover:shadow-2xl hover:shadow-indigo-500/10 transition-all duration-300 flex flex-col justify-between"
          >
            <div className="space-y-4">
              {/* Header Badge & Name */}
              <div className="flex items-start justify-between gap-2">
                <div className="space-y-1">
                  <span className="text-xs font-bold font-english text-indigo-400 block tracking-wide">
                    {tense.nameEn}
                  </span>
                  <h3 className="text-xl font-black text-white group-hover:text-indigo-300 transition-colors">
                    {tense.nameAr}
                  </h3>
                </div>
                <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-slate-800/90 text-slate-300 border border-slate-700/60 font-english">
                  {tense.timeCategory.toUpperCase()}
                </span>
              </div>

              {/* Formula Ribbon */}
              <div className="bg-slate-950/90 rounded-2xl p-2.5 border border-slate-800/80" dir="ltr">
                <span className="text-[10px] text-slate-500 block font-sans uppercase font-bold mb-0.5">Formula</span>
                <span className="text-xs font-bold text-emerald-300 font-mono block truncate">
                  {tense.formula.affirmative}
                </span>
              </div>

              {/* Summary */}
              <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">
                {tense.shortSummaryAr}
              </p>

              {/* Golden Question Sneak Peek */}
              <div className="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-3 flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <p className="text-[11px] text-amber-200/90 leading-snug line-clamp-2">
                  <strong className="text-amber-300 font-bold ml-1">السؤال الذهبي:</strong>
                  {tense.goldenQuestionAr}
                </p>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="flex items-center justify-between pt-4 mt-4 border-t border-slate-800/80">
              <span className="text-xs font-bold text-indigo-400 group-hover:text-indigo-300 flex items-center gap-1">
                عرض الشرح والمقارنات ←
              </span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  playSound('click');
                  onStartPractice(tense.id);
                }}
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-indigo-600/20 flex items-center gap-1"
              >
                <Play className="w-3 h-3 fill-current" />
                <span>تدرب</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredTenses.length === 0 && (
        <div className="text-center py-16 bg-slate-900/50 rounded-3xl border border-slate-800 space-y-3">
          <Layers className="w-12 h-12 text-slate-600 mx-auto" />
          <h3 className="text-lg font-bold text-slate-300">لم يتم العثور على أزمنة مطابقة</h3>
          <p className="text-xs text-slate-500">جرب تغيير كلمات البحث أو إزالة المرشحات لتصفح جميع الأزمنة الـ12.</p>
        </div>
      )}

      {/* Comprehensive Detail Modal */}
      {activeModalTense && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
          <div
            className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl space-y-8 my-8 max-h-[90vh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            dir="rtl"
          >
            {/* Modal Close Button */}
            <button
              onClick={() => {
                setActiveModalTense(null);
                if (onCloseSelectedTense) onCloseSelectedTense();
              }}
              className="absolute left-6 top-6 p-2 rounded-2xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header */}
            <div className="space-y-2 pr-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold font-english uppercase tracking-widest text-indigo-400 bg-indigo-500/10 border border-indigo-500/30 px-3 py-1 rounded-full">
                  {activeModalTense.nameEn}
                </span>
                <span className="text-xs text-slate-400 font-medium">
                  {activeModalTense.timeCategory === 'past' && 'الماضي'}
                  {activeModalTense.timeCategory === 'present' && 'الحاضر'}
                  {activeModalTense.timeCategory === 'future' && 'المستقبل'}
                </span>
              </div>
              <h2 className="text-3xl md:text-4xl font-black text-white">
                {activeModalTense.nameAr}
              </h2>
              <p className="text-sm md:text-base text-slate-300 leading-relaxed">
                {activeModalTense.detailedExplanationAr}
              </p>
            </div>

            {/* Golden Question Banner */}
            <div className="bg-gradient-to-r from-amber-500/20 via-slate-900 to-indigo-950/40 border border-amber-500/40 rounded-3xl p-5 md:p-6 space-y-2 shadow-lg">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                <HelpCircle className="w-5 h-5 text-amber-400 animate-pulse" />
                <span>السؤال الذهبي لاكتشاف هذا الزمن فوراً:</span>
              </div>
              <p className="text-lg md:text-xl font-bold text-white leading-relaxed">
                «{activeModalTense.goldenQuestionAr}»
              </p>
              <p className="text-xs text-amber-200/70">
                اطرح هذا السؤال على نفسك قبل اختيار أي خيار، وسيدلك المعنى مباشرة على هذا الزمن دون الحاجة لحفظ كلمات الإشارة وحدها!
              </p>
            </div>

            {/* Interactive Timeline Visualizer */}
            <div className="space-y-2">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-400" />
                <span>التمثيل البصري للزمن (Interactive Timeline):</span>
              </h3>
              <TimelineVisualizer timeline={activeModalTense.timeline} />
            </div>

            {/* Formula Breakdown Tabs */}
            <div className="bg-slate-950/80 border border-slate-800 rounded-3xl p-6 space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <h3 className="text-lg font-bold text-white">تركيب الجملة والقواعد (Formula & Structure)</h3>
                <div className="flex gap-1.5 bg-slate-900 p-1 rounded-2xl border border-slate-800">
                  <button
                    onClick={() => setFormulaTab('affirmative')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      formulaTab === 'affirmative' ? 'bg-emerald-600 text-white' : 'text-slate-400'
                    }`}
                  >
                    الإثبات (+)
                  </button>
                  <button
                    onClick={() => setFormulaTab('negative')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      formulaTab === 'negative' ? 'bg-rose-600 text-white' : 'text-slate-400'
                    }`}
                  >
                    النفي (-)
                  </button>
                  <button
                    onClick={() => setFormulaTab('question')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      formulaTab === 'question' ? 'bg-sky-600 text-white' : 'text-slate-400'
                    }`}
                  >
                    السؤال (?)
                  </button>
                </div>
              </div>

              {/* Active Formula Display */}
              <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800 text-center" dir="ltr">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wide block mb-1 font-english">
                  {formulaTab.toUpperCase()} PATTERN
                </span>
                <span className="text-base md:text-lg font-mono font-bold text-indigo-300">
                  {formulaTab === 'affirmative' && activeModalTense.formula.affirmative}
                  {formulaTab === 'negative' && activeModalTense.formula.negative}
                  {formulaTab === 'question' && activeModalTense.formula.question}
                </span>
              </div>

              {/* Rules Notes */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-400 block">ملاحظات وقواعد التركيب:</span>
                <ul className="space-y-2">
                  {activeModalTense.formula.rulesNotesAr.map((note, idx) => (
                    <li key={idx} className="text-xs text-slate-300 flex items-start gap-2 bg-slate-900/50 p-2.5 rounded-xl">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{note}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Examples with Speech */}
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Volume2 className="w-5 h-5 text-indigo-400" />
                <span>أمثلة تطبيقية ونطق صوتي:</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {activeModalTense.examples.map(ex => (
                  <div
                    key={ex.id}
                    className="bg-slate-950/70 border border-slate-800/80 rounded-2xl p-4 space-y-2.5 flex flex-col justify-between"
                  >
                    <div className="space-y-1.5" dir="ltr">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-bold text-slate-500 uppercase font-english">
                          {ex.type}
                        </span>
                        <button
                          onClick={() => speakEnglishText(ex.en)}
                          className="p-1 text-slate-400 hover:text-indigo-300 hover:bg-slate-800 rounded-lg transition-colors"
                          title="استمع للنطق"
                        >
                          <Volume2 className="w-4 h-4" />
                        </button>
                      </div>
                      <p className="text-sm font-bold text-white font-english">
                        {ex.en}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-800/60" dir="rtl">
                      <p className="text-xs text-emerald-300 font-medium">{ex.ar}</p>
                      {ex.contextNoteAr && (
                        <p className="text-[11px] text-slate-400 mt-1">💡 {ex.contextNoteAr}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Signal Words with Logic */}
            <div className="space-y-3">
              <h3 className="text-lg font-bold text-white">الكلمات الدلالية مع تفسير المنطق:</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {activeModalTense.signalWords.map((sig, idx) => (
                  <div key={idx} className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-3 flex flex-col justify-between">
                    <span className="text-xs font-bold text-amber-300 font-english" dir="ltr">{sig.word}</span>
                    <span className="text-[11px] text-slate-400 mt-1">{sig.noteAr}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* VS Comparisons */}
            {activeModalTense.vsComparisons.length > 0 && (
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <ArrowLeftRight className="w-5 h-5 text-indigo-400" />
                  <span>مقارنة مباشرة مع الأزمنة المشابهة:</span>
                </h3>

                {activeModalTense.vsComparisons.map((vs, idx) => (
                  <div key={idx} className="bg-slate-950/80 border border-slate-800 rounded-2xl p-5 space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                      <span className="text-sm font-bold text-indigo-300">مقارنة مع: {vs.targetTenseName}</span>
                      <span className="text-xs text-slate-400">{vs.coreDifferenceAr}</span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3" dir="ltr">
                      <div className="bg-slate-900/90 p-3 rounded-xl border border-slate-800">
                        <span className="text-[10px] text-slate-400 uppercase font-bold font-english">{vs.exampleA.tenseName}</span>
                        <p className="text-xs font-bold text-white font-english mt-1">{vs.exampleA.en}</p>
                        <p className="text-xs text-slate-400 mt-1" dir="rtl">{vs.exampleA.ar}</p>
                      </div>
                      <div className="bg-slate-900/90 p-3 rounded-xl border border-slate-800">
                        <span className="text-[10px] text-slate-400 uppercase font-bold font-english">{vs.exampleB.tenseName}</span>
                        <p className="text-xs font-bold text-white font-english mt-1">{vs.exampleB.en}</p>
                        <p className="text-xs text-slate-400 mt-1" dir="rtl">{vs.exampleB.ar}</p>
                      </div>
                    </div>

                    <p className="text-xs text-emerald-300 bg-emerald-500/10 border border-emerald-500/20 p-2.5 rounded-xl font-medium">
                      🎯 <strong className="ml-1">القاعدة الحاسمة:</strong> {vs.keyRuleAr}
                    </p>
                  </div>
                ))}
              </div>
            )}

            {/* Common Mistakes */}
            {activeModalTense.commonMistakes.length > 0 && (
              <div className="space-y-3">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-rose-400" />
                  <span>أخطاء شائعة وطريقة تجنبها:</span>
                </h3>

                <div className="space-y-3">
                  {activeModalTense.commonMistakes.map((mistake, idx) => (
                    <div key={idx} className="bg-rose-950/20 border border-rose-500/30 rounded-2xl p-4 space-y-2">
                      <div className="flex flex-wrap gap-4 items-center" dir="ltr">
                        <span className="text-xs font-bold text-rose-400 line-through font-english">❌ {mistake.mistakeEn}</span>
                        <span className="text-xs font-bold text-emerald-400 font-english">✅ {mistake.correctionEn}</span>
                      </div>
                      <p className="text-xs text-slate-300">{mistake.explanationAr}</p>
                      <p className="text-[11px] text-slate-400">💡 سبب الوقوع في الخطأ: {mistake.whyPeopleFailAr}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Action Launch Practice */}
            <div className="pt-6 border-t border-slate-800 flex flex-wrap items-center justify-between gap-4">
              <button
                onClick={() => {
                  setActiveModalTense(null);
                  if (onCloseSelectedTense) onCloseSelectedTense();
                }}
                className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-2xl transition-colors"
              >
                إغلاق
              </button>
              <button
                onClick={() => {
                  playSound('click');
                  const tId = activeModalTense.id;
                  setActiveModalTense(null);
                  if (onCloseSelectedTense) onCloseSelectedTense();
                  onStartPractice(tId);
                }}
                className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-sm font-bold rounded-2xl shadow-xl shadow-indigo-600/30 transition-all flex items-center gap-2"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>ابدأ تدريباً مكثفاً على {activeModalTense.nameAr}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
