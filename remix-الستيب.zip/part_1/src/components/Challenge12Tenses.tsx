import React, { useState } from 'react';
import { QuizQuestion, UserStats } from '../types';
import { QuizEngine } from './QuizEngine';
import { Flame } from 'lucide-react';
import { GAUNTLET_12_TENSES_50_QUESTIONS } from '../data/gauntlet12Questions50';

interface Challenge12TensesProps {
  userStats: UserStats;
  onUpdateStats: (newStats: UserStats) => void;
  onBackToMenu: () => void;
}

export const Challenge12Tenses: React.FC<Challenge12TensesProps> = ({
  userStats,
  onUpdateStats,
  onBackToMenu,
}) => {
  const [gauntletQuestions] = useState<QuizQuestion[]>(() => GAUNTLET_12_TENSES_50_QUESTIONS);

  return (
    <div className="space-y-6 animate-fade-in" dir="rtl">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-orange-950 via-slate-900 to-amber-950 border border-orange-500/40 rounded-3xl p-6 md:p-8 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 bg-orange-500/20 border border-orange-500/40 px-3 py-1 rounded-full text-orange-300 text-xs font-bold">
            <Flame className="w-4 h-4 text-orange-400 fill-current animate-pulse" />
            <span>تحدي الشمولية الكبرى</span>
          </div>
          <h1 className="text-2xl md:text-4xl font-black text-white">
            🔥 تحدي الأزمنة الـ12 (The 12 Tenses Gauntlet)
          </h1>
          <p className="text-xs md:text-sm text-slate-300 max-w-2xl">
            50 سؤالاً متتالياً يمر بك عبر كافة قواعد وأزمنة اللغة الإنجليزية لاختبار شمولية فهمك لجميع التراكيب.
          </p>
        </div>

        <button
          onClick={onBackToMenu}
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition-all shrink-0 cursor-pointer"
        >
          العودة للرئيسية
        </button>
      </div>

      {/* Gauntlet Quiz Engine */}
      <QuizEngine
        questions={gauntletQuestions}
        userStats={userStats}
        onUpdateStats={onUpdateStats}
        titleAr="🔥 تحدي الأزمنة الـ12 الشامل"
        subtitleAr="50 سؤالاً لاختبار شمولية استيعابك لكافة الأزمنة والتراكيب النحوية"
        onFinish={onBackToMenu}
      />
    </div>
  );
};
