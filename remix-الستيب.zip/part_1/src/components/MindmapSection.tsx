import React, { useState } from 'react';
import { MINDMAP_ASPECTS, CONFUSING_TENSES_DEEP_DIVE } from '../data/mindmapData';
import { ALL_TENSES } from '../data/tensesData';
import { playSound, speakEnglishText } from '../utils/audio';
import { Sparkles, Brain, ArrowLeftRight, Check, Volume2, Info } from 'lucide-react';
import { TenseId } from '../types';

interface MindmapSectionProps {
  onSelectTense: (tenseId: TenseId) => void;
  onStartPractice: (tenseId?: TenseId) => void;
}

export const MindmapSection: React.FC<MindmapSectionProps> = ({
  onSelectTense,
  onStartPractice,
}) => {
  const [selectedConfusingTense, setSelectedConfusingTense] = useState<string>('present_perfect');
  const [activeAspectTab, setActiveAspectTab] = useState<'all' | 'simple' | 'continuous' | 'perfect' | 'perfect_continuous'>('all');

  const currentDeepDive = CONFUSING_TENSES_DEEP_DIVE.find(t => t.tenseId === selectedConfusingTense) || CONFUSING_TENSES_DEEP_DIVE[0];

  return (
    <div className="space-y-10 animate-fade-in" dir="rtl">
      {/* Hero Header */}
      <div className="relative overflow-hidden bg-gradient-to-r from-indigo-950 via-slate-900 to-purple-950 border border-indigo-500/30 rounded-3xl p-6 md:p-10 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-4xl space-y-4">
          <div className="inline-flex items-center gap-2 bg-indigo-500/20 border border-indigo-400/30 px-3.5 py-1.5 rounded-full text-indigo-300 text-xs font-bold">
            <Brain className="w-4 h-4 text-indigo-400 animate-pulse" />
            <span>الخريطة الذهنية الكبرى للأزمنة الإنجليزية</span>
          </div>

          <h1 className="text-3xl md:text-5xl font-black text-white tracking-tight leading-tight">
            🧠 اربطها في عقلك
          </h1>

          <p className="text-slate-300 text-base md:text-lg leading-relaxed max-w-3xl">
            لا تحفظ القواعد كمعادلات جافة! السر الحقيقي لإتقان الإنجليزية يكمن في فهم <strong className="text-amber-300 font-bold">الأوجه الأربعة (Aspects)</strong> وكيف تتحرك عبر <strong className="text-cyan-300 font-bold">الأزمنة الثلاثة (الماضي، الحاضر، المستقبل)</strong>.
          </p>

          {/* 4 Core Pillars Quick Pills */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4">
            <div className="bg-slate-900/80 border border-emerald-500/40 rounded-2xl p-3.5 text-center shadow-lg">
              <span className="block text-emerald-400 font-bold text-sm mb-1 font-english">Simple</span>
              <span className="text-xs text-slate-300">حدث / عادة / حقيقة ثابته</span>
            </div>
            <div className="bg-slate-900/80 border border-cyan-500/40 rounded-2xl p-3.5 text-center shadow-lg">
              <span className="block text-cyan-400 font-bold text-sm mb-1 font-english">Continuous</span>
              <span className="text-xs text-slate-300">شيء مستمر قيد الحدوث</span>
            </div>
            <div className="bg-slate-900/80 border border-amber-500/40 rounded-2xl p-3.5 text-center shadow-lg">
              <span className="block text-amber-400 font-bold text-sm mb-1 font-english">Perfect</span>
              <span className="text-xs text-slate-300">حدث قبل نقطة زمنية</span>
            </div>
            <div className="bg-slate-900/80 border border-purple-500/40 rounded-2xl p-3.5 text-center shadow-lg">
              <span className="block text-purple-400 font-bold text-sm mb-1 font-english">Perfect Continuous</span>
              <span className="text-xs text-slate-300">استمرار لمدة حتى نقطة</span>
            </div>
          </div>
        </div>
      </div>

      {/* Section 1: The 4 Aspects Interactive Matrix */}
      <div className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-amber-400" />
              <span>مصفوفة الأوجه الأربعة عبر الزمن (3 Times × 4 Aspects)</span>
            </h2>
            <p className="text-sm text-slate-400 mt-1">
              انقر على أي خلية لاستكشاف تركيبتها ومثالها المنطقي
            </p>
          </div>

          {/* Aspect filter buttons */}
          <div className="flex flex-wrap gap-1.5 bg-slate-900/80 p-1.5 rounded-2xl border border-slate-800">
            {[
              { id: 'all', label: 'الكل (12 زمن)' },
              { id: 'simple', label: 'البسيط' },
              { id: 'continuous', label: 'المستمر' },
              { id: 'perfect', label: 'التام' },
              { id: 'perfect_continuous', label: 'التام المستمر' },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => {
                  playSound('click');
                  setActiveAspectTab(tab.id as typeof activeAspectTab);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  activeAspectTab === tab.id
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Matrix Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {MINDMAP_ASPECTS.filter(a => activeAspectTab === 'all' || a.aspect === activeAspectTab).map(node => (
            <div
              key={node.aspect}
              className="bg-slate-900/90 border border-slate-800 hover:border-slate-700 rounded-3xl p-5 shadow-xl transition-all duration-300 flex flex-col justify-between"
            >
              {/* Card Header */}
              <div className="space-y-3 pb-4 border-b border-slate-800/80">
                <div className="flex items-center justify-between">
                  <span className={`text-xs font-black uppercase px-2.5 py-1 rounded-lg bg-${node.color}-500/10 text-${node.color}-400 border border-${node.color}-500/30 font-english`}>
                    {node.nameEn}
                  </span>
                  <span className="text-xs text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded-full font-bold">
                    {node.mentalKeywordAr}
                  </span>
                </div>
                <h3 className="text-lg font-black text-white">{node.nameAr}</h3>
                <p className="text-xs text-slate-300 leading-relaxed min-h-[38px]">
                  {node.corePhilosophyAr}
                </p>
              </div>

              {/* 3 Times Breakdown */}
              <div className="space-y-3 my-4">
                {node.timeVariants.map(variant => (
                  <div
                    key={variant.tenseId}
                    onClick={() => {
                      playSound('click');
                      onSelectTense(variant.tenseId as TenseId);
                    }}
                    className="group bg-slate-950/70 hover:bg-indigo-950/40 border border-slate-800/80 hover:border-indigo-500/50 rounded-2xl p-3 cursor-pointer transition-all duration-200"
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs font-bold text-slate-300 group-hover:text-indigo-300 transition-colors">
                        {variant.time === 'past' && '⏮️ في الماضي'}
                        {variant.time === 'present' && '⚡ في الحاضر'}
                        {variant.time === 'future' && '🚀 في المستقبل'}
                      </span>
                      <span className="text-[10px] font-mono text-indigo-400 font-english bg-indigo-500/10 px-1.5 py-0.5 rounded border border-indigo-500/20">
                        {variant.formulaShort}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-400 mb-2 leading-relaxed">
                      {variant.mentalAnchorAr}
                    </p>

                    <div className="flex items-center justify-between bg-slate-900/90 rounded-xl p-2 border border-slate-800/60" dir="ltr">
                      <span className="text-xs font-semibold text-emerald-300 font-english">
                        {variant.sampleSentence}
                      </span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          speakEnglishText(variant.sampleSentence);
                        }}
                        className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
                        title="استمع للنطق"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Action */}
              <button
                onClick={() => {
                  playSound('click');
                  onStartPractice();
                }}
                className="w-full text-center text-xs text-indigo-400 hover:text-indigo-300 font-bold py-2 bg-indigo-500/10 hover:bg-indigo-500/20 rounded-xl transition-colors"
              >
                تدرب على أفعال {node.nameAr} ←
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Section 2: Deep Dive into the 4 Most Confusing Tenses */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl space-y-8">
        <div className="border-b border-slate-800 pb-6">
          <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 px-3 py-1 rounded-full text-amber-300 text-xs font-bold mb-2">
            <Info className="w-3.5 h-3.5" />
            <span>غرفة فك الالتباس الأكثر طلباً</span>
          </div>
          <h2 className="text-2xl md:text-3xl font-black text-white">
            🔍 تفكيك الأزمنة الأربعة الأكثر إرباكاً للطلاب
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            هنا نضع حداً للخلط الشائع بين (Present Perfect, Past Perfect, Future Continuous, Future Perfect Continuous).
          </p>

          {/* 4 Tenses Selector Tabs */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 mt-6">
            {CONFUSING_TENSES_DEEP_DIVE.map(dive => (
              <button
                key={dive.tenseId}
                onClick={() => {
                  playSound('click');
                  setSelectedConfusingTense(dive.tenseId);
                }}
                className={`p-3.5 rounded-2xl text-right transition-all border ${
                  selectedConfusingTense === dive.tenseId
                    ? 'bg-indigo-600 border-indigo-400 text-white shadow-xl shadow-indigo-600/30 scale-[1.02]'
                    : 'bg-slate-950/70 border-slate-800 text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                <span className="block text-xs font-english opacity-80">{dive.nameEn}</span>
                <span className="block text-sm font-bold mt-0.5">{dive.nameAr.split('(')[0]}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Selected Deep Dive Content */}
        <div className="space-y-6 animate-fade-in">
          {/* Mental Shortcut Banner */}
          <div className="bg-gradient-to-l from-amber-500/10 via-slate-900 to-indigo-950/40 border border-amber-500/30 rounded-2xl p-4 md:p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="space-y-1">
              <span className="text-xs font-bold text-amber-400 uppercase tracking-wide">
                المرساة الذهنية في عقلك (The Mental Anchor)
              </span>
              <p className="text-base md:text-lg font-bold text-white">
                {currentDeepDive.mentalShortcutAr}
              </p>
              <p className="text-xs text-slate-400">
                {currentDeepDive.whyItConfusesAr}
              </p>
            </div>

            <button
              onClick={() => {
                playSound('click');
                onSelectTense(currentDeepDive.tenseId as TenseId);
              }}
              className="shrink-0 px-4 py-2.5 bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-400/40 rounded-xl text-indigo-300 text-xs font-bold transition-all"
            >
              عرض الشرح الكامل للزمن ←
            </button>
          </div>

          {/* Temporal Visual Ribbon */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 text-center">
            <span className="text-xs text-slate-400 font-bold block mb-2">المسار الزمني في عقلك:</span>
            <div className="text-sm md:text-base font-mono text-cyan-300 bg-slate-900/90 py-2.5 px-4 rounded-xl border border-slate-800/80 inline-block max-w-full overflow-x-auto">
              {currentDeepDive.temporalVisualAr}
            </div>
          </div>

          {/* Formula Anatomy Breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-4">
              <span className="text-xs font-bold text-indigo-400 block mb-1">الفعل المساعد (Auxiliary)</span>
              <span className="text-sm font-bold text-white font-english">{currentDeepDive.formulaVisual.auxiliary}</span>
            </div>
            <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-4">
              <span className="text-xs font-bold text-purple-400 block mb-1">الفعل الرئيسي (Main Verb)</span>
              <span className="text-sm font-bold text-white font-english">{currentDeepDive.formulaVisual.mainVerb}</span>
            </div>
            <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-4">
              <span className="text-xs font-bold text-emerald-400 block mb-1">المنطق الرياضي</span>
              <span className="text-xs text-slate-300 leading-snug">{currentDeepDive.formulaVisual.logicAr}</span>
            </div>
          </div>

          {/* Head-to-Head Comparison Card */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <ArrowLeftRight className="w-5 h-5 text-indigo-400" />
              <span>المواجهة المباشرة مع الزمن المنافس</span>
            </h3>

            {currentDeepDive.matrixComparisons.map((comp, idx) => (
              <div key={idx} className="bg-slate-950/80 border border-slate-800/90 rounded-2xl p-5 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/70 pb-3">
                  <span className="text-sm font-bold text-amber-300">
                    ضد: {comp.rivalTenseName}
                  </span>
                  <span className="text-xs text-slate-400 bg-slate-800/90 px-3 py-1 rounded-full">
                    {comp.differentiatingClueAr}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3" dir="ltr">
                  {/* Rival sentence */}
                  <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 space-y-2">
                    <span className="text-[11px] font-bold text-slate-400 uppercase font-english">
                      {comp.rivalTenseName.split('(')[0]}
                    </span>
                    <p className="text-sm font-semibold text-slate-200 font-english">
                      {comp.rivalSentence}
                    </p>
                    <button
                      onClick={() => speakEnglishText(comp.rivalSentence)}
                      className="text-xs text-slate-400 hover:text-white flex items-center gap-1 mt-1"
                    >
                      <Volume2 className="w-3.5 h-3.5" /> استمع
                    </button>
                  </div>

                  {/* Target sentence */}
                  <div className="bg-indigo-950/40 border border-indigo-500/40 rounded-xl p-3.5 space-y-2">
                    <span className="text-[11px] font-bold text-indigo-400 uppercase font-english">
                      {currentDeepDive.nameEn}
                    </span>
                    <p className="text-sm font-bold text-emerald-300 font-english">
                      {comp.targetSentence}
                    </p>
                    <button
                      onClick={() => speakEnglishText(comp.targetSentence)}
                      className="text-xs text-indigo-300 hover:text-white flex items-center gap-1 mt-1"
                    >
                      <Volume2 className="w-3.5 h-3.5" /> استمع
                    </button>
                  </div>
                </div>

                {/* The Mind Shift */}
                <div className="bg-indigo-500/10 border border-indigo-500/20 rounded-xl p-3 flex items-start gap-2.5" dir="rtl">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <p className="text-xs leading-relaxed text-indigo-200">
                    <strong className="text-white font-bold ml-1">النقلة الفكرية الحاسمة:</strong>
                    {comp.theMindShiftAr}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
