import React, { useState } from 'react';
import { UserStats, TenseId, TimeCategory, TopicCategoryGroup } from '../types';
import { TWELVE_TENSES, ADDITIONAL_GRAMMAR_RULES, ALL_TENSES } from '../data/tensesData';
import { playSound } from '../utils/audio';
import {
  Sparkles,
  ArrowLeft,
  CheckCircle2,
  Brain,
  Clock,
  Zap,
  BookOpen,
  Layers,
  Search,
  Check,
  ListChecks,
} from 'lucide-react';

interface DashboardProps {
  userStats: UserStats;
  onNavigate: (view: string, payload?: any) => void;
  onSelectTense: (tenseId: TenseId) => void;
  onResetCourse?: () => void;
  onUpdateStats?: (newStats: UserStats) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  userStats,
  onNavigate,
  onSelectTense,
  onResetCourse,
  onUpdateStats,
}) => {
  const [activeTimeTab, setActiveTimeTab] = useState<'all' | TimeCategory>('all');
  const [grammarFilter, setGrammarFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Compute total mastered tenses and grammar rules
  const masteryValues = Object.values(userStats.tenseMastery || {}) as { attempted: number; correct: number; mastered: boolean }[];
  const masteredCount = masteryValues.filter(m => m.mastered).length;
  const totalTopicsCount = ALL_TENSES.length;
  const progressPercent = Math.round((masteredCount / totalTopicsCount) * 100);

  const timeColumns: { id: TimeCategory; labelAr: string; labelEn: string; color: string; bgBadge: string }[] = [
    { id: 'present', labelAr: 'الحاضر', labelEn: 'PRESENT', color: 'text-emerald-700 border-emerald-200', bgBadge: 'bg-emerald-50' },
    { id: 'past', labelAr: 'الماضي', labelEn: 'PAST', color: 'text-sky-700 border-sky-200', bgBadge: 'bg-sky-50' },
    { id: 'future', labelAr: 'المستقبل', labelEn: 'FUTURE', color: 'text-rose-700 border-rose-200', bgBadge: 'bg-rose-50' },
  ];

  const aspectMeanings = [
    { aspect: 'Simple (البسيط)', formula: 'حدث / عادة / حقيقة', icon: '⚡' },
    { aspect: 'Continuous (المستمر)', formula: 'شيء مستمر في لحظة معينة', icon: '⏳' },
    { aspect: 'Perfect (التام)', formula: 'حدث وقع قبل نقطة زمنية محددة', icon: '🎯' },
    { aspect: 'Perfect Continuous (التام المستمر)', formula: 'استمرار لمدة ممتدة حتى نقطة زمنية', icon: '🔄' },
  ];

  const grammarCategories: { id: string; labelAr: string; groupKey?: TopicCategoryGroup; icon: string }[] = [
    { id: 'all', labelAr: `جميع القواعد (${ADDITIONAL_GRAMMAR_RULES.length})`, icon: '📚' },
    { id: 'clauses_and_connectors', labelAr: 'الروابط وحروف الجر وعبارات الوصل', groupKey: 'clauses_and_connectors', icon: '🔗' },
    { id: 'verbs_and_structures', labelAr: 'المصادر والأفعال المركبة والسببية', groupKey: 'verbs_and_structures', icon: '🛠️' },
    { id: 'nouns_and_pronouns', labelAr: 'الأسماء والضمائر وأدوات التعريف والمحددات', groupKey: 'nouns_and_pronouns', icon: '📦' },
    { id: 'modals_and_voice', labelAr: 'الأفعال الناقصة والمبني للمجهول والمعلوم', groupKey: 'modals_and_voice', icon: '⚡' },
    { id: 'conditionals_and_speech', labelAr: 'الشرط والتمني والكلام المنقول', groupKey: 'conditionals_and_speech', icon: '🌲' },
    { id: 'modifiers_and_syntax', labelAr: 'الصفات والظروف وتوافق الجملة والترتيب', groupKey: 'modifiers_and_syntax', icon: '⚖️' },
    { id: 'advanced_grammar_mastery', labelAr: 'الأساليب المتقدمة: القلب والتوكيد والترقيم', groupKey: 'advanced_grammar_mastery', icon: '🎓' },
  ];

  // Filter additional grammar rules
  const filteredGrammarRules = ADDITIONAL_GRAMMAR_RULES.filter(rule => {
    const matchesGroup =
      grammarFilter === 'all' || rule.categoryGroup === grammarFilter;
    const matchesSearch =
      searchQuery.trim() === '' ||
      rule.nameAr.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rule.nameEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rule.shortSummaryAr.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (rule.tags && rule.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase())));

    return matchesGroup && matchesSearch;
  });

  return (
    <div className="max-w-5xl mx-auto space-y-10 animate-fade-in pb-12" dir="rtl">
      {/* ─── Hero Section (Minimal, Clear & Focused) ─── */}
      <section className="text-center space-y-6 pt-4 md:pt-6">
        <div className="inline-flex items-center gap-2 bg-indigo-50 border border-indigo-200 px-3.5 py-1.5 rounded-full text-indigo-700 text-xs font-bold font-mono shadow-2xs">
          <Clock className="w-3.5 h-3.5" />
          <span>افهم → شاهد → جرّب → قارن → أتقن</span>
        </div>

        <div className="space-y-3">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-black text-slate-900 tracking-tight">
            🕐 Tense & Grammar Master
          </h1>
          <p className="text-lg sm:text-xl text-slate-600 font-medium max-w-2xl mx-auto leading-relaxed">
            افهم الأزمنة الـ12 وجميع القواعد الإنجليزية الشاملة بدون لخبطة، عبر الفهم المنطقي والخط الزمني.
          </p>
        </div>

        {/* Two Main Actions Only */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 pt-2 max-w-md mx-auto">
          <button
            onClick={() => {
              playSound('click');
              onSelectTense('present_simple');
            }}
            className="w-full sm:w-auto px-8 py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold text-base shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2.5 transition-all hover:scale-[1.02] cursor-pointer"
          >
            <span>ابدأ التعلم</span>
            <ArrowLeft className="w-4 h-4" />
          </button>

          <button
            onClick={() => {
              playSound('click');
              onNavigate('practice');
            }}
            className="w-full sm:w-auto px-8 py-3.5 bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 rounded-2xl font-bold text-base flex items-center justify-center gap-2 transition-colors shadow-2xs cursor-pointer"
          >
            <Zap className="w-4 h-4 text-amber-500 fill-amber-500" />
            <span>اختبر نفسك</span>
          </button>
        </div>

        {/* Progress Snapshot & Central Checklist Box */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
          {/* Interactive Progress Box */}
          <button
            onClick={() => {
              playSound('click');
              onNavigate('checklist');
            }}
            className="inline-flex items-center gap-2.5 text-xs text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 hover:border-slate-300 px-4 py-2 rounded-2xl font-medium shadow-2xs transition-all cursor-pointer group"
            title="انقر لفتح صفحة قائمة القواعد والأزمنة (Checklist)"
          >
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0 group-hover:scale-125 transition-transform" />
            <span>
              نسبة إنجاز الدورة: <strong className="font-bold text-slate-900">{masteredCount}</strong> من <strong className="font-bold text-slate-900">{totalTopicsCount}</strong> ({progressPercent}%)
            </span>
            <div className="w-16 h-2 bg-slate-100 rounded-full overflow-hidden border border-slate-200/80">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 to-emerald-500 rounded-full transition-all duration-500"
                style={{ width: `${Math.max(progressPercent, 0)}%` }}
              />
            </div>
          </button>

          {/* Dedicated Central Checklist Trigger Button */}
          <button
            onClick={() => {
              playSound('click');
              onNavigate('checklist');
            }}
            className="inline-flex items-center gap-2 text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100/90 border border-indigo-200 px-4 py-2 rounded-2xl shadow-2xs hover:shadow-xs transition-all cursor-pointer"
            title="الانتقال لصفحة قائمة تدقيق القواعد والأزمنة (Checklist)"
          >
            <ListChecks className="w-4 h-4 text-indigo-600 shrink-0" />
            <span>قائمة تدقيق القواعد (Checklist)</span>
            <span className="bg-indigo-200/80 text-indigo-900 text-[10px] font-mono px-2 py-0.5 rounded-full font-bold">
              {masteredCount}/{totalTopicsCount} ✓
            </span>
          </button>
        </div>
      </section>

      {/* ─── Mental Aspect Meaning Formula (Core Anchor) ─── */}
      <section className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 space-y-3 shadow-xs">
        <div className="flex items-center gap-2 text-xs font-bold text-indigo-700 font-mono">
          <Brain className="w-4 h-4 text-indigo-600" />
          <span>المعادلة الذهنية لفهم أي زمن إنجليزي:</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {aspectMeanings.map((item, idx) => (
            <div key={idx} className="bg-slate-50/80 p-3.5 rounded-2xl border border-slate-200/80 space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
                <span>{item.icon}</span>
                <span>{item.aspect}</span>
              </div>
              <p className="text-xs text-slate-600 font-medium">
                = {item.formula}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* ─── The 12 Tenses Map (Clean 3-Column Matrix) ─── */}
      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-black text-slate-900">
                خريطة الأزمنة الـ12 (The 12 Tenses Map)
              </h2>
              <span className="bg-indigo-100 text-indigo-800 text-xs font-bold px-2.5 py-0.5 rounded-full font-mono">
                12 زمناً
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              الأزمنة الإنجليزية مقسمة حسب خط الزمن: الحاضر والماضي والمستقبل
            </p>
          </div>

          {/* Time Filter */}
          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200 self-start sm:self-auto">
            {(['all', 'present', 'past', 'future'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTimeTab(tab)}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  activeTimeTab === tab ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab === 'all' ? 'الكل' : tab === 'present' ? 'الحاضر' : tab === 'past' ? 'الماضي' : 'المستقبل'}
              </button>
            ))}
          </div>
        </div>

        {/* 3 Main Columns Matrix */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {timeColumns
            .filter(col => activeTimeTab === 'all' || activeTimeTab === col.id)
            .map(col => {
              const colTenses = TWELVE_TENSES.filter(t => t.timeCategory === col.id);

              return (
                <div
                  key={col.id}
                  className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-5 space-y-3.5 shadow-xs flex flex-col justify-between"
                >
                  {/* Column Header */}
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <div className="flex items-center gap-2">
                      <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${col.color} ${col.bgBadge} font-mono`}>
                        {col.labelEn}
                      </span>
                      <span className="text-sm font-black text-slate-900">{col.labelAr}</span>
                    </div>
                    <span className="text-[11px] text-slate-400 font-mono">4 أزمنة</span>
                  </div>

                  {/* 4 Aspect Cards inside this Time Column */}
                  <div className="space-y-2.5">
                    {colTenses.map(tense => {
                      const isMastered = userStats.tenseMastery?.[tense.id]?.mastered;

                      return (
                        <button
                          key={tense.id}
                          onClick={() => {
                            playSound('click');
                            onSelectTense(tense.id);
                          }}
                          className="w-full text-right p-3.5 rounded-2xl bg-slate-50/60 hover:bg-indigo-50/50 border border-slate-200 hover:border-indigo-300 transition-all group flex flex-col justify-between gap-2 cursor-pointer"
                        >
                          <div className="flex items-center justify-between w-full">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-sm text-slate-900 group-hover:text-indigo-700 transition-colors">
                                {tense.nameAr}
                              </span>
                              {isMastered && (
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                              )}
                            </div>
                            <span className="text-[10px] text-slate-500 font-english font-mono">
                              {tense.aspectCategory}
                            </span>
                          </div>

                          <p className="text-[11px] text-slate-600 line-clamp-1">
                            {tense.shortSummaryAr}
                          </p>

                          <div className="flex items-center justify-between text-[10px] text-slate-500 border-t border-slate-200/80 pt-1.5 font-english">
                            <span className="font-mono text-slate-600">{tense.nameEn}</span>
                            <span className="text-indigo-600 font-bold group-hover:translate-x-[-2px] transition-transform">
                              ابدأ الدرس ←
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
        </div>
      </section>

      {/* ─── 15 Comprehensive Grammar Topics ─── */}
      <section className="space-y-5 pt-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-black text-slate-900">
                موسوعة القواعد الإنجليزية الشاملة (15 Core Grammar Topics)
              </h2>
              <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2.5 py-0.5 rounded-full font-mono">
                15 قاعدة
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              الأفعال الناقصة، المبني للمجهول، الجمل الشرطية، الكلام المنقول، الأسماء وأدوات التعريف، والمقارنة والتفضيل
            </p>
          </div>

          {/* Search bar */}
          <div className="relative w-full md:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="ابحث عن أي قاعدة..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-xl pr-10 pl-4 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-indigo-500 shadow-2xs font-medium"
            />
          </div>
        </div>

        {/* Filter Categories Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {grammarCategories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setGrammarFilter(cat.id)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                grammarFilter === cat.id
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 hover:border-slate-300'
              }`}
            >
              <span>{cat.icon}</span>
              <span>{cat.labelAr}</span>
            </button>
          ))}
        </div>

        {/* 15 Rules Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredGrammarRules.map(rule => {
            const isMastered = userStats.tenseMastery?.[rule.id]?.mastered;

            return (
              <button
                key={rule.id}
                onClick={() => {
                  playSound('click');
                  onSelectTense(rule.id);
                }}
                className="w-full text-right p-4 rounded-3xl bg-white hover:bg-indigo-50/40 border border-slate-200 hover:border-indigo-300 transition-all group flex flex-col justify-between gap-3 shadow-xs hover:shadow-md cursor-pointer"
              >
                <div className="space-y-2 w-full">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-900 group-hover:text-indigo-700 transition-colors">
                        {rule.nameAr}
                      </span>
                      {isMastered && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      )}
                    </div>
                  </div>

                  <p className="text-xs font-bold text-indigo-600 font-english font-mono">
                    {rule.nameEn}
                  </p>

                  <p className="text-xs text-slate-600 leading-relaxed line-clamp-2">
                    {rule.shortSummaryAr}
                  </p>
                </div>

                {/* Formula Snippet & Footer */}
                <div className="w-full space-y-2 border-t border-slate-100 pt-2.5">
                  <div className="bg-slate-50 border border-slate-200/80 rounded-xl px-2.5 py-1.5 text-[11px] text-slate-700 font-mono font-medium truncate" dir="ltr">
                    {rule.formula.affirmative}
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
                    <span className="text-[11px] text-slate-400">
                      {rule.examples.length} أمثلة توضيحية
                    </span>
                    <span className="text-indigo-600 font-bold group-hover:translate-x-[-2px] transition-transform">
                      شرح وتدريب ←
                    </span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {filteredGrammarRules.length === 0 && (
          <div className="text-center py-10 bg-slate-50 border border-dashed border-slate-200 rounded-3xl space-y-2">
            <p className="text-sm font-bold text-slate-700">لم يتم العثور على قواعد تطابق بحثك</p>
            <p className="text-xs text-slate-500">جرب كتابة كلمة أخرى مثل "Modal" أو "Passive" أو "Conditionals"</p>
          </div>
        )}
      </section>
    </div>
  );
};
