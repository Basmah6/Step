import { QuizQuestion, TenseId, Difficulty } from '../types';
import { ALL_QUESTIONS } from './questionsBank';
import { ALL_TENSES } from './tensesData';
import { TENSE_QUESTIONS_DATA } from './tenseQuestionGenerators';
import { GRAMMAR_RULE_TEMPLATES } from './grammarRuleQuestionGenerators';
import { PRESENT_SIMPLE_EASY_50 } from './presentSimpleEasy50';
import { PRESENT_SIMPLE_MEDIUM_50 } from './presentSimpleMedium50';
import { PRESENT_SIMPLE_HARD_50 } from './presentSimpleHard50';
import { PRESENT_CONTINUOUS_EASY_50 } from './presentContinuousEasy50';
import { PRESENT_CONTINUOUS_MEDIUM_50 } from './presentContinuousMedium50';
import { PRESENT_CONTINUOUS_HARD_50 } from './presentContinuousHard50';
import { PRESENT_PERFECT_EASY_50 } from './presentPerfectEasy50';
import { PRESENT_PERFECT_MEDIUM_50 } from './presentPerfectMedium50';
import { PRESENT_PERFECT_HARD_50 } from './presentPerfectHard50';
import { PRESENT_PERFECT_CONTINUOUS_EASY_50 } from './presentPerfectContinuousEasy50';
import { PRESENT_PERFECT_CONTINUOUS_MEDIUM_50 } from './presentPerfectContinuousMedium50';
import { PRESENT_PERFECT_CONTINUOUS_HARD_50 } from './presentPerfectContinuousHard50';
import { PAST_SIMPLE_EASY_50 } from './pastSimpleEasy50';
import { PAST_SIMPLE_MEDIUM_50 } from './pastSimpleMedium50';
import { PAST_SIMPLE_HARD_50 } from './pastSimpleHard50';
import { PAST_CONTINUOUS_EASY_50 } from './pastContinuousEasy50';
import { PAST_CONTINUOUS_MEDIUM_50 } from './pastContinuousMedium50';
import { PAST_CONTINUOUS_HARD_50 } from './pastContinuousHard50';
import { PAST_PERFECT_EASY_50 } from './pastPerfectEasy50';
import { PAST_PERFECT_MEDIUM_50 } from './pastPerfectMedium50';
import { PAST_PERFECT_HARD_50 } from './pastPerfectHard50';
import { PAST_PERFECT_CONTINUOUS_EASY_50 } from './pastPerfectContinuousEasy50';
import { PAST_PERFECT_CONTINUOUS_MEDIUM_50 } from './pastPerfectContinuousMedium50';
import { PAST_PERFECT_CONTINUOUS_HARD_50 } from './pastPerfectContinuousHard50';
import { FUTURE_SIMPLE_EASY_50 } from './futureSimpleEasy50';
import { FUTURE_SIMPLE_MEDIUM_50 } from './futureSimpleMedium50';
import { FUTURE_SIMPLE_HARD_50 } from './futureSimpleHard50';
import { FUTURE_CONTINUOUS_EASY_50 } from './futureContinuousEasy50';
import { FUTURE_CONTINUOUS_MEDIUM_50 } from './futureContinuousMedium50';
import { FUTURE_CONTINUOUS_HARD_50 } from './futureContinuousHard50';
import { FUTURE_PERFECT_EASY_50 } from './futurePerfectEasy50';
import { FUTURE_PERFECT_MEDIUM_50 } from './futurePerfectMedium50';
import { FUTURE_PERFECT_HARD_50 } from './futurePerfectHard50';
import { FUTURE_PERFECT_CONTINUOUS_EASY_50 } from './futurePerfectContinuousEasy50';
import { FUTURE_PERFECT_CONTINUOUS_MEDIUM_50 } from './futurePerfectContinuousMedium50';
import { FUTURE_PERFECT_CONTINUOUS_HARD_50 } from './futurePerfectContinuousHard50';
import { MODAL_VERBS_EASY_30 } from './modalVerbsEasy30';
import { MODAL_VERBS_MEDIUM_30 } from './modalVerbsMedium30';
import { MODAL_VERBS_HARD_30 } from './modalVerbsHard30';
import { PASSIVE_VOICE_EASY_30 } from './passiveVoiceEasy30';
import { PASSIVE_VOICE_MEDIUM_30 } from './passiveVoiceMedium30';
import { PASSIVE_VOICE_HARD_30 } from './passiveVoiceHard30';
import { ACTIVE_VOICE_EASY_30 } from './activeVoiceEasy30';
import { ACTIVE_VOICE_MEDIUM_30 } from './activeVoiceMedium30';
import { ACTIVE_VOICE_HARD_30 } from './activeVoiceHard30';
import { MIXED_CONDITIONALS_EASY_30 } from './mixedConditionalsEasy30';
import { MIXED_CONDITIONALS_MEDIUM_30 } from './mixedConditionalsMedium30';
import { MIXED_CONDITIONALS_HARD_30 } from './mixedConditionalsHard30';
import { CONDITIONALS_EASY_30 } from './conditionalsEasy30';
import { CONDITIONALS_MEDIUM_30 } from './conditionalsMedium30';
import { CONDITIONALS_HARD_30 } from './conditionalsHard30';
import { WISH_IF_ONLY_EASY_30 } from './wishIfOnlyEasy30';
import { WISH_IF_ONLY_MEDIUM_30 } from './wishIfOnlyMedium30';
import { WISH_IF_ONLY_HARD_30 } from './wishIfOnlyHard30';
import { REPORTED_SPEECH_EASY_30 } from './reportedSpeechEasy30';
import { REPORTED_SPEECH_MEDIUM_30 } from './reportedSpeechMedium30';
import { REPORTED_SPEECH_HARD_30 } from './reportedSpeechHard30';
import { DIRECT_SPEECH_EASY_30 } from './directSpeechEasy30';
import { DIRECT_SPEECH_MEDIUM_30 } from './directSpeechMedium30';
import { DIRECT_SPEECH_HARD_30 } from './directSpeechHard30';
import { QUESTION_TAGS_EASY_30 } from './questionTagsEasy30';
import { QUESTION_TAGS_MEDIUM_30 } from './questionTagsMedium30';
import { QUESTION_TAGS_HARD_30 } from './questionTagsHard30';
import { SUBJECT_VERB_AGREEMENT_EASY_30 } from './subjectVerbAgreementEasy30';
import { SUBJECT_VERB_AGREEMENT_MEDIUM_30 } from './subjectVerbAgreementMedium30';
import { SUBJECT_VERB_AGREEMENT_HARD_30 } from './subjectVerbAgreementHard30';
import { ARTICLES_EASY_30 } from './articlesEasy30';
import { ARTICLES_MEDIUM_30 } from './articlesMedium30';
import { ARTICLES_HARD_30 } from './articlesHard30';
import { COUNTABLE_NOUNS_EASY_30 } from './countableNounsEasy30';
import { COUNTABLE_NOUNS_MEDIUM_30 } from './countableNounsMedium30';
import { COUNTABLE_NOUNS_HARD_30 } from './countableNounsHard30';
import { QUANTIFIERS_EASY_30 } from './quantifiersEasy30';
import { QUANTIFIERS_MEDIUM_30 } from './quantifiersMedium30';
import { QUANTIFIERS_HARD_30 } from './quantifiersHard30';
import { COMPARATIVES_EASY_30 } from './comparativesEasy30';
import { COMPARATIVES_MEDIUM_30 } from './comparativesMedium30';
import { COMPARATIVES_HARD_30 } from './comparativesHard30';
import { ADJECTIVES_ADVERBS_EASY_30 } from './adjectivesAdverbsEasy30';
import { ADJECTIVES_ADVERBS_MEDIUM_30 } from './adjectivesAdverbsMedium30';
import { ADJECTIVES_ADVERBS_HARD_30 } from './adjectivesAdverbsHard30';
import { PREPOSITIONS_EASY_30 } from './prepositionsEasy30';
import { PREPOSITIONS_MEDIUM_30 } from './prepositionsMedium30';
import { PREPOSITIONS_HARD_30 } from './prepositionsHard30';
import { CONJUNCTIONS_EASY_30 } from './conjunctionsEasy30';
import { CONJUNCTIONS_MEDIUM_30 } from './conjunctionsMedium30';
import { CONJUNCTIONS_HARD_30 } from './conjunctionsHard30';
import { GERUNDS_EASY_30 } from './gerundsEasy30';
import { GERUNDS_MEDIUM_30 } from './gerundsMedium30';
import { GERUNDS_HARD_30 } from './gerundsHard30';
import { PARTICIPLES_EASY_30 } from './participlesEasy30';
import { PARTICIPLES_MEDIUM_30 } from './participlesMedium30';
import { PARTICIPLES_HARD_30 } from './participlesHard30';
import { RELATIVE_CLAUSES_EASY_30 } from './relativeClausesEasy30';
import { RELATIVE_CLAUSES_MEDIUM_30 } from './relativeClausesMedium30';
import { RELATIVE_CLAUSES_HARD_30 } from './relativeClausesHard30';
import { NOUN_CLAUSES_EASY_30 } from './nounClausesEasy30';
import { NOUN_CLAUSES_MEDIUM_30 } from './nounClausesMedium30';
import { NOUN_CLAUSES_HARD_30 } from './nounClausesHard30';
import { ADVERB_CLAUSES_EASY_30 } from './adverbClausesEasy30';
import { ADVERB_CLAUSES_MEDIUM_30 } from './adverbClausesMedium30';
import { ADVERB_CLAUSES_HARD_30 } from './adverbClausesHard30';
import { PHRASAL_VERBS_EASY_30 } from './phrasalVerbsEasy30';
import { PHRASAL_VERBS_MEDIUM_30 } from './phrasalVerbsMedium30';
import { PHRASAL_VERBS_HARD_30 } from './phrasalVerbsHard30';
import { SUBJECT_OBJECT_PRONOUNS_EASY_30 } from './subjectObjectPronounsEasy30';
import { SUBJECT_OBJECT_PRONOUNS_MEDIUM_30 } from './subjectObjectPronounsMedium30';
import { SUBJECT_OBJECT_PRONOUNS_HARD_30 } from './subjectObjectPronounsHard30';
import { POSSESSIVES_EASY_30 } from './possessivesEasy30';
import { POSSESSIVES_MEDIUM_30 } from './possessivesMedium30';
import { POSSESSIVES_HARD_30 } from './possessivesHard30';
import { DEMONSTRATIVES_EASY_30 } from './demonstrativesEasy30';
import { DEMONSTRATIVES_MEDIUM_30 } from './demonstrativesMedium30';
import { DEMONSTRATIVES_HARD_30 } from './demonstrativesHard30';
import { INDEFINITE_PRONOUNS_EASY_30 } from './indefinitePronounsEasy30';
import { INDEFINITE_PRONOUNS_MEDIUM_30 } from './indefinitePronounsMedium30';
import { INDEFINITE_PRONOUNS_HARD_30 } from './indefinitePronounsHard30';
import { DETERMINERS_EASY_30 } from './determinersEasy30';
import { DETERMINERS_MEDIUM_30 } from './determinersMedium30';
import { DETERMINERS_HARD_30 } from './determinersHard30';
import { NEGATION_EASY_30 } from './negationEasy30';
import { NEGATION_MEDIUM_30 } from './negationMedium30';
import { NEGATION_HARD_30 } from './negationHard30';
import { IMPERATIVES_EASY_30 } from './imperativesEasy30';
import { IMPERATIVES_MEDIUM_30 } from './imperativesMedium30';
import { IMPERATIVES_HARD_30 } from './imperativesHard30';
import { THERE_IS_ARE_EASY_30 } from './thereIsAreEasy30';
import { THERE_IS_ARE_MEDIUM_30 } from './thereIsAreMedium30';
import { THERE_IS_ARE_HARD_30 } from './thereIsAreHard30';
import { USED_TO_EASY_30 } from './usedToEasy30';
import { USED_TO_MEDIUM_30 } from './usedToMedium30';
import { USED_TO_HARD_30 } from './usedToHard30';
import { HAVE_GOT_EASY_30 } from './haveGotEasy30';
import { HAVE_GOT_MEDIUM_30 } from './haveGotMedium30';
import { CAUSATIVE_EASY_30 } from './causativeEasy30';
import { CAUSATIVE_MEDIUM_30 } from './causativeMedium30';
import { CAUSATIVE_HARD_30 } from './causativeHard30';
import { SO_NEITHER_EASY_30 } from './soNeitherEasy30';
import { SO_NEITHER_MEDIUM_30 } from './soNeitherMedium30';
import { SO_NEITHER_HARD_30 } from './soNeitherHard30';
import { ELLIPSIS_SUBSTITUTION_EASY_30 } from './ellipsisSubstitutionEasy30';
import { ELLIPSIS_SUBSTITUTION_MEDIUM_30 } from './ellipsisSubstitutionMedium30';
import { ELLIPSIS_SUBSTITUTION_HARD_30 } from './ellipsisSubstitutionHard30';
import { PARALLEL_STRUCTURE_EASY_30 } from './parallelStructureEasy30';
import { PARALLEL_STRUCTURE_MEDIUM_30 } from './parallelStructureMedium30';
import { PARALLEL_STRUCTURE_HARD_30 } from './parallelStructureHard30';
import { WORD_ORDER_EASY_30 } from './wordOrderEasy30';
import { WORD_ORDER_MEDIUM_30 } from './wordOrderMedium30';
import { WORD_ORDER_HARD_30 } from './wordOrderHard30';
import { INVERSION_EASY_30 } from './inversionEasy30';
import { INVERSION_MEDIUM_30 } from './inversionMedium30';
import { INVERSION_HARD_30 } from './inversionHard30';
import { CLEFT_EASY_30 } from './cleftEasy30';
import { CLEFT_MEDIUM_30 } from './cleftMedium30';
import { CLEFT_HARD_30 } from './cleftHard30';
import { EMPHASIS_EASY_30 } from './emphasisEasy30';
import { EMPHASIS_MEDIUM_30 } from './emphasisMedium30';
import { EMPHASIS_HARD_30 } from './emphasisHard30';
import { PUNCTUATION_EASY_30 } from './punctuationEasy30';
import { PUNCTUATION_MEDIUM_30 } from './punctuationMedium30';
import { PUNCTUATION_HARD_30 } from './punctuationHard30';
import { COMMON_ERRORS_EASY_30 } from './commonErrorsEasy30';
import { COMMON_ERRORS_MEDIUM_30 } from './commonErrorsMedium30';
import { COMMON_ERRORS_HARD_30 } from './commonErrorsHard30';
import { GAUNTLET_12_TENSES_50_QUESTIONS } from './gauntlet12Questions50';

// Context subjects for rich variation
const SUBJECT_PROFILES = [
  { en: 'The aerospace engineer', ar: 'مهندس الطيران والفضاء', isSingular: true, pronoun: 'he' },
  { en: 'Marine biologists', ar: 'علماء الأحياء البحرية', isSingular: false, pronoun: 'they' },
  { en: 'Dr. Layla', ar: 'الدكتورة ليلى', isSingular: true, pronoun: 'she' },
  { en: 'Our software development team', ar: 'فريق تطوير البرمجيات لدينا', isSingular: true, pronoun: 'it' },
  { en: 'The university students', ar: 'طلاب الجامعة', isSingular: false, pronoun: 'they' },
  { en: 'Professor Omar', ar: 'البروفيسور عمر', isSingular: true, pronoun: 'he' },
  { en: 'International diplomats', ar: 'الدبلوماسيون الدوليون', isSingular: false, pronoun: 'they' },
  { en: 'The chief architect', ar: 'كبير المهندسين المعماريين', isSingular: true, pronoun: 'he' },
  { en: 'Astronomers', ar: 'علماء الفلك', isSingular: false, pronoun: 'they' },
  { en: 'The young pianist', ar: 'عازفة البيانو الشابة', isSingular: true, pronoun: 'she' },
  { en: 'Environmental researchers', ar: 'باحثو البيئة', isSingular: false, pronoun: 'they' },
  { en: 'The medical specialist', ar: 'الأخصائي الطبي', isSingular: true, pronoun: 'he' },
  { en: 'Archaeologists in Luxor', ar: 'علماء الآثار في الأقصر', isSingular: false, pronoun: 'they' },
  { en: 'The executive director', ar: 'المدير التنفيذي', isSingular: true, pronoun: 'she' },
  { en: 'Robotics engineers', ar: 'مهندسو الروبوتات', isSingular: false, pronoun: 'they' },
  { en: 'The experienced pilot', ar: 'الطيار الخبير', isSingular: true, pronoun: 'he' },
  { en: 'The laboratory chemist', ar: 'كيميائي المختبر', isSingular: true, pronoun: 'she' },
  { en: 'Cybersecurity analysts', ar: 'محللو الأمن السيبراني', isSingular: false, pronoun: 'they' },
  { en: 'The head chef', ar: 'رئيس الطهاة', isSingular: true, pronoun: 'he' },
  { en: 'Meteorologists', ar: 'خبراء الأرصاد الجوية', isSingular: false, pronoun: 'they' },
  { en: 'The wildlife photographer', ar: 'مصور الحياة البرية', isSingular: true, pronoun: 'she' },
  { en: 'Civil engineering consultants', ar: 'استشاريو الهندسة المدنية', isSingular: false, pronoun: 'they' },
  { en: 'The data scientist', ar: 'عالم البيانات', isSingular: true, pronoun: 'he' },
  { en: 'Solar energy technicians', ar: 'فنيو الطاقة الشمسية', isSingular: false, pronoun: 'they' },
  { en: 'The linguist', ar: 'عالم اللغويات', isSingular: true, pronoun: 'she' },
  { en: 'Museum curators', ar: 'أمناء المتاحف', isSingular: false, pronoun: 'they' },
  { en: 'The neurologist', ar: 'طبيب الأعصاب', isSingular: true, pronoun: 'he' },
  { en: 'Urban infrastructure planners', ar: 'مخططو البنية التحتية الحضرية', isSingular: false, pronoun: 'they' },
  { en: 'The historical novelist', ar: 'الروائي التاريخي', isSingular: true, pronoun: 'she' },
  { en: 'Renewable power innovators', ar: 'مبتكرو الطاقة المتجددة', isSingular: false, pronoun: 'they' },
];

interface DomainAction {
  baseVerb: string;
  v_s: string;
  v_ing: string;
  v_ed: string;
  v_3: string;
  objectContext: string;
  meaningAr: string;
}

const DOMAIN_ACTIONS: DomainAction[] = [
  { baseVerb: 'analyze', v_s: 'analyzes', v_ing: 'analyzing', v_ed: 'analyzed', v_3: 'analyzed', objectContext: 'complex genomic sequences in the laboratory', meaningAr: 'يحلل السلاسل الجينية المعقدة' },
  { baseVerb: 'design', v_s: 'designs', v_ing: 'designing', v_ed: 'designed', v_3: 'designed', objectContext: 'eco-friendly residential skyscrapers', meaningAr: 'يصمم ناطحات سحاب سكنية صديقة للبيئة' },
  { baseVerb: 'publish', v_s: 'publishes', v_ing: 'publishing', v_ed: 'published', v_3: 'published', objectContext: 'groundbreaking academic papers in prestigious journals', meaningAr: 'ينشر أبحاثاً أكاديمية رائدة' },
  { baseVerb: 'monitor', v_s: 'monitors', v_ing: 'monitoring', v_ed: 'monitored', v_3: 'monitored', objectContext: 'deep-sea biodiversity and coral reef ecosystems', meaningAr: 'يراقب التنوع البيولوجي في أعماق البحار' },
  { baseVerb: 'develop', v_s: 'develops', v_ing: 'developing', v_ed: 'developed', v_3: 'developed', objectContext: 'artificial intelligence diagnostic algorithms', meaningAr: 'يطور خوارزميات تشخيص ذكية' },
  { baseVerb: 'conduct', v_s: 'conducts', v_ing: 'conducting', v_ed: 'conducted', v_3: 'conducted', objectContext: 'thorough clinical safety trials', meaningAr: 'يجري تجارب سريرية دقيقة للسلامة' },
  { baseVerb: 'explore', v_s: 'explores', v_ing: 'exploring', v_ed: 'explored', v_3: 'explored', objectContext: 'uncharted subterranean cave networks', meaningAr: 'يستكشف شبكات كهوف غير مستكشفة' },
  { baseVerb: 'evaluate', v_s: 'evaluates', v_ing: 'evaluating', v_ed: 'evaluated', v_3: 'evaluated', objectContext: 'renewable solar energy efficiency metrics', meaningAr: 'يقيم مقاييس كفاءة الطاقة الشمسية' },
  { baseVerb: 'examine', v_s: 'examines', v_ing: 'examining', v_ed: 'examined', v_3: 'examined', objectContext: 'ancient papyrus scrolls under multispectral imaging', meaningAr: 'يفحص مخطوطات البردي القديمة' },
  { baseVerb: 'optimize', v_s: 'optimizes', v_ing: 'optimizing', v_ed: 'optimized', v_3: 'optimized', objectContext: 'network bandwidth and quantum computing speed', meaningAr: 'يحسن كفاءة الشبكة وسرعة الحوسبة' },
  { baseVerb: 'investigate', v_s: 'investigates', v_ing: 'investigating', v_ed: 'investigated', v_3: 'investigated', objectContext: 'atmospheric climate patterns in polar regions', meaningAr: 'يتحرى عن أنماط المناخ الجوي في المناطق القطبية' },
  { baseVerb: 'construct', v_s: 'constructs', v_ing: 'constructing', v_ed: 'constructed', v_3: 'constructed', objectContext: 'modern suspension bridges across the river', meaningAr: 'يشيد جسوراً معلقة حديثة' },
  { baseVerb: 'translate', v_s: 'translates', v_ing: 'translating', v_ed: 'translated', v_3: 'translated', objectContext: 'classical philosophical treatises into Arabic', meaningAr: 'يترجم الأطروحات الفلسفية الكلاسيكية' },
  { baseVerb: 'inspect', v_s: 'inspects', v_ing: 'inspecting', v_ed: 'inspected', v_3: 'inspected', objectContext: 'aircraft turbine components before long flights', meaningAr: 'يفحص توربينات الطائرات قبل الرحلات الطويلة' },
  { baseVerb: 'synthesize', v_s: 'synthesizes', v_ing: 'synthesizing', v_ed: 'synthesized', v_3: 'synthesized', objectContext: 'novel organic compounds for therapeutic use', meaningAr: 'يركب مركبات عضوية جديدة للاستخدام العلاجي' },
  { baseVerb: 'program', v_s: 'programs', v_ing: 'programming', v_ed: 'programmed', v_3: 'programmed', objectContext: 'autonomous robotic rovers for space missions', meaningAr: 'يبرمج مركبات روبوتية ذاتية القيادة' },
  { baseVerb: 'test', v_s: 'tests', v_ing: 'testing', v_ed: 'tested', v_3: 'tested', objectContext: 'water purity and mineral concentration in aquifers', meaningAr: 'يختبر نقاء المياه وتركيز المعادن' },
  { baseVerb: 'coordinate', v_s: 'coordinates', v_ing: 'coordinating', v_ed: 'coordinated', v_3: 'coordinated', objectContext: 'international humanitarian relief operations', meaningAr: 'ينسق عمليات الإغاثة الإنسانية الدولية' },
  { baseVerb: 'record', v_s: 'records', v_ing: 'recording', v_ed: 'recorded', v_3: 'recorded', objectContext: 'seismic frequency signals during volcanic activity', meaningAr: 'يسجل إشارات التردد الزلزالي' },
  { baseVerb: 'present', v_s: 'presents', v_ing: 'presenting', v_ed: 'presented', v_3: 'presented', objectContext: 'the annual innovation keynote to thousands of delegates', meaningAr: 'يقدم الخطاب الرئيسي للابتكار السنوي' },
  { baseVerb: 'calculate', v_s: 'calculates', v_ing: 'calculating', v_ed: 'calculated', v_3: 'calculated', objectContext: 'orbital trajectories for deep-space satellites', meaningAr: 'يحسب مسارات المدار للأقمار الصناعية' },
  { baseVerb: 'conserve', v_s: 'conserves', v_ing: 'conserving', v_ed: 'conserved', v_3: 'conserved', objectContext: 'endangered flora and fauna in national reserves', meaningAr: 'يحافظ على النباتات والحيوانات المهددة بالانقراض' },
  { baseVerb: 'review', v_s: 'reviews', v_ing: 'reviewing', v_ed: 'reviewed', v_3: 'reviewed', objectContext: 'confidential legal compliance documents', meaningAr: 'يراجع وثائق الامتثال القانوني السرية' },
  { baseVerb: 'upgrade', v_s: 'upgrades', v_ing: 'upgrading', v_ed: 'upgraded', v_3: 'upgraded', objectContext: 'cybersecurity firewall protocols across all servers', meaningAr: 'يرقي بروتوكولات جدران الحماية السيبرانية' },
  { baseVerb: 'supervise', v_s: 'supervises', v_ing: 'supervising', v_ed: 'supervised', v_3: 'supervised', objectContext: 'postgraduate doctoral candidates at the institute', meaningAr: 'يشرف على مرشحي الدكتوراه في المعهد' },
];

/**
 * Generate procedurally distinct, natural English grammar questions for any tense & level
 */
function generateProceduralTenseQuestion(
  tenseId: TenseId,
  level: 'easy' | 'medium' | 'hard' | 'gauntlet_12',
  index: number,
  tenseMeta: any
): QuizQuestion {
  const subject = SUBJECT_PROFILES[index % SUBJECT_PROFILES.length];
  const action = DOMAIN_ACTIONS[(index * 3 + 7) % DOMAIN_ACTIONS.length];

  let sentenceWithBlank = '';
  let correct = '';
  let distractors: string[] = [];
  let promptAr = '';
  let whyCorrectAr = '';
  let temporalAr = '';

  const verbCorrectSingular = action.v_s;
  const verbCorrectPlural = action.baseVerb;

  switch (tenseId) {
    case 'present_simple':
      if (level === 'easy') {
        const timeWord = (index % 2 === 0) ? 'every day' : 'regularly every week';
        sentenceWithBlank = subject.isSingular
          ? `${subject.en} ___ ${action.objectContext} ${timeWord}.`
          : `${subject.en} ___ ${action.objectContext} ${timeWord}.`;
        correct = subject.isSingular ? verbCorrectSingular : verbCorrectPlural;
        distractors = subject.isSingular
          ? [action.baseVerb, `is ${action.v_ing}`, action.v_ed]
          : [action.v_s, `are ${action.v_ing}`, action.v_ed];
        promptAr = `اختر تصريف الفعل المناسب مع الفاعل (${subject.ar}) للتعبير عن روتين منتظم:`;
        whyCorrectAr = subject.isSingular
          ? `مع الفاعل المفرد (${subject.en}) نستخدم صيغة الفعل المنتهية بـ s في المضارع البسيط.`
          : `مع فاعل الجمع (${subject.en}) نستخدم مصدر الفعل بدون إضافات.`;
        temporalAr = 'روتين دوري متكرر بانتظام.';
      } else if (level === 'medium') {
        sentenceWithBlank = `According to the official schedule, ${subject.en} ___ ${action.objectContext} tomorrow morning.`;
        correct = subject.isSingular ? verbCorrectSingular : verbCorrectPlural;
        distractors = [`will ${action.baseVerb}`, `is ${action.v_ing}`, `has ${action.v_3}`];
        promptAr = `اختر الفعل المناسب وفق جدول المواعيد والخطط الرسمية الثابتة (Official Timetable):`;
        whyCorrectAr = `المواعيد والجداول الزمنية الرسمية والمخططة بدقة تُصاغ بالمضارع البسيط حتى لو كانت في المستقبل.`;
        temporalAr = 'جدول مواعيد رسمي ثابت.';
      } else {
        sentenceWithBlank = `If ${subject.en} ___ ${action.objectContext}, the entire research project succeeds.`;
        correct = subject.isSingular ? verbCorrectSingular : verbCorrectPlural;
        distractors = [`will ${action.baseVerb}`, `is ${action.v_ing}`, action.v_ed];
        promptAr = `تحدي بدون كلمات دلالية: اختر الفعل المناسب في جملة الشرطية الصفرية/الأولى:`;
        whyCorrectAr = `في جملة الشرط (If clause) نستخدم المضارع البسيط للتعبير عن الشرط الحتمي.`;
        temporalAr = 'علاقة شرطية سببية قائمة.';
      }
      break;

    case 'present_continuous':
      if (level === 'easy') {
        sentenceWithBlank = subject.isSingular
          ? `Right now, ${subject.en} ___ ${action.objectContext}.`
          : `Right now, ${subject.en} ___ ${action.objectContext}.`;
        correct = subject.isSingular ? `is ${action.v_ing}` : `are ${action.v_ing}`;
        distractors = subject.isSingular
          ? [action.v_s, action.baseVerb, action.v_ed]
          : [action.baseVerb, action.v_s, action.v_ed];
        promptAr = `اختر الفعل المعبر عن حدث يقع في هذه اللحظة بالذات (Right now):`;
        whyCorrectAr = `الحدث الجاري في لحظة التحدث يتطلب (is/are + verb-ing).`;
        temporalAr = 'حدث مستمر في نقطة الحاضر الآن.';
      } else if (level === 'medium') {
        sentenceWithBlank = `This semester, ${subject.en} ___ ${action.objectContext} as part of a temporary initiative.`;
        correct = subject.isSingular ? `is ${action.v_ing}` : `are ${action.v_ing}`;
        distractors = [subject.isSingular ? action.v_s : action.baseVerb, action.v_ed, `has ${action.v_3}`];
        promptAr = `اختر الفعل المعبر عن وضع ومبادرة مؤقتة لهذا الفصل (Temporary Project):`;
        whyCorrectAr = `المواقف والأنشطة المؤقتة المحدودة بفترة زمنية معينة تصاغ بالمضارع المستمر.`;
        temporalAr = 'نشاط مؤقت له بداية ونهاية.';
      } else {
        sentenceWithBlank = `Why ___ ${subject.en} always ___ ${action.objectContext} during emergency meetings?!`;
        correct = subject.isSingular ? `is / ${action.v_ing}` : `are / ${action.v_ing}`;
        distractors = subject.isSingular ? [`does / ${action.baseVerb}`, `has / ${action.v_3}`, `did / ${action.baseVerb}`] : [`do / ${action.baseVerb}`, `have / ${action.v_3}`, `did / ${action.baseVerb}`];
        promptAr = `اختر الصيغة المعبرة عن الانزعاج والشكوى من تكرار تصرف مستمر مع (always):`;
        whyCorrectAr = `استخدام always مع المضارع المستمر يعبر عن الضيق والانزعاج من تكرار تصرف في الحاضر.`;
        temporalAr = 'سلوك متكرر يثير الاستياء في الحاضر.';
      }
      break;

    case 'present_perfect':
      if (level === 'easy') {
        sentenceWithBlank = subject.isSingular
          ? `${subject.en} has already ___ ${action.objectContext}.`
          : `${subject.en} have already ___ ${action.objectContext}.`;
        correct = action.v_3;
        distractors = [action.baseVerb, action.v_ing, action.v_s];
        promptAr = `اختر التصريف الصحيح للفعل بعد (has/have already) للتعبير عن إنجاز مكتمل:`;
        whyCorrectAr = `بعد have / has نستخدم دائماً التصريف الثالث للفعل (V3).`;
        temporalAr = 'إنجاز مكتمل ونتيجته حاضرة.';
      } else if (level === 'medium') {
        sentenceWithBlank = subject.isSingular
          ? `${subject.en} ___ ${action.objectContext} since early 2021.`
          : `${subject.en} ___ ${action.objectContext} since early 2021.`;
        correct = subject.isSingular ? `has ${action.v_3}` : `have ${action.v_3}`;
        distractors = [action.v_ed, subject.isSingular ? action.v_s : action.baseVerb, `is ${action.v_ing}`];
        promptAr = `اختر الفعل المناسب مع الرابط (since) الدال على بداية الحدث في الماضي واستمراره:`;
        whyCorrectAr = `نستخدم المضارع التام (have/has + V3) للتعبير عن حدث بدأ في الماضي وما زال متصلاً بالحاضر.`;
        temporalAr = 'بداية ماضية متصلة بالحاضر.';
      } else {
        sentenceWithBlank = subject.isSingular
          ? `So far this academic year, ${subject.en} ___ five major milestones without any external delay.`
          : `So far this academic year, ${subject.en} ___ five major milestones without any external delay.`;
        correct = subject.isSingular ? `has achieved` : `have achieved`;
        distractors = [subject.isSingular ? `has been achieving` : `have been achieving`, `achieved`, `had achieved`];
        promptAr = `اختر الصيغة المعبرة عن عدد الإنجازات المكتملة في فترة لم تنتهِ بعد (So far this year):`;
        whyCorrectAr = `عند ذكر عدد المرات والإنجازات المحققة في فترة مفتوحة نستخدم المضارع التام البسيط وليس المستمر.`;
        temporalAr = 'إنجازات محددة بالعدد في فترة زمنية مفتوحة.';
      }
      break;

    case 'present_perfect_continuous':
      if (level === 'easy') {
        sentenceWithBlank = subject.isSingular
          ? `${subject.en} has been ___ ${action.objectContext} for four straight hours.`
          : `${subject.en} have been ___ ${action.objectContext} for four straight hours.`;
        correct = action.v_ing;
        distractors = [action.v_3, action.baseVerb, action.v_s];
        promptAr = `اختر التصريف الصحيح للفعل في المضارع التام المستمر (have/has been + ...):`;
        whyCorrectAr = `تركيب المضارع التام المستمر يتطلب صيغة الفعل المنتهية بـ -ing بعد has/have been.`;
        temporalAr = 'نشاط مستمر استغرق مدة طويلة حتى الآن.';
      } else if (level === 'medium') {
        sentenceWithBlank = subject.isSingular
          ? `${subject.en} is exhausted because ${subject.pronoun} ___ ${action.objectContext} all morning.`
          : `${subject.en} are exhausted because ${subject.pronoun} ___ ${action.objectContext} all morning.`;
        correct = subject.isSingular ? `has been ${action.v_ing}` : `have been ${action.v_ing}`;
        distractors = [subject.isSingular ? `is ${action.v_ing}` : `are ${action.v_ing}`, action.v_ed, `had been ${action.v_ing}`];
        promptAr = `اختر الزمن المفسر لسبب التعب والإرهاق الظاهر على الشخص في الحاضر:`;
        whyCorrectAr = `المضارع التام المستمر يركز على استغراق النشاط كسبب مباشر لأثر بدني ملموس في الحاضر.`;
        temporalAr = 'نشاط مجهد مستمر ذو أثر حاضر.';
      } else {
        sentenceWithBlank = subject.isSingular
          ? `How long ___ ${subject.en} ___ ${action.objectContext}?`
          : `How long ___ ${subject.en} ___ ${action.objectContext}?`;
        correct = subject.isSingular ? `has / been ${action.v_ing}` : `have / been ${action.v_ing}`;
        distractors = subject.isSingular ? [`did / ${action.baseVerb}`, `is / ${action.v_ing}`, `had / been ${action.v_ing}`] : [`did / ${action.baseVerb}`, `are / ${action.v_ing}`, `had / been ${action.v_ing}`];
        promptAr = `اختر صيغة السؤال عن قياس مدة العمل المستمر حتى الحاضر:`;
        whyCorrectAr = `السؤال عن المدة المستمرة حتى الحاضر يبدأ بـ How long have/has + Subject + been + V-ing.`;
        temporalAr = 'قياس استمرارية النشاط عبر الزمن.';
      }
      break;

    case 'past_simple':
      if (level === 'easy') {
        sentenceWithBlank = `${subject.en} ___ ${action.objectContext} yesterday afternoon.`;
        correct = action.v_ed;
        distractors = [action.baseVerb, `has ${action.v_3}`, `is ${action.v_ing}`];
        promptAr = `اختر التصريف الثاني (V2) المناسب لحدث وقع وانتهى في وقت ماضٍ محدد (yesterday):`;
        whyCorrectAr = `وجود ظرف زمان ماضٍ محدد يوجب استخدام الماضي البسيط (V2).`;
        temporalAr = 'حدث مكتمل تماماً في الماضي.';
      } else if (level === 'medium') {
        sentenceWithBlank = `${subject.en} entered the room, checked the data, and ___ ${action.objectContext}.`;
        correct = action.v_ed;
        distractors = [action.v_s, `was ${action.v_ing}`, `had ${action.v_3}`];
        promptAr = `اختر الفعل المناسب في تسلسل الأحداث المتتالية السريعة في الماضي:`;
        whyCorrectAr = `سلسلة الأحداث السريعة المتتابعة في الماضي تصاغ كلها في الماضي البسيط.`;
        temporalAr: 'تتابع خطي لأفعال ماضية.';
      } else {
        sentenceWithBlank = `When ${subject.en} was leading the project in 2015, ${subject.pronoun} ___ ${action.objectContext}.`;
        correct = action.v_ed;
        distractors = [`has ${action.v_3}`, `had ${action.v_3}`, `was ${action.v_ing}`];
        promptAr = `اختر الفعل المعبر عن فترة زمنية أغلقت تماماً في الماضي:`;
        whyCorrectAr = `الفترة الزمنية الماضية المنتهية تصاغ حصراً في الماضي البسيط.`;
        temporalAr = 'حدث في فترة ماضية مغلقة.';
      }
      break;

    case 'past_continuous':
      if (level === 'easy') {
        sentenceWithBlank = subject.isSingular
          ? `At 8:00 PM last night, ${subject.en} ___ ${action.objectContext}.`
          : `At 8:00 PM last night, ${subject.en} ___ ${action.objectContext}.`;
        correct = subject.isSingular ? `was ${action.v_ing}` : `were ${action.v_ing}`;
        distractors = [action.v_ed, subject.isSingular ? `is ${action.v_ing}` : `are ${action.v_ing}`, `had ${action.v_3}`];
        promptAr = `اختر الفعل المعبر عن نشاط كان مستمراً في ساعة محددة بالضبط في الماضي:`;
        whyCorrectAr = `تحديد ساعة معينة في الماضي يركز على استمرار الفعل في تلك اللحظة (was/were + V-ing).`;
        temporalAr = 'حدث كان مستمراً في نقطة ماضية.';
      } else if (level === 'medium') {
        sentenceWithBlank = subject.isSingular
          ? `While ${subject.en} ___ ${action.objectContext}, the fire alarm suddenly sounded.`
          : `While ${subject.en} ___ ${action.objectContext}, the fire alarm suddenly sounded.`;
        correct = subject.isSingular ? `was ${action.v_ing}` : `were ${action.v_ing}`;
        distractors = [action.v_ed, `is ${action.v_ing}`, `had ${action.v_3}`];
        promptAr = `اختر التركيب الصحيح للحدث الطويل المستمر في الخلفية بعد While:`;
        whyCorrectAr = `الحدث الطويل المستمر بعد While يأتي في الماضي المستمر ويقطعه حدث قصير في الماضي البسيط.`;
        temporalAr = 'حدث طويل قوطع بحدث مفاجئ.';
      } else {
        sentenceWithBlank = subject.isSingular
          ? `While one team was conducting safety checks, ${subject.en} ___ ${action.objectContext}.`
          : `While one team was conducting safety checks, ${subject.en} ___ ${action.objectContext}.`;
        correct = subject.isSingular ? `was ${action.v_ing}` : `were ${action.v_ing}`;
        distractors = [action.v_ed, `had ${action.v_3}`, action.baseVerb];
        promptAr = `اختر الفعل المعبر عن حدثين كانا مستمرين في نفس الوقت بالتوازي (Parallel Actions):`;
        whyCorrectAr = `الحدثان المتزامنان في الماضي يصاغان معاً في الماضي المستمر.`;
        temporalAr = 'استمرارية متزامنة في الماضي.';
      }
      break;

    case 'past_perfect':
      if (level === 'easy') {
        sentenceWithBlank = `${subject.en} had already ___ ${action.objectContext} before the inspectors arrived.`;
        correct = action.v_3;
        distractors = [action.baseVerb, action.v_ing, action.v_s];
        promptAr = `اختر التصريف الثالث (V3) بعد had للتعبير عن الحدث الأسبق في الماضي:`;
        whyCorrectAr = `صيغة الماضي التام هي had + التصريف الثالث (V3).`;
        temporalAr = 'الحدث الأسبق زمنياً في الماضي.';
      } else if (level === 'medium') {
        sentenceWithBlank = `By the time the conference began, ${subject.en} ___ ${action.objectContext}.`;
        correct = `had ${action.v_3}`;
        distractors = [action.v_ed, `has ${action.v_3}`, `was ${action.v_ing}`];
        promptAr = `اختر الفعل المعبر عن اكتمال الإنجاز قبل نقطة ماضية معينة (By the time):`;
        whyCorrectAr = `By the time + ماضٍ بسيط يتبعها Past Perfect (had + V3) للحدث الأسبق.`;
        temporalAr = 'اكتمال أسبق قبل لحظة ماضية.';
      } else {
        sentenceWithBlank = `If ${subject.en} ___ ${action.objectContext}, the entire system would have operated smoothly.`;
        correct = `had ${action.v_3}`;
        distractors = [action.v_ed, `has ${action.v_3}`, `would ${action.baseVerb}`];
        promptAr = `اختر التركيب الصحيح في جملة شرط الشرطية الثالثة (Third Conditional):`;
        whyCorrectAr = `في الشرطية الثالثة نستخدم Past Perfect (had + V3) في جملة If.`;
        temporalAr = 'افتراض ماضٍ لم يتحقق.';
      }
      break;

    case 'past_perfect_continuous':
      if (level === 'easy') {
        sentenceWithBlank = `${subject.en} had been ___ ${action.objectContext} for two hours before taking a rest.`;
        correct = action.v_ing;
        distractors = [action.v_3, action.baseVerb, action.v_s];
        promptAr = `اختر تصريف الفعل في الماضي التام المستمر (had been + ...):`;
        whyCorrectAr = `تركيب الماضي التام المستمر هو had been + V-ing.`;
        temporalAr = 'استمرارية نشاط قبل حدث ماضٍ آخر.';
      } else if (level === 'medium') {
        sentenceWithBlank = `${subject.en} ___ ${action.objectContext} for months before the breakthrough occurred.`;
        correct = `had been ${action.v_ing}`;
        distractors = [subject.isSingular ? `was ${action.v_ing}` : `were ${action.v_ing}`, action.v_ed, `has been ${action.v_ing}`];
        promptAr = `اختر الفعل المعبر عن استمرار نشاط طويل قبل محطة ماضية معينة:`;
        whyCorrectAr = `التركيز على طول المدة والاستمرار حتى لحظة معينة في الماضي يوجب Past Perfect Continuous.`;
        temporalAr = 'مدة مستمرة حتى محطة ماضية.';
      } else {
        sentenceWithBlank = `The researchers were fatigued because ${subject.en} ___ ${action.objectContext} without any break.`;
        correct = `had been ${action.v_ing}`;
        distractors = [`had ${action.v_3}`, subject.isSingular ? `was ${action.v_ing}` : `were ${action.v_ing}`, action.v_ed];
        promptAr = `اختر الزمن الذي يفسر الإجهاد في الماضي بالتركيز على استمرار النشاط ومشقة العملية:`;
        whyCorrectAr = `الماضي التام المستمر يفسر النتيجة الماضية بالتركيز على عملية النشاط المستمر.`;
        temporalAr = 'نشاط مستمر مجهد سبب حالة ماضية.';
      }
      break;

    case 'future_simple':
      if (level === 'easy') {
        sentenceWithBlank = `Do not worry about the deadline; ${subject.en} ___ ${action.objectContext}.`;
        correct = `will ${action.baseVerb}`;
        distractors = [`is going to ${action.baseVerb}`, `did ${action.baseVerb}`, action.v_s];
        promptAr = `اختر الفعل المعبر عن وعد والتزام في المستقبل (Promise):`;
        whyCorrectAr = `الوعود والعروض والالتزامات المستقبلية تصاغ بـ (will + مصدر).`;
        temporalAr = 'التزام ووعد مستقبلي.';
      } else if (level === 'medium') {
        sentenceWithBlank = `Look at the progress indicators! ${subject.en} ___ ${action.objectContext} ahead of time.`;
        correct = subject.isSingular ? `is going to ${action.baseVerb}` : `are going to ${action.baseVerb}`;
        distractors = [`will ${action.baseVerb}`, action.v_ed, `has ${action.v_3}`];
        promptAr = `اختر الصيغة المعبرة عن تنبؤ قائم على دليل مادي مرئي حاضر (Evidence):`;
        whyCorrectAr = `التنبؤات المبنية على شواهد ودلائل مادية حاضرة تأخذ (be going to).`;
        temporalAr = 'تنبؤ وشيك بدليل مادي.';
      } else {
        sentenceWithBlank = `I firmly believe that ${subject.en} ___ ${action.objectContext} by applying innovative techniques.`;
        correct = `will ${action.baseVerb}`;
        distractors = [subject.isSingular ? `is going to ${action.baseVerb}` : `are going to ${action.baseVerb}`, action.v_s, action.v_ed];
        promptAr = `اختر الصيغة المناسبة بعد أفعال الرأي والاعتقاد الشخصي (I believe):`;
        whyCorrectAr = `التوقعات والآراء الشخصية المستقبلية تأخذ will + مصدر.`;
        temporalAr = 'توقع مستقبلي مبني على الرأي.';
      }
      break;

    case 'future_continuous':
      if (level === 'easy') {
        sentenceWithBlank = `This time tomorrow, ${subject.en} will be ___ ${action.objectContext}.`;
        correct = action.v_ing;
        distractors = [action.baseVerb, action.v_3, action.v_s];
        promptAr = `اختر تصريف الفعل في المستقبل المستمر (will be + ...):`;
        whyCorrectAr = `تركيب المستقبل المستمر هو will be + V-ing.`;
        temporalAr = 'حدث سيكون مستمراً في نقطة مستقبلية محددة.';
      } else if (level === 'medium') {
        sentenceWithBlank = `At 11:00 AM tomorrow, ${subject.en} ___ ${action.objectContext}.`;
        correct = `will be ${action.v_ing}`;
        distractors = [`will ${action.baseVerb}`, subject.isSingular ? `is ${action.v_ing}` : `are ${action.v_ing}`, action.v_s];
        promptAr = `اختر الفعل المعبر عن حدث سيكون في قمة سريانه واستمراره في ساعة معينة غداً:`;
        whyCorrectAr = `تحديد وقت دقيق في المستقبل يعبر عن نشاط سيكون جارياً ومستمراً خلاله.`;
        temporalAr = 'استمرارية في نقطة زمنية مستقبلية.';
      } else {
        sentenceWithBlank = `___ ${subject.en} ___ ${action.objectContext} during the international symposium?`;
        correct = `Will / be ${action.v_ing}`;
        distractors = [`Do / ${action.baseVerb}`, `Are / going to ${action.baseVerb}`, `Did / ${action.baseVerb}`];
        promptAr = `اختر الصيغة المهذبة غير الضاغطة للاستفسار عن الخطط الروتينية:`;
        whyCorrectAr = `المستقبل المستمر يستخدم كصيغة راقية للاستفسار المهذب عن خطط الآخرين.`;
        temporalAr = 'استفسار مهذب عن سريان المستقبل.';
      }
      break;

    case 'future_perfect':
      if (level === 'easy') {
        sentenceWithBlank = `By next December, ${subject.en} will have ___ ${action.objectContext}.`;
        correct = action.v_3;
        distractors = [action.baseVerb, action.v_ing, action.v_s];
        promptAr = `اختر تصريف الفعل في المستقبل التام (will have + ...):`;
        whyCorrectAr = `المستقبل التام يتكون من will have + التصريف الثالث (V3).`;
        temporalAr = 'إنجاز مكتمل قبل موعد مستقبلي.';
      } else if (level === 'medium') {
        sentenceWithBlank = `By the year 2030, ${subject.en} ___ ${action.objectContext} comprehensively.`;
        correct = `will have ${action.v_3}`;
        distractors = [`will ${action.baseVerb}`, action.v_s, subject.isSingular ? `is ${action.v_ing}` : `are ${action.v_ing}`];
        promptAr = `اختر الفعل المناسب مع الرابط الدال على الحد الزمني الأقصى (By 2030):`;
        whyCorrectAr = `By + تاريخ مستقبلي تعني بحلول ذلك التاريخ سيكون الحدث قد اكتمل تماماً.`;
        temporalAr = 'إنجاز مكتمل قبل محطة زمنية قادمة.';
      } else {
        sentenceWithBlank = `By the time the new regulations take effect, ${subject.en} ___ ${action.objectContext}.`;
        correct = `will have ${action.v_3}`;
        distractors = [`will ${action.baseVerb}`, action.baseVerb, action.v_ed];
        promptAr = `اختر التركيب الدقيق عند اقتران جملة شرطية زمنية بالمستقبل التام:`;
        whyCorrectAr = `الإنجاز سيكون قد تحقق واكتمل قبل لحظة سريان القوانين في المستقبل.`;
        temporalAr = 'اكتمال أسبق في المستقبل قبل حدث مستقبلي آخر.';
      }
      break;

    case 'future_perfect_continuous':
      if (level === 'easy') {
        sentenceWithBlank = `By midnight, ${subject.en} will have been ___ ${action.objectContext} for eight hours.`;
        correct = action.v_ing;
        distractors = [action.v_3, action.baseVerb, action.v_s];
        promptAr = `اختر تصريف الفعل في المستقبل التام المستمر (will have been + ...):`;
        whyCorrectAr = `المستقبل التام المستمر يتكون من will have been + V-ing.`;
        temporalAr = 'قياس استمرارية المدة حتى لحظة مستقبلية.';
      } else if (level === 'medium') {
        sentenceWithBlank = `Next month, ${subject.en} ___ ${action.objectContext} for exactly a decade.`;
        correct = `will have been ${action.v_ing}`;
        distractors = [`will be ${action.v_ing}`, `have been ${action.v_ing}`, `will ${action.baseVerb}`];
        promptAr = `اختر الفعل المعبر عن حساب مدة الاستمرار التراكمية بحلول محطة قادمة:`;
        whyCorrectAr = `التركيز على حساب واستعراض مدة النشاط المستمر عند حلول الشهر القادم.`;
        temporalAr = 'استمرار مدة متراكمة حتى نقطة مستقبلية.';
      } else {
        sentenceWithBlank = `When the milestone ceremony begins, ${subject.en} ___ ${action.objectContext} continuously for five years.`;
        correct = `will have been ${action.v_ing}`;
        distractors = [`will ${action.baseVerb}`, `will be ${action.v_ing}`, `has been ${action.v_ing}`];
        promptAr = `اختر الزمن الذي يبرز تراكم المدة الزمنية المستمرة حتى موعد حدث مستقبلي:`;
        whyCorrectAr = `قياس المدة الإجمالية للنشاط المتواصل حتى تاريخ الاحتفال المستقبلي.`;
        temporalAr: 'تراكم استمرارية نشاط حتى محطة مستقبلية.';
      }
      break;
  }

  const questionId = `proc_${tenseId}_${level}_${index}_${Math.random().toString(36).substring(2, 7)}`;
  const options = shuffleArray([correct, ...distractors]);

  return {
    id: questionId,
    tenseId,
    difficulty: level === 'easy' ? 'easy' : level === 'medium' ? 'medium' : 'hard',
    type: level === 'hard' ? 'no_clues' : level === 'medium' ? 'situation_challenge' : 'multiple_choice',
    hasNoSignalWords: level === 'hard',
    scenarioContextAr: `سياق تطبيقي: ${action.meaningAr} — ${subject.ar}.`,
    promptAr,
    sentenceWithBlank,
    options,
    correctAnswer: correct,
    explanation: {
      whyCorrectAr,
      temporalRelationshipAr: temporalAr,
      whyTenseFitsAr: `هذا التركيب هو التطبيق القياسي لـ ${tenseMeta ? tenseMeta.nameAr : tenseId}.`,
      whyOthersWrongAr: `الخيارات الأخرى تستخدم تراكيب أو أزمنة غير متطابقة مع المعنى الزمني للجملة.`,
      confusableTenseAr: tenseMeta?.vsComparisons?.[0]?.targetTenseName || 'الأزمنة المقاربة في الفئة الزمنية',
    },
  };
}

/**
 * Procedural generator for Additional Grammar Rules (e.g. Modals, Passive, Conditionals, Prepositions, etc.)
 */
function generateProceduralRuleQuestion(
  ruleId: string,
  level: 'easy' | 'medium' | 'hard' | 'gauntlet_12',
  index: number,
  ruleMeta: any
): QuizQuestion {
  const subject = SUBJECT_PROFILES[index % SUBJECT_PROFILES.length];
  const action = DOMAIN_ACTIONS[(index * 2 + 5) % DOMAIN_ACTIONS.length];

  let sentenceWithBlank = `${subject.en} must carefully ___ ${action.objectContext}.`;
  let correct = action.baseVerb;
  let distractors = [action.v_s, action.v_ing, action.v_ed];
  let promptAr = `اختر الصيغة الصحيحة بعد الفعل المساعد أو التركيب النحوي:`;
  let whyCorrectAr = `يتبع الفعل المساعد أو الرابط النحوي المصدر المجرد.`;
  let temporalAr = `قاعدة نحوية قياسية.`;

  // Specific variations based on rule type
  if (ruleId.includes('modal')) {
    if (level === 'easy') {
      sentenceWithBlank = `${subject.en} ___ obtain official authorization before accessing the restricted facility.`;
      correct = 'must';
      distractors = ['might', 'should have', 'could have'];
      promptAr = `اختر الفعل الناقص الدال على الإلزام الحتمي (Obligation):`;
      whyCorrectAr = `Must تعبر عن الوجوب والإلزام الصارم.`;
      temporalAr = `إلزام مباشر.`;
    } else if (level === 'medium') {
      sentenceWithBlank = `Since today is an official holiday, ${subject.en} ___ ${action.baseVerb} ${action.objectContext}.`;
      correct = subject.isSingular ? "doesn't have to" : "don't have to";
      distractors = ["mustn't", "can't", "shouldn't have"];
      promptAr = `اختر الفعل الناقص المعبر عن انعدام الإلزام (Lack of Obligation):`;
      whyCorrectAr = `don't / doesn't have to تعني لست ملزماً بالفعل.`;
      temporalAr = `حرية الاختيار.`;
    } else {
      sentenceWithBlank = `The experimental results were completely unexpected. ${subject.en} ___ ${action.v_3} the incorrect sample.`;
      correct = 'must have';
      distractors = ['should', 'might', 'can'];
      promptAr = `اختر صيغة الاستنتاج المنطقي المؤكد في الماضي (Past Deduction):`;
      whyCorrectAr = `must have + V3 تعبر عن استنتاج مؤكد لوقوع الفعل في الماضي بناء على دليل.`;
      temporalAr = `استنتاج يقيني ماضٍ.`;
    }
  } else if (ruleId.includes('passive')) {
    sentenceWithBlank = `The official documentation ___ by ${subject.en} before submission.`;
    correct = (level === 'easy') ? 'is reviewed' : (level === 'medium') ? 'has been reviewed' : 'must be reviewed';
    distractors = ['reviews', 'is reviewing', 'has reviewed'];
    promptAr = `اختر صيغة المبني للمجهول المناسبة للجملة:`;
    whyCorrectAr = `المبني للمجهول يركز على المفعول به ويتكون من be + V3.`;
    temporalAr = `تركيز على الحدث والمفعول به.`;
  } else if (ruleId.includes('preposition')) {
    const preps = ['in', 'on', 'at', 'by', 'for', 'during'];
    const selectedPrep = preps[index % preps.length];
    sentenceWithBlank = (selectedPrep === 'on')
      ? `The international symposium is scheduled ___ Monday morning.`
      : (selectedPrep === 'at')
      ? `The keynote presentation starts promptly ___ 09:00 AM.`
      : `The research grant was officially approved ___ 2024.`;
    correct = (selectedPrep === 'on') ? 'on' : (selectedPrep === 'at') ? 'at' : 'in';
    distractors = ['in', 'at', 'on', 'to'].filter(p => p !== correct).slice(0, 3);
    promptAr = `اختر حرف الجر الزماني الصحيح للجملة:`;
    whyCorrectAr = `on مع الأيام، at مع الساعات المحددة، in مع السنوات والشهور.`;
    temporalAr = `تحديد زماني دقيق.`;
  } else if (ruleId.includes('gerund') || ruleId.includes('infinitive')) {
    sentenceWithBlank = `${subject.en} decided ___ ${action.objectContext}.`;
    correct = `to ${action.baseVerb}`;
    distractors = [action.v_ing, action.baseVerb, action.v_s];
    promptAr = `اختر الصيغة الصحيحة بعد الفعل decide (Gerund vs Infinitive):`;
    whyCorrectAr = `الفعل decide يتبعه دائماً المصدر مع to (Infinitive: to + base).`;
    temporalAr = `قاعدة اقتران المصادر.`;
  }

  const questionId = `proc_rule_${ruleId}_${level}_${index}_${Math.random().toString(36).substring(2, 7)}`;
  const options = shuffleArray([correct, ...distractors]);

  return {
    id: questionId,
    tenseId: ruleId as TenseId,
    difficulty: level === 'easy' ? 'easy' : level === 'medium' ? 'medium' : 'hard',
    type: 'multiple_choice',
    promptAr,
    sentenceWithBlank,
    options,
    correctAnswer: correct,
    explanation: {
      whyCorrectAr,
      temporalRelationshipAr: temporalAr,
      whyTenseFitsAr: `هذا هو التطبيق النحوي القياسي لقاعدة ${ruleMeta?.nameAr || ruleId}.`,
      whyOthersWrongAr: `الخيارات البديلة لا تطابق القواعد النحوية المقترنة.`,
      confusableTenseAr: ruleMeta?.nameAr || 'القواعد المشابهة',
    },
  };
}

/**
 * Generate EXACTLY 50 completely distinct, non-repeating questions for any level and tense
 */
export function generatePracticeQuestions(
  level: 'easy' | 'medium' | 'hard' | 'gauntlet_12',
  selectedTense: string,
  targetCount: number = 50
): QuizQuestion[] {
  // If user selected easy level for Present Simple, serve the 50 handcrafted questions directly
  if (selectedTense === 'present_simple' && level === 'easy') {
    return [...PRESENT_SIMPLE_EASY_50].slice(0, targetCount);
  }

  // If user selected medium level for Present Simple, serve the 50 handcrafted medium questions directly
  if (selectedTense === 'present_simple' && level === 'medium') {
    return [...PRESENT_SIMPLE_MEDIUM_50].slice(0, targetCount);
  }

  // If user selected hard level for Present Simple, serve the 50 handcrafted hard questions directly
  if (selectedTense === 'present_simple' && level === 'hard') {
    return [...PRESENT_SIMPLE_HARD_50].slice(0, targetCount);
  }

  // If user selected easy level for Present Continuous, serve the 50 handcrafted questions directly
  if (selectedTense === 'present_continuous' && level === 'easy') {
    return [...PRESENT_CONTINUOUS_EASY_50].slice(0, targetCount);
  }

  // If user selected medium level for Present Continuous, serve the 50 handcrafted medium questions directly
  if (selectedTense === 'present_continuous' && level === 'medium') {
    return [...PRESENT_CONTINUOUS_MEDIUM_50].slice(0, targetCount);
  }

  // If user selected hard level for Present Continuous, serve the 50 handcrafted hard questions directly
  if (selectedTense === 'present_continuous' && level === 'hard') {
    return [...PRESENT_CONTINUOUS_HARD_50].slice(0, targetCount);
  }

  // If user selected easy level for Present Perfect, serve the 50 handcrafted questions directly
  if (selectedTense === 'present_perfect' && level === 'easy') {
    return [...PRESENT_PERFECT_EASY_50].slice(0, targetCount);
  }

  // If user selected medium level for Present Perfect, serve the 50 handcrafted medium questions directly
  if (selectedTense === 'present_perfect' && level === 'medium') {
    return [...PRESENT_PERFECT_MEDIUM_50].slice(0, targetCount);
  }

  // If user selected hard level for Present Perfect, serve the 50 handcrafted hard questions directly
  if (selectedTense === 'present_perfect' && level === 'hard') {
    return [...PRESENT_PERFECT_HARD_50].slice(0, targetCount);
  }

  // If user selected easy level for Present Perfect Continuous, serve the 50 handcrafted questions directly
  if (selectedTense === 'present_perfect_continuous' && level === 'easy') {
    return [...PRESENT_PERFECT_CONTINUOUS_EASY_50].slice(0, targetCount);
  }

  // If user selected medium level for Present Perfect Continuous, serve the 50 handcrafted medium questions directly
  if (selectedTense === 'present_perfect_continuous' && level === 'medium') {
    return [...PRESENT_PERFECT_CONTINUOUS_MEDIUM_50].slice(0, targetCount);
  }

  // If user selected hard level for Present Perfect Continuous, serve the 50 handcrafted hard questions directly
  if (selectedTense === 'present_perfect_continuous' && level === 'hard') {
    return [...PRESENT_PERFECT_CONTINUOUS_HARD_50].slice(0, targetCount);
  }

  // If user selected easy level for Past Simple, serve the 50 handcrafted questions directly
  if (selectedTense === 'past_simple' && level === 'easy') {
    return [...PAST_SIMPLE_EASY_50].slice(0, targetCount);
  }

  // If user selected medium level for Past Simple, serve the 50 handcrafted medium questions directly
  if (selectedTense === 'past_simple' && level === 'medium') {
    return [...PAST_SIMPLE_MEDIUM_50].slice(0, targetCount);
  }

  // If user selected hard level for Past Simple, serve the 50 handcrafted hard questions directly
  if (selectedTense === 'past_simple' && level === 'hard') {
    return [...PAST_SIMPLE_HARD_50].slice(0, targetCount);
  }

  // If user selected easy level for Past Continuous, serve the 50 handcrafted questions directly
  if (selectedTense === 'past_continuous' && level === 'easy') {
    return [...PAST_CONTINUOUS_EASY_50].slice(0, targetCount);
  }

  // If user selected medium level for Past Continuous, serve the 50 handcrafted medium questions directly
  if (selectedTense === 'past_continuous' && level === 'medium') {
    return [...PAST_CONTINUOUS_MEDIUM_50].slice(0, targetCount);
  }

  // If user selected hard level for Past Continuous, serve the 50 handcrafted hard questions directly
  if (selectedTense === 'past_continuous' && level === 'hard') {
    return [...PAST_CONTINUOUS_HARD_50].slice(0, targetCount);
  }

  // If user selected easy level for Past Perfect, serve the 50 handcrafted questions directly
  if (selectedTense === 'past_perfect' && level === 'easy') {
    return [...PAST_PERFECT_EASY_50].slice(0, targetCount);
  }

  // If user selected medium level for Past Perfect, serve the 50 handcrafted medium questions directly
  if (selectedTense === 'past_perfect' && level === 'medium') {
    return [...PAST_PERFECT_MEDIUM_50].slice(0, targetCount);
  }

  // If user selected hard level for Past Perfect, serve the 50 handcrafted hard questions directly
  if (selectedTense === 'past_perfect' && level === 'hard') {
    return [...PAST_PERFECT_HARD_50].slice(0, targetCount);
  }

  // If user selected easy level for Past Perfect Continuous, serve the 50 handcrafted questions directly
  if (selectedTense === 'past_perfect_continuous' && level === 'easy') {
    return [...PAST_PERFECT_CONTINUOUS_EASY_50].slice(0, targetCount);
  }

  // If user selected medium level for Past Perfect Continuous, serve the 50 handcrafted medium questions directly
  if (selectedTense === 'past_perfect_continuous' && level === 'medium') {
    return [...PAST_PERFECT_CONTINUOUS_MEDIUM_50].slice(0, targetCount);
  }

  // If user selected hard level for Past Perfect Continuous, serve the 50 handcrafted hard questions directly
  if (selectedTense === 'past_perfect_continuous' && level === 'hard') {
    return [...PAST_PERFECT_CONTINUOUS_HARD_50].slice(0, targetCount);
  }

  // If user selected easy level for Future Simple, serve the 50 handcrafted questions directly
  if (selectedTense === 'future_simple' && level === 'easy') {
    return [...FUTURE_SIMPLE_EASY_50].slice(0, targetCount);
  }

  // If user selected medium level for Future Simple, serve the 50 handcrafted medium questions directly
  if (selectedTense === 'future_simple' && level === 'medium') {
    return [...FUTURE_SIMPLE_MEDIUM_50].slice(0, targetCount);
  }

  // If user selected hard level for Future Simple, serve the 50 handcrafted hard questions directly
  if (selectedTense === 'future_simple' && level === 'hard') {
    return [...FUTURE_SIMPLE_HARD_50].slice(0, targetCount);
  }

  // If user selected easy level for Future Continuous, serve the 50 handcrafted questions directly
  if (selectedTense === 'future_continuous' && level === 'easy') {
    return [...FUTURE_CONTINUOUS_EASY_50].slice(0, targetCount);
  }

  // If user selected medium level for Future Continuous, serve the 50 handcrafted medium questions directly
  if (selectedTense === 'future_continuous' && level === 'medium') {
    return [...FUTURE_CONTINUOUS_MEDIUM_50].slice(0, targetCount);
  }

  // If user selected hard level for Future Continuous, serve the 50 handcrafted hard questions directly
  if (selectedTense === 'future_continuous' && level === 'hard') {
    return [...FUTURE_CONTINUOUS_HARD_50].slice(0, targetCount);
  }

  // If user selected easy level for Future Perfect, serve the 50 handcrafted questions directly
  if (selectedTense === 'future_perfect' && level === 'easy') {
    return [...FUTURE_PERFECT_EASY_50].slice(0, targetCount);
  }

  // If user selected medium level for Future Perfect, serve the 50 handcrafted medium questions directly
  if (selectedTense === 'future_perfect' && level === 'medium') {
    return [...FUTURE_PERFECT_MEDIUM_50].slice(0, targetCount);
  }

  // If user selected hard level for Future Perfect, serve the 50 handcrafted hard questions directly
  if (selectedTense === 'future_perfect' && level === 'hard') {
    return [...FUTURE_PERFECT_HARD_50].slice(0, targetCount);
  }

  // If user selected easy level for Future Perfect Continuous, serve the 50 handcrafted questions directly
  if (selectedTense === 'future_perfect_continuous' && level === 'easy') {
    return [...FUTURE_PERFECT_CONTINUOUS_EASY_50].slice(0, targetCount);
  }

  // If user selected medium level for Future Perfect Continuous, serve the 50 handcrafted medium questions directly
  if (selectedTense === 'future_perfect_continuous' && level === 'medium') {
    return [...FUTURE_PERFECT_CONTINUOUS_MEDIUM_50].slice(0, targetCount);
  }

  // If user selected hard level for Future Perfect Continuous, serve the 50 handcrafted hard questions directly
  if (selectedTense === 'future_perfect_continuous' && level === 'hard') {
    return [...FUTURE_PERFECT_CONTINUOUS_HARD_50].slice(0, targetCount);
  }

  // If user selected easy level for Modal Verbs, serve the 30 handcrafted questions directly
  if (selectedTense === 'modal_verbs' && level === 'easy') {
    return [...MODAL_VERBS_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Modal Verbs, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'modal_verbs' && level === 'medium') {
    return [...MODAL_VERBS_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Modal Verbs, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'modal_verbs' && level === 'hard') {
    return [...MODAL_VERBS_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Passive Voice, serve the 30 handcrafted questions directly
  if (selectedTense === 'passive_voice' && level === 'easy') {
    return [...PASSIVE_VOICE_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Passive Voice, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'passive_voice' && level === 'medium') {
    return [...PASSIVE_VOICE_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Passive Voice, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'passive_voice' && level === 'hard') {
    return [...PASSIVE_VOICE_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Active Voice, serve the 30 handcrafted questions directly
  if (selectedTense === 'active_voice' && level === 'easy') {
    return [...ACTIVE_VOICE_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Active Voice, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'active_voice' && level === 'medium') {
    return [...ACTIVE_VOICE_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Active Voice, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'active_voice' && level === 'hard') {
    return [...ACTIVE_VOICE_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Mixed Conditionals, serve the 30 handcrafted questions directly
  if (selectedTense === 'mixed_conditionals' && level === 'easy') {
    return [...MIXED_CONDITIONALS_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Mixed Conditionals, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'mixed_conditionals' && level === 'medium') {
    return [...MIXED_CONDITIONALS_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Mixed Conditionals, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'mixed_conditionals' && level === 'hard') {
    return [...MIXED_CONDITIONALS_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Conditionals (Zero, First, Second, Third), serve the 30 handcrafted questions directly
  if (selectedTense === 'conditionals_zero_first_second_third' && level === 'easy') {
    return [...CONDITIONALS_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Conditionals (Zero, First, Second, Third), serve the 30 handcrafted medium questions directly
  if (selectedTense === 'conditionals_zero_first_second_third' && level === 'medium') {
    return [...CONDITIONALS_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Conditionals (Zero, First, Second, Third), serve the 30 handcrafted hard questions directly
  if (selectedTense === 'conditionals_zero_first_second_third' && level === 'hard') {
    return [...CONDITIONALS_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Wish / If only, serve the 30 handcrafted questions directly
  if (selectedTense === 'wish_if_only' && level === 'easy') {
    return [...WISH_IF_ONLY_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Wish / If only, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'wish_if_only' && level === 'medium') {
    return [...WISH_IF_ONLY_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Wish / If only, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'wish_if_only' && level === 'hard') {
    return [...WISH_IF_ONLY_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Reported Speech, serve the 30 handcrafted questions directly
  if (selectedTense === 'reported_speech' && level === 'easy') {
    return [...REPORTED_SPEECH_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Reported Speech, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'reported_speech' && level === 'medium') {
    return [...REPORTED_SPEECH_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Reported Speech, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'reported_speech' && level === 'hard') {
    return [...REPORTED_SPEECH_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Direct Speech, serve the 30 handcrafted questions directly
  if (selectedTense === 'direct_speech' && level === 'easy') {
    return [...DIRECT_SPEECH_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Direct Speech, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'direct_speech' && level === 'medium') {
    return [...DIRECT_SPEECH_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Direct Speech, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'direct_speech' && level === 'hard') {
    return [...DIRECT_SPEECH_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Questions & Question Tags, serve the 30 handcrafted questions directly
  if (selectedTense === 'questions_and_tags' && level === 'easy') {
    return [...QUESTION_TAGS_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Questions & Question Tags, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'questions_and_tags' && level === 'medium') {
    return [...QUESTION_TAGS_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Questions & Question Tags, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'questions_and_tags' && level === 'hard') {
    return [...QUESTION_TAGS_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Subject-Verb Agreement, serve the 30 handcrafted questions directly
  if (selectedTense === 'subject_verb_agreement' && level === 'easy') {
    return [...SUBJECT_VERB_AGREEMENT_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Subject-Verb Agreement, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'subject_verb_agreement' && level === 'medium') {
    return [...SUBJECT_VERB_AGREEMENT_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Subject-Verb Agreement, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'subject_verb_agreement' && level === 'hard') {
    return [...SUBJECT_VERB_AGREEMENT_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Articles, serve the 30 handcrafted questions directly
  if (selectedTense === 'articles_a_an_the_zero' && level === 'easy') {
    return [...ARTICLES_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Articles, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'articles_a_an_the_zero' && level === 'medium') {
    return [...ARTICLES_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Articles, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'articles_a_an_the_zero' && level === 'hard') {
    return [...ARTICLES_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Countable & Uncountable Nouns, serve the 30 handcrafted questions directly
  if (selectedTense === 'countable_uncountable_nouns' && level === 'easy') {
    return [...COUNTABLE_NOUNS_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Countable & Uncountable Nouns, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'countable_uncountable_nouns' && level === 'medium') {
    return [...COUNTABLE_NOUNS_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Countable & Uncountable Nouns, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'countable_uncountable_nouns' && level === 'hard') {
    return [...COUNTABLE_NOUNS_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Quantifiers, serve the 30 handcrafted questions directly
  if (selectedTense === 'quantifiers' && level === 'easy') {
    return [...QUANTIFIERS_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Quantifiers, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'quantifiers' && level === 'medium') {
    return [...QUANTIFIERS_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Quantifiers, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'quantifiers' && level === 'hard') {
    return [...QUANTIFIERS_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Comparatives & Superlatives, serve the 30 handcrafted questions directly
  if (selectedTense === 'comparatives_superlatives' && level === 'easy') {
    return [...COMPARATIVES_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Comparatives & Superlatives, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'comparatives_superlatives' && level === 'medium') {
    return [...COMPARATIVES_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Comparatives & Superlatives, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'comparatives_superlatives' && level === 'hard') {
    return [...COMPARATIVES_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Adjectives & Adverbs, serve the 30 handcrafted questions directly
  if (selectedTense === 'adjectives_adverbs' && level === 'easy') {
    return [...ADJECTIVES_ADVERBS_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Adjectives & Adverbs, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'adjectives_adverbs' && level === 'medium') {
    return [...ADJECTIVES_ADVERBS_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Adjectives & Adverbs, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'adjectives_adverbs' && level === 'hard') {
    return [...ADJECTIVES_ADVERBS_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Prepositions, serve the 30 handcrafted questions directly
  if (selectedTense === 'prepositions' && level === 'easy') {
    return [...PREPOSITIONS_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Prepositions, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'prepositions' && level === 'medium') {
    return [...PREPOSITIONS_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Prepositions, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'prepositions' && level === 'hard') {
    return [...PREPOSITIONS_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Conjunctions & Linking Words, serve the 30 handcrafted questions directly
  if (selectedTense === 'conjunctions_linking_words' && level === 'easy') {
    return [...CONJUNCTIONS_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Conjunctions & Linking Words, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'conjunctions_linking_words' && level === 'medium') {
    return [...CONJUNCTIONS_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Conjunctions & Linking Words, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'conjunctions_linking_words' && level === 'hard') {
    return [...CONJUNCTIONS_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Gerunds & Infinitives, serve the 30 handcrafted questions directly
  if (selectedTense === 'gerunds_infinitives' && level === 'easy') {
    return [...GERUNDS_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Gerunds & Infinitives, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'gerunds_infinitives' && level === 'medium') {
    return [...GERUNDS_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Gerunds & Infinitives, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'gerunds_infinitives' && level === 'hard') {
    return [...GERUNDS_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Participles, serve the 30 handcrafted questions directly
  if (selectedTense === 'participles' && level === 'easy') {
    return [...PARTICIPLES_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Participles, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'participles' && level === 'medium') {
    return [...PARTICIPLES_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Participles, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'participles' && level === 'hard') {
    return [...PARTICIPLES_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Relative Clauses, serve the 30 handcrafted questions directly
  if (selectedTense === 'relative_clauses' && level === 'easy') {
    return [...RELATIVE_CLAUSES_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Relative Clauses, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'relative_clauses' && level === 'medium') {
    return [...RELATIVE_CLAUSES_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Relative Clauses, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'relative_clauses' && level === 'hard') {
    return [...RELATIVE_CLAUSES_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Noun Clauses, serve the 30 handcrafted questions directly
  if (selectedTense === 'noun_clauses' && level === 'easy') {
    return [...NOUN_CLAUSES_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Noun Clauses, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'noun_clauses' && level === 'medium') {
    return [...NOUN_CLAUSES_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Noun Clauses, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'noun_clauses' && level === 'hard') {
    return [...NOUN_CLAUSES_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Adverb Clauses, serve the 30 handcrafted questions directly
  if (selectedTense === 'adverb_clauses' && level === 'easy') {
    return [...ADVERB_CLAUSES_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Adverb Clauses, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'adverb_clauses' && level === 'medium') {
    return [...ADVERB_CLAUSES_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Adverb Clauses, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'adverb_clauses' && level === 'hard') {
    return [...ADVERB_CLAUSES_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Phrasal Verbs, serve the 30 handcrafted questions directly
  if (selectedTense === 'phrasal_verbs' && level === 'easy') {
    return [...PHRASAL_VERBS_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Phrasal Verbs, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'phrasal_verbs' && level === 'medium') {
    return [...PHRASAL_VERBS_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Phrasal Verbs, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'phrasal_verbs' && level === 'hard') {
    return [...PHRASAL_VERBS_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Subject & Object Pronouns, serve the 30 handcrafted questions directly
  if (selectedTense === 'subject_object_pronouns' && level === 'easy') {
    return [...SUBJECT_OBJECT_PRONOUNS_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Subject & Object Pronouns, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'subject_object_pronouns' && level === 'medium') {
    return [...SUBJECT_OBJECT_PRONOUNS_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Subject & Object Pronouns, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'subject_object_pronouns' && level === 'hard') {
    return [...SUBJECT_OBJECT_PRONOUNS_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Possessives, serve the 30 handcrafted questions directly
  if (selectedTense === 'possessives' && level === 'easy') {
    return [...POSSESSIVES_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Possessives, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'possessives' && level === 'medium') {
    return [...POSSESSIVES_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Possessives, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'possessives' && level === 'hard') {
    return [...POSSESSIVES_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Demonstratives, serve the 30 handcrafted questions directly
  if (selectedTense === 'demonstratives' && level === 'easy') {
    return [...DEMONSTRATIVES_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Demonstratives, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'demonstratives' && level === 'medium') {
    return [...DEMONSTRATIVES_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Demonstratives, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'demonstratives' && level === 'hard') {
    return [...DEMONSTRATIVES_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Indefinite Pronouns, serve the 30 handcrafted questions directly
  if (selectedTense === 'indefinite_pronouns' && level === 'easy') {
    return [...INDEFINITE_PRONOUNS_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Indefinite Pronouns, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'indefinite_pronouns' && level === 'medium') {
    return [...INDEFINITE_PRONOUNS_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Indefinite Pronouns, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'indefinite_pronouns' && level === 'hard') {
    return [...INDEFINITE_PRONOUNS_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Determiners, serve the 30 handcrafted questions directly
  if (selectedTense === 'determiners' && level === 'easy') {
    return [...DETERMINERS_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Determiners, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'determiners' && level === 'medium') {
    return [...DETERMINERS_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Determiners, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'determiners' && level === 'hard') {
    return [...DETERMINERS_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Negation, serve the 30 handcrafted questions directly
  if (selectedTense === 'negation' && level === 'easy') {
    return [...NEGATION_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Negation, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'negation' && level === 'medium') {
    return [...NEGATION_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Negation, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'negation' && level === 'hard') {
    return [...NEGATION_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Imperatives, serve the 30 handcrafted questions directly
  if (selectedTense === 'imperatives' && level === 'easy') {
    return [...IMPERATIVES_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Imperatives, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'imperatives' && level === 'medium') {
    return [...IMPERATIVES_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Imperatives, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'imperatives' && level === 'hard') {
    return [...IMPERATIVES_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for There is / There are, serve the 30 handcrafted questions directly
  if (selectedTense === 'there_is_there_are' && level === 'easy') {
    return [...THERE_IS_ARE_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for There is / There are, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'there_is_there_are' && level === 'medium') {
    return [...THERE_IS_ARE_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for There is / There are, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'there_is_there_are' && level === 'hard') {
    return [...THERE_IS_ARE_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Used to / Be used to / Get used to, serve the 30 handcrafted questions directly
  if (selectedTense === 'used_to_be_used_to_get_used_to' && level === 'easy') {
    return [...USED_TO_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Used to / Be used to / Get used to, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'used_to_be_used_to_get_used_to' && level === 'medium') {
    return [...USED_TO_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Used to / Be used to / Get used to, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'used_to_be_used_to_get_used_to' && level === 'hard') {
    return [...USED_TO_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Have / Have got, serve the 30 handcrafted questions directly
  if (selectedTense === 'have_have_got' && level === 'easy') {
    return [...HAVE_GOT_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Have / Have got, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'have_have_got' && level === 'medium') {
    return [...HAVE_GOT_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected easy level for Causative Verbs, serve the 30 handcrafted questions directly
  if (selectedTense === 'causative_verbs' && level === 'easy') {
    return [...CAUSATIVE_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Causative Verbs, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'causative_verbs' && level === 'medium') {
    return [...CAUSATIVE_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Causative Verbs, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'causative_verbs' && level === 'hard') {
    return [...CAUSATIVE_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for So / Neither / Either / Too, serve the 30 handcrafted easy questions directly
  if (selectedTense === 'so_neither_either_too' && level === 'easy') {
    return [...SO_NEITHER_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for So / Neither / Either / Too, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'so_neither_either_too' && level === 'medium') {
    return [...SO_NEITHER_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for So / Neither / Either / Too, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'so_neither_either_too' && level === 'hard') {
    return [...SO_NEITHER_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Ellipsis & Substitution, serve the 30 handcrafted easy questions directly
  if (selectedTense === 'ellipsis_substitution' && level === 'easy') {
    return [...ELLIPSIS_SUBSTITUTION_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Ellipsis & Substitution, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'ellipsis_substitution' && level === 'medium') {
    return [...ELLIPSIS_SUBSTITUTION_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Ellipsis & Substitution, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'ellipsis_substitution' && level === 'hard') {
    return [...ELLIPSIS_SUBSTITUTION_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Parallel Structure, serve the 30 handcrafted easy questions directly
  if (selectedTense === 'parallel_structure' && level === 'easy') {
    return [...PARALLEL_STRUCTURE_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Parallel Structure, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'parallel_structure' && level === 'medium') {
    return [...PARALLEL_STRUCTURE_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Parallel Structure, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'parallel_structure' && level === 'hard') {
    return [...PARALLEL_STRUCTURE_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Word Order, serve the 30 handcrafted easy questions directly
  if (selectedTense === 'word_order' && level === 'easy') {
    return [...WORD_ORDER_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Word Order, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'word_order' && level === 'medium') {
    return [...WORD_ORDER_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Word Order, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'word_order' && level === 'hard') {
    return [...WORD_ORDER_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Inversion, serve the 30 handcrafted easy questions directly
  if (selectedTense === 'inversion' && level === 'easy') {
    return [...INVERSION_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Inversion, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'inversion' && level === 'medium') {
    return [...INVERSION_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Inversion, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'inversion' && level === 'hard') {
    return [...INVERSION_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Cleft Sentences, serve the 30 handcrafted easy questions directly
  if (selectedTense === 'cleft_sentences' && level === 'easy') {
    return [...CLEFT_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Cleft Sentences, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'cleft_sentences' && level === 'medium') {
    return [...CLEFT_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Cleft Sentences, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'cleft_sentences' && level === 'hard') {
    return [...CLEFT_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Emphasis, serve the 30 handcrafted easy questions directly
  if (selectedTense === 'emphasis' && level === 'easy') {
    return [...EMPHASIS_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Emphasis, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'emphasis' && level === 'medium') {
    return [...EMPHASIS_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Emphasis, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'emphasis' && level === 'hard') {
    return [...EMPHASIS_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Punctuation & Capitalization, serve the 30 handcrafted easy questions directly
  if (selectedTense === 'punctuation_capitalization' && level === 'easy') {
    return [...PUNCTUATION_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Punctuation & Capitalization, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'punctuation_capitalization' && level === 'medium') {
    return [...PUNCTUATION_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Punctuation & Capitalization, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'punctuation_capitalization' && level === 'hard') {
    return [...PUNCTUATION_HARD_30].slice(0, targetCount);
  }

  // If user selected easy level for Common Grammar Errors, serve the 30 handcrafted easy questions directly
  if (selectedTense === 'common_grammar_errors' && level === 'easy') {
    return [...COMMON_ERRORS_EASY_30].slice(0, targetCount);
  }

  // If user selected medium level for Common Grammar Errors, serve the 30 handcrafted medium questions directly
  if (selectedTense === 'common_grammar_errors' && level === 'medium') {
    return [...COMMON_ERRORS_MEDIUM_30].slice(0, targetCount);
  }

  // If user selected hard level for Common Grammar Errors, serve the 30 handcrafted hard questions directly
  if (selectedTense === 'common_grammar_errors' && level === 'hard') {
    return [...COMMON_ERRORS_HARD_30].slice(0, targetCount);
  }

  // If user selected the 12 Tenses Gauntlet Challenge, serve the 50 comprehensive questions directly
  if (level === 'gauntlet_12') {
    return [...GAUNTLET_12_TENSES_50_QUESTIONS].slice(0, targetCount);
  }

  const result: QuizQuestion[] = [];
  const usedSentenceSignatures = new Set<string>();
  const usedIds = new Set<string>();

  const isAllTenses = selectedTense === 'all';

  // 1. Gather all matching static questions from ALL_QUESTIONS
  const matchingStatic = ALL_QUESTIONS.filter(q => {
    const matchTense = isAllTenses || q.tenseId === selectedTense;
    if (level === 'easy') return matchTense && q.difficulty === 'easy';
    if (level === 'medium') return matchTense && (q.difficulty === 'medium' || q.type === 'situation_challenge' || q.type === 'two_events_challenge');
    return matchTense && (q.difficulty === 'hard' || q.hasNoSignalWords);
  });

  // Add static questions without duplication
  for (const q of matchingStatic) {
    const signature = (q.sentenceWithBlank || q.promptAr).toLowerCase().trim();
    if (!usedSentenceSignatures.has(signature) && !usedIds.has(q.id)) {
      result.push(q);
      usedSentenceSignatures.add(signature);
      usedIds.add(q.id);
      if (result.length >= targetCount) break;
    }
  }

  // 2. Gather from handcrafted bank TENSE_QUESTIONS_DATA
  const targetTenseIds: TenseId[] = isAllTenses
    ? (ALL_TENSES.map(t => t.id) as TenseId[])
    : ([selectedTense as TenseId]);

  if (result.length < targetCount) {
    for (const tId of targetTenseIds) {
      const bank = TENSE_QUESTIONS_DATA[tId];
      if (bank) {
        const pool = (level === 'easy') ? bank.easy : (level === 'medium') ? bank.medium : (level === 'hard') ? bank.hard : [...bank.easy, ...bank.medium, ...bank.hard];
        const tenseMeta = ALL_TENSES.find(t => t.id === tId);

        for (const item of pool) {
          const signature = item.sentenceWithBlank.toLowerCase().trim();
          if (!usedSentenceSignatures.has(signature)) {
            const questionId = `bank_${tId}_${level}_${result.length}_${Math.random().toString(36).substring(2, 6)}`;
            result.push({
              id: questionId,
              tenseId: tId,
              difficulty: level === 'easy' ? 'easy' : level === 'medium' ? 'medium' : 'hard',
              type: level === 'hard' ? 'no_clues' : level === 'medium' ? 'situation_challenge' : 'multiple_choice',
              hasNoSignalWords: level === 'hard',
              promptAr: item.promptAr,
              sentenceWithBlank: item.sentenceWithBlank,
              options: shuffleArray([item.correct, ...item.distractors]),
              correctAnswer: item.correct,
              explanation: {
                whyCorrectAr: item.whyCorrectAr,
                temporalRelationshipAr: item.temporalAr,
                whyTenseFitsAr: `هذا التركيب هو التطبيق النموذجي لـ ${tenseMeta?.nameAr || tId}.`,
                whyOthersWrongAr: `الخيارات الأخرى تستخدم أزمنة وتراكيب غير صحيحة سياقياً.`,
                confusableTenseAr: tenseMeta?.vsComparisons?.[0]?.targetTenseName || 'الأزمنة المشابهة',
              },
            });
            usedSentenceSignatures.add(signature);
            usedIds.add(questionId);
            if (result.length >= targetCount) break;
          }
        }
      }
      if (result.length >= targetCount) break;
    }
  }

  // 3. Gather from GRAMMAR_RULE_TEMPLATES if a grammar rule is selected
  if (result.length < targetCount && !isAllTenses) {
    const ruleTemplates = GRAMMAR_RULE_TEMPLATES[selectedTense];
    if (ruleTemplates) {
      const pool = (level === 'easy') ? ruleTemplates.easy : (level === 'medium') ? ruleTemplates.medium : (level === 'hard') ? ruleTemplates.hard : [...ruleTemplates.easy, ...ruleTemplates.medium, ...ruleTemplates.hard];
      const ruleMeta = ALL_TENSES.find(t => t.id === selectedTense);

      for (const item of pool) {
        const signature = item.sentenceWithBlank.toLowerCase().trim();
        if (!usedSentenceSignatures.has(signature)) {
          const questionId = `rule_bank_${selectedTense}_${result.length}_${Math.random().toString(36).substring(2, 6)}`;
          result.push({
            id: questionId,
            tenseId: selectedTense as TenseId,
            difficulty: level === 'easy' ? 'easy' : level === 'medium' ? 'medium' : 'hard',
            type: 'multiple_choice',
            promptAr: item.promptAr,
            sentenceWithBlank: item.sentenceWithBlank,
            options: shuffleArray([item.correct, ...item.distractors]),
            correctAnswer: item.correct,
            explanation: {
              whyCorrectAr: item.whyCorrectAr,
              temporalRelationshipAr: item.temporalAr,
              whyTenseFitsAr: `هذا التركيب يطابق قاعدة ${ruleMeta?.nameAr || selectedTense}.`,
              whyOthersWrongAr: `الخيارات الأخرى غير صحيحة نحوياً.`,
              confusableTenseAr: ruleMeta?.nameAr || 'القواعد المشابهة',
            },
          });
          usedSentenceSignatures.add(signature);
          usedIds.add(questionId);
          if (result.length >= targetCount) break;
        }
      }
    }
  }

  // 4. Procedurally generate high-variety, guaranteed unique questions until targetCount (50) is reached
  let procIndex = 0;
  let safetyLoop = 0;

  while (result.length < targetCount && safetyLoop < 1200) {
    safetyLoop++;
    const tId = targetTenseIds[procIndex % targetTenseIds.length];
    const tenseMeta = ALL_TENSES.find(t => t.id === tId);

    const isGrammarRule = !tId.startsWith('present_') && !tId.startsWith('past_') && !tId.startsWith('future_');

    const generatedQ = isGrammarRule
      ? generateProceduralRuleQuestion(tId, level, procIndex, tenseMeta)
      : generateProceduralTenseQuestion(tId, level, procIndex, tenseMeta);

    const signature = (generatedQ.sentenceWithBlank || generatedQ.promptAr).toLowerCase().trim();

    if (!usedSentenceSignatures.has(signature)) {
      result.push(generatedQ);
      usedSentenceSignatures.add(signature);
      usedIds.add(generatedQ.id);
    }

    procIndex++;
  }

  // Shuffle questions so they appear in fresh, varied orders
  return shuffleArray(result).slice(0, targetCount);
}

function shuffleArray<T>(array: T[]): T[] {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}
