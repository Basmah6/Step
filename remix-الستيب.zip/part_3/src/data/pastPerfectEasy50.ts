import { QuizQuestion } from '../types';

export const PAST_PERFECT_EASY_50: QuizQuestion[] = [
  {
    "id": "pp_easy_1",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد المناسب للماضي التام مع (I):",
    "sentenceWithBlank": "I _______ finished my homework before the teacher arrived.",
    "options": [
      "had",
      "has",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام نستخدم الفعل المساعد (had + P.P) لجميع الضمائر للتعبير عن حدث وقع قبل حدث آخر في الماضي.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_2",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد للماضي التام مع الفاعل المفرد (She):",
    "sentenceWithBlank": "She _______ cleaned her room before her mother came.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had) مع جميع الفواعل في الماضي التام، مثل (She had cleaned) قبل قدوم الأم.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_3",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد للماضي التام مع الفاعل الجمع (They):",
    "sentenceWithBlank": "They _______ played football before it started to rain.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had) مع (They) للدلالة على الحدث الأسبق في الماضي (They had played).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_4",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد للماضي التام مع (He):",
    "sentenceWithBlank": "He _______ left the office when I called him.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had left) للدلالة على مغادرته المكتب قبل إجراء المكالمة.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_5",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد للماضي التام مع (We):",
    "sentenceWithBlank": "We _______ lived in that city before we moved here.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had lived) للتعبير عن العيش هناك قبل الانتقال إلى هنا.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_6",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد للماضي التام مع (You):",
    "sentenceWithBlank": "You _______ eaten all the food before I got home.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had eaten) للتعبير عن الأكل قبل الوصول إلى المنزل.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_7",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد للماضي التام مع (The sun):",
    "sentenceWithBlank": "The sun _______ set before we reached the camp.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had set) للدلالة على غروب الشمس قبل وصولنا إلى المخيم.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_8",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد للماضي التام مع (Birds):",
    "sentenceWithBlank": "Birds _______ flown away before the storm began.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had flown) للدلالة على طيران الطيور بعيداً قبل بدء العاصفة.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_9",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد للماضي التام مع الفاعل المفرد (My cat):",
    "sentenceWithBlank": "My cat _______ eaten its food before I went out.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had eaten) للدلالة على أكل القطة لطعامها قبل خروجي.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_10",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد للماضي التام مع (Water):",
    "sentenceWithBlank": "Water _______ boiled before the electricity went off.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had boiled) للدلالة على غليان الماء قبل انقطاع الكهرباء.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_11",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد المنفي للماضي التام مع (I):",
    "sentenceWithBlank": "I _______ not seen that movie before last night.",
    "options": [
      "had",
      "have",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "تكوين النفي في الماضي التام هو (had not + التصريف الثالث seen).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_12",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد المنفي للماضي التام مع (She):",
    "sentenceWithBlank": "She _______ not finished her project when the bell rang.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had not finished) للدلالة على عدم إتمام المشروع عند رنين الجرس.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_13",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد المنفي مع (They):",
    "sentenceWithBlank": "They _______ not arrived when we reached the station.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had not arrived) للدلالة على عدم وصولهم بحلول وقت وصولنا للمحطة.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_14",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد المنفي مع (He):",
    "sentenceWithBlank": "He _______ not read the book before the test.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had not read) للدلالة على عدم قراءة الكتاب قبل الاختبار.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_15",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد المنفي مع (We):",
    "sentenceWithBlank": "We _______ not met before that day.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had not met) للدلالة على عدم التقائنا قبل ذلك اليوم المحدد.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_16",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد المنفي مع (You):",
    "sentenceWithBlank": "You _______ not told me the truth before I found out.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had not told) للدلالة على عدم قول الحقيقة قبل اكتشافها.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_17",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد المنفي مع (The dog):",
    "sentenceWithBlank": "The dog _______ not eaten before we fed it.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had not eaten) للدلالة على عدم أكل الكلب قبل أن نطعه.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_18",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد المنفي للفاعل الجمع المركب:",
    "sentenceWithBlank": "Ali and Ahmed _______ not called me before noon.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had not called) للدلالة على عدم اتصالهما قبل الظهر.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_19",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد المنفي مع (It):",
    "sentenceWithBlank": "It _______ not rained before yesterday.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had not rained) للدلالة على عدم سقوط المطر قبل يوم أمس.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_20",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد المنفي مع (My mother):",
    "sentenceWithBlank": "My mother _______ not cooked lunch when we arrived.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had not cooked) للدلالة على عدم طهو الغداء بحلول وقت وصولنا.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_21",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد في بداية سؤال الماضي التام:",
    "sentenceWithBlank": "_______ you ever been to Paris before last year?",
    "options": [
      "Has",
      "Had",
      "Have",
      "Did"
    ],
    "correctAnswer": "Had",
    "explanation": {
      "whyCorrectAr": "يبدأ سؤال الماضي التام دائماً بـ (Had) متبوعاً بالفاعل والتصريف الثالث (Had you ever been).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_22",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد في بداية السؤال مع (she):",
    "sentenceWithBlank": "_______ she finished her exam when time was up?",
    "options": [
      "Have",
      "Had",
      "Has",
      "Did"
    ],
    "correctAnswer": "Had",
    "explanation": {
      "whyCorrectAr": "يبدأ السؤال في الماضي التام بـ (Had she finished).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_23",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد في بداية السؤال مع (they):",
    "sentenceWithBlank": "_______ they played this game before we tried it?",
    "options": [
      "Has",
      "Had",
      "Have",
      "Did"
    ],
    "correctAnswer": "Had",
    "explanation": {
      "whyCorrectAr": "يبدأ السؤال في الماضي التام بـ (Had they played).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_24",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد في بداية السؤال مع (he):",
    "sentenceWithBlank": "_______ he washed his car before it rained?",
    "options": [
      "Have",
      "Had",
      "Has",
      "Did"
    ],
    "correctAnswer": "Had",
    "explanation": {
      "whyCorrectAr": "يبدأ السؤال في الماضي التام بـ (Had he washed).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_25",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد في بداية السؤال مع (we):",
    "sentenceWithBlank": "_______ we met somewhere before that party?",
    "options": [
      "Has",
      "Had",
      "Have",
      "Did"
    ],
    "correctAnswer": "Had",
    "explanation": {
      "whyCorrectAr": "يبدأ السؤال في الماضي التام بـ (Had we met).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_26",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد أداة الاستفهام (What):",
    "sentenceWithBlank": "What _______ you done before I arrived?",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في سؤال Wh- بالماضي التام نضع (had) بعد أداة الاستفهام متبوعاً بالفاعل (What had you done).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_27",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد أداة الاستفهام (Where):",
    "sentenceWithBlank": "Where _______ she gone before we looked for her?",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نضع (had) بعد (Where) في الماضي التام (Where had she gone).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_28",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد أداة الاستفهام (Why):",
    "sentenceWithBlank": "Why _______ they left early before the show ended?",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نضع (had) بعد (Why) للسؤال عن سبب المغادرة الأسبق (Why had they left).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_29",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد أداة الاستفهام (Who):",
    "sentenceWithBlank": "Who _______ he invited before the party started?",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نضع (had) بعد (Who) في الماضي التام (Who had he invited).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_30",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد عبارة الاستفهام:",
    "sentenceWithBlank": "How many times _______ it rained before yesterday?",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نضع (had) بعد (How many times) للسؤال عن عدد المرات السابقة في الماضي (had it rained).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_31",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر صيغة التصريف الثالث (P.P) المناسبة بعد (had):",
    "sentenceWithBlank": "I had _______ my keys before I went out.",
    "options": [
      "lose",
      "loses",
      "losing",
      "lost"
    ],
    "correctAnswer": "lost",
    "explanation": {
      "whyCorrectAr": "بعد الفعل المساعد (had) في الماضي التام يجب استخدام التصريف الثالث للفعل (lost).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_32",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر التصريف الثالث للفعل (buy):",
    "sentenceWithBlank": "She had _______ a new car before she moved.",
    "options": [
      "buy",
      "buys",
      "buying",
      "bought"
    ],
    "correctAnswer": "bought",
    "explanation": {
      "whyCorrectAr": "التصريف الثالث من الفعل (buy) هو (bought) بعد (had).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_33",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر صيغة التصريف الثالث المناسبة للذهاب والعودة / الزيارة:",
    "sentenceWithBlank": "They had _______ to France before they visited Italy.",
    "options": [
      "go",
      "goes",
      "going",
      "been"
    ],
    "correctAnswer": "been",
    "explanation": {
      "whyCorrectAr": "نستخدم (been) كتصريف ثالث بعد (had) للدلالة على زيارة فرنسا سابقاً.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_34",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر التصريف الثالث للفعل (write):",
    "sentenceWithBlank": "He had _______ a letter before the phone rang.",
    "options": [
      "write",
      "writes",
      "writing",
      "written"
    ],
    "correctAnswer": "written",
    "explanation": {
      "whyCorrectAr": "التصريف الثالث للفعل غير المنتظم (write) هو (written) بعد (had).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_35",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر التصريف الثالث للفعل (eat):",
    "sentenceWithBlank": "We had _______ our breakfast before we left home.",
    "options": [
      "eat",
      "eats",
      "eating",
      "eaten"
    ],
    "correctAnswer": "eaten",
    "explanation": {
      "whyCorrectAr": "التصريف الثالث للفعل (eat) هو (eaten) بعد (had).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_36",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر التصريف الثالث للفعل (go):",
    "sentenceWithBlank": "The children had _______ to bed before their parents returned.",
    "options": [
      "go",
      "goes",
      "going",
      "gone"
    ],
    "correctAnswer": "gone",
    "explanation": {
      "whyCorrectAr": "التصريف الثالث للفعل (go) هو (gone) بعد (had).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_37",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر التصريف الثالث للفعل (do):",
    "sentenceWithBlank": "You had _______ a great job before you resigned.",
    "options": [
      "do",
      "does",
      "doing",
      "done"
    ],
    "correctAnswer": "done",
    "explanation": {
      "whyCorrectAr": "التصريف الثالث للفعل (do) هو (done) بعد (had).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_38",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر التصريف الثالث للفعل (make):",
    "sentenceWithBlank": "The chef had _______ a delicious cake before the guests arrived.",
    "options": [
      "make",
      "makes",
      "making",
      "made"
    ],
    "correctAnswer": "made",
    "explanation": {
      "whyCorrectAr": "التصريف الثالث للفعل (make) هو (made) بعد (had).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_39",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر التصريف الثالث للفعل المنتظم (die):",
    "sentenceWithBlank": "The flowers had _______ because of the frost before we saved them.",
    "options": [
      "die",
      "dies",
      "dying",
      "died"
    ],
    "correctAnswer": "died",
    "explanation": {
      "whyCorrectAr": "التصريف الثالث للفعل (die) هو (died) بعد (had).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_40",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر التصريف الثالث للفعل (give):",
    "sentenceWithBlank": "My friends had _______ me a nice gift before my birthday party.",
    "options": [
      "give",
      "gives",
      "giving",
      "given"
    ],
    "correctAnswer": "given",
    "explanation": {
      "whyCorrectAr": "التصريف الثالث للفعل غير المنتظم (give) هو (given) بعد (had).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_41",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد المناسب مع (already) في الماضي التام:",
    "sentenceWithBlank": "I _______ already eaten my dinner when he called.",
    "options": [
      "had",
      "have",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had already eaten) للتعبير عن حدث تم وانتهى مسبقاً قبل وقوع مكالمة الهاتف في الماضي.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_42",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد المناسب مع (just) في الماضي التام:",
    "sentenceWithBlank": "She _______ just arrived at the office when the manager called her.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had just arrived) للدلالة على اكتمال الوصول للتو قبل اتصال المدير.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_43",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر صيغة النفي الصحيحة في الماضي التام:",
    "sentenceWithBlank": "They _______ not finished their work when I saw them.",
    "options": [
      "has not",
      "had not",
      "have not",
      "did not"
    ],
    "correctAnswer": "had not",
    "explanation": {
      "whyCorrectAr": "صيغة النفي في الماضي التام هي (had not) متبوعة بالتصريف الثالث (finished).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_44",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد لوصف مدة سابقة لحدث ماضٍ:",
    "sentenceWithBlank": "He _______ known her for ten years before they got married.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had known) للتعبير عن معرفة استمرت لمدة 10 سنوات قبل زواجهما في الماضي.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_45",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد لوصف تكرار الزيارة قبل حدث ماضٍ:",
    "sentenceWithBlank": "We _______ visited them many times before they moved.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had visited) للتعبير عن تكرار الزيارة في الماضي التام قبل انتقالهم.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_46",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع (never) في الماضي التام:",
    "sentenceWithBlank": "You _______ never seen a whale before we went on that trip.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had never seen) لنفي التجربة في الماضي التام قبل تلك الرحلة.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_47",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع (just) للدلالة على مغادرة القطار:",
    "sentenceWithBlank": "The train _______ just left the station when we reached the platform.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had just left) للدلالة على أن مغادرة القطار حدثت للتو قبل وصولنا إلى الرصيف.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_48",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد للحدث الأسبق في الماضي:",
    "sentenceWithBlank": "Look! Someone _______ broken the window before we woke up.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "كسر النافذة حدث قبل استيقاظنا في الماضي، لذا يأخذ الماضي التام (had broken).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_49",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد لإتمام قراءة عدد من الكتب قبل نهاية الأسبوع:",
    "sentenceWithBlank": "I _______ read three books before last week ended.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had read) للدلالة على إتمام قراءة 3 كتب قبل نقطة زمنية محددة في الماضي.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_easy_50",
    "tenseId": "past_perfect",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد لوصف فترة عمل سابقة لإغلاق الشركة:",
    "sentenceWithBlank": "She _______ worked there for five years before the company closed.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had worked) للتعبير عن فترة العمل التي سبقت إغلاق الشركة في الماضي.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  }
];
