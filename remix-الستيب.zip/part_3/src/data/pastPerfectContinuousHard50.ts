import { QuizQuestion } from '../types';

export const PAST_PERFECT_CONTINUOUS_HARD_50: QuizQuestion[] = [
  {
    "id": "ppc_hard_1",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كنت أبحث عن مفاتيحي لأكثر من ساعة قبل أن أجدها أخيراً في جيبي.",
    "sentenceWithBlank": "I _______ looking for my keys for over an hour before I finally found them in my pocket.",
    "options": [
      "has been",
      "had been",
      "have been",
      "was being"
    ],
    "correctAnswer": "had been",
    "explanation": {
      "whyCorrectAr": "مع استمرار الحدث في الماضي قبل حدث آخر، نستخدم الماضي التام المستمر (had been looking).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_2",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كانت تدرس طوال الليل قبل أن تخوض امتحانات البورد الطبي.",
    "sentenceWithBlank": "She _______ studying all night before she took the medical board exams.",
    "options": [
      "have been",
      "had been",
      "has been",
      "was being"
    ],
    "correctAnswer": "had been",
    "explanation": {
      "whyCorrectAr": "الفاعل المفرد (she) يسبقه (had been studying).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_3",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "لم يكن أي من الفنيين يعمل على النظام قبل تعطله.",
    "sentenceWithBlank": "Neither of the technicians _______ working on the system before it crashed.",
    "options": [
      "have been",
      "had been",
      "were being",
      "have"
    ],
    "correctAnswer": "had been",
    "explanation": {
      "whyCorrectAr": "(Neither) تُعامل معاملة المفرد في القواعد التقليدية، فيأخذ الفعل (had been working).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_4",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كان عدد السياح الذين يزورون البلاد يتزايد باطراد قبل الأزمة.",
    "sentenceWithBlank": "The number of tourists visiting the country _______ been increasing steadily before the crisis.",
    "options": [
      "had",
      "have",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "عبارة (The number of) تعني \"رقم/عدد\" وتأخذ فعلاً مفرداً (had been increasing).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_5",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كان عدد من العمال مضربين لأيام للمطالبة بأجور أفضل قبل موافقة الإدارة.",
    "sentenceWithBlank": "A number of workers _______ been striking for better wages for days before management agreed.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "عبارة (A number of) تعني \"العديد من\" وتأخذ أفعال جمع (had been striking).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_6",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كانت الرياضيات تتحدى الباحثين لقرون قبل النظرية الجديدة.",
    "sentenceWithBlank": "Mathematics _______ been challenging researchers for centuries before the new theorem.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "اسم المادة (Mathematics) مفرد، فيأخذ (had been challenging).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_7",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كانت خمسون دولاراً تتراكم في الحساب قبل سحبها.",
    "sentenceWithBlank": "Fifty dollars _______ been accumulating in the account before it was withdrawn.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "المبالغ المالية كوحدة واحدة تُعامل معاملة المفرد (had been accumulating).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_8",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كان كل من المشاركين يقدم ملاحظاته قبل انتهاء الندوة.",
    "sentenceWithBlank": "Each of the participants _______ been giving feedback before the seminar ended.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الكلمة الأساسية هي (Each) وتأخذ فعلاً مفرداً (had been giving).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_9",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كان أكثر من شخص يشتكون من الضوضاء قبل تدخل الأمن.",
    "sentenceWithBlank": "More than one person _______ been complaining about the noise before security intervened.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "التركيب (More than one + اسم مفرد) يأخذ دائماً فعلاً مفرداً (had been complaining).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_10",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كانت الفيزياء تتقدم بسرعة قبل هذا الإنجاز الكبير.",
    "sentenceWithBlank": "Physics _______ been advancing rapidly before the breakthrough.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "أسماء العلوم (Physics) مفردة وتأخذ (had been advancing).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_11",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كان الخبز والزبدة يشبعاننا لساعات قبل تقديم الغداء.",
    "sentenceWithBlank": "Bread and butter _______ been keeping us full for hours before lunch was served.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الوجبة الواحدة المشتركة تعامل معاملة المفرد (had been keeping).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_12",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كانت الشرطة تحقق في القضية لمدة أسبوع قبل تنفيذ الاعتقال.",
    "sentenceWithBlank": "The police _______ been investigating the case for a week before they made an arrest.",
    "options": [
      "has",
      "had",
      "were",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "كلمة (Police) تُعامل معاملة الجمع دائماً (had been investigating).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_13",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كانت عائلتي تعيش في ذلك الحي لأجيال قبل انتقالنا.",
    "sentenceWithBlank": "My family _______ been living in that neighborhood for generations before we moved.",
    "options": [
      "had",
      "have",
      "has",
      "were"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "العائلة عبر الأجيال في الماضي التام المستمر تأخذ (had been living).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_14",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كانت اللجنة تراجع الاقتراح لأيام قبل الموافقة عليه.",
    "sentenceWithBlank": "The committee _______ been reviewing the proposal for days before approving it.",
    "options": [
      "had",
      "have",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "اللجنة كوحدة واحدة تأخذ (had been reviewing).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_15",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "لم يكن المعلم ولا الطلاب منتبهين قبل التحذير.",
    "sentenceWithBlank": "Neither the teacher nor the students _______ been paying attention before the warning.",
    "options": [
      "has",
      "had",
      "were",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في قاعدة (Neither... nor)، يتبع الفعل الفاعل الأقرب (students جمع، فيأخذ had been).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_16",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "لم يكن الطلاب ولا المعلم منتبهاً قبل التحذير.",
    "sentenceWithBlank": "Neither the students nor the teacher _______ been paying attention before the warning.",
    "options": [
      "had",
      "have",
      "were",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الفاعل الأقرب هو (teacher) مفرد، فيأخذ (had been paying).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_17",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "نادراً ما كان أي شخص يعمل بجد مثله قبل ترقيته.",
    "sentenceWithBlank": "Rarely _______ anyone been working as hard as him before he got promoted.",
    "options": [
      "have",
      "had",
      "were",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "عند البدء بظرف نفي (Rarely)، يقلب الفعل والفاعل. الفاعل (anyone) مفرد، فيأخذ (had been working).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_18",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "لم يسبق لي أبداً أن شعرت بهذا القدر من النشاط قبل تناول ذلك الفيتامين.",
    "sentenceWithBlank": "Never _______ I been feeling so energetic before I took that vitamin.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "تقديم ظرف النفي (Never) يولد قلباً (Inversion) مع الضمير I، فيأخذ الفعل المساعد (had been feeling).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_19",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "مؤخراً فقط كانت تأخذ دروساً في الرسم قبل دخول المسابقة.",
    "sentenceWithBlank": "Only recently _______ she been taking painting lessons before she entered the contest.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "تقديم الظرف (Only recently) يتطلب قلباً، والفاعل (she) مفرد يأخذ (had been taking).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_20",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "قليلاً ما كان يهتم بالعواقب قبل مواجهة الكارثة.",
    "sentenceWithBlank": "Little _______ he been caring about the consequences before he faced disaster.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "البدء بـ (Little) النافية يولد قلباً، والفاعل (he) يأخذ (had been caring).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_21",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كانت المرة الثانية التي يتصرف فيها بغرابة قبل أن يعتذر.",
    "sentenceWithBlank": "It was the second time he _______ been acting strangely before he apologized.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "التركيب (It was the second time + مفرد) يتبعه ماضٍ تام مستمر مع (had been acting).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_22",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كنت أعمل على ذلك المشروع لأشهر قبل إنجازه النهائي.",
    "sentenceWithBlank": "I _______ been working on that project for months before it was finalized.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "مع الضمير I، نستخدم (had been working).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_23",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كان المقص ملقى على المكتب لأيام قبل أن ألتقطه.",
    "sentenceWithBlank": "The scissors _______ been lying on the desk for days before I picked them up.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الأدوات المكونة من جزأين (scissors) جمع وتأخذ (had been lying).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_24",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كان بنطالي يبلى بسرعة قبل أن أستبدله.",
    "sentenceWithBlank": "My trousers _______ been wearing out quickly before I replaced them.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "كلمة (trousers) جمع دائماً وتأخذ (had been wearing).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_25",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كانت الحصبة تنتشر في أنحاء المنطقة قبل حملة التطعيم.",
    "sentenceWithBlank": "Measles _______ been spreading across the region before the vaccination campaign.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "اسم المرض (Measles) مفرد ويأخذ (had been spreading).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_26",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كانت الولايات المتحدة تستثمر بكثافة في التكنولوجيا قبل تغيير السياسة.",
    "sentenceWithBlank": "The United States _______ been investing heavily in technology before the policy change.",
    "options": [
      "had",
      "have",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "اسم الدولة المفرد (The United States) يأخذ (had been investing).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_27",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كان علم الاقتصاد يجذب المزيد من الطلاب قبل تغيير المنهج.",
    "sentenceWithBlank": "Economics _______ been attracting more students before the curriculum changed.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "اسم العلم (Economics) مفرد ويأخذ (had been attracting).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_28",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كان الطاقم يجهز السفينة للمغادرة قبل هبوب العاصفة.",
    "sentenceWithBlank": "The crew _______ been preparing the ship for departure before the storm hit.",
    "options": [
      "had",
      "have",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "طاقم العمل في الماضي التام المستمر يأخذ (had been preparing).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_29",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كان الجمهور يطالب بخفض الضرائب قبل استجابة الحكومة.",
    "sentenceWithBlank": "The public _______ been demanding lower taxes before the government reacted.",
    "options": [
      "had",
      "have",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الجمهور كوحدة عامة واحدة يأخذ (had been demanding).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_30",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كانت عشر سنوات تمر بسرعة شديدة قبل أن ندرك ذلك.",
    "sentenceWithBlank": "Ten years _______ been passing very quickly before we realized it.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الفترات الزمنية كوحدات متتابعة في الماضي التام المستمر تأخذ (had been passing).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_31",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كان الرياضيون يركضون لمسافة ثلاثة أميال قبل أن يوقفهم المدرب.",
    "sentenceWithBlank": "The athletes _______ been running for three miles before the coach stopped them.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الفاعل (athletes) جمع، فيأخذ (had been running).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_32",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كان أيا من المرشحين ينتظر بالخارج لمدة ساعة قبل المقابلة.",
    "sentenceWithBlank": "Either of the candidates _______ been waiting outside for an hour before the interview.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "كلمة (Either) تعني \"أيهما\" وتأخذ فعلاً مفرداً (had been waiting).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_33",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "لم تكن أي من الخطتين تنجح قبل أن نتخلى عنهما.",
    "sentenceWithBlank": "Neither of the two plans _______ been working out before we abandoned them.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "(Neither) مفردة فيأخذ الفعل (had been working).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_34",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "نادراً ما كنت أمر بمثل هذا التركيز الشديد قبل تلك الخلوة.",
    "sentenceWithBlank": "Seldom _______ I been experiencing such intense focus before that retreat.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "تقديم ظرف النفي (Seldom) مع الضمير I يتطلب قلباً (had been experiencing).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_35",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كان تقدم كبير يتحقق من خلال البحث المستمر قبل الموعد النهائي.",
    "sentenceWithBlank": "Much progress _______ been achieved through continuous research before the deadline.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "كلمة (progress) غير معدودة مفردة (had been achieved).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_36",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كان قدر كبير من المال يُنفق على الحملة قبل انتهائها.",
    "sentenceWithBlank": "A great deal of money _______ been spent on the campaign before it ended.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "عبارة (A great deal of) تتبعها كلمة غير معدودة مفردة (had been spent).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_37",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كان متسع كبير من الوقت يُمنح للفريق قبل الاختبار.",
    "sentenceWithBlank": "Plenty of time _______ been given to the team before the test.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "كلمة (time) غير معدودة مفردة، فتأخذ (had been given).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_38",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كان معظم الكعك قد أُكل قبل وصولي.",
    "sentenceWithBlank": "Most of the cake _______ been eaten before I arrived.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "(Most of) تتبع الاسم الذي بعدها (cake مفرد)، فيأخذ (had been eaten).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_39",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كان معظم التفاح قد أُكل قبل وصولي.",
    "sentenceWithBlank": "Most of the apples _______ been eaten before I arrived.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "(Most of) تتبع (apples جمع)، فيأخذ (had been eaten).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_40",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كان نصف المال مخصصاً للمشروع قبل إلغائه.",
    "sentenceWithBlank": "Half of the money _______ been allocated for the project before it was cancelled.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "(Half of) تتبع اسم غير معدود (money مفرد)، فيأخذ (had been allocated).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_41",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كان نصف الطلاب يتدربون طوال الصباح قبل العرض.",
    "sentenceWithBlank": "Half of the students _______ been practicing all morning before the show.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "(Half of) تتبع اسم معدود جمع (students)، فيأخذ الفعل (had been practicing).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_42",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "فيم كنت تفكر أثناء المحاضرة قبل أن تغفو؟",
    "sentenceWithBlank": "What _______ you been thinking about during the lecture before you dozed off?",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "مع الضمير you في الماضي التام المستمر نسبق بـ (had).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_43",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "لماذا كانت تتجنبني طوال الأسبوع قبل أن نتحدث؟",
    "sentenceWithBlank": "Why _______ she been avoiding me all week before we spoke?",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الفاعل المفرد (she) يتطلب (had been avoiding).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_44",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "من كان يسرب معلومات سرية قبل اكتشاف الاختراق؟",
    "sentenceWithBlank": "Who _______ been leaking confidential information before the breach was found?",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "صيغة السؤال عن المفرد بـ (Who) تأخذ (had been leaking).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_45",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "منذ متى كانوا يقفون تحت المطر قبل فتح المأوى؟",
    "sentenceWithBlank": "How long _______ they been standing in the rain before the shelter opened?",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الفاعل الجمع (they) يتطلب (had been standing).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_46",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "أين كان يقيم أثناء وجوده في المدينة قبل شراء منزل؟",
    "sentenceWithBlank": "Where _______ he been staying while in town before he bought a house?",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الفاعل المفرد (he) يأخذ (had been staying).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_47",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "مع أي شركة كنت تتعاون قبل الاندماج؟",
    "sentenceWithBlank": "Which company _______ you been collaborating with before the merger?",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "مع الضمير you نستخدم (had been collaborating).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_48",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كم فصلاً كانت تحرر اليوم قبل تعطل حاسوبها؟",
    "sentenceWithBlank": "How many chapters _______ she been editing today before her computer crashed?",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الفاعل المفرد (she) يأخذ (had been editing).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_49",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "لماذا كانت الطابعة تصدر ذلك الصوت الغريب قبل أن تتعطل؟",
    "sentenceWithBlank": "Why _______ the printer been making that weird noise before it broke down?",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الفاعل المفرد غير العاقل (printer) يأخذ (had been making).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_hard_50",
    "tenseId": "past_perfect_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كم من الجهد كنت تبذله في تلك المهمة قبل أن تستسلم؟",
    "sentenceWithBlank": "How much effort _______ you been putting into that task before you gave up?",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "مع الضمير you في الماضي التام المستمر نستخدم (had been putting).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  }
];
