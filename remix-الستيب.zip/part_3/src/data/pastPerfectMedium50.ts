import { QuizQuestion } from '../types';

export const PAST_PERFECT_MEDIUM_50: QuizQuestion[] = [
  {
    "id": "pp_med_1",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد المناسب بعد التركيب (By the time):",
    "sentenceWithBlank": "By the time I arrived, she _______ already left.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "التركيب (By the time + ماض بسيط) يتبعه في الجملة الرئيسية ماضٍ تام (had already left) للدلالة على الحدث الأسبق.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_2",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد الرابط (After):",
    "sentenceWithBlank": "After he _______ finished his homework, he went out to play.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "يأتي بعد (After) زمن الماضي التام (had finished) لبيان الحدث الذي وقع أولاً.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_3",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الرابط الزمني المناسب لربط الماضي التام بالماضي البسيط:",
    "sentenceWithBlank": "They had already eaten dinner _______ I reached home.",
    "options": [
      "because",
      "since",
      "when",
      "while"
    ],
    "correctAnswer": "when",
    "explanation": {
      "whyCorrectAr": "نستخدم (when) لربط الحدث الأسبق في الماضي التام (had already eaten) بالحدث اللاحق في الماضي البسيط (reached).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_4",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد (because) لتفسير سبب المعرفة المسبقة:",
    "sentenceWithBlank": "I recognized him immediately because I _______ seen him before.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "رؤيته السابقة حدثت قبل التعرف عليه، لذا نستخدم الماضي التام (had seen).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_5",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد في الكلام المنقول (Reported Speech):",
    "sentenceWithBlank": "She told me that she _______ lost her keys the day before.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في الكلام غير المباشر في السياق الماضي، يتحول الفعل إلى الماضي التام (had lost).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_6",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع (By + سنة ماضية):",
    "sentenceWithBlank": "By 2010, my father _______ built his second house.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "مع (By 2010) نستخدم الماضي التام (had built) للدلالة على اكتمال البناء قبل حلول هذا العام.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_7",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع (never) قبل حدث في الماضي:",
    "sentenceWithBlank": "We _______ never visited that museum before our school trip last year.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had never visited) لنفي التجربة في الماضي التام قبل الرحلة المدرسية العام الماضي.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_8",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الرابط الزمني المناسب في سؤال الماضي التام:",
    "sentenceWithBlank": "Had the train left _______ you reached the station?",
    "options": [
      "already",
      "just",
      "ever",
      "before"
    ],
    "correctAnswer": "before",
    "explanation": {
      "whyCorrectAr": "نستخدم (before) للسؤال عما إذا كانت مغادرة القطار قد سبقت وصولك إلى المحطة.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_9",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد المنفي للماضي التام:",
    "sentenceWithBlank": "He failed the exam because he _______ studied hard.",
    "options": [
      "hadn't",
      "haven't",
      "hasn't",
      "didn't"
    ],
    "correctAnswer": "hadn't",
    "explanation": {
      "whyCorrectAr": "الرسوب في الامتحان كان نتيجة لعدم المذاكرة مسبقاً، لذا نستخدم (hadn't).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_10",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد المنفي لتفسير جفاف الحديقة في الماضي:",
    "sentenceWithBlank": "The garden was dry because it _______ rained for months.",
    "options": [
      "hadn't",
      "hasn't",
      "haven't",
      "didn't"
    ],
    "correctAnswer": "hadn't",
    "explanation": {
      "whyCorrectAr": "جفاف الحديقة سببه عدم هطول المطر لشهور سابقة، لذا نستخدم (hadn't).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_11",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد المنفي في الماضي التام:",
    "sentenceWithBlank": "She _______ not answered my emails before I called her.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had not answered) للدلالة على عدم الرد قبل إجراء الاتصال الهاتفي.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_12",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد لوصف المعرفة السابقة قبل الشراكة:",
    "sentenceWithBlank": "We _______ known each other for years before we became partners.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had known) للدلالة على معرفة امتدت لسنوات قبل أن نصبح شركاء في الماضي.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_13",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر صيغة الفعل بعد (Had):",
    "sentenceWithBlank": "Had the mailman _______ before you left the house?",
    "options": [
      "arrive",
      "arrives",
      "arriving",
      "arrived"
    ],
    "correctAnswer": "arrived",
    "explanation": {
      "whyCorrectAr": "بعد (Had) في السؤال بالماضي التام نستخدم التصريف الثالث (arrived).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_14",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر التركيب الصحيح للماضي التام المنفي بـ never:",
    "sentenceWithBlank": "I _______ seen such a beautiful sunset before that evening.",
    "options": [
      "ever",
      "already",
      "had never",
      "have never"
    ],
    "correctAnswer": "had never",
    "explanation": {
      "whyCorrectAr": "نستخدم (had never) متبوعاً بالتصريف الثالث (seen) لنفي التجربة قبل تلك الأمسية في الماضي.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_15",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الكلمة المناسبة للتعبير عن عدد مرات الزيارة السابقة:",
    "sentenceWithBlank": "They had visited Paris three _______ before they moved to London.",
    "options": [
      "time",
      "times",
      "timing",
      "timed"
    ],
    "correctAnswer": "times",
    "explanation": {
      "whyCorrectAr": "نستخدم اسم الجمع (times) بعد الرقم three للتعبير عن تكرار الفعل (three times).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_16",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد (Why) في الماضي التام:",
    "sentenceWithBlank": "Why _______ you left early before the party ended?",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had) بعد (Why) للسؤال عن سبب المغادرة الأسبق (Why had you left early).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_17",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد لزيادة سعر الوقود في الماضي التام:",
    "sentenceWithBlank": "The price of fuel _______ increased twice before the end of the year.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had increased) للدلالة على حدوث الزيادة مرتين قبل نهاية ذلك العام في الماضي.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_18",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع الفاعل الجمع (All my friends):",
    "sentenceWithBlank": "All my friends _______ congratulated me before the party began.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had congratulated) للدلالة على تهنئتهم لي قبل بدء الحفلة.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_19",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد في الماضي التام مع (Neither of):",
    "sentenceWithBlank": "Neither of the boys _______ done his homework before class.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في الماضي التام نستخدم (had) مع جميع الضمائر والتراكيب مثل (Neither of the boys had done).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_20",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع (Each of):",
    "sentenceWithBlank": "Each of the participants _______ received his badge before the seminar started.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had received) للدلالة على استلام كل مشارك لبطاقته قبل بدء الندوة.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_21",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد (What) للسؤال عن إنجاز ماضٍ قبل سن الثلاثين:",
    "sentenceWithBlank": "What _______ you achieved in your career before you turned 30?",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "نستخدم (had you achieved) للسؤال عن الإنجازات الأسبق من بلوغ سن الثلاثين في الماضي.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_22",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد (Where) في الماضي التام:",
    "sentenceWithBlank": "Where _______ she hidden the keys before we looked for them?",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "إخفاء المفاتيح حدث قبل البحث عنها، لذا نستخدم (Where had she hidden).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_23",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد (Who) للسؤال عن الفاعل:",
    "sentenceWithBlank": "Who _______ taken my pen before I left the room?",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "أخذ القلم حدث قبل مغادرة الغرفة، لذا نستخدم (Who had taken).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_24",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد للسؤال عن البلدان التي زرتها سابقاً:",
    "sentenceWithBlank": "Which countries _______ you visited before your trip to Asia?",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الزيارات سبقت رحلة آسيا، لذا نستخدم (Which countries had you visited).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_25",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد (How many chapters):",
    "sentenceWithBlank": "How many chapters _______ he read before the test?",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "قراءة الفصول حدثت قبل الاختبار في الماضي، لذا نستخدم (had he read).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_26",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد لإلغاء الاجتماع في الماضي التام:",
    "sentenceWithBlank": "Why _______ the company canceled the meeting before we arrived?",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "إلغاء الاجتماع حدث قبل وصولنا، لذا نستخدم (Why had the company canceled).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_27",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد للسؤال عن مدة العمل السابقة في الماضي:",
    "sentenceWithBlank": "How long _______ she worked as a nurse before she became a doctor?",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "العمل كممرضة سبق أن أصبحت طبيبة، لذا نستخدم (How long had she worked).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_28",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد للتغييرات التي وقعت قبل الحرب:",
    "sentenceWithBlank": "What changes _______ taken place in the city before the war?",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "حدوث التغييرات كان قبل الحرب في الماضي، لذا نستخدم (What changes had taken place).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_29",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد للسؤال عن المقابلة التي سبقت المؤتمر:",
    "sentenceWithBlank": "Who _______ you met before the conference started?",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "المقابلة سبقت بدء المؤتمر في الماضي، لذا نستخدم (Who had you met).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_30",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد للسؤال عن مقدار المال المنفق قبل الوصول:",
    "sentenceWithBlank": "How much money _______ you spent before you reached home?",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "إنفاق المال حدث قبل الوصول للمنزل، لذا نستخدم (had you spent).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_31",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر التصريف الثالث للفعل غير المنتظم (send):",
    "sentenceWithBlank": "I had already _______ the report to the manager before he asked.",
    "options": [
      "send",
      "sends",
      "sending",
      "sent"
    ],
    "correctAnswer": "sent",
    "explanation": {
      "whyCorrectAr": "التصريف الثالث للفعل (send) هو (sent) بعد (had already).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_32",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر التصريف الثالث للفعل (drink):",
    "sentenceWithBlank": "She had _______ three cups of coffee before noon.",
    "options": [
      "drink",
      "drinks",
      "drinking",
      "drunk"
    ],
    "correctAnswer": "drunk",
    "explanation": {
      "whyCorrectAr": "التصريف الثالث للفعل (drink) هو (drunk) بعد (had).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_33",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر التصريف الثالث للفعل المنتظم (sign):",
    "sentenceWithBlank": "They had _______ a new contract before the deadline.",
    "options": [
      "sign",
      "signs",
      "signing",
      "signed"
    ],
    "correctAnswer": "signed",
    "explanation": {
      "whyCorrectAr": "التصريف الثالث للفعل (sign) هو (signed) بعد (had).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_34",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر التصريف الثالث للفعل غير المنتظم (break):",
    "sentenceWithBlank": "He had _______ his arm before the match started.",
    "options": [
      "break",
      "breaks",
      "breaking",
      "broken"
    ],
    "correctAnswer": "broken",
    "explanation": {
      "whyCorrectAr": "التصريف الثالث للفعل (break) هو (broken) بعد (had).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_35",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر التصريف الثالث للفعل (complete):",
    "sentenceWithBlank": "We had _______ all the preparations before the guests arrived.",
    "options": [
      "complete",
      "completes",
      "completing",
      "completed"
    ],
    "correctAnswer": "completed",
    "explanation": {
      "whyCorrectAr": "التصريف الثالث للفعل (complete) هو (completed) بعد (had).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_36",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر التصريف الثالث للفعل غير المنتظم (rise):",
    "sentenceWithBlank": "The river had _______ over its banks before the dam was built.",
    "options": [
      "rise",
      "rises",
      "rising",
      "risen"
    ],
    "correctAnswer": "risen",
    "explanation": {
      "whyCorrectAr": "التصريف الثالث للفعل (rise) هو (risen) بعد (had).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_37",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر التصريف الثالث للفعل (make):",
    "sentenceWithBlank": "You had _______ a huge mistake before you noticed.",
    "options": [
      "make",
      "makes",
      "making",
      "made"
    ],
    "correctAnswer": "made",
    "explanation": {
      "whyCorrectAr": "التصريف الثالث للفعل (make) هو (made) بعد (had).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_38",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر التصريف الثالث للفعل (go):",
    "sentenceWithBlank": "The sun had _______ behind the mountains before we reached the peak.",
    "options": [
      "go",
      "goes",
      "going",
      "gone"
    ],
    "correctAnswer": "gone",
    "explanation": {
      "whyCorrectAr": "التصريف الثالث للفعل (go) هو (gone) بعد (had).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_39",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر التصريف الثالث للفعل (leave):",
    "sentenceWithBlank": "She had _______ her phone at home before she realized it.",
    "options": [
      "leave",
      "leaves",
      "leaving",
      "left"
    ],
    "correctAnswer": "left",
    "explanation": {
      "whyCorrectAr": "التصريف الثالث للفعل (leave) هو (left) بعد (had).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_40",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر التصريف الثالث للفعل (find):",
    "sentenceWithBlank": "My brother had _______ a new job before he graduated.",
    "options": [
      "find",
      "finds",
      "finding",
      "found"
    ],
    "correctAnswer": "found",
    "explanation": {
      "whyCorrectAr": "التصريف الثالث للفعل (find) هو (found) بعد (had).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_41",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الرابط الزمني لنقطة البداية المحددة:",
    "sentenceWithBlank": "I had not seen him _______ we met in school.",
    "options": [
      "for",
      "since",
      "already",
      "yet"
    ],
    "correctAnswer": "since",
    "explanation": {
      "whyCorrectAr": "نستخدم (since) مع نقطة زمنية محددة في الماضي (since we met in school) مع الماضي التام.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_42",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الرابط الزمني مع المدة الزمنية المحددة:",
    "sentenceWithBlank": "She had lived in Cairo _______ five years before moving.",
    "options": [
      "for",
      "since",
      "already",
      "yet"
    ],
    "correctAnswer": "for",
    "explanation": {
      "whyCorrectAr": "نستخدم (for) مع المدد الزمنية الممتدة (for five years) في الماضي التام.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_43",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الرابط الزمني المناسب للسؤال عن الأسبقية:",
    "sentenceWithBlank": "Had you finished your work _______ the boss arrived?",
    "options": [
      "already",
      "just",
      "ever",
      "before"
    ],
    "correctAnswer": "before",
    "explanation": {
      "whyCorrectAr": "نستخدم (before) للدلالة على وقوع إنهاء العمل قبل وصول المدير في الماضي.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_44",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الظرف المناسب لنفي التجربة في الماضي التام:",
    "sentenceWithBlank": "I had _______ been to Japan before last summer.",
    "options": [
      "ever",
      "already",
      "never",
      "yet"
    ],
    "correctAnswer": "never",
    "explanation": {
      "whyCorrectAr": "نستخدم (never) بين (had) و (been) لنفي التجربة السابقة تماماً قبل الصيف الماضي.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_45",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الظرف الدال على الحدوث للتو قبل لحظة الاتصال:",
    "sentenceWithBlank": "He had _______ returned from his trip when I called him.",
    "options": [
      "yet",
      "ever",
      "just",
      "since"
    ],
    "correctAnswer": "just",
    "explanation": {
      "whyCorrectAr": "نستخدم (just) بين الفعل المساعد والتصريف الثالث للدلالة على حدوث الفعل للتو.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_46",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الرابط الدال على مدة زمنية طويلة:",
    "sentenceWithBlank": "We had known about the issue _______ a long time before acting.",
    "options": [
      "for",
      "since",
      "yet",
      "already"
    ],
    "correctAnswer": "for",
    "explanation": {
      "whyCorrectAr": "نستخدم (for) مع العبارة الزمنية (for a long time).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_47",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الظرف المستخدم في الأسئلة عن التجارب السابقة:",
    "sentenceWithBlank": "Had she _______ worked in a multinational company before joining us?",
    "options": [
      "ever",
      "never",
      "yet",
      "just"
    ],
    "correctAnswer": "ever",
    "explanation": {
      "whyCorrectAr": "نستخدم (ever) في أسئلة الماضي التام للسؤال عن وجود تجربة سابقة في أي وقت مضى.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_48",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الظرف الدال على الإتمام المسبق:",
    "sentenceWithBlank": "I had _______ read that book twice before writing the review.",
    "options": [
      "ever",
      "already",
      "yet",
      "since"
    ],
    "correctAnswer": "already",
    "explanation": {
      "whyCorrectAr": "نستخدم (already) للدلالة على قراءة الكتاب مسبقاً مرتين قبل كتابة المراجعة.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_49",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر الرابط المناسب للمدة الزمنية (months):",
    "sentenceWithBlank": "They had not updated their website _______ months before the crash.",
    "options": [
      "for",
      "since",
      "yet",
      "already"
    ],
    "correctAnswer": "for",
    "explanation": {
      "whyCorrectAr": "نستخدم (for) متبوعة بـ (months) للتعبير عن استمرار عدم التحديث لشهور.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_med_50",
    "tenseId": "past_perfect",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "اختر حرف الجر الدال على الموعد الأقصى المحدد (بحلول):",
    "sentenceWithBlank": "The computer had crashed three times _______ that morning.",
    "options": [
      "for",
      "by",
      "yet",
      "already"
    ],
    "correctAnswer": "by",
    "explanation": {
      "whyCorrectAr": "نستخدم (by that morning) للدلالة على تكرار التعطل 3 مرات بحلول ذلك الصباح.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  }
];
