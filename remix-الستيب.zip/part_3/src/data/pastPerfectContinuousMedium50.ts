import { QuizQuestion } from '../types';

export const PAST_PERFECT_CONTINUOUS_MEDIUM_50: QuizQuestion[] = [
  {
    "id": "ppc_medium_1",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كم من الوقت كنت تتعلم الإنجليزية قبل أن تنتقل إلى لندن؟",
    "sentenceWithBlank": "How long _______ you been learning English before you moved to London?",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_2",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كانت تدهن الجدار لمدة ثلاث ساعات عندما وصلت.",
    "sentenceWithBlank": "She had been painting the wall _______ three hours when I arrived.",
    "options": [
      "for",
      "since",
      "yet",
      "already"
    ],
    "correctAnswer": "for",
    "explanation": {
      "whyCorrectAr": "نستخدم for متبوعة بفترة زمنية محددة أو مدة استغراق الحدث.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_3",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كنت أعمل على ذلك التقرير منذ هذا الصباح قبل تعطل حاسوبي.",
    "sentenceWithBlank": "I had been working on that report _______ this morning before my computer crashed.",
    "options": [
      "for",
      "since",
      "yet",
      "just"
    ],
    "correctAnswer": "since",
    "explanation": {
      "whyCorrectAr": "نستخدم since للإشارة إلى نقطة بداية الحدث الزمنية المحددة.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_4",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كانت عيناه حمراوين لأنه كان يبكي.",
    "sentenceWithBlank": "His eyes were red because he _______ crying.",
    "options": [
      "has been",
      "have been",
      "had been",
      "was being"
    ],
    "correctAnswer": "had been",
    "explanation": {
      "whyCorrectAr": "نستخدم had been متبوعة بـ (V-ing) في الماضي التام المستمر للتعبير عن حدث استمر لفترة قبل وقوع حدث آخر في الماضي.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_5",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "بدا متعباً لأنه كان يركض لمدة ساعة.",
    "sentenceWithBlank": "He looked tired because he _______ running for an hour.",
    "options": [
      "has been",
      "have been",
      "had been",
      "were being"
    ],
    "correctAnswer": "had been",
    "explanation": {
      "whyCorrectAr": "نستخدم had been متبوعة بـ (V-ing) في الماضي التام المستمر للتعبير عن حدث استمر لفترة قبل وقوع حدث آخر في الماضي.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_6",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كنا نناقش ذلك الأمر لأكثر من ساعة قبل أن نتفق.",
    "sentenceWithBlank": "We _______ been discussing that matter for over an hour before we agreed.",
    "options": [
      "has",
      "had",
      "have",
      "were"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_7",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "هل كنت تنتظر هناك طويلاً عندما جاء القطار؟",
    "sentenceWithBlank": "Had you _______ waiting there long when the train came?",
    "options": [
      "be",
      "been",
      "being",
      "were"
    ],
    "correctAnswer": "been",
    "explanation": {
      "whyCorrectAr": "التركيب النحوي للماضي التام المستمر يتطلب التصريف been بعد had متبوعاً بالفعل مضافاً له -ing.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_8",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كانت تعيش في الخارج لسنوات قبل عودتها إلى الوطن.",
    "sentenceWithBlank": "She had _______ living abroad for years before she returned home.",
    "options": [
      "be",
      "been",
      "being",
      "was"
    ],
    "correctAnswer": "been",
    "explanation": {
      "whyCorrectAr": "التركيب النحوي للماضي التام المستمر يتطلب التصريف been بعد had متبوعاً بالفعل مضافاً له -ing.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_9",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كانوا يتدربون على تلك الأغنية طوال الأسبوع قبل العرض.",
    "sentenceWithBlank": "They had _______ practicing that song all week before the performance.",
    "options": [
      "be",
      "been",
      "being",
      "were"
    ],
    "correctAnswer": "been",
    "explanation": {
      "whyCorrectAr": "التركيب النحوي للماضي التام المستمر يتطلب التصريف been بعد had متبوعاً بالفعل مضافاً له -ing.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_10",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كانت تمطر باستمرار لأيام قبل شروق الشمس.",
    "sentenceWithBlank": "It had _______ raining continuously for days before the sun came out.",
    "options": [
      "be",
      "been",
      "being",
      "was"
    ],
    "correctAnswer": "been",
    "explanation": {
      "whyCorrectAr": "التركيب النحوي للماضي التام المستمر يتطلب التصريف been بعد had متبوعاً بالفعل مضافاً له -ing.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_11",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "ماذا كنت تفعل قبل أن أراك بالأمس؟",
    "sentenceWithBlank": "What _______ you been doing before I saw you yesterday?",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_12",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "أين كانت تقيم أثناء زيارتها قبل أن تستأجر شقة؟",
    "sentenceWithBlank": "Where _______ she been staying during her visit before she rented a flat?",
    "options": [
      "have",
      "had",
      "has",
      "was"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_13",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لماذا كانوا يتجادلون حول تلك المسألة البسيطة قبل أن أتدخل؟",
    "sentenceWithBlank": "Why _______ they been arguing about that minor issue before I intervened?",
    "options": [
      "has",
      "had",
      "have",
      "were"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_14",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "من كان يستخدم حاسوبي دون إذن قبل أن أقفله؟",
    "sentenceWithBlank": "Who _______ been using my computer without permission before I locked it?",
    "options": [
      "have",
      "had",
      "has",
      "was"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_15",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "منذ متى كان يدير ذلك الفرع قبل ترقيته؟",
    "sentenceWithBlank": "How long _______ he been managing that branch before he was promoted?",
    "options": [
      "have",
      "had",
      "has",
      "was"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_16",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "أي كتاب كنت تقرؤه قبل أن تنتقل إلى كتاب آخر؟",
    "sentenceWithBlank": "Which book had you _______ reading before you switched to another one?",
    "options": [
      "be",
      "been",
      "being",
      "were"
    ],
    "correctAnswer": "been",
    "explanation": {
      "whyCorrectAr": "التركيب النحوي للماضي التام المستمر يتطلب التصريف been بعد had متبوعاً بالفعل مضافاً له -ing.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_17",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كم ساعة كنت تدرس قبل أن تأخذ استراحة؟",
    "sentenceWithBlank": "How many hours had you _______ studying before you took a break?",
    "options": [
      "be",
      "been",
      "being",
      "were"
    ],
    "correctAnswer": "been",
    "explanation": {
      "whyCorrectAr": "التركيب النحوي للماضي التام المستمر يتطلب التصريف been بعد had متبوعاً بالفعل مضافاً له -ing.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_18",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لماذا كان الكلب ينبح باستمرار قبل أن نطعمه؟",
    "sentenceWithBlank": "Why _______ the dog been barking continuously before we fed it?",
    "options": [
      "have",
      "had",
      "has",
      "was"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_19",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كان إخوتي يلعبون ألعاب الفيديو طوال المساء قبل وصول أبي.",
    "sentenceWithBlank": "My brothers had _______ playing video games all evening before dad arrived.",
    "options": [
      "be",
      "been",
      "being",
      "were"
    ],
    "correctAnswer": "been",
    "explanation": {
      "whyCorrectAr": "التركيب النحوي للماضي التام المستمر يتطلب التصريف been بعد had متبوعاً بالفعل مضافاً له -ing.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_20",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لم يكن أي من المشاركين يحضر في الوقت المحدد قبل التنبيه.",
    "sentenceWithBlank": "Neither of the participants had _______ showing up on time before the warning.",
    "options": [
      "be",
      "been",
      "being",
      "were"
    ],
    "correctAnswer": "been",
    "explanation": {
      "whyCorrectAr": "التركيب النحوي للماضي التام المستمر يتطلب التصريف been بعد had متبوعاً بالفعل مضافاً له -ing.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_21",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كنت أبحث عن هاتفي منذ الصباح قبل أن أجده في السيارة.",
    "sentenceWithBlank": "I had been _______ for my phone since morning before I found it in the car.",
    "options": [
      "search",
      "searches",
      "searching",
      "searched"
    ],
    "correctAnswer": "searching",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_22",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كانت تحاول جاهدة اجتياز الامتحانات قبل أن تمرض.",
    "sentenceWithBlank": "She had been _______ hard to pass the exams before she fell ill.",
    "options": [
      "try",
      "tries",
      "trying",
      "tried"
    ],
    "correctAnswer": "trying",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_23",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كانوا يبنون منزلاً جديداً في الضواحي قبل نفاد التمويل.",
    "sentenceWithBlank": "They had been _______ a new house in the suburbs before funding ran out.",
    "options": [
      "build",
      "builds",
      "building",
      "built"
    ],
    "correctAnswer": "building",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_24",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كان يجلس في الشمس لفترة طويلة قبل أن يشعر بالدوار.",
    "sentenceWithBlank": "He had been _______ in the sun too long before he got dizzy.",
    "options": [
      "sit",
      "sits",
      "sitting",
      "sat"
    ],
    "correctAnswer": "sitting",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_25",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كنا ننتظر أصدقاءنا لأكثر من عشرين دقيقة قبل ظهورهم.",
    "sentenceWithBlank": "We had been _______ for our friends for over twenty minutes before they showed up.",
    "options": [
      "wait",
      "waits",
      "waiting",
      "waited"
    ],
    "correctAnswer": "waiting",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_26",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كانت الرياح تعصف بشدة قبل أن تهدأ العاصفة.",
    "sentenceWithBlank": "The wind had been _______ fiercely before the storm calmed down.",
    "options": [
      "blow",
      "blows",
      "blowing",
      "blew"
    ],
    "correctAnswer": "blowing",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_27",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كنت تحقق تقدماً رائعاً قبل أن تغير استراتيجيتك.",
    "sentenceWithBlank": "You had been _______ great progress before you changed your strategy.",
    "options": [
      "make",
      "makes",
      "making",
      "made"
    ],
    "correctAnswer": "making",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_28",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كان الطفل يبكي بسبب ألم في أسنانه قبل وصول الطبيب.",
    "sentenceWithBlank": "The baby had been _______ because of a toothache before the doctor arrived.",
    "options": [
      "cry",
      "cries",
      "crying",
      "cried"
    ],
    "correctAnswer": "crying",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_29",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كانت تساعد والدتها في المطبخ قبل قدوم الضيوف.",
    "sentenceWithBlank": "She had been _______ her mother in the kitchen before the guests came.",
    "options": [
      "help",
      "helps",
      "helping",
      "helped"
    ],
    "correctAnswer": "helping",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_30",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كان أصدقائي يدعمونني في مشروعي الجديد قبل مغادرتهم.",
    "sentenceWithBlank": "My friends had been _______ me with my new project before they left.",
    "options": [
      "support",
      "supports",
      "supporting",
      "supported"
    ],
    "correctAnswer": "supporting",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_31",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لم أكن أشعر أنني بخير قبل زيارتي للعيادة.",
    "sentenceWithBlank": "I had not been _______ well before I visited the clinic.",
    "options": [
      "feel",
      "feels",
      "feeling",
      "felt"
    ],
    "correctAnswer": "feeling",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_32",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لم تكن تحضر المحاضرات قبل أن تتلقى تحذيراً.",
    "sentenceWithBlank": "She had not been _______ to lectures before she received a warning.",
    "options": [
      "go",
      "goes",
      "going",
      "gone"
    ],
    "correctAnswer": "going",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_33",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لم يكونوا يقدمون أفضل أداء لديهم قبل أن يتحدث المدرب معهم.",
    "sentenceWithBlank": "They had not been _______ their best performance before the coach spoke to them.",
    "options": [
      "give",
      "gives",
      "giving",
      "given"
    ],
    "correctAnswer": "giving",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_34",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لم يكن يحصل على قسط كافٍ من النوم قبل أسبوع الامتحانات.",
    "sentenceWithBlank": "He had not been _______ enough sleep before the exam week.",
    "options": [
      "get",
      "gets",
      "getting",
      "got"
    ],
    "correctAnswer": "getting",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_35",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لم نكن نعمل في عطلات نهاية الأسبوع قبل بدء السياسة الجديدة.",
    "sentenceWithBlank": "We had not been _______ on weekends before the new policy started.",
    "options": [
      "work",
      "works",
      "working",
      "worked"
    ],
    "correctAnswer": "working",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_36",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لم تكن تنتبه للتفاصيل قبل ارتكاب ذلك الخطأ.",
    "sentenceWithBlank": "You had not been _______ attention to detail before making that mistake.",
    "options": [
      "pay",
      "pays",
      "paying",
      "paid"
    ],
    "correctAnswer": "paying",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_37",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لم يكن يعمل بشكل سليم قبل أن نصلحه.",
    "sentenceWithBlank": "It had not been _______ properly before we repaired it.",
    "options": [
      "function",
      "functions",
      "functioning",
      "functioned"
    ],
    "correctAnswer": "functioning",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_38",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لم تكن الآلة تعمل بسلاسة قبل تغيير الزيت.",
    "sentenceWithBlank": "The machine had not been _______ smoothly before the oil change.",
    "options": [
      "run",
      "runs",
      "running",
      "ran"
    ],
    "correctAnswer": "running",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_39",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لم يكن حاسوبي يعمل بشكل جيد قبل أن يتعطل تماماً.",
    "sentenceWithBlank": "My computer had not been _______ right before it crashed completely.",
    "options": [
      "work",
      "works",
      "working",
      "worked"
    ],
    "correctAnswer": "working",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_40",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لم يكن الطلاب يحافظون على تركيزهم قبل تدخل المعلم.",
    "sentenceWithBlank": "The students had not been _______ focused before the teacher intervened.",
    "options": [
      "stay",
      "stays",
      "staying",
      "stayed"
    ],
    "correctAnswer": "staying",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_41",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "هل كنت تقرأ ذلك الكتاب لمدة شهر قبل أن تنهيه؟",
    "sentenceWithBlank": "Had you been _______ that book for a month before you finished it?",
    "options": [
      "read",
      "reads",
      "reading",
      "readed"
    ],
    "correctAnswer": "reading",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_42",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "هل كانت تعمل في ذلك المكتب لفترة طويلة قبل نقلها؟",
    "sentenceWithBlank": "Had she been _______ in that office long before she was transferred?",
    "options": [
      "work",
      "works",
      "working",
      "worked"
    ],
    "correctAnswer": "working",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_43",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "هل كانوا يتدربون للمنافسة قبل تأجيلها؟",
    "sentenceWithBlank": "Had they been _______ for the competition before it was postponed?",
    "options": [
      "train",
      "trains",
      "training",
      "trained"
    ],
    "correctAnswer": "training",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_44",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "هل كان يقود تلك السيارة لفترة طويلة قبل بيعها؟",
    "sentenceWithBlank": "Had he been _______ that car for a long time before he sold it?",
    "options": [
      "drive",
      "drives",
      "driving",
      "driven"
    ],
    "correctAnswer": "driving",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_45",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "هل كنا نحقق في تلك القضية معاً قبل إغلاق الملفات؟",
    "sentenceWithBlank": "Had we been _______ on that case together before the files were closed?",
    "options": [
      "investigate",
      "investigates",
      "investigating",
      "investigated"
    ],
    "correctAnswer": "investigating",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_46",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كم من الوقت كنت تستخدم ذلك الحاسوب قبل أن يتعطل؟",
    "sentenceWithBlank": "How long had you been _______ that computer before it broke?",
    "options": [
      "use",
      "uses",
      "using",
      "used"
    ],
    "correctAnswer": "using",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_47",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كم من الوقت كانت تتعلم الإسبانية قبل انتقالها إلى مدريد؟",
    "sentenceWithBlank": "How long had she been _______ Spanish before she moved to Madrid?",
    "options": [
      "learn",
      "learns",
      "learning",
      "learned"
    ],
    "correctAnswer": "learning",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_48",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لماذا كان يصل متأخراً كل يوم قبل طرده؟",
    "sentenceWithBlank": "Why had he been _______ late every day before he was fired?",
    "options": [
      "arrive",
      "arrives",
      "arriving",
      "arrived"
    ],
    "correctAnswer": "arriving",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_49",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "عماذا كنتم تتحدثون قبل أن يبدأ الجدال؟",
    "sentenceWithBlank": "What had you been _______ about before the argument started?",
    "options": [
      "talk",
      "talks",
      "talking",
      "talked"
    ],
    "correctAnswer": "talking",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_medium_50",
    "tenseId": "past_perfect_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "من كان يطرق الباب قبل أن نفتحه؟",
    "sentenceWithBlank": "Who had been _______ the door before we opened it?",
    "options": [
      "knock",
      "knocks",
      "knocking",
      "knocked"
    ],
    "correctAnswer": "knocking",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  }
];
