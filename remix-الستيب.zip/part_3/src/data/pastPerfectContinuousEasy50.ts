import { QuizQuestion } from '../types';

export const PAST_PERFECT_CONTINUOUS_EASY_50: QuizQuestion[] = [
  {
    "id": "ppc_easy_1",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كنت أنتظرك لمدة ساعتين قبل أن تأتي.",
    "sentenceWithBlank": "I _______ waiting for you for two hours before you came.",
    "options": [
      "had been",
      "have been",
      "has been",
      "was being"
    ],
    "correctAnswer": "had been",
    "explanation": {
      "whyCorrectAr": "نستخدم had been متبوعة بـ (V-ing) في الماضي التام المستمر للتعبير عن حدث استمر لفترة قبل وقوع حدث آخر في الماضي.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_2",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كانت تعمل في تلك الشركة لمدة خمس سنوات قبل أن تستقيل.",
    "sentenceWithBlank": "She _______ working in that company for five years before she resigned.",
    "options": [
      "have been",
      "had been",
      "has been",
      "was being"
    ],
    "correctAnswer": "had been",
    "explanation": {
      "whyCorrectAr": "نستخدم had been متبوعة بـ (V-ing) في الماضي التام المستمر للتعبير عن حدث استمر لفترة قبل وقوع حدث آخر في الماضي.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_3",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كانوا يلعبون كرة القدم طوال فترة بعد الظهر قبل أن تبدأ السماء بالمطر.",
    "sentenceWithBlank": "They _______ playing football all afternoon before it started to rain.",
    "options": [
      "has been",
      "had been",
      "have been",
      "were being"
    ],
    "correctAnswer": "had been",
    "explanation": {
      "whyCorrectAr": "نستخدم had been متبوعة بـ (V-ing) في الماضي التام المستمر للتعبير عن حدث استمر لفترة قبل وقوع حدث آخر في الماضي.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_4",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كان نائماً لمدة عشر ساعات عندما أيقظته.",
    "sentenceWithBlank": "He _______ sleeping for ten hours when I woke him up.",
    "options": [
      "have been",
      "had been",
      "has been",
      "was being"
    ],
    "correctAnswer": "had been",
    "explanation": {
      "whyCorrectAr": "نستخدم had been متبوعة بـ (V-ing) في الماضي التام المستمر للتعبير عن حدث استمر لفترة قبل وقوع حدث آخر في الماضي.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_5",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كنا نعيش في تلك المدينة لمدة ثلاث سنوات قبل أن ننتقل.",
    "sentenceWithBlank": "We _______ living in that city for three years before we moved.",
    "options": [
      "has been",
      "had been",
      "have been",
      "were being"
    ],
    "correctAnswer": "had been",
    "explanation": {
      "whyCorrectAr": "نستخدم had been متبوعة بـ (V-ing) في الماضي التام المستمر للتعبير عن حدث استمر لفترة قبل وقوع حدث آخر في الماضي.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_6",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كنت تدرس اللغة الإنجليزية لساعات قبل أن يبدأ الاختبار.",
    "sentenceWithBlank": "You _______ studying English for hours before the test began.",
    "options": [
      "has been",
      "had been",
      "have been",
      "were being"
    ],
    "correctAnswer": "had been",
    "explanation": {
      "whyCorrectAr": "نستخدم had been متبوعة بـ (V-ing) في الماضي التام المستمر للتعبير عن حدث استمر لفترة قبل وقوع حدث آخر في الماضي.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_7",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كانت تمطر لأيام قبل أن يحدث الفيضان.",
    "sentenceWithBlank": "It _______ raining for days before the flood happened.",
    "options": [
      "have been",
      "had been",
      "has been",
      "was being"
    ],
    "correctAnswer": "had been",
    "explanation": {
      "whyCorrectAr": "نستخدم had been متبوعة بـ (V-ing) في الماضي التام المستمر للتعبير عن حدث استمر لفترة قبل وقوع حدث آخر في الماضي.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_8",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كان الأطفال يلعبون في الفناء لساعات قبل العشاء.",
    "sentenceWithBlank": "The children _______ playing in the yard for hours before dinner.",
    "options": [
      "has been",
      "had been",
      "have been",
      "were being"
    ],
    "correctAnswer": "had been",
    "explanation": {
      "whyCorrectAr": "نستخدم had been متبوعة بـ (V-ing) في الماضي التام المستمر للتعبير عن حدث استمر لفترة قبل وقوع حدث آخر في الماضي.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_9",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كانت قطتي نائمة على الأريكة طوال اليوم بالأمس.",
    "sentenceWithBlank": "My cat _______ sleeping on the couch all day yesterday.",
    "options": [
      "have been",
      "had been",
      "has been",
      "was being"
    ],
    "correctAnswer": "had been",
    "explanation": {
      "whyCorrectAr": "نستخدم had been متبوعة بـ (V-ing) في الماضي التام المستمر للتعبير عن حدث استمر لفترة قبل وقوع حدث آخر في الماضي.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_10",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كانت الطيور تغرد في الأشجار حتى وصل الصياد.",
    "sentenceWithBlank": "Birds _______ singing in the trees until the hunter arrived.",
    "options": [
      "has been",
      "had been",
      "have been",
      "were being"
    ],
    "correctAnswer": "had been",
    "explanation": {
      "whyCorrectAr": "نستخدم had been متبوعة بـ (V-ing) في الماضي التام المستمر للتعبير عن حدث استمر لفترة قبل وقوع حدث آخر في الماضي.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_11",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لم أكن أشعر بأنني بخير قبل أن أتناول الدواء.",
    "sentenceWithBlank": "I _______ not been feeling well before I took the medicine.",
    "options": [
      "had",
      "have",
      "has",
      "was"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_12",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لم تكن منتبهة للدرس قبل أن تُسأل.",
    "sentenceWithBlank": "She _______ not been paying attention to the class before she was asked.",
    "options": [
      "have",
      "had",
      "has",
      "was"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_13",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لم يكونوا يتدربون بجد قبل المباراة.",
    "sentenceWithBlank": "They _______ not been practicing hard before the match.",
    "options": [
      "has",
      "had",
      "have",
      "were"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_14",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لم يكن يدرس جيداً قبل أن يرسب.",
    "sentenceWithBlank": "He _______ not been studying well before he failed.",
    "options": [
      "have",
      "had",
      "has",
      "was"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_15",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لم نكن ننتظر طويلاً عندما وصلت الحافلة.",
    "sentenceWithBlank": "We _______ not been waiting for long when the bus arrived.",
    "options": [
      "has",
      "had",
      "have",
      "were"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_16",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لم تكن تأكل بشكل صحيح قبل أن تمرض.",
    "sentenceWithBlank": "You _______ not been eating properly before you got sick.",
    "options": [
      "has",
      "had",
      "have",
      "were"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_17",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لم تكن تثلج لفترة طويلة عندما توقف الثلج.",
    "sentenceWithBlank": "It _______ not been snowing for long when it stopped.",
    "options": [
      "have",
      "had",
      "has",
      "was"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_18",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "علي وأحمد لم يكونا يعملان معاً لفترة طويلة.",
    "sentenceWithBlank": "Ali and Ahmed _______ not been working together for long.",
    "options": [
      "has",
      "had",
      "have",
      "were"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_19",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "أمي لم تكن تطبخ طوال اليوم عندما وصلنا.",
    "sentenceWithBlank": "My mother _______ not been cooking all day when we arrived.",
    "options": [
      "have",
      "had",
      "has",
      "was"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_20",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لم يكن الكلب ينبح قبل أن يُفتح الباب.",
    "sentenceWithBlank": "The dog _______ not been barking before the door opened.",
    "options": [
      "have",
      "had",
      "has",
      "was"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_21",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "هل كنت تنتظر هناك لفترة طويلة عندما وصلت؟",
    "sentenceWithBlank": "_______ you been waiting there for a long time when I arrived?",
    "options": [
      "Has",
      "Had",
      "Have",
      "Were"
    ],
    "correctAnswer": "Had",
    "explanation": {
      "whyCorrectAr": "الإجابة الصحيحة هي Had لتوافقها مع قواعد الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_22",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "هل كانت تدرس لامتحاناتها النهائية قبل أن تأخذ استراحة؟",
    "sentenceWithBlank": "_______ she been studying for her final exams before she took a break?",
    "options": [
      "Have",
      "Had",
      "Has",
      "Was"
    ],
    "correctAnswer": "Had",
    "explanation": {
      "whyCorrectAr": "الإجابة الصحيحة هي Had لتوافقها مع قواعد الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_23",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "هل كانوا يلعبون التنس طوال الصباح قبل أن تمطر؟",
    "sentenceWithBlank": "_______ they been playing tennis all morning before it rained?",
    "options": [
      "Has",
      "Had",
      "Have",
      "Were"
    ],
    "correctAnswer": "Had",
    "explanation": {
      "whyCorrectAr": "الإجابة الصحيحة هي Had لتوافقها مع قواعد الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_24",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "هل كان يعمل على ذلك المشروع منذ يوم الاثنين قبل أن ينتهي؟",
    "sentenceWithBlank": "_______ he been working on that project since Monday before it ended?",
    "options": [
      "Have",
      "Had",
      "Has",
      "Was"
    ],
    "correctAnswer": "Had",
    "explanation": {
      "whyCorrectAr": "الإجابة الصحيحة هي Had لتوافقها مع قواعد الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_25",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "هل كنا نعيش هناك لفترة كافية قبل شراء المنزل؟",
    "sentenceWithBlank": "_______ we been living there long enough before buying a house?",
    "options": [
      "Has",
      "Had",
      "Have",
      "Were"
    ],
    "correctAnswer": "Had",
    "explanation": {
      "whyCorrectAr": "الإجابة الصحيحة هي Had لتوافقها مع قواعد الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_26",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ماذا كنت تفعل قبل أن آتي؟",
    "sentenceWithBlank": "What _______ you been doing before I came?",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_27",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "أين كانت تختبئ قبل أن نجدها؟",
    "sentenceWithBlank": "Where _______ she been hiding before we found her?",
    "options": [
      "have",
      "had",
      "has",
      "was"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_28",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لماذا كانوا يبكون قبل أن يواسيهم المعلم؟",
    "sentenceWithBlank": "Why _______ they been crying before the teacher consoled them?",
    "options": [
      "has",
      "had",
      "have",
      "were"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_29",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "مع من كان يتحدث قبل أن يبدأ الاجتماع؟",
    "sentenceWithBlank": "Who _______ he been talking to before the meeting started?",
    "options": [
      "have",
      "had",
      "has",
      "was"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_30",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "منذ متى كانت تمطر قبل أن تصفو السماء؟",
    "sentenceWithBlank": "How long _______ it been raining before it cleared up?",
    "options": [
      "have",
      "had",
      "has",
      "was"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_31",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كنت أبحث عن مفاتيحي في كل مكان قبل أن أجدها.",
    "sentenceWithBlank": "I had been _______ for my keys everywhere before I found them.",
    "options": [
      "look",
      "looks",
      "looking",
      "looked"
    ],
    "correctAnswer": "looking",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_32",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كانت تكتب رواية لأشهر قبل أن تنشرها.",
    "sentenceWithBlank": "She had been _______ a novel for months before she published it.",
    "options": [
      "write",
      "writes",
      "writing",
      "written"
    ],
    "correctAnswer": "writing",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_33",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كانوا يستمعون إلى الموسيقى لساعات قبل انقطاع الكهرباء.",
    "sentenceWithBlank": "They had been _______ to music for hours before the electricity went out.",
    "options": [
      "listen",
      "listens",
      "listening",
      "listened"
    ],
    "correctAnswer": "listening",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_34",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كان يدرس اللغة الفرنسية لمدة عام قبل أن يسافر إلى باريس.",
    "sentenceWithBlank": "He had been _______ French for a year before he traveled to Paris.",
    "options": [
      "study",
      "studies",
      "studying",
      "studied"
    ],
    "correctAnswer": "studying",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_35",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كنا ننتظر الحافلة في البرد قبل أن تصل أخيراً.",
    "sentenceWithBlank": "We had been _______ for the bus in the cold before it finally arrived.",
    "options": [
      "wait",
      "waits",
      "waiting",
      "waited"
    ],
    "correctAnswer": "waiting",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_36",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كان الأطفال يلعبون في الحديقة قبل أن يناديهم والداهم.",
    "sentenceWithBlank": "The children had been _______ in the park before their parents called them.",
    "options": [
      "play",
      "plays",
      "playing",
      "played"
    ],
    "correctAnswer": "playing",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_37",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كنت تقود بسرعة كبيرة قبل أن توقفك الشرطة.",
    "sentenceWithBlank": "You had been _______ too fast before the police stopped you.",
    "options": [
      "drive",
      "drives",
      "driving",
      "driven"
    ],
    "correctAnswer": "driving",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_38",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كان الطاهي يطبخ عشاءً خاصاً قبل دخول الضيوف.",
    "sentenceWithBlank": "The chef had been _______ a special dinner before the guests walked in.",
    "options": [
      "cook",
      "cooks",
      "cooking",
      "cooked"
    ],
    "correctAnswer": "cooking",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_39",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كان الماء يقطر من السقف قبل أن نصلحه.",
    "sentenceWithBlank": "Water had been _______ from the roof before we fixed it.",
    "options": [
      "drip",
      "drips",
      "dripping",
      "dripped"
    ],
    "correctAnswer": "dripping",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_40",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كان أصدقائي يساعدونني في تجارتي قبل أن تُغلق.",
    "sentenceWithBlank": "My friends had been _______ me with my business before it closed.",
    "options": [
      "help",
      "helps",
      "helping",
      "helped"
    ],
    "correctAnswer": "helping",
    "explanation": {
      "whyCorrectAr": "بعد had been، يضاف للفعل اللاحقة (-ing) للتعبير عن استمرارية الحدث في الماضي التام المستمر.",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_41",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كنت أقرأ ذلك الكتاب لساعات قبل أن تقاطعني.",
    "sentenceWithBlank": "I _______ been reading that book for hours before you interrupted me.",
    "options": [
      "had",
      "have",
      "has",
      "was"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_42",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كانت تنظف المنزل منذ الصباح عندما وصلت.",
    "sentenceWithBlank": "She _______ been cleaning the house since morning when I arrived.",
    "options": [
      "have",
      "had",
      "has",
      "was"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_43",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كانوا يتدربون بجد للحفل الموسيقي قبل أن يُلغى.",
    "sentenceWithBlank": "They _______ been practicing hard for the concert before it was cancelled.",
    "options": [
      "has",
      "had",
      "have",
      "were"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_44",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كان يصلح سيارته لساعات قبل أن تعمل أخيراً.",
    "sentenceWithBlank": "He _______ been fixing his car for hours before it finally started.",
    "options": [
      "have",
      "had",
      "has",
      "was"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_45",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كنا نناقش تلك المسألة لأيام قبل التوصل إلى قرار.",
    "sentenceWithBlank": "We _______ been discussing that issue for days before reaching a decision.",
    "options": [
      "has",
      "had",
      "have",
      "were"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_46",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كنت تعمل بجد زائد مؤخراً قبل أن تأخذ إجازة.",
    "sentenceWithBlank": "You _______ been working too hard lately before you took a vacation.",
    "options": [
      "has",
      "had",
      "have",
      "were"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_47",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كانت تثلج بغزارة لساعات قبل إغلاق الطريق.",
    "sentenceWithBlank": "It _______ been snowing heavily for hours before the road closed.",
    "options": [
      "have",
      "had",
      "has",
      "was"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_48",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كان الطفل يبكي لمدة عشرين دقيقة قبل أن تطعمه أمه.",
    "sentenceWithBlank": "The baby _______ been crying for twenty minutes before his mother fed him.",
    "options": [
      "have",
      "had",
      "has",
      "was"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_49",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كنت أتعلم كيفية السباحة قبل انضمامي إلى الفريق.",
    "sentenceWithBlank": "I _______ been learning how to swim before I joined the team.",
    "options": [
      "has",
      "had",
      "have",
      "was"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  },
  {
    "id": "ppc_easy_50",
    "tenseId": "past_perfect_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كانت تدرّس اللغة الإنجليزية لمدة عشر سنوات قبل أن تتقاعد.",
    "sentenceWithBlank": "She _______ been teaching English for ten years before she retired.",
    "options": [
      "have",
      "had",
      "has",
      "was"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في زمن الماضي التام المستمر (Past Perfect Continuous)، الفعل المساعد دائماً هو had لجميع الضمائر والأسماء (المفرد والجمع).",
      "temporalRelationshipAr": "حدث استمر لفترة معينة في الماضي واكتمل أو كانت آثاره واضحة قبل نقطة زمنية أخرى أو حدث آخر في الماضي.",
      "whyTenseFitsAr": "الماضي التام المستمر (Past Perfect Continuous) يركز على مدة واستمرارية الحدث الأسبق في الماضي (had been + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها إما في المضارع أو لا تحقق صيغة الاستمرارية التامة للحدث الأسبق.",
      "confusableTenseAr": "Past Perfect / Past Continuous / Present Perfect Continuous"
    }
  }
];
