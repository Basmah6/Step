import { QuizQuestion } from '../types';

export const PAST_PERFECT_HARD_50: QuizQuestion[] = [
  {
    "id": "pp_hard_1",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد صيغة التفضيل في السياق الماضي (This was the best):",
    "sentenceWithBlank": "This was the best movie I _______ ever seen.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في الماضي، عند التعبير عن تفضيل ماضٍ (This was the best...), يتبعها ماضٍ تام (had ever seen).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_2",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد التركيب (It was the first time):",
    "sentenceWithBlank": "It was the first time she _______ visited our country.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "تركيب (It was the first time) في الماضي يتبعه ماضٍ تام (had visited).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_3",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع الفاعل (Neither of):",
    "sentenceWithBlank": "Neither of the workers _______ finished their tasks before the deadline.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في الماضي التام نستخدم الفعل المساعد (had) للتعبير عن الحدث الأسبق قبل الموعد النهائي.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_4",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع العبارة (The number of):",
    "sentenceWithBlank": "The number of tourists visiting the museum _______ increased before the closure.",
    "options": [
      "had",
      "have",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "عبارة (The number of) تشير إلى العدد وتأخذ في الماضي التام (had increased).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_5",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع العبارة (A number of):",
    "sentenceWithBlank": "A number of workers _______ complained before management intervened.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "عبارة (A number of) تعني \"العديد من\" وتأخذ في الماضي التام (had complained).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_6",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع اسم المادة (Mathematics):",
    "sentenceWithBlank": "Mathematics _______ played a crucial role in the ancient discovery.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "اسم المادة الدراسية (Mathematics) في الماضي التام يأخذ (had played).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_7",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد للمبالغ المالية في المبني للمجهول:",
    "sentenceWithBlank": "Fifty dollars _______ been spent on the project before it was halted.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "المبالغ المالية كوحدة قياسية في الماضي التام المبني للمجهول تأخذ (had been spent).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_8",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع (Each of):",
    "sentenceWithBlank": "Each of the students _______ submitted their report before the bell.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الكلمة المفتاحية هي (Each) وتأخذ في الماضي التام (had submitted).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_9",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع التركيب (More than one):",
    "sentenceWithBlank": "More than one person _______ expressed interest before the position was filled.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "التركيب (More than one person) في الماضي التام يأخذ (had expressed).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_10",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع اسم العلم (Physics):",
    "sentenceWithBlank": "Physics _______ fascinated generations of scientists before the new theory.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "اسم العلم (Physics) في الماضي التام يأخذ (had fascinated).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_11",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد للوجبة الواحدة المشتركة:",
    "sentenceWithBlank": "Bread and butter _______ been my favorite breakfast before I changed my diet.",
    "options": [
      "had",
      "have",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الوجبة الواحدة المشتركة (Bread and butter) في الماضي التام تأخذ (had been).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_12",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع كلمة (Police):",
    "sentenceWithBlank": "The police _______ arrested the suspect before he left the country.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "كلمة (Police) جمع دائم وتأخذ في الماضي التام (had arrested).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_13",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع اسم الجمع (My family):",
    "sentenceWithBlank": "My family _______ always supported my goals before I moved out.",
    "options": [
      "had",
      "have",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "اسم الجمع (My family) في الماضي التام يأخذ (had supported).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_14",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع اسم الهيئة الموحدة (The committee):",
    "sentenceWithBlank": "The committee _______ reached a final decision before the meeting adjourned.",
    "options": [
      "had",
      "have",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "اللجنة كوحدة واحدة في الماضي التام تأخذ (had reached).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_15",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع التركيب (Neither ... nor):",
    "sentenceWithBlank": "Neither the teacher nor the students _______ arrived before the bell.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في الماضي التام نستخدم الفعل المساعد (had) لجميع الفواعل (had arrived).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_16",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع الفاعل الأقرب المفرد:",
    "sentenceWithBlank": "Neither the students nor the teacher _______ arrived before the bell.",
    "options": [
      "had",
      "have",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في الماضي التام نستخدم الفعل المساعد (had) دائماً قبل التصريف الثالث (had arrived).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_17",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد في صيغة القلب النحوي بعد (Rarely):",
    "sentenceWithBlank": "Rarely _______ anyone achieved such a high score before that year.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "عند البدء بظرف نفي (Rarely)، يقلب الفعل والفاعل في الماضي التام (Rarely had anyone achieved).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_18",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد في صيغة القلب النحوي بعد (Never):",
    "sentenceWithBlank": "Never _______ I seen such a dedicated professional before working there.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "تقديم ظرف النفي (Never) يولد قلباً نحوياً (Inversion) في الماضي التام (Never had I seen).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_19",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد في صيغة القلب النحوي بعد (Only twice):",
    "sentenceWithBlank": "Only twice _______ she traveled abroad before her marriage.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "تقديم الظرف (Only twice) يتطلب قلباً في الماضي التام (Only twice had she traveled).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_20",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد (Little) النافية:",
    "sentenceWithBlank": "Little _______ she known about the surprise awaiting her back then.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "البدء بـ (Little) النافية يولد قلباً نحوياً في الماضي التام (Little had she known).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_21",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد (This was the second time):",
    "sentenceWithBlank": "This was the second time he _______ forgotten his keys.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "التركيب (This was the second time) في الماضي يتبعه ماضٍ تام (had forgotten).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_22",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد صيغة التفضيل في الماضي:",
    "sentenceWithBlank": "It was the most challenging task I _______ ever undertaken.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "بعد صيغة التفضيل في الماضي (It was the most challenging...) مع الضمير I يأخذ الماضي التام (had ever undertaken).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_23",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد الرابط (as if) للافتراض الماضي غير الحقيقي:",
    "sentenceWithBlank": "He talked as if he _______ traveled all over the world.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "بعد (as if) في السياق الماضي للتعبير عن حالة افتراضية نستخدم الماضي التام (had traveled).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_24",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد الرابط الزمني (until):",
    "sentenceWithBlank": "I decided not to leave until she _______ arrived.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الروابط الزمنية مثل (until) في السياق الماضي يتبعها ماضٍ تام (had arrived) للدلالة على اكتمال الوصول أولاً.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_25",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد (Once) في المبني للمجهول:",
    "sentenceWithBlank": "Once the contract _______ been signed, we started the project.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "المبني للمجهول في الماضي التام بعد (Once) يأخذ (had been signed).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_26",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد (Supposing that) مع (everyone):",
    "sentenceWithBlank": "Supposing that everyone _______ agreed to the terms, why did they quit?",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "في الماضي التام نستخدم (had agreed) مع (everyone) للتعبير عن الافتراض المسبق.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_27",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد في تركيب (Whether ... or):",
    "sentenceWithBlank": "Whether the plan _______ succeeded or failed, we had to move on.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الفاعل (plan) في الماضي التام يأخذ (had succeeded or failed).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_28",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد بعد (No matter what):",
    "sentenceWithBlank": "No matter what _______ happened, we remained optimistic.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "(what) كفاعل ضميري في الماضي التام يأخذ (had happened).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_29",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع (The data):",
    "sentenceWithBlank": "The data _______ shown interesting trends in the previous study.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "كلمة (Data) في الماضي التام تأخذ (had shown) للدلالة على النتائج السابقة.",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_30",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع (The scissors) في المبني للمجهول:",
    "sentenceWithBlank": "The scissors _______ been placed on the top shelf before I looked.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الأدوات المكونة من جزأين (scissors) في الماضي التام تأخذ (had been placed).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_31",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع (My trousers) في الماضي التام المبني للمجهول:",
    "sentenceWithBlank": "My trousers _______ been stained before I went out.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "كلمة (trousers) في الماضي التام تأخذ (had been stained).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_32",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع اسم المرض (Measles):",
    "sentenceWithBlank": "Measles _______ broken out in several schools before the vaccine.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "اسم المرض (Measles) مفرد ويأخذ في الماضي التام (had broken out).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_33",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع اسم الدولة (The United States):",
    "sentenceWithBlank": "The United States _______ signed a new trade agreement before the crisis.",
    "options": [
      "had",
      "have",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "اسم الدولة ككيان سياسي موحد في الماضي التام يأخذ (had signed).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_34",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع اسم العلم (Economics):",
    "sentenceWithBlank": "Economics _______ become a very popular major before he enrolled.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "علم الاقتصاد (Economics) في الماضي التام يأخذ (had become).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_35",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع الفاعل (The crew):",
    "sentenceWithBlank": "The crew _______ finished checking all equipment before takeoff.",
    "options": [
      "had",
      "have",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "طاقم الطائرة في الماضي التام يأخذ (had finished).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_36",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع (The public):",
    "sentenceWithBlank": "The public _______ shown great interest before the show was cancelled.",
    "options": [
      "had",
      "have",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الجمهور ككيان عام واحد في الماضي التام يأخذ (had shown).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_37",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع المدة الزمنية بعد (By + سنة ماضية):",
    "sentenceWithBlank": "By 2020, ten years _______ passed since we last met.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الفترات الزمنية المحددة في نقطة بالماضي (By 2020) تأخذ الماضي التام (had passed).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_38",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد للمسافة المقطوعة في المبني للمجهول:",
    "sentenceWithBlank": "Three miles _______ been covered by the runners before the rain started.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "المسافات المقطوعة كوحدة قياسية في الماضي التام المبني للمجهول تأخذ (had been covered).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_39",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع (Either of) في المبني للمجهول:",
    "sentenceWithBlank": "Either of the proposals _______ been approved before the meeting.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "كلمة (Either) في الماضي التام المبني للمجهول تأخذ (had been approved).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_40",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع (Neither of the two plans):",
    "sentenceWithBlank": "Neither of the two plans _______ worked as expected.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "(Neither) في الماضي التام تأخذ دائماً (had worked).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_41",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد في شق التوازي مع (not only ... but also):",
    "sentenceWithBlank": "The manager had not only resigned, but he _______ also missed the meeting.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "للحفاظ على التوازي النحوي في الماضي التام، نستخدم (had also missed).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_42",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد في القلب النحوي بعد (Seldom):",
    "sentenceWithBlank": "Seldom _______ I experienced such warmth before that night.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "تقديم ظرف النفي (Seldom) مع الضمير I يتطلب قلباً في الماضي التام (Seldom had I experienced).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_43",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع الفاعل (they) في الماضي التام:",
    "sentenceWithBlank": "Try as they _______, they had not succeeded before the deadline.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "الفاعل (they) في الماضي التام يأخذ (had).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_44",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع الاسم غير المعدود (Much progress) في المبني للمجهول:",
    "sentenceWithBlank": "Much progress _______ been made in science before the new century.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "كلمة (progress) اسم غير معدود، فيأخذ في الماضي التام المبني للمجهول (had been made).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_45",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع (A great deal of money):",
    "sentenceWithBlank": "A great deal of money _______ been invested before the market crashed.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "عبارة (A great deal of) متبوعة بـ money غير المعدود تأخذ في الماضي التام المبني للمجهول (had been invested).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_46",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع (Plenty of time):",
    "sentenceWithBlank": "Plenty of time _______ been given before the test began.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "كلمة (time) غير معدودة، فتأخذ في الماضي التام المبني للمجهول (had been given).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_47",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع (Most of the cake) في المبني للمجهول:",
    "sentenceWithBlank": "Most of the cake _______ been eaten before I arrived.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "(Most of) تتبع الاسم المفرد (cake)، فيأخذ في الماضي التام المبني للمجهول (had been eaten).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_48",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع (Most of the apples):",
    "sentenceWithBlank": "Most of the apples _______ been eaten before I arrived.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "(Most of) تتبع اسم الجمع (apples)، فيأخذ في الماضي التام المبني للمجهول (had been eaten).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_49",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع (Half of the money):",
    "sentenceWithBlank": "Half of the money _______ been spent before the audit.",
    "options": [
      "have",
      "had",
      "has",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "(Half of) تتبع اسماً غير معدود (money)، فيأخذ في الماضي التام المبني للمجهول (had been spent).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  },
  {
    "id": "pp_hard_50",
    "tenseId": "past_perfect",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "اختر الفعل المساعد مع (Half of the students):",
    "sentenceWithBlank": "Half of the students _______ passed the exam before the revision.",
    "options": [
      "has",
      "had",
      "have",
      "did"
    ],
    "correctAnswer": "had",
    "explanation": {
      "whyCorrectAr": "(Half of) تتبع اسم معدود جمع (students)، فيأخذ الفعل في الماضي التام (had passed).",
      "temporalRelationshipAr": "حدث وقع وتم واكتمل قبل نقطة زمنية محددة أو حدث آخر في الماضي (الحدث الأسبق).",
      "whyTenseFitsAr": "الماضي التام (Past Perfect) يُستخدم للدلالة على الحدث الأسبق في الماضي (had + past participle).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تحقق شرط التتابع الزمني للحدث الأسبق أو لا تطابق التوافق النحوي.",
      "confusableTenseAr": "Past Simple / Present Perfect"
    }
  }
];
