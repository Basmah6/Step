import { QuizQuestion } from '../types';

export const FUTURE_PERFECT_EASY_50: QuizQuestion[] = [
  {
    id: "fp_easy_1",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "بحلول الغد، سأكون قد أنهيت واجبي المنزلي.",
    sentenceWithBlank: "By tomorrow, I _______ finished my homework.",
    options: [
      "will have",
      "will has",
      "am have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم المستقبل التام (will have + V3) للتعبير عن حدث سيكتمل قبل وقت محدد في المستقبل (By tomorrow).",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_2",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون قد نظفت غرفتها بحلول الساعة 5 مساءً.",
    sentenceWithBlank: "She _______ cleaned her room by 5 PM.",
    options: [
      "will has",
      "will have",
      "is have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "الفعل المساعد في المستقبل التام دائماً هو will have مع جميع الضمائر المفردة والجمع متبوعاً بالتصريف الثالث.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_3",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكونون قد لعبوا كرة القدم بحلول الأسبوع القادم.",
    sentenceWithBlank: "They _______ played football by next week.",
    options: [
      "will has",
      "will have",
      "are have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have + played للتعبير عن اكتمال الفعل قبل الأسبوع القادم.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_4",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكون قد اشترى سيارة جديدة بحلول نهاية العام.",
    sentenceWithBlank: "He _______ bought a new car by the end of the year.",
    options: [
      "will has",
      "will have",
      "is have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "صيغة المستقبل التام هي will have + التصريف الثالث (bought).",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_5",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سنكون قد زرنا أجدادنا بحلول مساء الغد.",
    sentenceWithBlank: "We _______ visited our grandparents by tomorrow evening.",
    options: [
      "will has",
      "will have",
      "are have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have للتعبير عن فعل يكتمل قبل مساء الغد.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_6",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون قد اجتزت الامتحان بحلول يوم الجمعة.",
    sentenceWithBlank: "You _______ passed the exam by Friday.",
    options: [
      "will has",
      "will have",
      "are have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "صيغة المستقبل التام will have + passed تدل على إتمام النجاح قبل يوم الجمعة.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_7",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون الشمس قد غربت بحلول وقت وصولنا.",
    sentenceWithBlank: "The sun _______ set by the time we arrive.",
    options: [
      "will has",
      "will have",
      "is have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "مع الرابط by the time نستخدم المستقبل التام will have set للحدث الذي سيكتمل أولاً.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_8",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون الطيور قد طارت جنوباً بحلول الشهر القادم.",
    sentenceWithBlank: "Birds _______ flown south by next month.",
    options: [
      "will has",
      "will have",
      "are have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have + flown مع الفاعل الجمع للتعبير عن اكتمال الهجرة بحلول الشهر القادم.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_9",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون قطتي قد أكلت طعامها بحلول الظهيرة.",
    sentenceWithBlank: "My cat _______ eaten its food by noon.",
    options: [
      "will has",
      "will have",
      "is have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have + eaten للتعبير عن اكتمال تناول الطعام قبل الظهيرة.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_10",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكون الماء قد تبخر بحلول الغد.",
    sentenceWithBlank: "Water _______ evaporated by tomorrow.",
    options: [
      "will has",
      "will have",
      "is have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have + evaporated للتعبير عن اكتمال التبخر بحلول الغد.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_11",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "لن أكون قد أنهيت الكتاب بحلول الغد.",
    sentenceWithBlank: "I _______ finished the book by tomorrow.",
    options: [
      "won't has",
      "don't have",
      "won't have",
      "haven't"
],
    correctAnswer: "won't have",
    explanation: {
      whyCorrectAr: "نفي المستقبل التام يكون باستخدام won't have متبوعاً بالتصريف الثالث للفعل.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_12",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "لن تكون قد نظفت المنزل بحلول الظهيرة.",
    sentenceWithBlank: "She _______ cleaned the house by noon.",
    options: [
      "won't has",
      "don't have",
      "won't have",
      "hasn't"
],
    correctAnswer: "won't have",
    explanation: {
      whyCorrectAr: "صيغة النفي في المستقبل التام هي won't have + V3 لجميع الضمائر.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_13",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "لن يكونوا قد وصلوا بحلول الساعة 6 مساءً.",
    sentenceWithBlank: "They _______ arrived by 6 PM.",
    options: [
      "won't has",
      "won't have",
      "haven't",
      "don't have"
],
    correctAnswer: "won't have",
    explanation: {
      whyCorrectAr: "نستخدم won't have للتعبير عن عدم اكتمال الوصول بحلول الساعة 6.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_14",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "لن يكون قد قرأ الكتاب بحلول الغد.",
    sentenceWithBlank: "He _______ read the book by tomorrow.",
    options: [
      "won't has",
      "won't have",
      "hasn't",
      "don't have"
],
    correctAnswer: "won't have",
    explanation: {
      whyCorrectAr: "نستخدم won't have لنفي المستقبل التام مع الفاعل المفرد he.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_15",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "لن نكون قد أنهينا المشروع بحلول يوم الجمعة.",
    sentenceWithBlank: "We _______ finished the project by Friday.",
    options: [
      "won't has",
      "won't have",
      "haven't",
      "don't have"
],
    correctAnswer: "won't have",
    explanation: {
      whyCorrectAr: "نستخدم won't have لنفي اكتمال المشروع قبل يوم الجمعة.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_16",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "لن يكون الكلب قد أكل بحلول وقت إطعامه.",
    sentenceWithBlank: "The dog _______ eaten by the time we feed it.",
    options: [
      "won't has",
      "won't have",
      "hasn't",
      "don't have"
],
    correctAnswer: "won't have",
    explanation: {
      whyCorrectAr: "نستخدم won't have لنفي المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_17",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "لن تكون قد أكلت كل ذلك بحلول الغد.",
    sentenceWithBlank: "You _______ eaten all that by tomorrow.",
    options: [
      "won't has",
      "won't have",
      "haven't",
      "don't have"
],
    correctAnswer: "won't have",
    explanation: {
      whyCorrectAr: "صيغة النفي won't have تعبر عن نفي إتمام الأكل بحلول الغد.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_18",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "علي وأحمد لن يكونا قد وصلا بحلول الظهيرة.",
    sentenceWithBlank: "Ali and Ahmed _______ arrived by noon.",
    options: [
      "won't has",
      "won't have",
      "haven't",
      "don't have"
],
    correctAnswer: "won't have",
    explanation: {
      whyCorrectAr: "نستخدم won't have مع الفاعل الجمع لنفي إتمام الوصول.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_19",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "لن تكون السماء قد توقفت عن المطر بحلول الغد.",
    sentenceWithBlank: "It _______ stopped raining by tomorrow.",
    options: [
      "won't has",
      "won't have",
      "hasn't",
      "don't have"
],
    correctAnswer: "won't have",
    explanation: {
      whyCorrectAr: "نستخدم won't have مع الفاعل it لنفي توقف المطر بحلول الغد.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_20",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "أمي لن تكون قد طبخت الغداء بحلول الساعة 2 بعد الظهر.",
    sentenceWithBlank: "My mother _______ cooked lunch by 2 PM.",
    options: [
      "won't has",
      "won't have",
      "hasn't",
      "don't have"
],
    correctAnswer: "won't have",
    explanation: {
      whyCorrectAr: "نستخدم won't have لنفي اكتمال الطبخ بحلول الساعة الثانية.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_21",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "هل ستكون قد أنهيت عملك بحلول الغد؟",
    sentenceWithBlank: "_______ finished your work by tomorrow?",
    options: [
      "Will you has",
      "Will you have",
      "Have you",
      "Did you"
],
    correctAnswer: "Will you have",
    explanation: {
      whyCorrectAr: "يبدأ السؤال في المستقبل التام بـ Will متبوعاً بالفاعل you ثم have والتصريف الثالث.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_22",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "هل ستكون قد نظفت الغرفة بحلول الظهيرة؟",
    sentenceWithBlank: "_______ cleaned the room by noon?",
    options: [
      "Will she has",
      "Will she have",
      "Has she",
      "Did she"
],
    correctAnswer: "Will she have",
    explanation: {
      whyCorrectAr: "في السؤال بالمستقبل التام نستخدم Will she have مع الفاعل المفرد she.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_23",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "هل سيكونون قد فازوا بالمباراة بحلول الأسبوع القادم؟",
    sentenceWithBlank: "_______ won the match by next week?",
    options: [
      "Will they has",
      "Will they have",
      "Have they",
      "Did they"
],
    correctAnswer: "Will they have",
    explanation: {
      whyCorrectAr: "نستخدم Will they have لتكوين السؤال مع الفاعل الجمع they.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_24",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "هل سيكون قد وصل بحلول صباح الغد؟",
    sentenceWithBlank: "_______ arrived by tomorrow morning?",
    options: [
      "Will he has",
      "Will he have",
      "Has he",
      "Did he"
],
    correctAnswer: "Will he have",
    explanation: {
      whyCorrectAr: "تركيب السؤال في المستقبل التام هو Will he have + V3.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_25",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "هل سنكون قد ادخرنا مالاً كافياً بحلول العام القادم؟",
    sentenceWithBlank: "_______ saved enough money by next year?",
    options: [
      "Will we has",
      "Will we have",
      "Have we",
      "Did we"
],
    correctAnswer: "Will we have",
    explanation: {
      whyCorrectAr: "نستخدم Will we have للسؤال عن اكتمال الادخار في المستقبل.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_26",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ماذا ستكون قد فعلت بحلول نهاية اليوم؟",
    sentenceWithBlank: "What _______ done by the end of the day?",
    options: [
      "will you has",
      "will you have",
      "have you",
      "did you"
],
    correctAnswer: "will you have",
    explanation: {
      whyCorrectAr: "في السؤال بأداة الاستفهام، يأتي will ثم الفاعل you ثم have والتصريف الثالث.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_27",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "إلى أين ستكون قد ذهبت بحلول الغد؟",
    sentenceWithBlank: "Where _______ gone by tomorrow?",
    options: [
      "will she has",
      "will she have",
      "has she",
      "did she"
],
    correctAnswer: "will she have",
    explanation: {
      whyCorrectAr: "نضع will she have بعد أداة الاستفهام Where.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_28",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "لماذا سيكونون قد غادروا مبكراً بحلول ذلك الوقت؟",
    sentenceWithBlank: "Why _______ left early by then?",
    options: [
      "will they has",
      "will they have",
      "have they",
      "did they"
],
    correctAnswer: "will they have",
    explanation: {
      whyCorrectAr: "نستخدم will they have بعد Why للسؤال في زمن المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_29",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "من سيكون قد دعا بحلول الأسبوع القادم؟",
    sentenceWithBlank: "Who _______ invited by next week?",
    options: [
      "will he has",
      "will he have",
      "has he",
      "did he"
],
    correctAnswer: "will he have",
    explanation: {
      whyCorrectAr: "نستخدم will he have لتكوين سؤال المستقبل التام مع الفاعل he.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_30",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "كم مرة ستكون قد أمطرت بحلول الشهر القادم؟",
    sentenceWithBlank: "How many times _______ rained by next month?",
    options: [
      "will it has",
      "will it have",
      "has it",
      "did it"
],
    correctAnswer: "will it have",
    explanation: {
      whyCorrectAr: "نستخدم will it have بعد عبارة السؤال للسؤال عن تكرار الحدث قبل موعد مستقبلي.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_31",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سأكون قد أنهيت واجبي المنزلي بحلول الغد.",
    sentenceWithBlank: "I will have _______ my homework by tomorrow.",
    options: [
      "finish",
      "finishes",
      "finishing",
      "finished"
],
    correctAnswer: "finished",
    explanation: {
      whyCorrectAr: "بعد will have نستخدم دائماً التصريف الثالث للفعل (finished).",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_32",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون قد اشترت فستاناً جديداً بحلول موعد الحفلة.",
    sentenceWithBlank: "She will have _______ a new dress by the party.",
    options: [
      "buy",
      "buys",
      "buying",
      "bought"
],
    correctAnswer: "bought",
    explanation: {
      whyCorrectAr: "التصريف الثالث للفعل buy هو bought بعد will have.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_33",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكونون قد ذهبوا إلى فرنسا بحلول الصيف القادم.",
    sentenceWithBlank: "They will have _______ to France by next summer.",
    options: [
      "go",
      "goes",
      "going",
      "been"
],
    correctAnswer: "been",
    explanation: {
      whyCorrectAr: "نستخدم التصريف الثالث been للدلالة على السفر والزيارة المكتملة بحلول الصيف.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_34",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكون قد كتب رسالة بحلول الظهيرة.",
    sentenceWithBlank: "He will have _______ a letter by noon.",
    options: [
      "write",
      "writes",
      "writing",
      "written"
],
    correctAnswer: "written",
    explanation: {
      whyCorrectAr: "التصريف الثالث من الفعل write هو written بعد will have.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_35",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سنكون قد تناولنا عشائنا بحلول الساعة 8 مساءً.",
    sentenceWithBlank: "We will have _______ our dinner by 8 PM.",
    options: [
      "eat",
      "eats",
      "eating",
      "eaten"
],
    correctAnswer: "eaten",
    explanation: {
      whyCorrectAr: "نستخدم التصريف الثالث eaten بعد will have.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_36",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكون الأطفال قد ذهبوا إلى الفراش بحلول منتصف الليل.",
    sentenceWithBlank: "The children will have _______ to bed by midnight.",
    options: [
      "go",
      "goes",
      "going",
      "gone"
],
    correctAnswer: "gone",
    explanation: {
      whyCorrectAr: "التصريف الثالث للفعل go هو gone بعد will have.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_37",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون قد قمت بعمل رائع بحلول نهاية الفصل الدراسي.",
    sentenceWithBlank: "You will have _______ a great job by the end of the term.",
    options: [
      "do",
      "does",
      "doing",
      "done"
],
    correctAnswer: "done",
    explanation: {
      whyCorrectAr: "نستخدم done (التصريف الثالث) بعد will have.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_38",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكون الطاهي قد صنع كعكة لذيذة بحلول الساعة 3 بعد الظهر.",
    sentenceWithBlank: "The chef will have _______ a delicious cake by 3 PM.",
    options: [
      "make",
      "makes",
      "making",
      "made"
],
    correctAnswer: "made",
    explanation: {
      whyCorrectAr: "التصريف الثالث للفعل make هو made بعد will have.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_39",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون الزهور قد ماتت بحلول الغد بسبب الحرارة.",
    sentenceWithBlank: "The flowers will have _______ by tomorrow due to heat.",
    options: [
      "die",
      "dies",
      "dying",
      "died"
],
    correctAnswer: "died",
    explanation: {
      whyCorrectAr: "نستخدم التصريف الثالث died بعد will have.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_40",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكون أصدقائي قد قدموا لي هدية لطيفة بحلول عيد ميلادي.",
    sentenceWithBlank: "My friends will have _______ me a nice gift by my birthday.",
    options: [
      "give",
      "gives",
      "giving",
      "given"
],
    correctAnswer: "given",
    explanation: {
      whyCorrectAr: "التصريف الثالث للفعل give هو given بعد will have.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_41",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سأكون قد تناولت عشائي بالفعل بحلول وقت وصولك.",
    sentenceWithBlank: "I _______ already eaten my dinner by the time you arrive.",
    options: [
      "will have",
      "will has",
      "am have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have مع الظرف already في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_42",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون قد وصلت للتو إلى المكتب بحلول الساعة 9 صباح الغد.",
    sentenceWithBlank: "She _______ just arrived at the office by 9 AM tomorrow.",
    options: [
      "will has",
      "will have",
      "is have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have مع just للتعبير عن اكتمال الوصول للتو قبل التاسعة.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_43",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكونون قد أنهوا عملهم بحلول الأسبوع القادم.",
    sentenceWithBlank: "They _______ finished their work by next week.",
    options: [
      "will has",
      "will have",
      "are have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "صيغة المستقبل التام will have + V3 تدل على إنجاز العمل قبل الأسبوع القادم.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_44",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكون قد عرفها لمدة عشر سنوات بحلول العام القادم.",
    sentenceWithBlank: "He _______ known her for ten years by next year.",
    options: [
      "will has",
      "will have",
      "is have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have known مع أفعال الحالة للتعبير عن مدة مستمرة حتى نقطة في المستقبل.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_45",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سنكون قد زرناهم مرات عديدة بحلول نهاية هذا العام.",
    sentenceWithBlank: "We _______ visited them many times by the end of this year.",
    options: [
      "will has",
      "will have",
      "are have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have visited للتعبير عن تكرار الزيارات المكتملة حتى نهاية العام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_46",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون قد رأيت حوتاً بحلول نهاية الرحلة البحرية.",
    sentenceWithBlank: "You _______ seen a whale by the end of the cruise.",
    options: [
      "will has",
      "will have",
      "are have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have seen للتعبير عن تجربة ستتحقق بحلول نهاية الرحلة.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_47",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكون القطار قد غادر المحطة بحلول وقت وصولنا إلى الرصيف.",
    sentenceWithBlank: "The train _______ left the station by the time we reach the platform.",
    options: [
      "will has",
      "will have",
      "is have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have left للحدث الأسبق اكتمالاً في المستقبل.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_48",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكون شخص ما قد كسر النافذة بحلول الغد إذا لم نصلحها.",
    sentenceWithBlank: "Someone _______ broken the window by tomorrow if we don't fix it.",
    options: [
      "will has",
      "will have",
      "is have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have broken مع الفاعل المفرد Someone في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_49",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سأكون قد قرأت ثلاثة كتب بحلول نهاية هذا الشهر.",
    sentenceWithBlank: "I _______ read three books by the end of this month.",
    options: [
      "will has",
      "will have",
      "am have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have read للتعبير عن إنجاز قراءة 3 كتب قبل نهاية الشهر.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_easy_50",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون قد عملت هنا لمدة خمس سنوات بحلول يونيو القادم.",
    sentenceWithBlank: "She _______ worked here for five years by next June.",
    options: [
      "will has",
      "will have",
      "is have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have worked للتعبير عن اكتمال مدة 5 سنوات عمل بحلول يونيو.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  }
];
