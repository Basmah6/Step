import { QuizQuestion } from '../types';

export const FUTURE_SIMPLE_MEDIUM_50: QuizQuestion[] = [
  {
    "id": "fs_medium_1",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "أعتقد أنها ستمطر غداً.",
    "sentenceWithBlank": "I think it _______ rain tomorrow.",
    "options": [
      "rain",
      "rains",
      "will rain",
      "rained"
    ],
    "correctAnswer": "will rain",
    "explanation": {
      "whyCorrectAr": "مع أفعال الرأي والاعتقاد (I think) نستخدم المستقبل البسيط will + المصدر.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_2",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "هي تعد بأنها ستساعدني في واجبي المنزلي.",
    "sentenceWithBlank": "She promises she _______ help me with my homework.",
    "options": [
      "help",
      "helps",
      "will help",
      "helped"
    ],
    "correctAnswer": "will help",
    "explanation": {
      "whyCorrectAr": "مع أفعال الوعد (promise) نستخدم المستقبل البسيط will help.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_3",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "في أي وقت ستصل إلى المطار غداً؟",
    "sentenceWithBlank": "What time _______ you arrive at the airport tomorrow?",
    "options": [
      "do",
      "does",
      "will",
      "were"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will لتكوين السؤال في زمن المستقبل مع الكلمة الدالة tomorrow.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_4",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "أين سيقضون إجازتهم الصيف القادم؟",
    "sentenceWithBlank": "Where _______ they spend their vacation next summer?",
    "options": [
      "do",
      "does",
      "will",
      "were"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للسؤال عن خطط المستقبل مع next summer.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_5",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لماذا ستكون غير سعيدة غداً؟",
    "sentenceWithBlank": "Why _______ she be unhappy tomorrow?",
    "options": [
      "do",
      "does",
      "will",
      "was"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للسؤال عن حالة مستقبلية مع tomorrow.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_6",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كم سيكلف هذا المعطف عندما تشتريه غداً؟",
    "sentenceWithBlank": "How much _______ this jacket cost when you buy it tomorrow?",
    "options": [
      "do",
      "does",
      "will",
      "was"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للسؤال عن السعر في المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_7",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "من سترى في المؤتمر الأسبوع القادم؟",
    "sentenceWithBlank": "Who _______ you see at the conference next week?",
    "options": [
      "do",
      "does",
      "will",
      "was"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للسؤال عن حدث مستقبلي محدد.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_8",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "أي كتاب ستختاره لتقرأه أثناء الإجازة الشهر القادم؟",
    "sentenceWithBlank": "Which book _______ she choose to read during the holiday next month?",
    "options": [
      "do",
      "does",
      "will",
      "was"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للسؤال في المستقبل مع next month.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_9",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "ماذا سيفعل والدك عندما يتقاعد العام القادم؟",
    "sentenceWithBlank": "What _______ your father do when he retires next year?",
    "options": [
      "do",
      "does",
      "will",
      "was"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will في الجملة الرئيسية للسؤال عن المستقبل المرتبط بشرط زمني.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_10",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "أين سيعيش أبناء عمك عندما ينتقلون إلى المدينة؟",
    "sentenceWithBlank": "Where _______ your cousins live when they move to town?",
    "options": [
      "do",
      "does",
      "will",
      "were"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will لتكوين السؤال المستقبلي مع الفاعل الجمع.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_11",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لن أعرف الإجابة حتى أتحقق من الكتاب.",
    "sentenceWithBlank": "I _______ not know the answer until I check the book.",
    "options": [
      "doesn't",
      "didn't",
      "won't",
      "wasn't"
    ],
    "correctAnswer": "won't",
    "explanation": {
      "whyCorrectAr": "نستخدم won't للتعبير عن نفي في المستقبل مرتبط بحدث آخر بواسطة until.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_12",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لن تنهي مشروعها في الوقت المحدد إذا تأخرت.",
    "sentenceWithBlank": "She _______ not finish her project on time if she delays.",
    "options": [
      "don't",
      "didn't",
      "won't",
      "wasn't"
    ],
    "correctAnswer": "won't",
    "explanation": {
      "whyCorrectAr": "في جواب الشرط للحالة الأولى نستخدم won't للنفي.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_13",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "هذا الحذاء لن يناسبك إذا كبرت قدماك أكثر.",
    "sentenceWithBlank": "These shoes _______ fit you if your feet grow more.",
    "options": [
      "won't",
      "doesn't",
      "weren't",
      "wasn't"
    ],
    "correctAnswer": "won't",
    "explanation": {
      "whyCorrectAr": "نستخدم won't لنفي المستقبل في جواب الشرط.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_14",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لن يتحدث أي من الأخوين الإنجليزية أثناء المقابلة غداً.",
    "sentenceWithBlank": "Neither of the brothers _______ speak English during the interview tomorrow.",
    "options": [
      "speak",
      "will speak",
      "speaks",
      "speaking"
    ],
    "correctAnswer": "will speak",
    "explanation": {
      "whyCorrectAr": "في المستقبل البسيط نستخدم will + المصدر (will speak).",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_15",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لن يحب عمي تناول الطعام الحار عندما يزورنا.",
    "sentenceWithBlank": "My uncle _______ like eating spicy food when he visits us.",
    "options": [
      "doesn't",
      "didn't",
      "won't",
      "wasn't"
    ],
    "correctAnswer": "won't",
    "explanation": {
      "whyCorrectAr": "نستخدم won't للتنبؤ بعدم الرغبة في المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_16",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "النباتيون لن يتناولوا أي نوع من اللحوم في العشاء القادم.",
    "sentenceWithBlank": "Vegetarians _______ eat any kind of meat at the upcoming dinner.",
    "options": [
      "eats",
      "won't",
      "didn't",
      "aren't"
    ],
    "correctAnswer": "won't",
    "explanation": {
      "whyCorrectAr": "نستخدم won't لنفي الفعل في المستقبل (won't eat).",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_17",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لن يعرف أحد إجابة ذلك اللغز الصعب غداً.",
    "sentenceWithBlank": "Nobody _______ the answer to that difficult riddle tomorrow.",
    "options": [
      "know",
      "will know",
      "knowing",
      "known"
    ],
    "correctAnswer": "will know",
    "explanation": {
      "whyCorrectAr": "مع المستقبل المحدد بـ tomorrow نستخدم will + المصدر know.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_18",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "سيكون الجميع سعداء عندما تبدأ العطلات الشهر القادم.",
    "sentenceWithBlank": "Everyone _______ happy when the holidays start next month.",
    "options": [
      "are",
      "was",
      "will be",
      "am"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be للمستقبل مع الضمير Everyone والجملة الزمنية.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_19",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "والداي لن يسافرا إلى الخارج كثيراً العام القادم.",
    "sentenceWithBlank": "My parents _______ travel abroad very often next year.",
    "options": [
      "doesn't",
      "didn't",
      "won't",
      "weren't"
    ],
    "correctAnswer": "won't",
    "explanation": {
      "whyCorrectAr": "نستخدم won't لنفي المستقبل مع الفاعل الجمع والدلالة next year.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_20",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "ستُبث الأخبار على التلفاز في الساعة 9:00 مساءً غداً.",
    "sentenceWithBlank": "The news _______ broadcasted on TV at 9:00 PM tomorrow.",
    "options": [
      "were",
      "was",
      "will be",
      "is"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "صيغة المبني للمجهول في المستقبل البسيط هي will be + P.P.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_21",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كم مرة ستزور أجدادك عندما تنتقل إلى الخارج؟",
    "sentenceWithBlank": "How often _______ you visit your grandparents when you move abroad?",
    "options": [
      "do",
      "does",
      "will",
      "were"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للسؤال عن وتيرة الحدث المستقبلي.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_22",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "في أي وقت سيفتح البنك صباح الغد؟",
    "sentenceWithBlank": "What time _______ the bank open tomorrow morning?",
    "options": [
      "do",
      "will",
      "was",
      "were"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will لتكوين السؤال المستقبلي مع الفاعل المفرد the bank.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_23",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لماذا سيتذمرون دائماً من الطقس في الشتاء القادم؟",
    "sentenceWithBlank": "Why _______ they always complain about the weather next winter?",
    "options": [
      "do",
      "will",
      "were",
      "are"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للسؤال عن المستقبل مع next winter.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_24",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كم سيكلف هذا المعطف الأسبوع القادم؟",
    "sentenceWithBlank": "How much _______ this jacket cost next week?",
    "options": [
      "do",
      "will",
      "was",
      "were"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للسؤال عن تكلفة في المستقبل مع next week.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_25",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "مع من ستتحدث عادة عندما تواجهك مشكلة غداً؟",
    "sentenceWithBlank": "Who _______ you usually talk to when you have a problem tomorrow?",
    "options": [
      "do",
      "will",
      "were",
      "was"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للسؤال عن التصرف المستقبلي.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_26",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "أي كتاب ستفضل قراءته أثناء إجازتها؟",
    "sentenceWithBlank": "Which book _______ she prefer to read during her vacation?",
    "options": [
      "do",
      "will",
      "was",
      "were"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للسؤال عن التفضيل المستقبلي.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_27",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "ماذا سيعمل والدك لكسب عيشه في عام 2030؟",
    "sentenceWithBlank": "What _______ your father do for a living in 2030?",
    "options": [
      "do",
      "will",
      "was",
      "were"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "للسؤال عن تواريخ مستقبلية (in 2030) نستخدم will.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_28",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "أين سيعيش أبناء عمك عندما ينتقلون؟",
    "sentenceWithBlank": "Where _______ your cousins live when they move?",
    "options": [
      "do",
      "will",
      "were",
      "was"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للسؤال في جملة المستقبل الرئيسية.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_29",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لماذا سيصل متأخراً دائماً للاجتماعات الشهر القادم؟",
    "sentenceWithBlank": "Why _______ he always arrive late for meetings next month?",
    "options": [
      "do",
      "will",
      "was",
      "were"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للسؤال المستقبلي مع next month.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_30",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كيف سيحتفل الناس في بلدك بالعام الجديد السنة القادمة؟",
    "sentenceWithBlank": "How _______ people in your country celebrate New Year next year?",
    "options": [
      "do",
      "will",
      "were",
      "was"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للسؤال عن الاحتفالات المستقبلية مع next year.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_31",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "أختي لن تنسى أبداً مفاتيحها في رحلة الغد.",
    "sentenceWithBlank": "My sister _______ forget her keys on the trip tomorrow.",
    "options": [
      "always",
      "will never",
      "usually",
      "often"
    ],
    "correctAnswer": "will never",
    "explanation": {
      "whyCorrectAr": "التركيب الصحيح في المستقبل المنفي المشدد هو will never + المصدر forget.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_32",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لن يكونوا أبداً متأخرين عن حصة اللغة الإنجليزية غداً.",
    "sentenceWithBlank": "They _______ late for their English class tomorrow.",
    "options": [
      "never",
      "will never be",
      "never will be",
      "do never"
    ],
    "correctAnswer": "will never be",
    "explanation": {
      "whyCorrectAr": "ظرف التكرار never يأتي بين will وفعل الكينونة be (will never be).",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_33",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "هل ستتناول الفطور دائماً قبل الذهاب إلى المدرسة غداً؟",
    "sentenceWithBlank": "Will you _______ eat breakfast before going to school tomorrow?",
    "options": [
      "always",
      "always do",
      "will always",
      "be always"
    ],
    "correctAnswer": "always",
    "explanation": {
      "whyCorrectAr": "في صيغة السؤال بـ Will، يوضع ظرف التكرار always بعد الفاعل مباشرة وقبل المصدر eat.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_34",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "نادراً ما ستأخذ حافلة إلى العمل العام القادم؛ ستفضل المشي.",
    "sentenceWithBlank": "She _______ take a bus to work next year; she will prefer walking.",
    "options": [
      "will always",
      "will usually",
      "will rarely",
      "rarely will"
    ],
    "correctAnswer": "will rarely",
    "explanation": {
      "whyCorrectAr": "نستخدم will rarely للدلالة على ندرة حدوث الفعل في المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_35",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "عادة ما سيكون لدينا اجتماعات صباح أيام الاثنين في الفصل الدراسي القادم.",
    "sentenceWithBlank": "We _______ have meetings on Monday mornings next term.",
    "options": [
      "will usually",
      "usually will",
      "are usually",
      "do usually"
    ],
    "correctAnswer": "will usually",
    "explanation": {
      "whyCorrectAr": "ظرف التكرار usually يأتي بعد will وقبل الفعل الأساسي have.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_36",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "غالباً ما سيكون متعباً بعد يوم طويل في المكتب غداً.",
    "sentenceWithBlank": "He _______ tired after a long day at the office tomorrow.",
    "options": [
      "often",
      "will often be",
      "often will be",
      "did often"
    ],
    "correctAnswer": "will often be",
    "explanation": {
      "whyCorrectAr": "نستخدم will often be للتعبير عن تكرار الحالة المستقبلية المتوقعة.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_37",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كم مرة ستذهب إلى السينما عندما تكبر؟",
    "sentenceWithBlank": "How often _______ you go to the cinema when you grow up?",
    "options": [
      "does",
      "will",
      "were",
      "was"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للسؤال عن المستقبل المرتبط بـ when you grow up.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_38",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "غالباً ما ستنام القطط أثناء النهار كالمعتاد غداً.",
    "sentenceWithBlank": "Cats _______ sleep during the day as usual tomorrow.",
    "options": [
      "will often",
      "often will",
      "often are",
      "did often"
    ],
    "correctAnswer": "will often",
    "explanation": {
      "whyCorrectAr": "الترتيب النحوي الصحيح هو will متبوعة بظرف التكرار often ثم المصدر sleep.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_39",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لن أشرب القهوة أبداً مساء الغد لأنها تبقيني مستيقظاً.",
    "sentenceWithBlank": "I _______ drink coffee tomorrow evening because it keeps me awake.",
    "options": [
      "always",
      "will never",
      "usually",
      "often"
    ],
    "correctAnswer": "will never",
    "explanation": {
      "whyCorrectAr": "نستخدم will never للتأكيد على الامتناع عن الفعل في المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_40",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "هل ستتذمر دائماً من وظيفتها الشهر القادم؟",
    "sentenceWithBlank": "Will she _______ complain about her job next month?",
    "options": [
      "always",
      "always will",
      "will always",
      "be always"
    ],
    "correctAnswer": "always",
    "explanation": {
      "whyCorrectAr": "في السؤال المبدوء بـ Will، يأتي ظرف التكرار always بعد الفاعل she وقبل الفعل المجرد complain.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_41",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "ستستمر الأرض في الدوران حول الشمس إلى الأبد.",
    "sentenceWithBlank": "The Earth _______ around the Sun forever.",
    "options": [
      "move",
      "will move",
      "moving",
      "moved"
    ],
    "correctAnswer": "will move",
    "explanation": {
      "whyCorrectAr": "نستخدم will move للتعبير عن استمرار حقيقة كونية إلى ما لا نهاية في المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_42",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "سيتجمد الماء عند درجة صفر مئوية خلال موجة الصقيع القادمة.",
    "sentenceWithBlank": "Water _______ freeze at zero degrees Celsius during the next winter freeze.",
    "options": [
      "freeze",
      "will",
      "freezing",
      "frozen"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will قبل المصدر freeze للدلالة على المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_43",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "إذا أمطرت غداً، سنبقى في المنزل.",
    "sentenceWithBlank": "If it rains tomorrow, we _______ stay at home.",
    "options": [
      "rain",
      "will",
      "raining",
      "rained"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "في جواب الشرط للحالة الأولى (First Conditional) نستخدم will + المصدر stay.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_44",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "سأذهب أنا وأصدقائي إلى النادي الرياضي ثلاث مرات الأسبوع القادم.",
    "sentenceWithBlank": "My friends and I _______ go to the gym three times next week.",
    "options": [
      "will",
      "go",
      "going",
      "gone"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will مع المصدر go للتعبير عن الخطة المستقبلية مع next week.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_45",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "سيغادر القطار المتجه إلى لندن في الساعة 4 مساءً غداً.",
    "sentenceWithBlank": "The train to London _______ leave at 4 PM tomorrow.",
    "options": [
      "leave",
      "will",
      "leaving",
      "leaves"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للدلالة على موعد المغادرة المستقبلي.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_46",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "ستصنع النحل العسل من الزهور في الربيع القادم.",
    "sentenceWithBlank": "Bees _______ make honey from flowers next spring.",
    "options": [
      "will",
      "make",
      "making",
      "makes"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will مع المصدر make للتعبير عن حدث مستقبلي.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_47",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "ستقيم حماتي معنا خلال الصيف القادم.",
    "sentenceWithBlank": "My mother-in-law _______ stay with us during next summer.",
    "options": [
      "stay",
      "will",
      "staying",
      "stays"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will مع المصدر stay للتعبير عن إقامة مستقبلية مع next summer.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_48",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "سيستمر الأطفال في لعب ألعاب الفيديو في أوقات فراغهم.",
    "sentenceWithBlank": "Children _______ continue to play video games in their free time.",
    "options": [
      "will",
      "like",
      "liking",
      "likes"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للدلالة على استمرارية العادة في المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_49",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "سيفتح المتحف في الساعة 9 صباحاً ويغلق في 5 مساءً غداً.",
    "sentenceWithBlank": "The museum _______ open at 9 AM and close at 5 PM tomorrow.",
    "options": [
      "open",
      "will",
      "opening",
      "opens"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للدلالة على مواعيد الغد المستقبلية.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_medium_50",
    "tenseId": "future_simple",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "ستكون قواعد اللغة الإنجليزية سهلة بالنسبة لك إذا مارستها كل يوم.",
    "sentenceWithBlank": "English grammar _______ be easy for you if you practice every day.",
    "options": [
      "are",
      "will",
      "were",
      "be"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will مع المصدر be في جواب الشرط للحالة الأولى.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  }
];
