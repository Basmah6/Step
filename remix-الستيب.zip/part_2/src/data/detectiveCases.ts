import { DetectiveCase } from '../types';

export const DETECTIVE_CASES: DetectiveCase[] = [
  {
    id: 'case_01',
    titleAr: 'قضية المتحف وساعة منتصف الليل 🏛️',
    settingAr: 'متحف لندن للفنون — سرقة ماسة التاج في الساعة 11:30 مساءً.',
    mysteryAr: 'حارس المتحف، عامل النظافة، والزائر الأخير يدلون بإفاداتهم. استخدم الأزمنة الصحيحة لتحليل حركاتهم واكتشاف المتناقضات!',
    clues: [
      {
        clueId: 'clue_1',
        witnessStatementEn: 'At 11:30 PM, I was patrolling the second floor.',
        translationAr: 'في الساعة 11:30 مساءً، كنت أقوم بدورية في الطابق الثاني.',
        timestampAr: '11:30 PM (وقت السرقة)',
        temporalClueAr: 'استخدم الماضي المستمر (was patrolling) للإشارة إلى نشاط كان في منتصف الحدوث في دقيقة السرقة.',
      },
      {
        clueId: 'clue_2',
        witnessStatementEn: 'When the alarm sounded, the thief had already escaped through the window.',
        translationAr: 'عندما انطلق جرس الإنذار، كان اللص قد هرب مسبقاً من النافذة.',
        timestampAr: '11:35 PM',
        temporalClueAr: 'الماضي التام (had escaped) يثبت أن الهروب وقع قبل انطلاق الإنذار.',
      },
      {
        clueId: 'clue_3',
        witnessStatementEn: 'The suspect has visited the museum three times this week.',
        translationAr: 'المشتبه به زار المتحف ثلاث مرات هذا الأسبوع.',
        timestampAr: 'خلال الأسبوع الحالي',
        temporalClueAr: 'المضارع التام (has visited) يربط الزيارات المتكررة بالأسبوع الحالي المفتوح.',
      },
    ],
    questions: [
      {
        id: 'det_q1',
        tenseId: 'past_continuous',
        difficulty: 'medium',
        type: 'multiple_choice',
        promptAr: 'حارس الأمن يصف المشهد عند وقوع انقطاع الكهرباء:',
        sentenceWithBlank: 'I ___ on the surveillance monitors when suddenly all screens went black.',
        options: ['was looking', 'looked', 'have looked', 'had been looked'],
        correctAnswer: 'was looking',
        explanation: {
          whyCorrectAr: 'المراقبة كانت النشاط المستمر كخلفية عندما وقع انقطاع الشاشات المفاجئ.',
          temporalRelationshipAr: 'حدث مستمر في الماضي قوطع بحدث ماضٍ بسيط.',
          whyTenseFitsAr: 'Past Continuous (was looking).',
        },
      },
      {
        id: 'det_q2',
        tenseId: 'past_perfect',
        difficulty: 'hard',
        type: 'two_events_challenge',
        promptAr: 'تقرير الأدلة الجنائية: البصمات وُضعت على الزجاج قبل وصول الحارس:',
        sentenceWithBlank: 'The forensic team proved that someone ___ the display case before the guard arrived.',
        options: ['had unlocked', 'has unlocked', 'was unlocking', 'unlocks'],
        correctAnswer: 'had unlocked',
        explanation: {
          whyCorrectAr: 'فتح الخزانة تم أولاً في الماضي، ثم وصل الحارس ثانياً، فالحدث الأسبق هو الماضي التام.',
          temporalRelationshipAr: 'الحدث 1: had unlocked -> الحدث 2: arrived.',
          whyTenseFitsAr: 'Past Perfect (had unlocked).',
        },
      },
    ],
    conclusionAr: 'تم حل القضية! بفضل التمييز الدقيق بين ما كان يحدث (Past Continuous) وما حدث قبل ذلك (Past Perfect)، استطاع المحقق حصر وقت السرقة بين 11:20 و 11:28 مساءً!',
  },
  {
    id: 'case_02',
    titleAr: 'لغز رحلة القطار السريع 🚄',
    settingAr: 'قطار أورينت إكسبريس — فقدان حقيبة الوثائق السرية بين باريس وفيينا.',
    mysteryAr: 'أربعة ركاب في عربة الدرجة الأولى. كل راكب يقدم عذراً زمنياً (Alibi). من منهم استخدم زمناً غير منطقي؟',
    clues: [
      {
        clueId: 'clue_4',
        witnessStatementEn: 'I have been sitting in this seat since we left Paris.',
        translationAr: 'أنا جالس في هذا المقعد منذ أن غادرنا باريس.',
        timestampAr: 'طوال الرحلة حتى الآن',
        temporalClueAr: 'المضارع التام المستمر يؤكد عدم مغادرة المقعد طوال المدة.',
      },
      {
        clueId: 'clue_5',
        witnessStatementEn: 'By the time the train reaches Vienna, I will have finished my business report.',
        translationAr: 'بحلول وقت وصول القطار إلى فيينا، سأكون قد أنهيت تقرير عملي.',
        timestampAr: 'محطة فيينا (المستقبل)',
        temporalClueAr: 'المستقبل التام يعبر عن موعد نهائي للإنجاز.',
      },
    ],
    questions: [
      {
        id: 'det_q3',
        tenseId: 'present_perfect_continuous',
        difficulty: 'medium',
        type: 'duration_challenge',
        promptAr: 'الراكب المشتبه به يبرر توتره للمحقق:',
        sentenceWithBlank: 'I am exhausted because I ___ on urgent financial files for six hours without a break.',
        options: ['have been working', 'had worked', 'am working', 'worked'],
        correctAnswer: 'have been working',
        explanation: {
          whyCorrectAr: 'الراكب يبرر حالته الحاضرة (I am exhausted) بنشاط استمر لـ 6 ساعات وما زال أثره ملموساً الآن.',
          temporalRelationshipAr: 'نشاط استمر طوال مدة ماضية قريبة يفسر الحالة الحاضرة.',
          whyTenseFitsAr: 'Present Perfect Continuous (have been working).',
        },
      },
    ],
    conclusionAr: 'رائع أيها المحقق! كشفت التحليلات الزمنية أن حقيبة الوثائق سُحبت أثناء انشغال الركاب بطلب العشاء قبل محطة ميونخ!',
  },
];
