import { QuizQuestion } from '../types';

export const FUTURE_PERFECT_CONTINUOUS_EASY_50: QuizQuestion[] = [
  {
    id: "fpc_easy_1",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "بحلول العام القادم، سأكون قد عملت هنا لمدة خمس سنوات.",
    sentenceWithBlank: "By next year, I _______ working here for five years.",
    options: [
      "will have been",
      "will has been",
      "will be have",
      "had been"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "نستخدم المستقبل التام المستمر (will have been + V-ing) للتعبير عن استمرار الحدث لمدة زمنية محددة حتى نقطة في المستقبل (By next year + for five years).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_2",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "بحلول صباح الغد، ستكون قد نامت لمدة عشر ساعات.",
    sentenceWithBlank: "By tomorrow morning, she _______ sleeping for ten hours.",
    options: [
      "will has been",
      "will have been",
      "is been",
      "had been"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "صيغة المستقبل التام المستمر هي will have been + sleeping مع جميع الضمائر.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_3",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكونون قد لعبوا كرة القدم لمدة ساعتين بحلول الساعة 5 مساءً.",
    sentenceWithBlank: "They _______ playing football for two hours by 5 PM.",
    options: [
      "will has been",
      "will have been",
      "are been",
      "had been"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "نستخدم will have been + playing للتعبير عن استمرار اللعب لمدة ساعتين حتى الخامسة مساءً.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_4",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكون قد انتظرنا لمدة ساعة بحلول وقت وصولنا.",
    sentenceWithBlank: "He _______ waiting for us for an hour by the time we arrive.",
    options: [
      "will has been",
      "will have been",
      "is been",
      "had been"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "الفعل المساعد للمستقبل التام المستمر هو will have been متبوعاً بالفعل مضافاً له ing.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_5",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سنكون قد عشنا في هذه المدينة لمدة عشر سنوات بحلول الشهر القادم.",
    sentenceWithBlank: "We _______ living in this city for ten years by next month.",
    options: [
      "will has been",
      "will have been",
      "are been",
      "had been"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "نستخدم will have been + living للدلالة على مدة الإقامة المستمرة حتى الشهر القادم.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_6",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون قد درست اللغة الإنجليزية لمدة ثلاث سنوات بحلول نهاية هذا الفصل الدراسي.",
    sentenceWithBlank: "You _______ studying English for three years by the end of this term.",
    options: [
      "will has been",
      "will have been",
      "are been",
      "had been"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "صيغة will have been studying توضح استمرار الدراسة لمدة 3 سنوات حتى نهاية الفصل.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_7",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون السماء قد أمطرت لمدة 24 ساعة بحلول بعد ظهر الغد.",
    sentenceWithBlank: "It _______ raining for 24 hours by tomorrow afternoon.",
    options: [
      "will has been",
      "will have been",
      "is been",
      "had been"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "نستخدم will have been + raining للتعبير عن استمرار هطول المطر حتى الغد.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_8",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكون الأطفال قد لعبوا في الحديقة لعدة ساعات بحلول الغروب.",
    sentenceWithBlank: "The children _______ playing in the park for hours by sunset.",
    options: [
      "will has been",
      "will have been",
      "are been",
      "had been"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "نستخدم will have been مع الفاعل الجمع the children في المستقبل التام المستمر.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_9",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون قطتي قد نامت على الأريكة طوال اليوم بحلول الليلة.",
    sentenceWithBlank: "My cat _______ sleeping on the couch all day by tonight.",
    options: [
      "will has been",
      "will have been",
      "is been",
      "had been"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "صيغة will have been sleeping تدل على استمرار النوم طوال اليوم حتى الليلة.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_10",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون الطيور قد حلقت جنوباً لأيام بحلول ذروة الشتاء.",
    sentenceWithBlank: "Birds _______ flying south for days by the time winter peaks.",
    options: [
      "will has been",
      "will have been",
      "are been",
      "had been"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "نستخدم will have been flying للدلالة على استمرار الطيران لأيام حتى ذروة الشتاء.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_11",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "لن أكون قد عملت لفترة طويلة عندما تصل.",
    sentenceWithBlank: "I _______ working for long when you arrive.",
    options: [
      "won't has been",
      "don't have been",
      "won't have been",
      "haven't been"
],
    correctAnswer: "won't have been",
    explanation: {
      whyCorrectAr: "نفي المستقبل التام المستمر يكون بـ won't have been متبوعاً بالفعل بصيغة ing.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_12",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "لن تكون قد نظفت المنزل لفترة طويلة بحلول ذلك الوقت.",
    sentenceWithBlank: "She _______ cleaning the house for long by then.",
    options: [
      "won't has been",
      "won't have been",
      "hasn't been",
      "don't have been"
],
    correctAnswer: "won't have been",
    explanation: {
      whyCorrectAr: "صيغة النفي في المستقبل التام المستمر هي won't have been مع جميع الضمائر.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_13",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "لن يكونوا قد سافروا لمدة أسبوع بحلول الغد.",
    sentenceWithBlank: "They _______ traveling for a week by tomorrow.",
    options: [
      "won't has been",
      "won't have been",
      "haven't been",
      "don't have been"
],
    correctAnswer: "won't have been",
    explanation: {
      whyCorrectAr: "نستخدم won't have been لنفي استمرار السفر لمدة أسبوع بحلول الغد.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_14",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "لن يكون قد درس لساعات عندما يبدأ الاختبار.",
    sentenceWithBlank: "He _______ studying for hours when the test starts.",
    options: [
      "won't has been",
      "won't have been",
      "hasn't been",
      "don't have been"
],
    correctAnswer: "won't have been",
    explanation: {
      whyCorrectAr: "نستخدم won't have been مع الفاعل المفرد he لنفي استمرار المذاكرة.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_15",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "لن نكون قد انتظرنا طويلاً بحلول وقت وصول الحافلة.",
    sentenceWithBlank: "We _______ waiting long by the time the bus comes.",
    options: [
      "won't has been",
      "won't have been",
      "haven't been",
      "don't have been"
],
    correctAnswer: "won't have been",
    explanation: {
      whyCorrectAr: "صيغة النفي won't have been تدل على نفي طول مدة الانتظار في المستقبل.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_16",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "لن يكون الكلب قد نبح طوال الليل بحلول الصباح.",
    sentenceWithBlank: "The dog _______ barking all night by morning.",
    options: [
      "won't has been",
      "won't have been",
      "hasn't been",
      "don't have been"
],
    correctAnswer: "won't have been",
    explanation: {
      whyCorrectAr: "نستخدم won't have been barking لنفي استمرار النباح طوال الليل.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_17",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "لن تكون قد تدربت لفترة طويلة بحلول الأسبوع القادم.",
    sentenceWithBlank: "You _______ exercising for long by next week.",
    options: [
      "won't has been",
      "won't have been",
      "haven't been",
      "don't have been"
],
    correctAnswer: "won't have been",
    explanation: {
      whyCorrectAr: "نستخدم won't have been لنفي استمرار التمرين بحلول الأسبوع القادم.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_18",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "علي وأحمد لن يكونا قد عملا معاً لمدة عام بحلول ذلك الوقت.",
    sentenceWithBlank: "Ali and Ahmed _______ working together for a year by then.",
    options: [
      "won't has been",
      "won't have been",
      "haven't been",
      "don't have been"
],
    correctAnswer: "won't have been",
    explanation: {
      whyCorrectAr: "نستخدم won't have been مع الفاعل المركب الجمع لنفي استمرار العمل معاً لعام.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_19",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "لن تكون السماء قد أمطرت لأيام بحلول الغد.",
    sentenceWithBlank: "It _______ raining for days by tomorrow.",
    options: [
      "won't has been",
      "won't have been",
      "hasn't been",
      "don't have been"
],
    correctAnswer: "won't have been",
    explanation: {
      whyCorrectAr: "نستخدم won't have been raining لنفي استمرار المطر لأيام.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_20",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "أمي لن تكون قد طبخت طوال اليوم بحلول الظهيرة.",
    sentenceWithBlank: "My mother _______ cooking all day by noon.",
    options: [
      "won't has been",
      "won't have been",
      "hasn't been",
      "don't have been"
],
    correctAnswer: "won't have been",
    explanation: {
      whyCorrectAr: "نستخدم won't have been لنفي استمرار الطبخ طوال اليوم.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_21",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "هل ستكون قد انتظرت هنا لمدة ساعتين بحلول الساعة 5 مساءً؟",
    sentenceWithBlank: "_______ you have been waiting here for two hours by 5 PM?",
    options: [
      "Will you has been",
      "Will you have been",
      "Have you been",
      "Did you be"
],
    correctAnswer: "Will you have been",
    explanation: {
      whyCorrectAr: "يبدأ السؤال في المستقبل التام المستمر بـ Will متبوعاً بالفاعل you ثم have been والفعل بصيغة ing.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_22",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "هل ستكون قد درست لساعات بحلول الليلة؟",
    sentenceWithBlank: "_______ she have been studying for hours by tonight?",
    options: [
      "Will she has been",
      "Will she have been",
      "Has she been",
      "Did she be"
],
    correctAnswer: "Will she have been",
    explanation: {
      whyCorrectAr: "نستخدم Will she have been لتكوين السؤال في المستقبل التام المستمر مع الفاعل المفرد she.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_23",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "هل سيكونون قد لعبوا التنس طوال الصباح بحلول الظهيرة؟",
    sentenceWithBlank: "_______ they have been playing tennis all morning by noon?",
    options: [
      "Will they has been",
      "Will they have been",
      "Have they been",
      "Did they be"
],
    correctAnswer: "Will they have been",
    explanation: {
      whyCorrectAr: "نستخدم Will they have been لتكوين السؤال مع الفاعل الجمع they.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_24",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "هل سيكون قد عمل على ذلك المشروع لمدة أسبوع بحلول يوم الجمعة؟",
    sentenceWithBlank: "_______ he have been working on that project for a week by Friday?",
    options: [
      "Will he has been",
      "Will he have been",
      "Has he been",
      "Did he be"
],
    correctAnswer: "Will he have been",
    explanation: {
      whyCorrectAr: "صيغة السؤال في المستقبل التام المستمر هي Will he have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_25",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "هل سنكون قد عشنا هنا لمدة خمس سنوات بحلول العام القادم؟",
    sentenceWithBlank: "_______ we have been living here for five years by next year?",
    options: [
      "Will we has been",
      "Will we have been",
      "Have we been",
      "Did we be"
],
    correctAnswer: "Will we have been",
    explanation: {
      whyCorrectAr: "نستخدم Will we have been للسؤال عن استمرار الإقامة حتى العام القادم.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_26",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ماذا ستكون قد فعلت خلال الساعة الماضية عندما أراك؟",
    sentenceWithBlank: "What _______ you have been doing for the past hour when I see you?",
    options: [
      "will you has been",
      "will you have been",
      "have you been",
      "did you be"
],
    correctAnswer: "will you have been",
    explanation: {
      whyCorrectAr: "بعد أداة الاستفهام What نضع will you have been متبوعة بالفعل بصيغة ing.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_27",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "أين ستكون قد اختبأت لساعات بحلول الوقت الذي نجدها فيه؟",
    sentenceWithBlank: "Where _______ she have been hiding for hours by the time we find her?",
    options: [
      "will she has been",
      "will she have been",
      "has she been",
      "did she be"
],
    correctAnswer: "will she have been",
    explanation: {
      whyCorrectAr: "نستخدم will she have been بعد أداة الاستفهام Where.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_28",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "لماذا سيكونون قد تجادلوا لفترة طويلة بحلول وقت وصولنا؟",
    sentenceWithBlank: "Why _______ they have been arguing for so long by the time we arrive?",
    options: [
      "will they has been",
      "will they have been",
      "have they been",
      "did they be"
],
    correctAnswer: "will they have been",
    explanation: {
      whyCorrectAr: "نستخدم will they have been بعد Why في زمن المستقبل التام المستمر.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_29",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "مع من سيكون قد تحدث لمدة ساعة بحلول ذلك الوقت؟",
    sentenceWithBlank: "Who _______ he have been talking to for an hour by then?",
    options: [
      "will he has been",
      "will he have been",
      "has he been",
      "did he be"
],
    correctAnswer: "will he have been",
    explanation: {
      whyCorrectAr: "نستخدم will he have been لتكوين السؤال مع الفاعل he.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_30",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "كم المدة التي ستكون السماء قد أمطرت فيها بحلول مساء الغد؟",
    sentenceWithBlank: "How long _______ it have been raining by tomorrow evening?",
    options: [
      "will it has been",
      "will it have been",
      "has it been",
      "did it be"
],
    correctAnswer: "will it have been",
    explanation: {
      whyCorrectAr: "نستخدم will it have been للسؤال عن مدة استمرار هطول المطر حتى مساء الغد.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_31",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سأكون قد بحثت عن مفاتيحي لمدة ساعة بحلول الوقت الذي أجدها فيه.",
    sentenceWithBlank: "I will have been _______ for my keys for an hour by the time I find them.",
    options: [
      "look",
      "looks",
      "looked",
      "looking"
],
    correctAnswer: "looking",
    explanation: {
      whyCorrectAr: "بعد will have been يأتي دائماً الفعل مضافاً إليه ing (looking).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_32",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون قد كتبت رواية لعدة أشهر بحلول الشتاء القادم.",
    sentenceWithBlank: "She will have been _______ a novel for months by next winter.",
    options: [
      "write",
      "writes",
      "written",
      "writing"
],
    correctAnswer: "writing",
    explanation: {
      whyCorrectAr: "نستخدم صيغة ing (writing) بعد will have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_33",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكونون قد استمعوا إلى الموسيقى لساعات بحلول وقت العشاء.",
    sentenceWithBlank: "They will have been _______ to music for hours by dinner time.",
    options: [
      "listen",
      "listens",
      "listened",
      "listening"
],
    correctAnswer: "listening",
    explanation: {
      whyCorrectAr: "نستخدم listening بعد will have been للدلالة على استمرار الاستماع.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_34",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكون قد درس الفرنسية لمدة عام بحلول الشهر القادم.",
    sentenceWithBlank: "He will have been _______ French for a year by next month.",
    options: [
      "study",
      "studies",
      "studied",
      "studying"
],
    correctAnswer: "studying",
    explanation: {
      whyCorrectAr: "نستخدم studying بعد will have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_35",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سنكون قد انتظرنا الحافلة في البرد لمدة عشرين دقيقة.",
    sentenceWithBlank: "We will have been _______ for the bus in the cold for twenty minutes.",
    options: [
      "wait",
      "waits",
      "waited",
      "waiting"
],
    correctAnswer: "waiting",
    explanation: {
      whyCorrectAr: "نستخدم صيغة الفيرب مع ing (waiting) بعد will have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_36",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكون الأطفال قد لعبوا في الحديقة طوال فترة بعد الظهر.",
    sentenceWithBlank: "The children will have been _______ in the park all afternoon.",
    options: [
      "play",
      "plays",
      "played",
      "playing"
],
    correctAnswer: "playing",
    explanation: {
      whyCorrectAr: "نستخدم playing بعد will have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_37",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون قد قدت بسرعة كبيرة لمدة ساعة قبل الوصول إلى المدينة.",
    sentenceWithBlank: "You will have been _______ too fast for an hour before reaching the city.",
    options: [
      "drive",
      "drives",
      "driven",
      "driving"
],
    correctAnswer: "driving",
    explanation: {
      whyCorrectAr: "نستخدم driving بعد will have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_38",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكون الطاهي قد طهى عشاءً خاصاً لمدة ثلاث ساعات بحلول الساعة 6 مساءً.",
    sentenceWithBlank: "The chef will have been _______ a special dinner for three hours by 6 PM.",
    options: [
      "cook",
      "cooks",
      "cooked",
      "cooking"
],
    correctAnswer: "cooking",
    explanation: {
      whyCorrectAr: "نستخدم cooking بعد will have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_39",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكون الماء قد تقاطر من السقف لأيام قبل أن نصلحه.",
    sentenceWithBlank: "Water will have been _______ from the roof for days before we fix it.",
    options: [
      "drip",
      "drips",
      "dripped",
      "dripping"
],
    correctAnswer: "dripping",
    explanation: {
      whyCorrectAr: "نستخدم dripping بعد will have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_40",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكون أصدقائي قد ساعدوني في عملي لمدة عام بحلول شهر يونيو.",
    sentenceWithBlank: "My friends will have been _______ me with my business for a year by June.",
    options: [
      "help",
      "helps",
      "helped",
      "helping"
],
    correctAnswer: "helping",
    explanation: {
      whyCorrectAr: "نستخدم helping بعد will have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_41",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سأكون قد قرأت هذا الكتاب لساعات بحلول وقت وصولك.",
    sentenceWithBlank: "I _______ have been reading this book for hours by the time you arrive.",
    options: [
      "will",
      "won't has",
      "am",
      "had"
],
    correctAnswer: "will",
    explanation: {
      whyCorrectAr: "نستخدم will قبل have been + V-ing في زمن المستقبل التام المستمر.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_42",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون قد نظفت المنزل منذ الصباح بحلول وقت زيارتنا.",
    sentenceWithBlank: "She _______ have been cleaning the house since morning by the time we visit.",
    options: [
      "will has",
      "will",
      "is",
      "had"
],
    correctAnswer: "will",
    explanation: {
      whyCorrectAr: "نستخدم will مع الفاعل she في المستقبل التام المستمر.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_43",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكونون قد تدربوا بجد من أجل الحفلة بحلول الأسبوع القادم.",
    sentenceWithBlank: "They _______ have been practicing hard for the concert by next week.",
    options: [
      "will has",
      "will",
      "are",
      "had"
],
    correctAnswer: "will",
    explanation: {
      whyCorrectAr: "نستخدم will مع they قبل have been practicing.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_44",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكون قد أصلح سيارته لساعات بحلول ظهر الغد.",
    sentenceWithBlank: "He _______ have been fixing his car for hours by tomorrow noon.",
    options: [
      "will has",
      "will",
      "is",
      "had"
],
    correctAnswer: "will",
    explanation: {
      whyCorrectAr: "نستخدم will قبل have been fixing.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_45",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سنكون قد ناقشنا هذه المسألة لأيام بحلول الاجتماع.",
    sentenceWithBlank: "We _______ have been discussing this issue for days by the meeting.",
    options: [
      "will has",
      "will",
      "are",
      "had"
],
    correctAnswer: "will",
    explanation: {
      whyCorrectAr: "نستخدم will قبل have been discussing.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_46",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون قد عملت بجدية بالغة مؤخراً بحلول الوقت الذي تأخذ فيه استراحة.",
    sentenceWithBlank: "You _______ have been working too hard lately by the time you take a break.",
    options: [
      "will has",
      "will",
      "are",
      "had"
],
    correctAnswer: "will",
    explanation: {
      whyCorrectAr: "نستخدم will قبل have been working.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_47",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون السماء قد أثلجت بغزارة لساعات بحلول صباح الغد.",
    sentenceWithBlank: "It _______ have been snowing heavily for hours by tomorrow morning.",
    options: [
      "will has",
      "will",
      "is",
      "had"
],
    correctAnswer: "will",
    explanation: {
      whyCorrectAr: "نستخدم will قبل have been snowing.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_48",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سيكون الرضيع قد بكى لمدة عشرين دقيقة بحلول الوقت الذي تطعمه فيه أمه.",
    sentenceWithBlank: "The baby _______ have been crying for twenty minutes by the time his mother feeds him.",
    options: [
      "will has",
      "will",
      "is",
      "had"
],
    correctAnswer: "will",
    explanation: {
      whyCorrectAr: "نستخدم will قبل have been crying.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_49",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سأكون قد تعلمت السباحة لمدة شهر بحلول الأسبوع القادم.",
    sentenceWithBlank: "I _______ have been learning how to swim for a month by next week.",
    options: [
      "will has",
      "will",
      "am",
      "had"
],
    correctAnswer: "will",
    explanation: {
      whyCorrectAr: "نستخدم will قبل have been learning.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_easy_50",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "ستكون قد درّست اللغة الإنجليزية لمدة عشر سنوات بحلول شهر يونيو القادم.",
    sentenceWithBlank: "She _______ have been teaching English for ten years by next June.",
    options: [
      "will has",
      "will",
      "is",
      "had"
],
    correctAnswer: "will",
    explanation: {
      whyCorrectAr: "نستخدم will قبل have been teaching.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  }
];
