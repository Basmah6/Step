import { QuizQuestion } from '../types';

export const FUTURE_PERFECT_MEDIUM_50: QuizQuestion[] = [
  {
    id: "fp_medium_1",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "بحلول الوقت الذي تصل فيه غداً، سأكون قد أنهيت عملي.",
    sentenceWithBlank: "By the time you arrive tomorrow, I _______ finished my work.",
    options: [
      "will has",
      "will have",
      "am have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "مع العبارة الزمنية By the time + مضارع بسيط، نستخدم المستقبل التام (will have + V3) في الجملة الرئيسية.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_2",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "ستكون قد نظفت المطبخ بحلول وقت وصول الضيوف.",
    sentenceWithBlank: "She _______ cleaned the kitchen by the time the guests arrive.",
    options: [
      "will has",
      "will have",
      "is have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have cleaned للتعبير عن حدث يكتمل قبل وصول الضيوف في المستقبل.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_3",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "هل سيكونون قد أنهوا مشروعهم بحلول يوم الإثنين القادم؟",
    sentenceWithBlank: "Will they have finished their project _______ next Monday?",
    options: [
      "already",
      "just",
      "ever",
      "by"
],
    correctAnswer: "by",
    explanation: {
      whyCorrectAr: "حرف الجر by هو العلامة الأساسية للمستقبل التام ويعني (بحلول / قبل موعد محدد).",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_4",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سأكون قد أنهيت اختباري للتو بحلول الساعة 10 صباحاً.",
    sentenceWithBlank: "I will have _______ finished my test by 10 AM.",
    options: [
      "yet",
      "ever",
      "just",
      "since"
],
    correctAnswer: "just",
    explanation: {
      whyCorrectAr: "نستخدم الظرف just بين will have والتصريف الثالث للتعبير عن اكتمال الحدث للتو.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_5",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "كم المدة التي ستكون قد عشتها في هذه المدينة بحلول العام القادم؟",
    sentenceWithBlank: "How long will you _______ lived in this town by next year?",
    options: [
      "has",
      "have",
      "are",
      "do"
],
    correctAnswer: "have",
    explanation: {
      whyCorrectAr: "بعد will والفاعل you يأتي المصدر have في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_6",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سيكون والدي قد عمل في هذه الشركة لمدة 10 سنوات بحلول الشهر القادم.",
    sentenceWithBlank: "My father will have worked in this company _______ 10 years by next month.",
    options: [
      "for",
      "since",
      "yet",
      "already"
],
    correctAnswer: "for",
    explanation: {
      whyCorrectAr: "نستخدم حرف الجر for للدلالة على طول المدة الزمنية المستغرقة (10 years).",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_7",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سنكون قد عشنا في لندن لمدة عشر سنوات بحلول الصيف القادم.",
    sentenceWithBlank: "We will have lived in London _______ ten years by next summer.",
    options: [
      "for",
      "since",
      "yet",
      "just"
],
    correctAnswer: "for",
    explanation: {
      whyCorrectAr: "نستخدم for مع المدة المحددة (ten years) في زمن المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_8",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "هل ستكون قد سافرت خارج بلدك بحلول الوقت الذي تبلغ فيه الثلاثين؟",
    sentenceWithBlank: "_______ you have traveled outside your country by the time you turn 30?",
    options: [
      "Has",
      "Will",
      "Are",
      "Do"
],
    correctAnswer: "Will",
    explanation: {
      whyCorrectAr: "يبدأ السؤال في المستقبل التام بالفعل المساعد Will متبوعاً بالفاعل ثم have + V3.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_9",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سيكون قد فقد محفظته إذا لم يكن حذراً بحلول الغد.",
    sentenceWithBlank: "He _______ lost his wallet if he is not careful by tomorrow.",
    options: [
      "will has",
      "will have",
      "is have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have + lost للتعبير عن نتيجة مستقبلية متوقعة الاكتمال بحلول الغد.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_10",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سيكون الطقس شديد البرودة بحلول الأسبوع القادم.",
    sentenceWithBlank: "The weather will have been very cold _______ next week.",
    options: [
      "for",
      "by",
      "already",
      "yet"
],
    correctAnswer: "by",
    explanation: {
      whyCorrectAr: "نستخدم by لتحديد النقطة الزمنية المستقبلية في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_11",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لن تكون قد ردت على رسائلي الإلكترونية بحلول الغد.",
    sentenceWithBlank: "She _______ answered my emails by tomorrow.",
    options: [
      "will has",
      "won't have",
      "is have",
      "had"
],
    correctAnswer: "won't have",
    explanation: {
      whyCorrectAr: "صيغة النفي في المستقبل التام هي won't have + answered.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_12",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سنكون قد عرفنا بعضنا البعض لمدة عشر سنوات بحلول الشهر القادم.",
    sentenceWithBlank: "We _______ known each other for ten years by next month.",
    options: [
      "will has",
      "will have",
      "are have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have known للتعبير عن مدة المعرفة المكتملة بحلول الشهر القادم.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_13",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "هل سيكون ساعي البريد قد وصل بحلول ظهر الغد؟",
    sentenceWithBlank: "Will the mailman _______ arrived by noon tomorrow?",
    options: [
      "be",
      "have",
      "has",
      "had"
],
    correctAnswer: "have",
    explanation: {
      whyCorrectAr: "بعد Will والفاعل the mailman يأتي have في المصدر دائماً.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_14",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لن أكون قد رأيت مثل هذا الغروب قط قبل أن تنتهي رحلتي.",
    sentenceWithBlank: "I will have _______ seen such a sunset before my trip ends.",
    options: [
      "ever",
      "already",
      "never",
      "yet"
],
    correctAnswer: "never",
    explanation: {
      whyCorrectAr: "نستخدم never لنفي التجربة داخل سياق المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_15",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سيكونون قد زاروا باريس ثلاث مرات بحلول العام القادم.",
    sentenceWithBlank: "They will have visited Paris three _______ by next year.",
    options: [
      "time",
      "times",
      "timing",
      "timed"
],
    correctAnswer: "times",
    explanation: {
      whyCorrectAr: "نستخدم times للدلالة على عدد مرات تكرار الفعل (three times).",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_16",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لماذا ستكون قد غادرت مبكراً بحلول ذلك الوقت؟",
    sentenceWithBlank: "Why _______ you have left early by then?",
    options: [
      "will has",
      "will",
      "are",
      "do"
],
    correctAnswer: "will",
    explanation: {
      whyCorrectAr: "نستخدم will بعد أداة الاستفهام وقبل الفاعل you في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_17",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سيكون سعر الوقود قد ارتفع مرتين بحلول الشهر القادم.",
    sentenceWithBlank: "The price of fuel _______ increased twice by next month.",
    options: [
      "will has",
      "will have",
      "is have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have increased للتعبير عن زيادة مكتملة بحلول الشهر القادم.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_18",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سيكون جميع أصدقائي قد هنأوني بحلول وقت التخرج.",
    sentenceWithBlank: "All my friends _______ congratulated me by the time of the graduation.",
    options: [
      "will has",
      "will have",
      "are have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have congratulated مع الفاعل الجمع.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_19",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لا أحد من الولدين سيكون قد أنجز واجبه بحلول الغد.",
    sentenceWithBlank: "Neither of the boys _______ done his homework by tomorrow.",
    options: [
      "will has",
      "will have",
      "are have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "التركيب مع Neither يأخذ will have done في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_20",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سيكون كل واحد من المشاركين قد استلم شهادة بحلول نهاية اليوم.",
    sentenceWithBlank: "Each of the participants _______ received a certificate by the end of the day.",
    options: [
      "will has",
      "will have",
      "are have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have received مع الفاعل المسبوق بـ Each.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_21",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "ماذا ستكون قد حققت في مسيرتك بحلول الوقت الذي تبلغ فيه الأربعين؟",
    sentenceWithBlank: "What _______ you achieved in your career by the time you turn 40?",
    options: [
      "will has",
      "will have",
      "are have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have مع you للتعبير عن الإنجاز المكتمل في المستقبل.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_22",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "أين ستكون قد أخفت المفاتيح بحلول الغد؟",
    sentenceWithBlank: "Where _______ she hidden the keys by tomorrow?",
    options: [
      "will has",
      "will have",
      "is have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "صيغة السؤال في المستقبل التام تستخدم will have hidden.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_23",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "من سيكون قد أخذ قلمي بحلول نهاية الحصة؟",
    sentenceWithBlank: "Who _______ taken my pen by the end of the class?",
    options: [
      "will has",
      "will have",
      "is have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have taken للسؤال عن الفاعل في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_24",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "ما هي الدول التي ستكون قد زرتها بحلول نهاية جولتك؟",
    sentenceWithBlank: "Which countries _______ you visited by the end of your tour?",
    options: [
      "will has",
      "will have",
      "are have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have visited للسؤال عن الزيارات المكتملة بحلول نهاية الجولة.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_25",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "كم فصلاً سيكون قد قرأ بحلول ليلة الغد؟",
    sentenceWithBlank: "How many chapters _______ he read by tomorrow night?",
    options: [
      "will has",
      "will have",
      "is have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have read للسؤال عن المقدار المنجز في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_26",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لماذا ستكون الشركة قد ألغت الاجتماع بحلول الغد؟",
    sentenceWithBlank: "Why _______ the company canceled the meeting by tomorrow?",
    options: [
      "will has",
      "will have",
      "is have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have canceled للتعبير عن قرار ملغى بحلول الغد.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_27",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "كم المدة التي ستكون قد عملت فيها كممرضة بحلول العام القادم؟",
    sentenceWithBlank: "How long _______ she worked as a nurse by next year?",
    options: [
      "will has",
      "will have",
      "is have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have worked للسؤال عن مدة العمل حتى العام القادم.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_28",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "ما التغييرات التي ستكون قد حدثت في المدينة بحلول عام 2030؟",
    sentenceWithBlank: "What changes _______ taken place in the city by 2030?",
    options: [
      "will has",
      "will have",
      "is have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have taken place للتعبير عن التغييرات المكتملة بحلول عام 2030.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_29",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "من ستكون قد قابلت بحلول نهاية المؤتمر؟",
    sentenceWithBlank: "Who _______ you met by the end of the conference?",
    options: [
      "will has",
      "will have",
      "are have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have met للسؤال عن الأشخاص الذين تمت مقابلتهم بحلول نهاية المؤتمر.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_30",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "كم من المال ستكون قد أنفقت بحلول نهاية الرحلة؟",
    sentenceWithBlank: "How much money _______ you spent by the end of the trip?",
    options: [
      "will has",
      "will have",
      "are have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have spent للسؤال عن المقدار المنفق في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_31",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سأكون قد أرسلت التقرير للمدير بالفعل بحلول الظهيرة.",
    sentenceWithBlank: "I will have already _______ the report to the manager by noon.",
    options: [
      "send",
      "sends",
      "sending",
      "sent"
],
    correctAnswer: "sent",
    explanation: {
      whyCorrectAr: "التصريف الثالث للفعل send هو sent بعد will have.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_32",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "ستكون قد شربت ثلاثة أكواب من القهوة بحلول الساعة 10 صباحاً.",
    sentenceWithBlank: "She will have _______ three cups of coffee by 10 AM.",
    options: [
      "drink",
      "drinks",
      "drinking",
      "drunk"
],
    correctAnswer: "drunk",
    explanation: {
      whyCorrectAr: "التصريف الثالث للفعل drink هو drunk بعد will have.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_33",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سيكونون قد وقعوا عقداً جديداً بحلول بعد ظهر الغد.",
    sentenceWithBlank: "They will have _______ a new contract by tomorrow afternoon.",
    options: [
      "sign",
      "signs",
      "signing",
      "signed"
],
    correctAnswer: "signed",
    explanation: {
      whyCorrectAr: "التصريف الثالث للفعل sign هو signed.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_34",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سيكون قد خضع لاختباره بحلول الغد.",
    sentenceWithBlank: "He will have _______ his test by tomorrow.",
    options: [
      "take",
      "taken",
      "taking",
      "takes"
],
    correctAnswer: "taken",
    explanation: {
      whyCorrectAr: "التصريف الثالث للفعل take هو taken بعد will have.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_35",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سنكون قد أتممنا جميع الاستعدادات بحلول وقت وصول الضيوف.",
    sentenceWithBlank: "We will have _______ all the preparations by the time guests arrive.",
    options: [
      "complete",
      "completes",
      "completing",
      "completed"
],
    correctAnswer: "completed",
    explanation: {
      whyCorrectAr: "نستخدم completed (التصريف الثالث) بعد will have.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_36",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سيكون النهر قد فاض عن ضفافه بحلول الغد إذا استمر المطر.",
    sentenceWithBlank: "The river will have _______ over its banks by tomorrow if it keeps raining.",
    options: [
      "rise",
      "rises",
      "rising",
      "risen"
],
    correctAnswer: "risen",
    explanation: {
      whyCorrectAr: "التصريف الثالث للفعل اللازم rise هو risen بعد will have.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_37",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "ستكون قد ارتكبت خطأ فادحاً بوثوقك به.",
    sentenceWithBlank: "You will have _______ a huge mistake by trusting him.",
    options: [
      "make",
      "makes",
      "making",
      "made"
],
    correctAnswer: "made",
    explanation: {
      whyCorrectAr: "التصريف الثالث للفعل make هو made.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_38",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "ستكون الشمس قد توارت خلف الجبال بحلول الغروب.",
    sentenceWithBlank: "The sun will have _______ behind the mountains by sunset.",
    options: [
      "go",
      "goes",
      "going",
      "gone"
],
    correctAnswer: "gone",
    explanation: {
      whyCorrectAr: "التصريف الثالث للفعل go هو gone.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_39",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "ستكون قد تركت هاتفها في المنزل بحلول وقت وصولها إلى العمل.",
    sentenceWithBlank: "She will have _______ her phone at home by the time she reaches work.",
    options: [
      "leave",
      "leaves",
      "leaving",
      "left"
],
    correctAnswer: "left",
    explanation: {
      whyCorrectAr: "التصريف الثالث للفعل leave هو left بعد will have.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_40",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سيكون أخي قد وجد وظيفة جديدة بحلول الشهر القادم.",
    sentenceWithBlank: "My brother will have _______ a new job by next month.",
    options: [
      "find",
      "finds",
      "finding",
      "found"
],
    correctAnswer: "found",
    explanation: {
      whyCorrectAr: "التصريف الثالث للفعل find هو found.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_41",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لن أكون قد رأيته بحلول يوم الإثنين القادم.",
    sentenceWithBlank: "I will not have seen him _______ next Monday.",
    options: [
      "for",
      "by",
      "since",
      "yet"
],
    correctAnswer: "by",
    explanation: {
      whyCorrectAr: "نستخدم by لتحديد الموعد النهائي في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_42",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "ستكون قد عاشت في القاهرة لمدة خمس سنوات بحلول العام القادم.",
    sentenceWithBlank: "She will have lived in Cairo _______ five years by next year.",
    options: [
      "for",
      "since",
      "already",
      "yet"
],
    correctAnswer: "for",
    explanation: {
      whyCorrectAr: "نستخدم for للتعبير عن مدة زمنية (five years).",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_43",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "هل ستكون قد انتهيت بحلول ظهر الغد؟",
    sentenceWithBlank: "Will you have finished _______ tomorrow noon?",
    options: [
      "already",
      "just",
      "ever",
      "by"
],
    correctAnswer: "by",
    explanation: {
      whyCorrectAr: "نستخدم by قبل الموعد الزمني (tomorrow noon) في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_44",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لن أكون قد ذهبت إلى اليابان قط بحلول ذلك الوقت.",
    sentenceWithBlank: "I will have _______ been to Japan by then.",
    options: [
      "ever",
      "already",
      "never",
      "yet"
],
    correctAnswer: "never",
    explanation: {
      whyCorrectAr: "نستخدم never لنفي التجربة في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_45",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سيكون قد عاد لتوه من رحلته بحلول الغد.",
    sentenceWithBlank: "He will have _______ returned from his trip by tomorrow.",
    options: [
      "yet",
      "ever",
      "just",
      "since"
],
    correctAnswer: "just",
    explanation: {
      whyCorrectAr: "الظرف just يوضع بين will have والتصريف الثالث للتعبير عن حداثة الفعل.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_46",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سنكون قد علمنا بالأمر لفترة طويلة بحلول الأسبوع القادم.",
    sentenceWithBlank: "We will have known about the issue _______ a long time by next week.",
    options: [
      "for",
      "since",
      "yet",
      "already"
],
    correctAnswer: "for",
    explanation: {
      whyCorrectAr: "نستخدم for مع العبارة الزمنية a long time.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_47",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "هل ستكون قد عملت في شركة متعددة الجنسيات بحلول العام القادم؟",
    sentenceWithBlank: "Will she _______ worked in a multinational company by next year?",
    options: [
      "will",
      "have",
      "has",
      "had"
],
    correctAnswer: "have",
    explanation: {
      whyCorrectAr: "بعد Will والفاعل she نستخدم have دائماً كمصدر مساعد.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_48",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سأكون قد قرأت ذلك الكتاب مرتين بالفعل بحلول ليلة الغد.",
    sentenceWithBlank: "I will have _______ read that book twice by tomorrow night.",
    options: [
      "ever",
      "already",
      "yet",
      "since"
],
    correctAnswer: "already",
    explanation: {
      whyCorrectAr: "نستخدم already للتأكيد على اكتمال الإنجاز مسبقاً قبل الموعد.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_49",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لن يكونوا قد حدثوا موقعهم لعدة أشهر بحلول وقت التدقيق.",
    sentenceWithBlank: "They will not have updated their website _______ months by the time of audit.",
    options: [
      "for",
      "since",
      "yet",
      "already"
],
    correctAnswer: "for",
    explanation: {
      whyCorrectAr: "نستخدم for مع المدة الزمنية months.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_medium_50",
    tenseId: "future_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سيكون الحاسوب قد تعطل ثلاث مرات بحلول صباح الغد.",
    sentenceWithBlank: "The computer will have crashed three times _______ tomorrow morning.",
    options: [
      "for",
      "by",
      "yet",
      "already"
],
    correctAnswer: "by",
    explanation: {
      whyCorrectAr: "نستخدم by مع الوقت المحدد (tomorrow morning) في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  }
];
