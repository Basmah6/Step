import { QuizQuestion } from '../types';

export const FUTURE_CONTINUOUS_MEDIUM_50: QuizQuestion[] = [
  {
    "id": "fc_medium_1",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "في مثل هذا الوقت غداً، سأكون أدرس لامتحاني.",
    "sentenceWithBlank": "This time tomorrow, I _______ studying for my exam.",
    "options": [
      "will be",
      "will",
      "am",
      "do"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "المستقبل المستمر يتطلب will be متبوعة بـ studying للتعبير عن وقت محدد في المستقبل.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_2",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "ماذا ستكون تفعل عندما أتصل بك الليلة؟",
    "sentenceWithBlank": "What _______ you be doing when I call you tonight?",
    "options": [
      "will",
      "are",
      "do",
      "did"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "في السؤال عن المستقبل المستمر، يأتي will قبل الفاعل you وقبل be doing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_3",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "ستكون تقرأ كتاباً بينما يتجاذب أصدقاؤها أطراف الحديث.",
    "sentenceWithBlank": "She _______ reading a book while her friends are chatting.",
    "options": [
      "will be",
      "will",
      "is",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be للتعبير عن حدث مستمر في المستقبل بالتزامن مع نشاط آخر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_4",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "عندما تدخل الغرفة غداً، سيكون الجميع يعملون بصمت.",
    "sentenceWithBlank": "When you enter the room tomorrow, everyone _______ working silently.",
    "options": [
      "will be",
      "will",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "في جملة جواب الرابط الزمني when في المستقبل، نستخدم المستقبل المستمر will be working.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_5",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "في الساعة 5 مساءً، سيكونون يمشون في الحديقة.",
    "sentenceWithBlank": "At 5 PM, they _______ walking in the park.",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "تحديد وقت زمني (At 5 PM) في المستقبل يتطلب will be + V-ing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_6",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "سيكون والداي يشاهدان التلفاز عندما يصل الضيوف.",
    "sentenceWithBlank": "My parents _______ be watching television when the guests arrive.",
    "options": [
      "will",
      "are",
      "do",
      "did"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "الفعل المساعد الناقص قبل be watching هو will.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_7",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لماذا ستكون تبكي عندما أراك غداً؟",
    "sentenceWithBlank": "Why _______ you be crying when I see you tomorrow?",
    "options": [
      "will",
      "are",
      "do",
      "did"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will بعد أداة الاستفهام لتكوين سؤال المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_8",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "سيرن الهاتف بينما ستكون هي تعد العشاء.",
    "sentenceWithBlank": "The phone will ring while she _______ preparing dinner.",
    "options": [
      "will be",
      "will",
      "is",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be preparing للتعبير عن حدث مستمر في المستقبل خلال حدوث فعل آخر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_9",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "عند الظهيرة غداً، سأكون أعبر الشارع.",
    "sentenceWithBlank": "At noon tomorrow, I _______ crossing the street.",
    "options": [
      "will be",
      "will",
      "am",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be crossing للتعبير عن حدث مستمر عند ظهيرة الغد.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_10",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "سيكون الأطفال يحدثون فوضى عارمة غداً.",
    "sentenceWithBlank": "The children _______ be making a huge mess tomorrow.",
    "options": [
      "will",
      "are",
      "do",
      "did"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will قبل be making للتعبير عن المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_11",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لن أكون نائماً عندما تطرق الباب.",
    "sentenceWithBlank": "I _______ not be sleeping when you knock on the door.",
    "options": [
      "will",
      "won't",
      "am not",
      "did not"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "وجود not بعد الفراغ يقتضي استخدام will (will not be sleeping).",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_12",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "هي لن تكون مستمعة بينما المعلم يشرح.",
    "sentenceWithBlank": "She _______ not be listening while the teacher is explaining.",
    "options": [
      "will",
      "won't",
      "is",
      "did"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will مع not be listening لصياغة النفي في المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_13",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لن يكونوا منتبهين أثناء المحاضرة غداً.",
    "sentenceWithBlank": "They _______ not be paying attention during the lecture tomorrow.",
    "options": [
      "will",
      "are",
      "did",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will قبل not be paying attention.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_14",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "هو لن يكون يعمل على واجبه في تلك اللحظة.",
    "sentenceWithBlank": "He _______ not be working on his assignment at that moment.",
    "options": [
      "will",
      "won't",
      "is",
      "did"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "صيغة النفي الكاملة مع وجود not هي will not be working.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_15",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لن نكون نائمين عندما يضرب الزلزال.",
    "sentenceWithBlank": "We _______ not be sleeping when the earthquake hits.",
    "options": [
      "will",
      "are",
      "did",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will قبل not be sleeping.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_16",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لن يكون الكلب ينبح عندما يدخل اللص.",
    "sentenceWithBlank": "The dog _______ not be barking when the thief enters.",
    "options": [
      "will",
      "won't",
      "is",
      "did"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will قبل not be barking.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_17",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لن تكون ترتدي سترتك عندما يتجمد الطقس.",
    "sentenceWithBlank": "You _______ not be wearing your jacket when it freezes.",
    "options": [
      "will",
      "are",
      "did",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will قبل not be wearing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_18",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "علي وأحمد لن يكونا يدرسان عندما يدخل المدير.",
    "sentenceWithBlank": "Ali and Ahmed _______ not be studying when the headmaster walks in.",
    "options": [
      "will",
      "are",
      "did",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will قبل not be studying للفاعل الجمع.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_19",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لن تكون السماء تمطر عندما نبدأ رحلتنا.",
    "sentenceWithBlank": "It _______ not be raining when we start our journey.",
    "options": [
      "will",
      "won't",
      "is",
      "did"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "صياغة النفي في المستقبل المستمر مع وجود not تتطلب will.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_20",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "أمي لن تكون تطبخ عندما يمر الزوار فجأة.",
    "sentenceWithBlank": "My mother _______ not be cooking when the visitors drop by.",
    "options": [
      "will",
      "won't",
      "is",
      "did"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will قبل not be cooking.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_21",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "هل ستكون نائماً عندما أتصل بك الليلة؟",
    "sentenceWithBlank": "Will you _______ sleeping when I call you tonight?",
    "options": [
      "will",
      "be",
      "being",
      "are"
    ],
    "correctAnswer": "be",
    "explanation": {
      "whyCorrectAr": "بعد Will والفاعل you يأتي المصدر be متبوعاً بـ sleeping.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_22",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "هل ستكون ترتدي معطفاً عندما تغادر؟",
    "sentenceWithBlank": "Will she _______ wearing a coat when she leaves?",
    "options": [
      "will",
      "be",
      "being",
      "is"
    ],
    "correctAnswer": "be",
    "explanation": {
      "whyCorrectAr": "في السؤال بالمستقبل المستمر نضع be بعد الفاعل she.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_23",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "هل سيكونون يعملون على التقرير في منتصف الليل؟",
    "sentenceWithBlank": "Will they _______ working on the report at midnight?",
    "options": [
      "will",
      "be",
      "being",
      "are"
    ],
    "correctAnswer": "be",
    "explanation": {
      "whyCorrectAr": "نستخدم be بعد الفاعل they وقبل الفعل المضاف له ing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_24",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "هل سيكون يقود بسرعة عندما يبدأ السباق؟",
    "sentenceWithBlank": "Will he _______ driving fast when the race starts?",
    "options": [
      "will",
      "be",
      "being",
      "is"
    ],
    "correctAnswer": "be",
    "explanation": {
      "whyCorrectAr": "نضع be بعد الفاعل he في السؤال.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_25",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "هل سنكون نحدث ضوضاء زائدة أثناء الاختبار؟",
    "sentenceWithBlank": "Will we _______ making too much noise during the test?",
    "options": [
      "will",
      "be",
      "being",
      "are"
    ],
    "correctAnswer": "be",
    "explanation": {
      "whyCorrectAr": "نستخدم be بعد we لتكوين المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_26",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "ماذا ستكون تطبخ عندما يصل الضيوف؟",
    "sentenceWithBlank": "What will you _______ cooking when the guests arrive?",
    "options": [
      "will",
      "be",
      "being",
      "are"
    ],
    "correctAnswer": "be",
    "explanation": {
      "whyCorrectAr": "في السؤال بأداة استفهام نضع be بعد الفاعل you.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_27",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "أين ستكون واقفة أثناء المراسم؟",
    "sentenceWithBlank": "Where will she _______ standing during the ceremony?",
    "options": [
      "be",
      "will",
      "being",
      "is"
    ],
    "correctAnswer": "be",
    "explanation": {
      "whyCorrectAr": "نستخدم be بعد الفاعل she وقبل standing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_28",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "لماذا سيكونون يتجادلون عندما أدخل الغرفة؟",
    "sentenceWithBlank": "Why will they _______ arguing when I enter the room?",
    "options": [
      "will",
      "be",
      "being",
      "are"
    ],
    "correctAnswer": "be",
    "explanation": {
      "whyCorrectAr": "نضع be بعد الفاعل they وقبل arguing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_29",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "مع من سيكون يتحدث غداً؟",
    "sentenceWithBlank": "Who will he _______ speaking to tomorrow?",
    "options": [
      "be",
      "will",
      "being",
      "is"
    ],
    "correctAnswer": "be",
    "explanation": {
      "whyCorrectAr": "نستخدم be بعد he وقبل speaking.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_30",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "كيف سيكون أداء السيارة أثناء القيادة التجريبية؟",
    "sentenceWithBlank": "How will the car _______ behaving during the test drive?",
    "options": [
      "be",
      "will",
      "being",
      "is"
    ],
    "correctAnswer": "be",
    "explanation": {
      "whyCorrectAr": "نضع be بعد الفاعل the car في المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_31",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "في الساعة 5 مساءً غداً، سأكون أبحث عن مفاتيحي.",
    "sentenceWithBlank": "At 5 PM tomorrow, I will be _______ for my keys.",
    "options": [
      "search",
      "searching",
      "searched",
      "searches"
    ],
    "correctAnswer": "searching",
    "explanation": {
      "whyCorrectAr": "بعد will be يأتي الفعل بصيغة ing (searching).",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_32",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "ستكون تقدم عرضاً تقديمياً في المؤتمر.",
    "sentenceWithBlank": "She will be _______ a presentation at the conference.",
    "options": [
      "give",
      "giving",
      "gave",
      "given"
    ],
    "correctAnswer": "giving",
    "explanation": {
      "whyCorrectAr": "بعد will be نستخدم giving.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_33",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "سيكونون يبنون سياجاً جديداً حول حديقتهم.",
    "sentenceWithBlank": "They will be _______ a new fence around their garden.",
    "options": [
      "build",
      "building",
      "built",
      "builds"
    ],
    "correctAnswer": "building",
    "explanation": {
      "whyCorrectAr": "نستخدم building بعد will be.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_34",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "سيكون جالساً في الشمس طوال فترة بعد الظهر.",
    "sentenceWithBlank": "He will be _______ in the sun all afternoon.",
    "options": [
      "sit",
      "sitting",
      "sat",
      "sits"
    ],
    "correctAnswer": "sitting",
    "explanation": {
      "whyCorrectAr": "نستخدم sitting مع مضاعفة حرف t بعد will be.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_35",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "سنكون ننتظر أصدقاءنا في المحطة.",
    "sentenceWithBlank": "We will be _______ for our friends at the station.",
    "options": [
      "wait",
      "waiting",
      "waited",
      "waits"
    ],
    "correctAnswer": "waiting",
    "explanation": {
      "whyCorrectAr": "نستخدم waiting بعد will be.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_36",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "ستكون الرياح تهب بعنف أثناء العاصفة.",
    "sentenceWithBlank": "The wind will be _______ fiercely during the storm.",
    "options": [
      "blow",
      "blowing",
      "blew",
      "blows"
    ],
    "correctAnswer": "blowing",
    "explanation": {
      "whyCorrectAr": "نستخدم blowing بعد will be.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_37",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "ستكون تحقق تقدماً كبيراً بحلول الشهر القادم.",
    "sentenceWithBlank": "You will be _______ great progress by next month.",
    "options": [
      "make",
      "making",
      "made",
      "makes"
    ],
    "correctAnswer": "making",
    "explanation": {
      "whyCorrectAr": "نستخدم making بعد will be.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_38",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "سيكون الطفل يبكي لأنه جائع.",
    "sentenceWithBlank": "The baby will be _______ because he is hungry.",
    "options": [
      "cry",
      "crying",
      "cried",
      "cries"
    ],
    "correctAnswer": "crying",
    "explanation": {
      "whyCorrectAr": "نستخدم crying بعد will be.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_39",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "ستكون تساعد والدتها في المطبخ.",
    "sentenceWithBlank": "She will be _______ her mother in the kitchen.",
    "options": [
      "help",
      "helping",
      "helped",
      "helps"
    ],
    "correctAnswer": "helping",
    "explanation": {
      "whyCorrectAr": "نستخدم helping بعد will be.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_40",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "سيكون أصدقائي يساعدونني في الانتقال غداً.",
    "sentenceWithBlank": "My friends will be _______ me move tomorrow.",
    "options": [
      "help",
      "helping",
      "helped",
      "helps"
    ],
    "correctAnswer": "helping",
    "explanation": {
      "whyCorrectAr": "نستخدم helping بعد will be.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_41",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "في مثل هذا الوقت غداً، بينما أكون أمشي، سيبدأ المطر بالهطول.",
    "sentenceWithBlank": "At this time tomorrow, while I am walking, it _______ be starting to rain.",
    "options": [
      "will",
      "is",
      "did",
      "does"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will قبل be starting للتعبير عن المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_42",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "في الساعة 6 مساءً، بينما هي تطبخ، سيكون الهاتف يرن.",
    "sentenceWithBlank": "At 6 PM, while she is cooking, the phone _______ be ringing.",
    "options": [
      "will",
      "is",
      "did",
      "does"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will قبل be ringing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_43",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "بينما هم يلعبون، ستكون الرياح تهب.",
    "sentenceWithBlank": "While they are playing, the wind _______ be blowing.",
    "options": [
      "will",
      "is",
      "did",
      "does"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will قبل be blowing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_44",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "بينما هو على الطريق، سيكون يقود بحذر.",
    "sentenceWithBlank": "While he is on the road, he _______ be driving carefully.",
    "options": [
      "will",
      "is",
      "did",
      "does"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will قبل be driving.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_45",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "بينما نحن نتحدث، ستكون الأضواء تنطفئ.",
    "sentenceWithBlank": "While we are talking, the lights _______ be going out.",
    "options": [
      "will",
      "is",
      "did",
      "does"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will قبل be going out.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_46",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "سيرن الهاتف بينما أكون نائماً.",
    "sentenceWithBlank": "The phone will ring while I _______ sleeping.",
    "options": [
      "am",
      "will be",
      "was",
      "did"
    ],
    "correctAnswer": "am",
    "explanation": {
      "whyCorrectAr": "بعد رابط الزمن while نستخدم جملة مضارع مستمر (am sleeping) للإشارة إلى الحاضر المتزامن مع المستقبل.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_47",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "ستسقط طبقها بينما هي تحمله.",
    "sentenceWithBlank": "She will drop her plate while she _______ carrying it.",
    "options": [
      "am",
      "is",
      "was",
      "did"
    ],
    "correctAnswer": "is",
    "explanation": {
      "whyCorrectAr": "بعد while نستخدم مضارعاً مستمراً (is carrying) مع الفاعل المفرد she.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_48",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "سيسمعون صوتاً عالياً بينما هم نائمون.",
    "sentenceWithBlank": "They will hear a loud noise while they _______ sleeping.",
    "options": [
      "am",
      "are",
      "were",
      "did"
    ],
    "correctAnswer": "are",
    "explanation": {
      "whyCorrectAr": "بعد while نستخدم are sleeping مع الفاعل الجمع they.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_49",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "سيفقد محفظته بينما هو يتسوق.",
    "sentenceWithBlank": "He will lose his wallet while he _______ shopping.",
    "options": [
      "am",
      "is",
      "was",
      "did"
    ],
    "correctAnswer": "is",
    "explanation": {
      "whyCorrectAr": "بعد while نستخدم is shopping مع الفاعل المفرد he.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_medium_50",
    "tenseId": "future_continuous",
    "difficulty": "medium",
    "type": "multiple_choice",
    "promptAr": "سنلتقي بهم بينما نحن مسافرون إلى الخارج.",
    "sentenceWithBlank": "We will meet them while we _______ traveling abroad.",
    "options": [
      "am",
      "are",
      "were",
      "did"
    ],
    "correctAnswer": "are",
    "explanation": {
      "whyCorrectAr": "بعد while نستخدم are traveling مع الفاعل we.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  }
];
