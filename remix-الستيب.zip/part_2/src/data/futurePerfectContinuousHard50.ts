import { QuizQuestion } from '../types';

export const FUTURE_PERFECT_CONTINUOUS_HARD_50: QuizQuestion[] = [
  {
    id: "fpc_hard_1",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "بحلول الشهر القادم، سأكون قد بحثت عن مفاتيحي لأكثر من ساعة.",
    sentenceWithBlank: "By next month, I _______ looking for my keys for over an hour.",
    options: [
      "will has been",
      "will have been",
      "am being",
      "had been"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "مع استمرار الحدث في المستقبل حتى نقطة زمنية معينة، نستخدم المستقبل التام المستمر (will have been looking).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_2",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون قد درست طوال الليل بحلول الوقت الذي تخوض فيه امتحانات البورد الطبي غداً.",
    sentenceWithBlank: "She _______ studying all night by the time she takes her medical board exams tomorrow.",
    options: [
      "will has been",
      "will have been",
      "is being",
      "had been"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "الفاعل المفرد (she) يتبعه (will have been studying) للتعبير عن الاستمرار حتى موعد الامتحان.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_3",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "لا أحد من الفنيين سيكون قد عمل على النظام لساعات بحلول الغد.",
    sentenceWithBlank: "Neither of the technicians _______ working on the system for hours by tomorrow.",
    options: [
      "will have",
      "will have been",
      "are being",
      "had"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "التركيب مع Neither يأخذ will have been working في زمن المستقبل التام المستمر.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_4",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون عدد السياح الذين يزورون البلاد قد استمر في التزايد بثبات بحلول العام القادم.",
    sentenceWithBlank: "The number of tourists visiting the country _______ increasing steadily by next year.",
    options: [
      "will have been",
      "will have",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "عبارة (The number of) تعبر عن رقم إحصائي وتأخذ فعلاً مفرداً (will have been increasing).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_5",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون عدد من العمال قد أضربوا طلباً لأجور أفضل لعدة أيام بحلول الأسبوع القادم.",
    sentenceWithBlank: "A number of workers _______ striking for better wages for days by next week.",
    options: [
      "will have",
      "will have been",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "عبارة (A number of) تعني 'العديد من' وتأخذ الفعل المساعد (will have been striking).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_6",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون الرياضيات قد شكلت تحدياً للباحثين لقرون بحلول العصر القادم.",
    sentenceWithBlank: "Mathematics _______ challenging researchers for centuries by the next era.",
    options: [
      "will have",
      "will have been",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "اسم المادة العلمية (Mathematics) مفرد ويأخذ (will have been challenging).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_7",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون خمسون دولاراً قد تراكمت في الحساب لمدة شهر بحلول الغد.",
    sentenceWithBlank: "Fifty dollars _______ accumulating in the account for a month by tomorrow.",
    options: [
      "will have",
      "will have been",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "المبالغ المالية كوحدة واحدة تُعامل معاملة المفرد وتأخذ (will have been accumulating).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_8",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون كل واحد من المشاركين قد قدم ملاحظاته لساعات بحلول وقت انتهاء الندوة.",
    sentenceWithBlank: "Each of the participants _______ giving feedback for hours by the time the seminar ends.",
    options: [
      "will have",
      "will have been",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "الكلمة الأساسية هي (Each) وتأخذ (will have been giving).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_9",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون أكثر من شخص واحد قد اشتكى من الضوضاء لساعات بحلول الغد.",
    sentenceWithBlank: "More than one person _______ complaining about the noise for hours by tomorrow.",
    options: [
      "will have",
      "will have been",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "التركيب (More than one + اسم مفرد) يأخذ (will have been complaining).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_10",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون الفيزياء قد تقدمت بسرعة لعقود بحلول القرن القادم.",
    sentenceWithBlank: "Physics _______ advancing rapidly for decades by next century.",
    options: [
      "will have",
      "will have been",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "أسماء العلوم المنتهية بـ s مثل (Physics) مفردة وتأخذ (will have been advancing).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_11",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون الخبز والزبدة قد أشبعنا لساعات بحلول وقت تقديم الغداء غداً.",
    sentenceWithBlank: "Bread and butter _______ keeping us full for hours by the time lunch is served tomorrow.",
    options: [
      "will have",
      "will have been",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "الوجبة الواحدة المشتركة تعامل كوحدة مفردة (will have been keeping).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_12",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون الشرطة قد حققت في القضية لمدة أسبوع بحلول الغد.",
    sentenceWithBlank: "The police _______ investigating the case for a week by tomorrow.",
    options: [
      "will have",
      "will have been",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "كلمة (Police) تُعامل معاملة الجمع دائماً وتأخذ (will have been investigating).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_13",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون عائلتي قد عاشت في ذلك الحي لأجيال بحلول العام القادم.",
    sentenceWithBlank: "My family _______ living in that neighborhood for generations by next year.",
    options: [
      "will have been",
      "will have",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "اسم الجمع الدال على العائلة كوحدة مستمرة في المستقبل التام المستمر يأخذ (will have been living).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_14",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون اللجنة قد راجعت المقترح لأيام بحلول وقت موافقتها عليه الأسبوع القادم.",
    sentenceWithBlank: "The committee _______ reviewing the proposal for days by the time they approve it next week.",
    options: [
      "will have been",
      "will have",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "اللجنة كوحدة عمل واحدة تأخذ (will have been reviewing).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_15",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "لا المعلم ولا الطلاب سيكونون قد انتبهوا لمدة ساعة بحلول رنين الجرس.",
    sentenceWithBlank: "Neither the teacher nor the students _______ paying attention for an hour by the bell.",
    options: [
      "will have",
      "will have been",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "في تركيب (Neither... nor)، يتبع الفعل الفاعل الأقرب (will have been paying).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_16",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "لا الطلاب ولا المعلم سيكون قد انتبه لمدة ساعة بحلول رنين الجرس.",
    sentenceWithBlank: "Neither the students nor the teacher _______ paying attention for an hour by the bell.",
    options: [
      "will have been",
      "will have",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "صيغة المستقبل التام المستمر لجميع حالات الفاعل هي (will have been + V-ing).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_17",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "نادراً ما سيكون أي شخص قد عمل بجد مثله لسنوات بحلول وقت ترقيته.",
    sentenceWithBlank: "Rarely _______ working as hard as him for years by the time he gets promoted.",
    options: [
      "will have anyone been",
      "will anyone have been",
      "have anyone will been",
      "anyone will have been"
],
    correctAnswer: "will anyone have been",
    explanation: {
      whyCorrectAr: "عند البدء بظرف نفي (Rarely)، يقلب الفعل المساعد والفاعل في المستقبل (Rarely will anyone have been working).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_18",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "لن أكون قد شعرت بمثل هذه الطاقة قط بحلول وقت إنهائي هذا الروتين.",
    sentenceWithBlank: "Never _______ feeling so energetic by the time I finish this routine.",
    options: [
      "will have I been",
      "will I have been",
      "have I will been",
      "I will have been"
],
    correctAnswer: "will I have been",
    explanation: {
      whyCorrectAr: "تقديم ظرف النفي (Never) يولد قلباً نحوياً (Inversion): will I have been feeling.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_19",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "مؤخراً فقط ستكون قد أخذت دروساً في الرسم لشهور بحلول موعد المسابقة.",
    sentenceWithBlank: "Only recently _______ taking painting lessons for months by the contest date.",
    options: [
      "will have she been",
      "will she have been",
      "have she will been",
      "she will have been"
],
    correctAnswer: "will she have been",
    explanation: {
      whyCorrectAr: "تقديم الظرف (Only recently) يتطلب قلباً نحوياً: will she have been taking.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_20",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "قليلاً ما سيكون قد اهتم بالعواقب بحلول وقت مواجهته للكارثة.",
    sentenceWithBlank: "Little _______ caring about the consequences by the time he faces disaster.",
    options: [
      "will have he been",
      "will he have been",
      "have he will been",
      "he will have been"
],
    correctAnswer: "will he have been",
    explanation: {
      whyCorrectAr: "البدء بـ (Little) النافية يولد قلباً نحوياً: will he have been caring.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_21",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون هذه المرة الثانية التي سيكون قد تصرف فيها بغرابة بحلول الغد.",
    sentenceWithBlank: "It will be the second time he _______ acting strangely by tomorrow.",
    options: [
      "will have",
      "will have been",
      "has been",
      "had been"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "التركيب (It will be the second time) يتبعه مستقبل تام مستمر (will have been acting).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_22",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سأكون قد عملت على ذلك المشروع لشهور بحلول وقت الانتهاء منه الأسبوع القادم.",
    sentenceWithBlank: "I _______ working on that project for months by the time it is finalized next week.",
    options: [
      "will have",
      "will have been",
      "am",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "مع الضمير I، نستخدم (will have been working) للدلالة على الاستمرار حتى موعد الإنجاز.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_23",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون المقص قد ظل ملقى على المكتب لأيام بحلول وقت رفعه غداً.",
    sentenceWithBlank: "The scissors _______ lying on the desk for days by the time I pick them up tomorrow.",
    options: [
      "will have",
      "will have been",
      "have",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "الأدوات المكونة من جزأين (scissors) جمع وتأخذ (will have been lying).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_24",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون بنطالي قد اهترأ سريعاً بحلول الشهر القادم.",
    sentenceWithBlank: "My trousers _______ wearing out quickly by next month.",
    options: [
      "will have",
      "will have been",
      "have",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "كلمة (trousers) جمع دائماً وتأخذ (will have been wearing out).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_25",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون الحصبة قد انتشرت في جميع أنحاء المنطقة لأسابيع بحلول وقت بدء حملة التطعيم.",
    sentenceWithBlank: "Measles _______ spreading across the region for weeks by the time the vaccination campaign starts.",
    options: [
      "will have",
      "will have been",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "اسم المرض (Measles) مفرد ويأخذ (will have been spreading).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_26",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون الولايات المتحدة قد استثمرت بكثافة في التكنولوجيا لعقد من الزمان بحلول العام القادم.",
    sentenceWithBlank: "The United States _______ investing heavily in technology for a decade by next year.",
    options: [
      "will have been",
      "will have",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "اسم الدولة المفرد (The United States) يأخذ (will have been investing).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_27",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون علم الاقتصاد قد جذب المزيد من الطلاب لسنوات بحلول وقت تغيير المناهج.",
    sentenceWithBlank: "Economics _______ attracting more students for years by the time the curriculum changes.",
    options: [
      "will have",
      "will have been",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "اسم العلم (Economics) مفرد ويأخذ (will have been attracting).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_28",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون طاقم السفينة قد أعد السفينة للمغادرة لساعات بحلول وقت هبوب العاصفة.",
    sentenceWithBlank: "The crew _______ preparing the ship for departure for hours by the time the storm hits.",
    options: [
      "will have been",
      "will have",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "طاقم العمل كوحدة واحدة في المستقبل التام المستمر يأخذ (will have been preparing).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_29",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون الجمهور قد طالب بخفض الضرائب لعدة أشهر بحلول وقت استجابة الحكومة.",
    sentenceWithBlank: "The public _______ demanding lower taxes for months by the time the government reacts.",
    options: [
      "will have been",
      "will have",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "الجمهور كوحدة جماعية واحدة يأخذ (will have been demanding).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_30",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون عشر سنوات قد مرت بسرعة كبيرة بحلول الوقت الذي ندرك فيه ذلك العام القادم.",
    sentenceWithBlank: "Ten years _______ passing very quickly by the time we realize it next year.",
    options: [
      "will have",
      "will have been",
      "have",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "الفترات الزمنية في المستقبل التام المستمر تأخذ (will have been passing).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_31",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون الرياضيون قد ركضوا لمسافة ثلاثة أميال بحلول الوقت الذي يوقفهم فيه المدرب غداً.",
    sentenceWithBlank: "The athletes _______ running for three miles by the time the coach stops them tomorrow.",
    options: [
      "will have",
      "will have been",
      "have",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "الفاعل (athletes) جمع، ويأخذ (will have been running).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_32",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون أي من المرشحين قد انتظر في الخارج لمدة ساعة بحلول وقت بدء المقابلة.",
    sentenceWithBlank: "Either of the candidates _______ waiting outside for an hour by the time the interview starts.",
    options: [
      "will have",
      "will have been",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "كلمة (Either) تعني 'أحدهما' وتأخذ (will have been waiting).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_33",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "لا أي من الخطتين ستكون قد أثمرت بحلول الوقت الذي نتخلى فيه عنهما الأسبوع القادم.",
    sentenceWithBlank: "Neither of the two plans _______ working out by the time we abandon them next week.",
    options: [
      "will have",
      "will have been",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "التركيب مع (Neither) يأخذ (will have been working).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_34",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "نادراً ما سأكون قد اختبرت مثل هذا التركيز الشديد بحلول نهاية ذلك الاعتكاف.",
    sentenceWithBlank: "Seldom _______ experiencing such intense focus by the end of that retreat.",
    options: [
      "will have I been",
      "will I have been",
      "have I will been",
      "I will have been"
],
    correctAnswer: "will I have been",
    explanation: {
      whyCorrectAr: "تقديم ظرف النفي (Seldom) مع الضمير I يتطلب قلباً نحوياً (will I have been experiencing).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_35",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون الباحثون قد حققوا الكثير من التقدم لسنوات بحلول وقت توقف التمويل.",
    sentenceWithBlank: "Researchers _______ achieving much progress for years by the time funding stops.",
    options: [
      "will have",
      "will have been",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "الفاعل (Researchers) جمع، ويأخذ (will have been achieving).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_36",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سنكون قد استثمرنا قدراً كبيراً من المال لسنوات بحلول وقت انتهاء المشروع.",
    sentenceWithBlank: "We _______ investing a great deal of money for years by the time the project ends.",
    options: [
      "will have",
      "will have been",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "الفاعل (We) يأخذ (will have been investing).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_37",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكونون قد منحوا وقتاً كافياً للفريق لعدة أشهر بحلول الغد.",
    sentenceWithBlank: "They _______ giving plenty of time to the team for months by tomorrow.",
    options: [
      "will have",
      "will have been",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "الفاعل (They) يأخذ (will have been giving).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_38",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون الأطفال قد أكلوا معظم الكعكة لمدة ساعة بحلول وقت وصولي.",
    sentenceWithBlank: "The kids _______ eating most of the cake for an hour by the time I arrive.",
    options: [
      "will have",
      "will have been",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "الفاعل (kids) جمع، ويأخذ (will have been eating).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_39",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون الأطفال قد قطفوا التفاح لساعات بحلول الغد.",
    sentenceWithBlank: "The children _______ picking apples for hours by tomorrow.",
    options: [
      "will have",
      "will have been",
      "have",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "الفاعل (children) جمع ويأخذ (will have been picking).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_40",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سنكون قد خصصنا نصف الأموال لعدة أشهر بحلول الأسبوع القادم.",
    sentenceWithBlank: "We _______ allocating half of the money for months by next week.",
    options: [
      "will have",
      "will have been",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "الفاعل (We) يأخذ (will have been allocating).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_41",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون نصف الطلاب قد تدربوا طوال الصباح بحلول وقت بدء العرض غداً.",
    sentenceWithBlank: "Half of the students _______ practicing all morning by the time the show starts tomorrow.",
    options: [
      "will have",
      "will have been",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "عبارة (Half of) متبوعة باسم جمع (students) تأخذ (will have been practicing).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_42",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "فيم ستكون قد فكرت أثناء المحاضرة بحلول وقت انتهائها؟",
    sentenceWithBlank: "What _______ thinking about during the lecture by the time it ends?",
    options: [
      "will have",
      "will you have been",
      "are you",
      "did you"
],
    correctAnswer: "will you have been",
    explanation: {
      whyCorrectAr: "في السؤال عن الاستمرار نستخدم will you have been متبوعة بـ thinking.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_43",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "لماذا ستكون قد تجنبتني طوال الأسبوع بحلول وقت حديثنا غداً؟",
    sentenceWithBlank: "Why _______ avoiding me all week by the time we speak tomorrow?",
    options: [
      "will have",
      "will she have been",
      "are you",
      "did you"
],
    correctAnswer: "will she have been",
    explanation: {
      whyCorrectAr: "نستخدم will she have been لتكوين السؤال مع الفاعل she.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_44",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "من سيكون قد سرب معلومات سرية لعدة أشهر بحلول وقت اكتشاف الاختراق؟",
    sentenceWithBlank: "Who _______ leaking confidential information for months by the time the breach is found?",
    options: [
      "will have been",
      "will have",
      "are",
      "did"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "في السؤال عن الفاعل مع استمرار الفعل نستخدم (will have been leaking).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_45",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "كم المدة التي سيكونون قد وقفوها في المطر بحلول وقت فتح الملجأ؟",
    sentenceWithBlank: "How long _______ standing in the rain by the time the shelter opens?",
    options: [
      "will have",
      "will they have been",
      "are you",
      "did you"
],
    correctAnswer: "will they have been",
    explanation: {
      whyCorrectAr: "نستخدم will they have been للسؤال عن مدة الوقوف في المستقبل التام المستمر.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_46",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "أين سيكون قد أقام أثناء وجوده في المدينة لمدة شهر بحلول الأسبوع القادم؟",
    sentenceWithBlank: "Where _______ staying while in town for a month by next week?",
    options: [
      "will he have been",
      "will have",
      "are",
      "did"
],
    correctAnswer: "will he have been",
    explanation: {
      whyCorrectAr: "نستخدم will he have been بعد أداة الاستفهام Where.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_47",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ما هي الشركة التي ستكونون قد تعاونتم معها لسنوات بحلول وقت الاندماج؟",
    sentenceWithBlank: "Which company _______ collaborating with for years by the time of the merger?",
    options: [
      "will have",
      "will you have been",
      "are you",
      "did you"
],
    correctAnswer: "will you have been",
    explanation: {
      whyCorrectAr: "نستخدم will you have been بعد اسم المفعول للسؤال في المستقبل التام المستمر.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_48",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "كم فصلاً ستكون قد حررته اليوم بحلول بعد ظهر اليوم؟",
    sentenceWithBlank: "How many chapters _______ editing today by this afternoon?",
    options: [
      "will have",
      "will she have been",
      "are you",
      "did you"
],
    correctAnswer: "will she have been",
    explanation: {
      whyCorrectAr: "نستخدم will she have been في السؤال عن مقدار العمل المستمر.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_49",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "لماذا ستكون قد أصدرت ذلك الصوت الغريب لمدة ساعة بحلول وقت فحصنا لها؟",
    sentenceWithBlank: "Why _______ making that weird noise for an hour by the time we check it?",
    options: [
      "will it have been",
      "will have",
      "are",
      "did"
],
    correctAnswer: "will it have been",
    explanation: {
      whyCorrectAr: "نستخدم will it have been بعد Why في سؤال المستقبل التام المستمر.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_hard_50",
    tenseId: "future_perfect_continuous",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "كم من الجهد ستكون قد بذلته في تلك المهمة لأسابيع بحلول الموعد النهائي؟",
    sentenceWithBlank: "How much effort _______ putting into that task for weeks by the deadline?",
    options: [
      "will have",
      "will you have been",
      "are you",
      "did you"
],
    correctAnswer: "will you have been",
    explanation: {
      whyCorrectAr: "نستخدم will you have been للسؤال عن استمرار بذل الجهد في المستقبل التام المستمر.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  }
];
