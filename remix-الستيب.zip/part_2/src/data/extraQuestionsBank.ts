import { QuizQuestion } from '../types';

export const EXTRA_GRAMMAR_QUESTIONS: QuizQuestion[] = [
  // 3. GERUNDS & INFINITIVES
  {
    id: 'q_gi_1',
    tenseId: 'gerunds_infinitives',
    difficulty: 'easy',
    type: 'multiple_choice',
    promptAr: 'اختر الصيغة الصحيحة بعد فعل Enjoy:',
    sentenceWithBlank: 'I really enjoy ___ historical documentaries during my free time.',
    options: ['watching', 'to watch', 'watch', 'watched'],
    correctAnswer: 'watching',
    explanation: {
      whyCorrectAr: 'فعل enjoy يتبعه دائماً اسم المصدر Gerund المنتهي بـ -ing.',
      temporalRelationshipAr: 'استمتاع بنشاط عام.',
      whyTenseFitsAr: 'Verb + Gerund pattern.',
      whyOthersWrongAr: 'enjoy لا يقبل to-infinitive إطلاقاً.',
    },
  },
  {
    id: 'q_gi_2',
    tenseId: 'gerunds_infinitives',
    difficulty: 'hard',
    type: 'multiple_choice',
    promptAr: 'اختر الصيغة الصحيحة للتعبير عن الإقلاع التام والنهائي عن عادة:',
    sentenceWithBlank: 'He had severe health issues, so he stopped ___ ten years ago.',
    options: ['smoking', 'to smoke', 'smoke', 'smoked'],
    correctAnswer: 'smoking',
    explanation: {
      whyCorrectAr: 'Stop + Gerund تعني الإقلاع التام عن العادة (Quit smoking)؛ بينما Stop + to smoke تعني توقف لكي يدخن.',
      temporalRelationshipAr: 'إنهاء نشاط بالكامل في الماضي.',
      whyTenseFitsAr: 'Stop + V-ing = cease doing an action.',
      whyOthersWrongAr: 'to smoke تعطي عكس المعنى المقصود تماماً (التوقف لأجل التدخين).',
    },
  },

  // 4. PARTICIPLES
  {
    id: 'q_part_1',
    tenseId: 'participles',
    difficulty: 'medium',
    type: 'multiple_choice',
    promptAr: 'اختر اسم الفاعل أو المفعول المناسب لوصف مصدر الشعور والمؤثر:',
    sentenceWithBlank: 'The lecture was so ___ that half the students fell asleep.',
    options: ['boring', 'bored', 'bore', 'boringly'],
    correctAnswer: 'boring',
    explanation: {
      whyCorrectAr: 'المحاضرة هي المسببة للملل (المصدر)، لذا نستخدم Present Participle المنتهي بـ -ing (boring).',
      temporalRelationshipAr: 'صفة مسببة للتأثير.',
      whyTenseFitsAr: '-ing for cause, -ed for feeling.',
      whyOthersWrongAr: 'bored تصف الشخص الذي يشعر بالملل، والمحاضرة جماد لا يشعر بالملل.',
    },
  },

  // 5. RELATIVE CLAUSES
  {
    id: 'q_rc_1',
    tenseId: 'relative_clauses',
    difficulty: 'medium',
    type: 'multiple_choice',
    promptAr: 'اختر ضمير الوصل المناسب للملكية بين اسمين:',
    sentenceWithBlank: 'The author ___ novel won the Pulitzer Prize gave an inspiring speech.',
    options: ['whose', 'who', 'whom', 'which'],
    correctAnswer: 'whose',
    explanation: {
      whyCorrectAr: 'Whose ضمير وصل يعبر عن الملكية بين المؤلف والرواية (whose novel).',
      temporalRelationshipAr: 'نسبة الرواية لكاتبها.',
      whyTenseFitsAr: 'Whose + Noun for possession.',
      whyOthersWrongAr: 'who للفاعل، whom للمفعول، which لغير العاقل.',
    },
  },
  {
    id: 'q_rc_2',
    tenseId: 'relative_clauses',
    difficulty: 'hard',
    type: 'multiple_choice',
    promptAr: 'اختر ضمير الوصل المناسب في الجملة الاعتراضية المحاطة بفواصل (Non-defining):',
    sentenceWithBlank: 'London, ___ is the capital of the UK, attracts millions of tourists.',
    options: ['which', 'that', 'who', 'where'],
    correctAnswer: 'which',
    explanation: {
      whyCorrectAr: 'في الجمل غير المحددة المسبوقة بفاصلة لغير العاقل نستخدم which حصراً وممنوع استخدام that.',
      temporalRelationshipAr: 'معلومة إضافية غير محددة للهوية.',
      whyTenseFitsAr: 'Non-defining clause with commas forbids "that".',
      whyOthersWrongAr: 'that ممنوعة تماماً بعد الفواصل في عبارات الوصل.',
    },
  },

  // 6. NOUN CLAUSES
  {
    id: 'q_nc_1',
    tenseId: 'noun_clauses',
    difficulty: 'medium',
    type: 'multiple_choice',
    promptAr: 'اختر الترتيب الصحيح للعبارة الاسمية غير المباشرة (Embedded Question):',
    sentenceWithBlank: 'Could you please tell me ___ ?',
    options: ['where the nearest bank is', 'where is the nearest bank', 'where does the bank be', 'where did the bank be'],
    correctAnswer: 'where the nearest bank is',
    explanation: {
      whyCorrectAr: 'في السؤال غير المباشر والعبارة الاسمية نستخدم الترتيب الخبري [فاعل + فعل] (where the bank is) وليس ترتيب السؤال المباشر.',
      temporalRelationshipAr: 'استفسار مهذب مركب.',
      whyTenseFitsAr: 'Embedded question word order: Wh-word + Subject + Verb.',
      whyOthersWrongAr: 'where is the bank هو ترتيب سؤال مباشر ولا يصح دمجه داخل سؤال آخر.',
    },
  },

  // 7. ADVERB CLAUSES
  {
    id: 'q_ac_1',
    tenseId: 'adverb_clauses',
    difficulty: 'medium',
    type: 'multiple_choice',
    promptAr: 'اختر الزمن المناسب في العبارة الظرفية الزمنية بعد as soon as للإشارة للمستقبل:',
    sentenceWithBlank: 'We will dispatch the order as soon as the payment ___ confirmed.',
    options: ['is', 'will be', 'was', 'would be'],
    correctAnswer: 'is',
    explanation: {
      whyCorrectAr: 'في عبارات الزمان المستقبلية (مع as soon as, when, until) نستخدم المضارع البسيط بدلاً من will.',
      temporalRelationshipAr: 'شرط زمني مستقبلي مرتبط بمضارع بسيط.',
      whyTenseFitsAr: 'Time clause takes Present Simple for future events.',
      whyOthersWrongAr: 'لا نستخدم will داخل العبارة الزمنية التابعة إطلاقاً.',
    },
  },

  // 8. PHRASAL VERBS
  {
    id: 'q_pv_1',
    tenseId: 'phrasal_verbs',
    difficulty: 'easy',
    type: 'multiple_choice',
    promptAr: 'اختر الموضع الصحيح للضمير مع الفعل المركب القابل للفصل (turn off):',
    sentenceWithBlank: 'The music is too loud. Could you please ___ ?',
    options: ['turn it down', 'turn down it', 'turn down them', 'turn off it'],
    correctAnswer: 'turn it down',
    explanation: {
      whyCorrectAr: 'عندما يكون المفعول به ضميراً (it) مع فعل مركب قابل للفصل، يجب وضعه في المنتصف حتماً بين الفعل وحرف الجر.',
      temporalRelationshipAr: 'طلب خفض الصوت فوراً.',
      whyTenseFitsAr: 'Separable phrasal verb pronoun rule: Verb + Pronoun + Particle.',
      whyOthersWrongAr: 'turn down it خطأ نحوي لأن الضمير لا يأتي بعد الحرف في الأفعال القابلة للفصل.',
    },
  },

  // 9. SUBJECT & OBJECT PRONOUNS
  {
    id: 'q_sop_1',
    tenseId: 'subject_object_pronouns',
    difficulty: 'medium',
    type: 'multiple_choice',
    promptAr: 'اختر الضمير الصحيح بعد حرف الجر between:',
    sentenceWithBlank: 'This conversation must remain strictly between you and ___ .',
    options: ['me', 'I', 'myself', 'mine'],
    correctAnswer: 'me',
    explanation: {
      whyCorrectAr: 'كلمة between حرف جر ويجب أن يتبعها ضمير مفعول به (me) وليس ضمير فاعل (I).',
      temporalRelationshipAr: 'خصوصية محصورة بين الطرفين.',
      whyTenseFitsAr: 'Preposition + Object Pronoun (between you and me).',
      whyOthersWrongAr: 'I ضمير فاعل لا يصح بعد حروف الجر.',
    },
  },

  // 10. POSSESSIVES
  {
    id: 'q_pos_1',
    tenseId: 'possessives',
    difficulty: 'easy',
    type: 'multiple_choice',
    promptAr: 'اختر صفة الملكية الصحيحة لغير العاقل بدون فاصلة عليا:',
    sentenceWithBlank: 'The innovative start-up expanded ___ operations into five new countries.',
    options: ['its', 'it’s', 'their', 'theirs'],
    correctAnswer: 'its',
    explanation: {
      whyCorrectAr: 'its (بدون فاصلة) هي صفة الملكية للفاعل المفرد غير العاقل، بينما it’s تعني it is.',
      temporalRelationshipAr: 'ملكية توسع العمليات.',
      whyTenseFitsAr: 'Possessive adjective for neuter singular.',
      whyOthersWrongAr: 'it’s تعني it is وهو تركيب خاطئ هنا.',
    },
  },

  // 11. DEMONSTRATIVES
  {
    id: 'q_dem_1',
    tenseId: 'demonstratives',
    difficulty: 'easy',
    type: 'multiple_choice',
    promptAr: 'اختر اسم الإشارة المناسب للجمع البعيد في المسافة أو الأفق:',
    sentenceWithBlank: 'Look at ___ snow-capped mountains over there on the horizon.',
    options: ['those', 'these', 'that', 'this'],
    correctAnswer: 'those',
    explanation: {
      whyCorrectAr: 'those تستخدم للجمع البعيد مكانياً أو زمنياً (mountains over there).',
      temporalRelationshipAr: 'إشارة لجمع بعيد في الأفق.',
      whyTenseFitsAr: 'Those + Plural Noun (Far distance).',
      whyOthersWrongAr: 'these للجمع القريب؛ that و this للمفرد.',
    },
  },

  // 12. INDEFINITE PRONOUNS
  {
    id: 'q_ip_1',
    tenseId: 'indefinite_pronouns',
    difficulty: 'easy',
    type: 'multiple_choice',
    promptAr: 'اختر الفعل المناسب للضمير غير المحدد Everyone:',
    sentenceWithBlank: 'Everyone in the research department ___ submitted the final report.',
    options: ['has', 'have', 'are', 'were'],
    correctAnswer: 'has',
    explanation: {
      whyCorrectAr: 'الضمائر المنتهية بـ -one و -body (مثل Everyone) تعامل كاسم مفرد دائماً وتأخذ فعلاً مفرداً (has).',
      temporalRelationshipAr: 'إنجاز التقرير من قِبل الجميع.',
      whyTenseFitsAr: 'Indefinite pronouns take singular verbs.',
      whyOthersWrongAr: 'have و are و were أفعال جمع لا تطابق Everyone.',
    },
  },

  // 13. DETERMINERS
  {
    id: 'q_det_1',
    tenseId: 'determiners',
    difficulty: 'medium',
    type: 'multiple_choice',
    promptAr: 'اختر المحدد المناسب لشيئين اثنين فقط:',
    sentenceWithBlank: 'She was holding a glass of juice in ___ hand.',
    options: ['each', 'every', 'all', 'both'],
    correctAnswer: 'each',
    explanation: {
      whyCorrectAr: 'الإنسان لديه يدان فقط، وعند الحديث عن اثنين نستخدم Each حصراً (ولا يصح every التي تتطلب 3 فأكثر).',
      temporalRelationshipAr: 'حمل كأس في كلتا اليدين.',
      whyTenseFitsAr: 'Each for two items individually.',
      whyOthersWrongAr: 'every تتطلب مجموعة من 3 عناصر فأكثر كحد أدنى.',
    },
  },

  // 14. NEGATION
  {
    id: 'q_neg_1',
    tenseId: 'negation',
    difficulty: 'medium',
    type: 'multiple_choice',
    promptAr: 'اختر التكملة الصحيحة لتفادي خطأ النفي المزدوج (Double Negation):',
    sentenceWithBlank: 'Due to the dense fog, the pilot could see ___ on the runway.',
    options: ['nothing', 'anything not', 'not nothing', 'hardly nothing'],
    correctAnswer: 'nothing',
    explanation: {
      whyCorrectAr: 'nothing تنفي الجملة ذاتياً بدون الحاجة إلى not أو فعل منفي آخر.',
      temporalRelationshipAr: 'انعدام الرؤية في الضباب.',
      whyTenseFitsAr: 'Single negative word maintains standard polarity.',
      whyOthersWrongAr: 'not nothing و hardly nothing نفي مزدوج غير صحيح.',
    },
  },

  // 15. IMPERATIVES
  {
    id: 'q_imp_1',
    tenseId: 'imperatives',
    difficulty: 'easy',
    type: 'multiple_choice',
    promptAr: 'اختر الصيغة الصحيحة للنهي والتحذير المباشر:',
    sentenceWithBlank: '___ touch the live electrical wiring under any circumstances.',
    options: ['Do not', 'Not', 'No', 'You not'],
    correctAnswer: 'Do not',
    explanation: {
      whyCorrectAr: 'صيغ النهي والأمر المنفي تبدأ دائماً بـ (Do not / Don’t) متبوعة بالمصدر المجرد.',
      temporalRelationshipAr: 'تحذير وأمر بالامتناع الفوري.',
      whyTenseFitsAr: 'Negative Imperative starts with Don’t / Do not.',
      whyOthersWrongAr: 'Not أو No أو You not لا تشكل أمراً نحوياً صحيحاً.',
    },
  },

  // 16. THERE IS / THERE ARE
  {
    id: 'q_ti_1',
    tenseId: 'there_is_there_are',
    difficulty: 'easy',
    type: 'multiple_choice',
    promptAr: 'اختر صيغة الوجود الصحيحة مع الاسم الجمع:',
    sentenceWithBlank: '___ several critical issues that need immediate resolution.',
    options: ['There are', 'There is', 'It is', 'They are'],
    correctAnswer: 'There are',
    explanation: {
      whyCorrectAr: 'الفاعل الحقيقي هو several critical issues (جمع)، لذا نستخدم There are.',
      temporalRelationshipAr: 'بيان وجود مشاكل حالية.',
      whyTenseFitsAr: 'There are + Plural Noun.',
      whyOthersWrongAr: 'There is للمفرد فقط؛ It is لا تستخدم للإخبار عن وجود قوائم لأول مرة.',
    },
  },

  // 17. USED TO / BE USED TO / GET USED TO
  {
    id: 'q_ut_1',
    tenseId: 'used_to_be_used_to_get_used_to',
    difficulty: 'hard',
    type: 'multiple_choice',
    promptAr: 'اختر الصيغة الصحيحة بعد التركيب الدال على الألفة والاعتياد الحالي (Be used to):',
    sentenceWithBlank: 'Living in London was difficult initially, but now I am used to ___ in cold weather.',
    options: ['living', 'live', 'lived', 'lives'],
    correctAnswer: 'living',
    explanation: {
      whyCorrectAr: 'بعد (am used to) تكون to حرف جر ويجب أن يتبعها اسم أو Gerund المنتهي بـ -ing (living).',
      temporalRelationshipAr: 'اعتياد وألفة في الحاضر.',
      whyTenseFitsAr: 'Be used to + Gerund (-ing) for familiarity.',
      whyOthersWrongAr: 'المصدر المجرد (live) يأتي فقط مع used to المجردة للماضي بدون am/is/are.',
    },
  },

  // 18. HAVE / HAVE GOT
  {
    id: 'q_hg_1',
    tenseId: 'have_have_got',
    difficulty: 'medium',
    type: 'multiple_choice',
    promptAr: 'اختر الصيغة الصحيحة لنفي الملكية مع have got:',
    sentenceWithBlank: 'I ___ any available appointments for today.',
    options: ['haven’t got', 'don’t have got', 'haven’t', 'am not having got'],
    correctAnswer: 'haven’t got',
    explanation: {
      whyCorrectAr: 'نفي have got يكون بـ haven’t got / hasn’t got مباشرة بدون do/does.',
      temporalRelationshipAr: 'عدم وجود موعد في الحاضر.',
      whyTenseFitsAr: 'Have got negative is haven’t got.',
      whyOthersWrongAr: 'don’t have got خلط خاطئ بين التركيبين.',
    },
  },

  // 19. CAUSATIVE VERBS
  {
    id: 'q_cau_1',
    tenseId: 'causative_verbs',
    difficulty: 'hard',
    type: 'multiple_choice',
    promptAr: 'اختر صيغة السببية الخدمية (Have something done) بواسطة خبير خارجي:',
    sentenceWithBlank: 'My laptop was crashing frequently, so I had it ___ by an IT specialist.',
    options: ['repaired', 'repair', 'repairing', 'to repair'],
    correctAnswer: 'repaired',
    explanation: {
      whyCorrectAr: 'في صيغة Have something done نستخدم دائماً التصريف الثالث (Past Participle - repaired).',
      temporalRelationshipAr: 'إصلاح الجهاز عبر طرف ثالث محترف.',
      whyTenseFitsAr: 'Causative structure: have + object + V3.',
      whyOthersWrongAr: 'المصدر أو ing لا يصحان في السببية الموجهة لغير العاقل.',
    },
  },

  // 20. SO / NEITHER / EITHER / TOO
  {
    id: 'q_sne_1',
    tenseId: 'so_neither_either_too',
    difficulty: 'medium',
    type: 'multiple_choice',
    promptAr: 'اختر صيغة الموافقة الصحيحة مع جملة منفية في الماضي البسيط:',
    sentenceWithBlank: '"I didn’t enjoy the movie last night." — "___ ."',
    options: ['Neither did I', 'So did I', 'Neither didn’t I', 'I did too'],
    correctAnswer: 'Neither did I',
    explanation: {
      whyCorrectAr: 'للموافقة على جملة منفية في الماضي نستخدم Neither + الفعل المساعد الموجب (did) + الفاعل (I).',
      temporalRelationshipAr: 'تأييد الموقف السلبي في الماضي.',
      whyTenseFitsAr: 'Neither + Auxiliary + Subject.',
      whyOthersWrongAr: 'So للمثبت فقط؛ Neither didn’t I نفي مزدوج غير صحيح.',
    },
  },

  // 21. ELLIPSIS & SUBSTITUTION
  {
    id: 'q_ell_1',
    tenseId: 'ellipsis_substitution',
    difficulty: 'medium',
    type: 'multiple_choice',
    promptAr: 'اختر أسلوب التعويض الصحيح بـ Hope عند الإجابة بالنفي:',
    sentenceWithBlank: '"Do you think the flight will be canceled?" — "I ___ ."',
    options: ['hope not', 'don’t hope so', 'hope it not', 'hope no'],
    correctAnswer: 'hope not',
    explanation: {
      whyCorrectAr: 'مع فعل Hope يكون النفي التعويضي هو (I hope not) حصراً وليس I don’t hope so.',
      temporalRelationshipAr: 'أمل وتوقع بعدم حدوث الإلغاء.',
      whyTenseFitsAr: 'Standard substitution for hope in negative response.',
      whyOthersWrongAr: 'I don’t hope so غير مستخدمة وغير قياسية مع فعل hope.',
    },
  },

  // 22. PARALLEL STRUCTURE
  {
    id: 'q_par_1',
    tenseId: 'parallel_structure',
    difficulty: 'medium',
    type: 'multiple_choice',
    promptAr: 'اختر التكملة التي تحقق التوازي القواعدي السليم (Parallel Structure):',
    sentenceWithBlank: 'The internship program focuses on developing leadership skills, enhancing technical proficiency, and ___ .',
    options: ['building professional networks', 'to build networks', 'build networks', 'networks building'],
    correctAnswer: 'building professional networks',
    explanation: {
      whyCorrectAr: 'لتحقيق التوازي يجب أن تتبع الصيغة نفس النمط (-ing) مثل developing و enhancing.',
      temporalRelationshipAr: 'قائمة متوازية من الأهداف التدريبية.',
      whyTenseFitsAr: 'Parallelism requires matching Gerund forms across listed items.',
      whyOthersWrongAr: 'to build أو build تكسر التوازي النحوي في القائمة.',
    },
  },

  // 23. WORD ORDER
  {
    id: 'q_wo_1',
    tenseId: 'word_order',
    difficulty: 'hard',
    type: 'multiple_choice',
    promptAr: 'اختر الترتيب الصحيح للصفات قبل الاسم وفق قاعدة OSASCOMP:',
    sentenceWithBlank: 'He bought a ___ leather sofa for the executive lounge.',
    options: ['magnificent large black Italian', 'black large Italian magnificent', 'Italian magnificent large black', 'large Italian black magnificent'],
    correctAnswer: 'magnificent large black Italian',
    explanation: {
      whyCorrectAr: 'ترتيب OSASCOMP: Opinion (magnificent) -> Size (large) -> Color (black) -> Origin (Italian).',
      temporalRelationshipAr: 'وصف دقيق للأثاث.',
      whyTenseFitsAr: 'Adjective order: Opinion, Size, Color, Origin.',
      whyOthersWrongAr: 'الخيارات الأخرى تخالف الترتيب القياسي للصفات.',
    },
  },

  // 24. INVERSION
  {
    id: 'q_inv_1',
    tenseId: 'inversion',
    difficulty: 'hard',
    type: 'multiple_choice',
    promptAr: 'اختر صيغة القلب (Inversion) الصحيحة بعد ظرف النفي Never في بداية الجملة:',
    sentenceWithBlank: 'Never ___ such an astonishing natural spectacle.',
    options: ['have I witnessed', 'I have witnessed', 'did I witnessed', 'I witnessed'],
    correctAnswer: 'have I witnessed',
    explanation: {
      whyCorrectAr: 'عند بدء الجملة بـ Never نقدم الفعل المساعد على الفاعل كصيغة سؤال (have I witnessed).',
      temporalRelationshipAr: 'توكيد درامي على تجربة فريدة عبر كل الأوقات.',
      whyTenseFitsAr: 'Negative adverb inversion: Never + Aux + Subject + Verb.',
      whyOthersWrongAr: 'I have witnessed ترتيب خبري عادي لا يجوز بعد Never في البداية.',
    },
  },

  // 25. CLEFT SENTENCES
  {
    id: 'q_cleft_1',
    tenseId: 'cleft_sentences',
    difficulty: 'hard',
    type: 'multiple_choice',
    promptAr: 'اختر الجملة المشطورة (It-cleft) لتوكيد أن البروفيسور هو صاحب الاكتشاف:',
    sentenceWithBlank: '___ discovered the vaccine in 1953.',
    options: ['It was Professor Salk who', 'What Professor Salk', 'Professor Salk was that', 'There was Professor Salk who'],
    correctAnswer: 'It was Professor Salk who',
    explanation: {
      whyCorrectAr: 'صيغة It-cleft تركز الأضواء على الفاعل: It + was + [Person] + who + ...',
      temporalRelationshipAr: 'توكيد هوية المكتشف في الماضي.',
      whyTenseFitsAr: 'It-cleft structure for focusing on a person.',
      whyOthersWrongAr: 'الخيارات الأخرى غير مكتملة التركيب نحواً وتوكيداً.',
    },
  },

  // 26. EMPHASIS
  {
    id: 'q_emp_1',
    tenseId: 'emphasis',
    difficulty: 'medium',
    type: 'multiple_choice',
    promptAr: 'اختر صيغة التوكيد الإيجابي بفعل Do الماضي لتأكيد حدوث الفعل:',
    sentenceWithBlank: 'I assure you that I ___ lock the security gate before leaving.',
    options: ['did', 'do', 'have', 'was'],
    correctAnswer: 'did',
    explanation: {
      whyCorrectAr: 'did + المصدر المجرد (lock) تؤكد بشكل قاطع حدوث الفعل في الماضي لدحض الشك.',
      temporalRelationshipAr: 'توكيد جازم لحدث ماضٍ.',
      whyTenseFitsAr: 'Emphatic past: did + Base Verb.',
      whyOthersWrongAr: 'do للمضارع؛ have تتطلب التصريف الثالث locked.',
    },
  },

  // 27. PUNCTUATION & CAPITALIZATION
  {
    id: 'q_punc_1',
    tenseId: 'punctuation_capitalization',
    difficulty: 'medium',
    type: 'multiple_choice',
    promptAr: 'اختر علامة الترقيم الصحيحة للربط بين جملتين مستقلتين متكاملتين بدون أداة عطف:',
    sentenceWithBlank: 'The experiment was extremely risky ___ however, the scientists decided to proceed.',
    options: [';', ',', ':', '-'],
    correctAnswer: ';',
    explanation: {
      whyCorrectAr: 'نستخدم الفاصلة المنقوطة (;) قبل الروابط الانتقالية مثل however عندما تفصل بين جملتين مستقلتين.',
      temporalRelationshipAr: 'ربط ترقيمي متزن بين جملتين كاملتين.',
      whyTenseFitsAr: 'Semicolon precedes conjunctive adverbs between independent clauses.',
      whyOthersWrongAr: 'الفاصلة العادية تسبب خطأ Comma Splice الجسيم.',
    },
  },

  // 28. COMMON GRAMMAR ERRORS
  {
    id: 'q_err_1',
    tenseId: 'common_grammar_errors',
    difficulty: 'easy',
    type: 'error_spotting',
    promptAr: 'اكتشف الكلمة الخاطئة نحوياً وإملائياً في الجملة التالية:',
    sentenceWithMistake: 'You should of informed the manager before submitting the proposal.',
    mistakeWord: 'should of',
    correctedWord: 'should have',
    correctAnswer: 'should of',
    explanation: {
      whyCorrectAr: 'التركيب النحوي الصحيح هو should have (أو should’ve)؛ ولا وجود لـ should of في الإنجليزية.',
      temporalRelationshipAr: 'لوم ونصيحة على تصرف ماضٍ.',
      whyTenseFitsAr: 'Modal + have + V3 in past tense.',
      whyOthersWrongAr: 'should of خطأ إملائي ناشئ عن الخلط الصوتي مع اختصار should’ve.',
    },
  },
];
