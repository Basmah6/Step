import { QuizQuestion, TenseId, Difficulty } from '../types';
import { ALL_TENSES } from './tensesData';

export interface GrammarRuleItem {
  promptAr: string;
  sentenceWithBlank: string;
  correct: string;
  distractors: string[];
  whyCorrectAr: string;
  temporalAr: string;
}

export const GRAMMAR_RULE_TEMPLATES: Record<string, { easy: GrammarRuleItem[]; medium: GrammarRuleItem[]; hard: GrammarRuleItem[] }> = {
  modal_verbs: {
    easy: [
      {
        promptAr: 'اختر الفعل الناقص الذي يعبر عن التزام وقانون إجباري حتمي (Obligation):',
        sentenceWithBlank: 'Drivers ___ stop their vehicles when the traffic signal turns red.',
        correct: 'must',
        distractors: ['might', 'should', 'could'],
        whyCorrectAr: 'التوقف عند الإشارة الحمراء قانون إجباري والتزام قاطع يتطلب استخدام Must.',
        temporalAr: 'إلزام قانوني دائم ومباشر.',
      },
      {
        promptAr: 'اختر الفعل الناقص الذي يعبر عن القدرة والاستطاعة في الحاضر (Ability):',
        sentenceWithBlank: 'She ___ speak four foreign languages fluently.',
        correct: 'can',
        distractors: ['must', 'might', 'shall'],
        whyCorrectAr: 'Can تعبر عن الاستطاعة والمهارة المكتسبة في الحاضر.',
        temporalAr: 'قدرة شخصية دائمة.',
      },
      {
        promptAr: 'اختر الفعل الناقص لتقديم نصيحة ودية مفيدة (Advice):',
        sentenceWithBlank: 'You ___ drink plenty of clean water every day for good health.',
        correct: 'should',
        distractors: ['must', 'can', 'might'],
        whyCorrectAr: 'Should تستخدم لإسداء النصيحة والتوجيه الإيجابي.',
        temporalAr: 'نصيحة وتوجيه عام.',
      },
    ],
    medium: [
      {
        promptAr: 'اختر الفعل الناقص المعبر عن انعدام الإلزام (Lack of Obligation / You are free):',
        sentenceWithBlank: 'Tomorrow is an official national holiday, so you ___ wake up early.',
        correct: "don't have to",
        distractors: ["mustn't", "can't", "shouldn't have"],
        whyCorrectAr: "don't have to تعني لست ملزماً (أنت حر تماماً)، بينما mustn't تعني ممنوع ومحرم.",
        temporalAr: 'حرية الاختيار وانعدام الإلزام.',
      },
      {
        promptAr: 'اختر الفعل الناقص المعبر عن المنع والتحريم القاطع (Prohibition):',
        sentenceWithBlank: 'Visitors ___ take photos inside the high-security military museum.',
        correct: "must not",
        distractors: ["don't have to", "might not", "needn't"],
        whyCorrectAr: 'must not (mustn’t) تعبر عن الحظر والمنع الصارم.',
        temporalAr: 'حظر ومنع قاطع.',
      },
    ],
    hard: [
      {
        promptAr: 'اختر صيغة الاستنتاج المنطقي المؤكد في الماضي (Deduction in the past):',
        sentenceWithBlank: 'The streets are completely flooded this morning. It ___ heavily last night.',
        correct: 'must have rained',
        distractors: ['should rain', 'can rain', 'might rain'],
        whyCorrectAr: 'وجود الفيضان دليل قاطع في الحاضر على حدوث المطر في الماضي، فنستخدم: must have + V3.',
        temporalAr: 'استنتاج يقيني لحدث وقع في الماضي بناء على دليل حالي.',
      },
      {
        promptAr: 'اختر صيغة الاستنتاج بالاستحالة في الماضي (Impossible in the past):',
        sentenceWithBlank: 'He ___ that crime because he was confirmed to be in Paris at that exact time.',
        correct: 'cannot have committed',
        distractors: ['must commit', 'should have committed', 'might commit'],
        whyCorrectAr: 'cannot have + V3 تعبر عن استحالة وقوع الفعل في الماضي بناء على دليل قاطع.',
        temporalAr: 'استنتاج الاستحالة التامة في الماضي.',
      },
    ],
  },

  passive_voice: {
    easy: [
      {
        promptAr: 'اختر صيغة المبني للمجهول في المضارع البسيط مع المفرد:',
        sentenceWithBlank: 'Arabic ___ by millions of people across the Middle East and the world.',
        correct: 'is spoken',
        distractors: ['speaks', 'is speaking', 'spoke'],
        whyCorrectAr: 'صيغة المبني للمجهول في المضارع البسيط: is/are + التصريف الثالث (is spoken).',
        temporalAr: 'حقيقة عامة مبنية للمجهول.',
      },
      {
        promptAr: 'اختر صيغة المبني للمجهول في الماضي البسيط مع الجمع:',
        sentenceWithBlank: 'The ancient pyramids of Giza ___ thousands of years ago.',
        correct: 'were built',
        distractors: ['built', 'are built', 'have built'],
        whyCorrectAr: 'الماضي البسيط المبني للمجهول مع الجمع يتكون من (were + V3).',
        temporalAr: 'حدث تاريخي ماضٍ مسند للمفعول به.',
      },
    ],
    medium: [
      {
        promptAr: 'اختر صيغة المبني للمجهول في المضارع التام:',
        sentenceWithBlank: 'The new international hospital ___ successfully in the capital city.',
        correct: 'has been inaugurated',
        distractors: ['has inaugurated', 'is inaugurated', 'was inaugurating'],
        whyCorrectAr: 'المبني للمجهول في المضارع التام: has/have been + V3.',
        temporalAr: 'إنجاز مكتمل في الحاضر بتركيز على المفعول به.',
      },
    ],
    hard: [
      {
        promptAr: 'اختر صيغة المبني للمجهول مع الأفعال الناقصة (Modal Passive):',
        sentenceWithBlank: 'All confidential documents ___ in the fireproof safe before leaving the office.',
        correct: 'must be kept',
        distractors: ['must keep', 'must have kept', 'must been kept'],
        whyCorrectAr: 'المبني للمجهول مع الأفعال الناقصة: Modal + be + V3.',
        temporalAr: 'إلزام موجه إلى المفعول به.',
      },
    ],
  },

  conditionals_zero_first_second_third: {
    easy: [
      {
        promptAr: 'اختر التركيب الصحيح للشرطية الصفرية (Zero Conditional - حقائق علمية):',
        sentenceWithBlank: 'If you freeze water, it ___ into ice.',
        correct: 'turns',
        distractors: ['will turn', 'turned', 'would turn'],
        whyCorrectAr: 'الشرطية الصفرية تستخدم المضارع البسيط في الشقين للتعبير عن حقيقة علمية.',
        temporalAr: 'حقيقة علمية حتمية في كل زمان.',
      },
    ],
    medium: [
      {
        promptAr: 'اختر التركيب الصحيح للشرطية الأولى (First Conditional - احتمالات حقيقية):',
        sentenceWithBlank: 'If she ___ hard for the entrance exam, she will get accepted.',
        correct: 'studies',
        distractors: ['studied', 'will study', 'would study'],
        whyCorrectAr: 'في الشرطية الأولى، جملة If تأخذ المضارع البسيط وجواب الشرط يأخذ will + base.',
        temporalAr: 'شرط محتمل الحدوث في المستقبل.',
      },
      {
        promptAr: 'اختر التركيب الصحيح للشرطية الثانية (Second Conditional - افتراض غير حقيقي):',
        sentenceWithBlank: 'If I ___ a million dollars, I would travel around the entire world.',
        correct: 'won',
        distractors: ['win', 'have won', 'will win'],
        whyCorrectAr: 'الشرطية الثانية للتخيل والافتراض تأخذ Past Simple في جملة If و would + base في جواب الشرط.',
        temporalAr: 'افتراض خيالي غير واقعي في الحاضر.',
      },
    ],
    hard: [
      {
        promptAr: 'اختر التركيب الصحيح للشرطية الثالثة (Third Conditional - ندم على الماضي):',
        sentenceWithBlank: 'If they had left on time, they ___ the scheduled flight.',
        correct: 'would not have missed',
        distractors: ['will not miss', 'did not miss', 'would not miss'],
        whyCorrectAr: 'الشرطية الثالثة: If + had + V3 ---> would have + V3.',
        temporalAr: 'افتراض ماضٍ مستحيل لم يقع وتمني نتيجته.',
      },
    ],
  },

  reported_speech: {
    easy: [
      {
        promptAr: 'اختر التحويل الزمني الصحيح من المضارع البسيط إلى الماضي البسيط في الكلام المنقول:',
        sentenceWithBlank: 'Direct: "I work at a bank." -> Reported: He said that he ___ at a bank.',
        correct: 'worked',
        distractors: ['works', 'is working', 'has worked'],
        whyCorrectAr: 'عند نقل الكلام نرجع بالزمن خطوة للوراء: Present Simple يصبح Past Simple.',
        temporalAr: 'نقل كلام من الماضي.',
      },
    ],
    medium: [
      {
        promptAr: 'اختر التحويل الصحيح للظرف الزمني في الكلام المنقول:',
        sentenceWithBlank: 'Direct: "We will leave tomorrow." -> Reported: They said they would leave ___.',
        correct: 'the next day',
        distractors: ['tomorrow', 'yesterday', 'the day before'],
        whyCorrectAr: 'في الكلام المنقول تتحول tomorrow إلى the next day أو the following day.',
        temporalAr: 'مواءمة الظروف الزمنية في النقل.',
      },
    ],
    hard: [
      {
        promptAr: 'اختر التركيب المنقول للسؤال الذي يبدأ بـ Wh-word:',
        sentenceWithBlank: 'She asked me where I ___ my keys.',
        correct: 'had put',
        distractors: ['did I put', 'have I put', 'was I putting'],
        whyCorrectAr: 'في السؤال المنقول يتحول الترتيب لترتيب جملة خبرية (فاعل + فعل) مع الرجوع بالزمن للماضي التام.',
        temporalAr: 'سؤال منقول بصيغة إخبارية.',
      },
    ],
  },
};
