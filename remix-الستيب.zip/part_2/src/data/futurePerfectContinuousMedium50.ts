import { QuizQuestion } from '../types';

export const FUTURE_PERFECT_CONTINUOUS_MEDIUM_50: QuizQuestion[] = [
  {
    id: "fpc_medium_1",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "بحلول الشهر القادم، كم المدة التي ستكون قد قضيتها في تعلم الإنجليزية؟",
    sentenceWithBlank: "By next month, how long _______ you been learning English?",
    options: [
      "will has",
      "will you have",
      "are you",
      "did you"
],
    correctAnswer: "will you have",
    explanation: {
      whyCorrectAr: "في السؤال عن المدة في المستقبل التام المستمر، نستخدم will + الفاعل + have قبل been + V-ing.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_2",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "ستكون قد قامت بطلاء الحائط لمدة ثلاث ساعات بحلول ظهر الغد.",
    sentenceWithBlank: "She will have been painting the wall _______ three hours by noon tomorrow.",
    options: [
      "for",
      "since",
      "yet",
      "already"
],
    correctAnswer: "for",
    explanation: {
      whyCorrectAr: "نستخدم حرف الجر for لتحديد طول المدة الزمنية المستغرقة (three hours).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_3",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سأكون قد عملت على ذلك التقرير منذ هذا الصباح بحلول وقت وصول المدير.",
    sentenceWithBlank: "I will have been working on that report _______ this morning by the time the boss arrives.",
    options: [
      "for",
      "since",
      "yet",
      "just"
],
    correctAnswer: "since",
    explanation: {
      whyCorrectAr: "نستخدم since للدلالة على نقطة بداية الحدث المستمر (this morning).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_4",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سيبدو متعباً لأنه سيكون قد ركض لمدة ساعة بحلول الوقت الذي نراه فيه.",
    sentenceWithBlank: "He will look tired because he _______ running for an hour by the time we see him.",
    options: [
      "will has been",
      "will have been",
      "is being",
      "had been"
],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "نستخدم المستقبل التام المستمر will have been running لبيان سبب التعب المستمر حتى لحظة الرؤية.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_5",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سنكون قد ناقشنا ذلك الأمر لأكثر من ساعة بحلول الوقت الذي نصل فيه إلى اتفاق.",
    sentenceWithBlank: "We _______ have been discussing that matter for over an hour by the time we reach an agreement.",
    options: [
      "will has",
      "will have",
      "are",
      "did"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "الفعل المساعد في المستقبل التام المستمر هو will have متبوعاً بـ been + V-ing.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_6",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "هل ستكون قد انتظرت هناك طويلاً بحلول وقت وصول القطار غداً؟",
    sentenceWithBlank: "Will you _______ been waiting there long by the time the train comes tomorrow?",
    options: [
      "be",
      "have",
      "has",
      "had"
],
    correctAnswer: "have",
    explanation: {
      whyCorrectAr: "بعد Will والفاعل you يأتي المصدر have دائماً قبل been waiting.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_7",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "ستكون قد عاشت في الخارج لمدة خمس سنوات بحلول الصيف القادم.",
    sentenceWithBlank: "She will have _______ living abroad for five years by next summer.",
    options: [
      "be",
      "been",
      "being",
      "is"
],
    correctAnswer: "been",
    explanation: {
      whyCorrectAr: "بعد will have في المستقبل التام المستمر نستخدم التصريف الثالث للفعل be وهو been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_8",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سيكونون قد تدربوا على تلك الأغنية طوال الأسبوع بحلول وقت العرض.",
    sentenceWithBlank: "They will have _______ practicing that song all week by the time of the show.",
    options: [
      "be",
      "been",
      "being",
      "are"
],
    correctAnswer: "been",
    explanation: {
      whyCorrectAr: "نستخدم been بعد will have في صيغة المستقبل التام المستمر.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_9",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "ستكون السماء قد أمطرت باستمرار لأيام بحلول وقت سطوع الشمس.",
    sentenceWithBlank: "It will have _______ raining continuously for days by the time the sun comes out.",
    options: [
      "be",
      "been",
      "being",
      "is"
],
    correctAnswer: "been",
    explanation: {
      whyCorrectAr: "نستخدم been بعد will have متبوعة بـ raining.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_10",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "ماذا ستكون قد فعلت لساعات بحلول الوقت الذي أقابلك فيه الليلة؟",
    sentenceWithBlank: "What _______ you have been doing for hours by the time I meet you tonight?",
    options: [
      "will has",
      "will",
      "are",
      "did"
],
    correctAnswer: "will",
    explanation: {
      whyCorrectAr: "نستخدم will بعد أداة الاستفهام What وقبل الفاعل you.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_11",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "أين ستكون قد أقامت أثناء زيارتها بحلول الشهر القادم؟",
    sentenceWithBlank: "Where will she _______ staying during her visit by next month?",
    options: [
      "have",
      "have been",
      "has been",
      "be been"
],
    correctAnswer: "have been",
    explanation: {
      whyCorrectAr: "في السؤال بعد will والفاعل she نستخدم have been + V-ing.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_12",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لماذا سيكونون قد تجادلوا لفترة طويلة بحلول وقت تدخلي؟",
    sentenceWithBlank: "Why will they _______ arguing for so long by the time I intervene?",
    options: [
      "have",
      "have been",
      "has been",
      "be been"
],
    correctAnswer: "have been",
    explanation: {
      whyCorrectAr: "نستخدم have been بعد will they في المستقبل التام المستمر.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_13",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "من سيكون قد استخدم حاسوبي دون إذن بحلول نهاية اليوم؟",
    sentenceWithBlank: "Who will have _______ using my computer without permission by the end of the day?",
    options: [
      "be",
      "been",
      "being",
      "is"
],
    correctAnswer: "been",
    explanation: {
      whyCorrectAr: "نستخدم been بعد will have في سؤال المستقبل التام المستمر.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_14",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "كم المدة التي سيكون قد أدار فيها ذلك الفرع بحلول العام القادم؟",
    sentenceWithBlank: "How long will he _______ managing that branch by next year?",
    options: [
      "have",
      "have been",
      "has been",
      "be been"
],
    correctAnswer: "have been",
    explanation: {
      whyCorrectAr: "بعد will he يأتي have been متبوعاً بـ managing.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_15",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "أي كتاب ستكون قد قرأته لمدة شهر بحلول الغد؟",
    sentenceWithBlank: "Which book will you have _______ reading for a month by tomorrow?",
    options: [
      "be",
      "been",
      "being",
      "are"
],
    correctAnswer: "been",
    explanation: {
      whyCorrectAr: "نستخدم been بعد will you have في المستقبل التام المستمر.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_16",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "كم ساعة ستكون قد درستها بحلول وقت بدء الامتحان؟",
    sentenceWithBlank: "How many hours will you _______ studying by the time the exam starts?",
    options: [
      "have",
      "have been",
      "has been",
      "be been"
],
    correctAnswer: "have been",
    explanation: {
      whyCorrectAr: "نستخدم have been بعد will you متبوعة بـ studying.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_17",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لماذا سيكون الكلب قد نبح باستمرار بحلول وقت إطعامه؟",
    sentenceWithBlank: "Why will the dog _______ barking continuously by the time we feed it?",
    options: [
      "have",
      "have been",
      "has been",
      "be been"
],
    correctAnswer: "have been",
    explanation: {
      whyCorrectAr: "نستخدم have been بعد will the dog في صيغة المستقبل التام المستمر.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_18",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سيكون إخوتي قد لعبوا ألعاب الفيديو طوال المساء بحلول وقت العشاء.",
    sentenceWithBlank: "My brothers will have _______ playing video games all evening by dinner time.",
    options: [
      "be",
      "been",
      "being",
      "are"
],
    correctAnswer: "been",
    explanation: {
      whyCorrectAr: "نستخدم been بعد will have.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_19",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لا أحد من المشاركين سيكون قد حضر في الموعد بحلول نهاية الندوة.",
    sentenceWithBlank: "Neither of the participants will have _______ showing up on time by the end of the seminar.",
    options: [
      "be",
      "been",
      "being",
      "are"
],
    correctAnswer: "been",
    explanation: {
      whyCorrectAr: "نستخدم been بعد will have مع Neither of the participants.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_20",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سأكون قد بحثت عن هاتفي منذ الصباح بحلول الوقت الذي أجده فيه.",
    sentenceWithBlank: "I will have been _______ for my phone since morning by the time I find it.",
    options: [
      "search",
      "searches",
      "searching",
      "searched"
],
    correctAnswer: "searching",
    explanation: {
      whyCorrectAr: "بعد will have been يأتي الفعل مضافاً له ing (searching).",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_21",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "ستكون قد حاولت بجد لاجتياز الامتحانات بحلول الأسبوع القادم.",
    sentenceWithBlank: "She will have been _______ hard to pass the exams by next week.",
    options: [
      "try",
      "tries",
      "trying",
      "tried"
],
    correctAnswer: "trying",
    explanation: {
      whyCorrectAr: "نستخدم trying بعد will have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_22",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سيكونون قد بنوا منزلاً جديداً في الضواحي بحلول العام القادم.",
    sentenceWithBlank: "They will have been _______ a new house in the suburbs by next year.",
    options: [
      "build",
      "builds",
      "building",
      "built"
],
    correctAnswer: "building",
    explanation: {
      whyCorrectAr: "نستخدم building بعد will have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_23",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سيكون قد جلس في الشمس لفترة طويلة جداً بحلول بعد الظهر.",
    sentenceWithBlank: "He will have been _______ in the sun too long by afternoon.",
    options: [
      "sit",
      "sits",
      "sitting",
      "sat"
],
    correctAnswer: "sitting",
    explanation: {
      whyCorrectAr: "نستخدم sitting بعد will have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_24",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سنكون قد انتظرنا أصدقاءنا لأكثر من عشرين دقيقة بحلول وقت وصولهم.",
    sentenceWithBlank: "We will have been _______ for our friends for over twenty minutes by the time they arrive.",
    options: [
      "wait",
      "waits",
      "waiting",
      "waited"
],
    correctAnswer: "waiting",
    explanation: {
      whyCorrectAr: "نستخدم waiting بعد will have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_25",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "ستكون الرياح قد هبت بشدة لساعات بحلول مساء الغد.",
    sentenceWithBlank: "The wind will have been _______ fiercely for hours by tomorrow evening.",
    options: [
      "blow",
      "blows",
      "blowing",
      "blew"
],
    correctAnswer: "blowing",
    explanation: {
      whyCorrectAr: "نستخدم blowing بعد will have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_26",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "ستكون قد أحرزت تقدماً كبيراً بحلول نهاية الدورة.",
    sentenceWithBlank: "You will have been _______ great progress by the end of the course.",
    options: [
      "make",
      "makes",
      "making",
      "made"
],
    correctAnswer: "making",
    explanation: {
      whyCorrectAr: "نستخدم making بعد will have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_27",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سيكون الطفل قد بكى بسبب ألم الأسنان لساعات بحلول وقت وصول الطبيب.",
    sentenceWithBlank: "The baby will have been _______ because of a toothache for hours by the time the doctor arrives.",
    options: [
      "cry",
      "cries",
      "crying",
      "dried"
],
    correctAnswer: "crying",
    explanation: {
      whyCorrectAr: "نستخدم crying بعد will have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_28",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "ستكون قد ساعدت والدتها في المطبخ لمدة ساعة بحلول الظهيرة.",
    sentenceWithBlank: "She will have been _______ her mother in the kitchen for an hour by noon.",
    options: [
      "help",
      "helps",
      "helping",
      "helped"
],
    correctAnswer: "helping",
    explanation: {
      whyCorrectAr: "نستخدم helping بعد will have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_29",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سيكون أصدقائي قد دعموني في مشروعي الجديد لعدة أشهر بحلول شهر يونيو.",
    sentenceWithBlank: "My friends will have been _______ me with my new project for months by June.",
    options: [
      "support",
      "supports",
      "supporting",
      "supported"
],
    correctAnswer: "supporting",
    explanation: {
      whyCorrectAr: "نستخدم supporting بعد will have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_30",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لن أكون قد شعرت أنني بحالة جيدة بحلول وقت زيارة العيادة غداً.",
    sentenceWithBlank: "I will not have been _______ well by the time I visit the clinic tomorrow.",
    options: [
      "feel",
      "feels",
      "feeling",
      "felt"
],
    correctAnswer: "feeling",
    explanation: {
      whyCorrectAr: "نستخدم feeling بعد will not have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_31",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لن تكون قد ذهبت إلى المحاضرات لأسابيع بحلول وقت حصولها على إنذار.",
    sentenceWithBlank: "She will not have been _______ to lectures for weeks by the time she gets a warning.",
    options: [
      "go",
      "goes",
      "going",
      "gone"
],
    correctAnswer: "going",
    explanation: {
      whyCorrectAr: "نستخدم going بعد will not have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_32",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لن يكونوا قد قدموا أفضل أداء لهم بحلول نهاية الشوط الأول.",
    sentenceWithBlank: "They will not have been _______ their best performance by the end of the first half.",
    options: [
      "give",
      "gives",
      "giving",
      "given"
],
    correctAnswer: "giving",
    explanation: {
      whyCorrectAr: "نستخدم giving بعد will not have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_33",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لن يكون قد حصل على قسط كافٍ من النوم بحلول أسبوع الامتحانات.",
    sentenceWithBlank: "He will not have been _______ enough sleep by the exam week.",
    options: [
      "get",
      "gets",
      "getting",
      "got"
],
    correctAnswer: "getting",
    explanation: {
      whyCorrectAr: "نستخدم getting بعد will not have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_34",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لن نكون قد عملنا في عطلات نهاية الأسبوع لمدة شهر بحلول وقت تغيير السياسة.",
    sentenceWithBlank: "We will not have been _______ on weekends for a month by the time the policy changes.",
    options: [
      "work",
      "works",
      "working",
      "worked"
],
    correctAnswer: "working",
    explanation: {
      whyCorrectAr: "نستخدم working بعد will not have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_35",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لن تكون قد انتبهت إلى التفاصيل بحلول وقت ارتكابك ذلك الخطأ.",
    sentenceWithBlank: "You will not have been _______ attention to detail by the time you make that mistake.",
    options: [
      "pay",
      "pays",
      "paying",
      "paid"
],
    correctAnswer: "paying",
    explanation: {
      whyCorrectAr: "نستخدم paying بعد will not have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_36",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لن يكون قد عمل بشكل صحيح لعدة أيام بحلول وقت إصلاحه.",
    sentenceWithBlank: "It will not have been _______ properly for days by the time we repair it.",
    options: [
      "function",
      "functions",
      "functioning",
      "functioned"
],
    correctAnswer: "functioning",
    explanation: {
      whyCorrectAr: "نستخدم functioning بعد will not have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_37",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لن تكون الآلة قد عملت بسلاسة لمدة ساعة بحلول وقت تغيير الزيت.",
    sentenceWithBlank: "The machine will not have been _______ smoothly for an hour by the time it gets an oil change.",
    options: [
      "run",
      "runs",
      "running",
      "ran"
],
    correctAnswer: "running",
    explanation: {
      whyCorrectAr: "نستخدم running بعد will not have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_38",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لن يكون حاسوبي قد عمل بشكل سليم لساعات بحلول وقت تعطله.",
    sentenceWithBlank: "My computer will not have been _______ right for hours by the time it crashes.",
    options: [
      "work",
      "works",
      "working",
      "worked"
],
    correctAnswer: "working",
    explanation: {
      whyCorrectAr: "نستخدم working بعد will not have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_39",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لن يكون الطلاب قد حافظوا على تركيزهم لفترة طويلة بحلول وقت تدخل المعلم.",
    sentenceWithBlank: "The students will not have been _______ focused for long by the time the teacher intervenes.",
    options: [
      "stay",
      "stays",
      "staying",
      "stayed"
],
    correctAnswer: "staying",
    explanation: {
      whyCorrectAr: "نستخدم staying بعد will not have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_40",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "هل ستكون قد قرأت ذلك الكتاب لمدة شهر بحلول الغد؟",
    sentenceWithBlank: "Will you have been _______ that book for a month by tomorrow?",
    options: [
      "read",
      "reads",
      "reading",
      "readed"
],
    correctAnswer: "reading",
    explanation: {
      whyCorrectAr: "نستخدم reading بعد Will you have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_41",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "هل ستكون قد عملت في ذلك المكتب لفترة طويلة بحلول وقت نقلها الشهر القادم؟",
    sentenceWithBlank: "Will she have been _______ in that office long by the time she is transferred next month?",
    options: [
      "work",
      "works",
      "working",
      "worked"
],
    correctAnswer: "working",
    explanation: {
      whyCorrectAr: "نستخدم working بعد Will she have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_42",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "هل سيكونون قد تدربوا من أجل المسابقة لعدة أشهر بحلول الأسبوع القادم؟",
    sentenceWithBlank: "Will they have been _______ for the competition for months by next week?",
    options: [
      "train",
      "trains",
      "training",
      "trained"
],
    correctAnswer: "training",
    explanation: {
      whyCorrectAr: "نستخدم training بعد Will they have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_43",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "هل سيكون قد قاد تلك السيارة لفترة طويلة بحلول وقت بيعها؟",
    sentenceWithBlank: "Will he have been _______ that car for a long time by the time he sells it?",
    options: [
      "drive",
      "drives",
      "driving",
      "driven"
],
    correctAnswer: "driving",
    explanation: {
      whyCorrectAr: "نستخدم driving بعد Will he have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_44",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "هل سنكون قد حققنا في تلك القضية معاً لأسابيع بحلول وقت إغلاق الملفات؟",
    sentenceWithBlank: "Will we have been _______ on that case together for weeks by the time files close?",
    options: [
      "investigate",
      "investigates",
      "investigating",
      "investigated"
],
    correctAnswer: "investigating",
    explanation: {
      whyCorrectAr: "نستخدم investigating بعد Will we have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_45",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "كم المدة التي ستكون قد استخدمت فيها ذلك الحاسوب بحلول وقت تعطله العام القادم؟",
    sentenceWithBlank: "How long will you have been _______ that computer by the time it breaks next year?",
    options: [
      "use",
      "uses",
      "using",
      "used"
],
    correctAnswer: "using",
    explanation: {
      whyCorrectAr: "نستخدم using بعد will you have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_46",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "كم المدة التي ستكون قد تعلمت فيها الإسبانية بحلول وقت انتقالها إلى مدريد؟",
    sentenceWithBlank: "How long will she have been _______ Spanish by the time she moves to Madrid?",
    options: [
      "learn",
      "learns",
      "learning",
      "learned"
],
    correctAnswer: "learning",
    explanation: {
      whyCorrectAr: "نستخدم learning بعد will she have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_47",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "لماذا سيكون قد وصل متأخراً كل يوم بحلول وقت تلقيه إنذاراً؟",
    sentenceWithBlank: "Why will he have been _______ late every day by the time he gets a warning?",
    options: [
      "arrive",
      "arrives",
      "arriving",
      "arrived"
],
    correctAnswer: "arriving",
    explanation: {
      whyCorrectAr: "نستخدم arriving بعد will he have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_48",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "عما ستكونون قد تحدثتم بحلول وقت بدء الجدال؟",
    sentenceWithBlank: "What will you have been _______ about by the time the argument starts?",
    options: [
      "talk",
      "talks",
      "talking",
      "talked"
],
    correctAnswer: "talking",
    explanation: {
      whyCorrectAr: "نستخدم talking بعد will you have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_49",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "من سيكون قد طرق الباب لمدة ساعة بحلول وقت فتحنا له؟",
    sentenceWithBlank: "Who will have been _______ the door for an hour by the time we open it?",
    options: [
      "knock",
      "knocks",
      "knocking",
      "knocked"
],
    correctAnswer: "knocking",
    explanation: {
      whyCorrectAr: "نستخدم knocking بعد will have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  },
  {
    id: "fpc_medium_50",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "بحلول مساء الغد، كم المدة التي ستكون قد أقمت فيها هنا؟",
    sentenceWithBlank: "By tomorrow evening, how long will you have been _______ here?",
    options: [
      "stay",
      "stays",
      "staying",
      "stayed"
],
    correctAnswer: "staying",
    explanation: {
      whyCorrectAr: "نستخدم staying بعد will you have been.",
      temporalRelationshipAr: "حدث مستمر في المستقبل لفترة زمنية محددة حتى نقطة زمنية معينة أو حدث آخر.",
      whyTenseFitsAr: "المستقبل التام المستمر (Future Perfect Continuous) يُستخدم للتعبير عن استمرار وقوع الفعل لمدة زمنية حتى موعد مستقبلي محدد (will have been + V-ing).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام المستمر (will have been + verb-ing).",
      confusableTenseAr: "Future Continuous / Future Perfect / Present Perfect Continuous"
    }
  }
];
