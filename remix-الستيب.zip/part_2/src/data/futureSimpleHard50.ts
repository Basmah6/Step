import { QuizQuestion } from '../types';

export const FUTURE_SIMPLE_HARD_50: QuizQuestion[] = [
  {
    "id": "fs_hard_1",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ستبحث الشرطة عن اللص غداً.",
    "sentenceWithBlank": "The police _______ search for the thief tomorrow.",
    "options": [
      "catches",
      "will",
      "catching",
      "catch"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "كلمة Police تُعامل معاملة الجمع وتأخذ الفعل المساعد will في المستقبل البسيط.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_2",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ستكون مادة الرياضيات مادتي المفضلة العام القادم.",
    "sentenceWithBlank": "Mathematics _______ be my favorite subject next year.",
    "options": [
      "were",
      "will",
      "am",
      "be"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "أسماء المواد الدراسية (Mathematics) مفردة دائماً وتأخذ will be في المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_3",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ستكون خمسون دولاراً مبلغاً كبيراً لدفعه مقابل ذلك القميص غداً.",
    "sentenceWithBlank": "Fifty dollars _______ be too much to pay for that shirt tomorrow.",
    "options": [
      "were",
      "will",
      "am",
      "be"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "المبالغ المالية تُعامل كوحدة واحدة وتأخذ will be في المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_4",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ستتناول عائلتي عشاءً كبيراً معاً الأحد القادم.",
    "sentenceWithBlank": "My family _______ have a big dinner together next Sunday.",
    "options": [
      "eat",
      "will",
      "eating",
      "eaten"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "الاسم الجماعي (family) كوحدة واحدة يأخذ will have في المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_5",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون الأرز والفاصولياء طبقاً مشهوراً جداً في وليمة الغد.",
    "sentenceWithBlank": "Rice and beans _______ be a very popular dish at tomorrow's feast.",
    "options": [
      "was",
      "will",
      "am",
      "be"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "في المستقبل البسيط نستخدم will be سواء كان الفاعل مفرداً أو معطوفاً.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_6",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون كل طالب وكل معلم مطالباً بحضور الاجتماع غداً.",
    "sentenceWithBlank": "Every student and every teacher _______ required to attend the meeting tomorrow.",
    "options": [
      "were",
      "will be",
      "had",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "عندما يسبق الفاعل بـ Every فإن التعبير المستقبلي للمبني للمجهول هو will be required.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_7",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "لا المعلم ولا الطلاب سيعرفون الإجابة غداً.",
    "sentenceWithBlank": "Neither the teacher nor the students _______ know the answer tomorrow.",
    "options": [
      "knows",
      "will",
      "known",
      "knowing"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "في قاعدة Neither... nor للمستقبل البسيط نستخدم الفعل المساعد will مع المصدر know.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_8",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "لا الطلاب ولا المعلم سيعرف الإجابة غداً.",
    "sentenceWithBlank": "Neither the students nor the teacher _______ know the answer tomorrow.",
    "options": [
      "will",
      "know",
      "knowing",
      "known"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للمستقبل البسيط لجميع حالات الفاعل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_9",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيغادر طاقم العمل مكاتبهم في الساعة 5 مساءً غداً.",
    "sentenceWithBlank": "The staff _______ leave their offices at 5 PM tomorrow.",
    "options": [
      "leave",
      "will",
      "leaving",
      "leaves"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "اسم الجمع (staff) يأخذ will leave للتعبير عن حدث مستقبلي.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_10",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيتأخر عدد من الطلاب عن الفصل غداً.",
    "sentenceWithBlank": "A number of students _______ be late for class tomorrow.",
    "options": [
      "was",
      "will",
      "am",
      "be"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "عبارة A number of تعني العديد من وتأخذ will be في المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_11",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سأريدك أن تفهم أهمية القاعدة غداً.",
    "sentenceWithBlank": "I _______ want you to understand the importance of the rule tomorrow.",
    "options": [
      "was wanting",
      "wanting",
      "will",
      "wants"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "أفعال الرغبة والشعور (want) لا تقبل الاستمرار وتصرف في المستقبل البسيط بـ will want.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_12",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيعود ذلك الحاسوب المحمول باهظ الثمن إلى أخي العام القادم.",
    "sentenceWithBlank": "That expensive laptop _______ belong to my brother next year.",
    "options": [
      "will be belonging",
      "will",
      "belong",
      "belonging"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "الفعل belong من أفعال الملكية التقريرية ولا يستخدم في الاستمرار، بل المستقبل البسيط will belong.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_13",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ستؤمن بأن الصدق هو أفضل سياسة.",
    "sentenceWithBlank": "She _______ believe that honesty is the best policy.",
    "options": [
      "will",
      "is believing",
      "believe",
      "believing"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "الفعل believe فعل حالة يعبر عن الاعتقاد المستقبلي بـ will believe.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_14",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ستفوح رائحة تلك الزهور بشكل رائع في الحديقة الربيع القادم.",
    "sentenceWithBlank": "Those flowers _______ smell wonderful in the garden next spring.",
    "options": [
      "smelling",
      "will be smelling",
      "will",
      "smells"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "الفعل smell كفعل حواس وحالة يأخذ المستقبل البسيط will smell.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_15",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سأعرف الإجابة بحلول الغد.",
    "sentenceWithBlank": "I _______ know the answer by tomorrow.",
    "options": [
      "will",
      "am knowing",
      "know",
      "knowing"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "فعل الإدراك know لا يقبل الاستمرار، ويصاغ بـ will know.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_16",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيحتوي الطرد على ثلاثة كتب ودفتر ملاحظات عندما يصل.",
    "sentenceWithBlank": "The package _______ contain three books and a notebook when it arrives.",
    "options": [
      "contain",
      "will",
      "containing",
      "contains"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "الفعل contain فعل حالة احتواء، ويصاغ في المستقبل البسيط بـ will contain.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_17",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "هل ستتذكر ما يقوله المعلم غداً؟",
    "sentenceWithBlank": "Will you _______ what the teacher says tomorrow?",
    "options": [
      "remembered",
      "remember",
      "remembers",
      "remembering"
    ],
    "correctAnswer": "remember",
    "explanation": {
      "whyCorrectAr": "بعد الفعل المساعد Will يأتي الفعل الرئيسي مجرداً في المصدر (remember).",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_18",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيبدو هذا الحل الخيار الأفضل لدينا العام القادم.",
    "sentenceWithBlank": "This solution _______ seem to be the best option we have next year.",
    "options": [
      "seem",
      "will",
      "seeming",
      "seems"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "الفعل seem من أفعال الحالة التقريرية ويصرف بـ will seem.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_19",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سنفهم الفروق بين النظريتين غداً.",
    "sentenceWithBlank": "We _______ understand the differences between the two theories tomorrow.",
    "options": [
      "will",
      "understands",
      "will be understanding",
      "understand"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "أفعال الفهم والإدراك (understand) تأخذ المستقبل البسيط will understand.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_20",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كم ستكون قيمة تلك المجموعة من العملات القديمة العام القادم؟",
    "sentenceWithBlank": "How much _______ that collection of ancient coins be worth next year?",
    "options": [
      "did",
      "does",
      "were",
      "will"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "الفعل المرتبط بالقيمة المستقبلية مع next year يتطلب will be.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_21",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "لن يكون أبداً متأخراً عن محاضراته الصباحية غداً.",
    "sentenceWithBlank": "He _______ be late for his morning lectures tomorrow.",
    "options": [
      "will never",
      "never will",
      "did never",
      "is never"
    ],
    "correctAnswer": "will never",
    "explanation": {
      "whyCorrectAr": "ظرف التكرار never يأتي بعد الفعل المساعد will وقبل be (will never be).",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_22",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "نادراً ما ستقرأ كتب الخيال أثناء الرحلة الأسبوع القادم.",
    "sentenceWithBlank": "She _______ read fiction books during the flight next week.",
    "options": [
      "seldom will",
      "will rarely",
      "did seldom",
      "was seldom"
    ],
    "correctAnswer": "will rarely",
    "explanation": {
      "whyCorrectAr": "ظرف التكرار rarely يأتي بعد will وقبل الفعل الأساسي read (will rarely read).",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_23",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "هو لن يعمل بجد العام القادم فحسب، بل سيساعد الآخرين أيضاً.",
    "sentenceWithBlank": "He will not only work hard next year, but he also _______ help others.",
    "options": [
      "help",
      "will",
      "helping",
      "helps"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "التوافق والتوازي النحوي في المستقبل البسيط يتطلب will help.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_24",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "نادراً ما سينهي أي شخص ذلك الاختبار الصعب للغاية غداً.",
    "sentenceWithBlank": "Rarely _______ anyone finish that extremely difficult test tomorrow.",
    "options": [
      "did",
      "does",
      "will",
      "was"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "عند البدء بظرف نفي (Rarely)، يحدث قلب (Inversion) ونستخدم الفعل المساعد will للمستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_25",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "لن يستمع أبداً للنصيحة الجيدة في المستقبل.",
    "sentenceWithBlank": "Never _______ he listen to good advice in the future.",
    "options": [
      "do",
      "will",
      "was",
      "were"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "تقديم ظرف النفي Never يولد قلباً نحوياً في المستقبل البسيط بـ will.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_26",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "قليلاً ما سيهتم بالعواقب في المستقبل.",
    "sentenceWithBlank": "Little _______ about the consequences in the future.",
    "options": [
      "he will care",
      "will he cared",
      "will he care",
      "care he will"
    ],
    "correctAnswer": "will he care",
    "explanation": {
      "whyCorrectAr": "عند البدء بـ Little النافية يحدث تقديم وتأخير: will + الفاعل he + المصدر care.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_27",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "بمثل هذه السرعة سيمر الوقت خلال إجازتنا الصيف القادم.",
    "sentenceWithBlank": "So fast _______ time pass during our vacation next summer.",
    "options": [
      "do",
      "will",
      "was",
      "were"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "بعد الصيغة التوكيدية المنقلبة، نستخدم الفعل المساعد will للمستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_28",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "فقط في عطلات نهاية الأسبوع سيسترخون ويشاهدون الأفلام العام القادم.",
    "sentenceWithBlank": "Only on weekends _______ they relax and watch movies next year.",
    "options": [
      "does",
      "will",
      "were",
      "was"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "البدء بـ Only on weekends يتطلب قلباً في المستقبل باستخدام will.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_29",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون هناك كتاب، وقلمان، ودفتر ملاحظات على المكتب غداً.",
    "sentenceWithBlank": "There _______ a book, two pens, and a notebook on the desk tomorrow.",
    "options": [
      "will be",
      "will are",
      "am",
      "be"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "مع تركيب There في المستقبل نستخدم دائماً will be بصرف النظر عن المفرد أو الجمع.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_30",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون هناك قلمان، وكتاب، ودفتر ملاحظات على المكتب غداً.",
    "sentenceWithBlank": "There _______ two pens, a book, and a notebook on the desk tomorrow.",
    "options": [
      "will is",
      "will be",
      "am",
      "be"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "في المستقبل مع There نستخدم دائماً will be لجميع الأسماء.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_31",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "إذا وصل الماء إلى 100 درجة مئوية غداً، فإنه سيغلي.",
    "sentenceWithBlank": "If water _______ 100 degrees Celsius tomorrow, it will boil.",
    "options": [
      "reach",
      "reaches",
      "reaching",
      "reached"
    ],
    "correctAnswer": "reaches",
    "explanation": {
      "whyCorrectAr": "الحالة الشرطية الأولى تستخدم المضارع البسيط (reaches) في جملة الشرط مع فاعل مفرد.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_32",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ما لم يجتهد في الفصل الدراسي القادم، فسيرسب في الامتحان.",
    "sentenceWithBlank": "Unless he _______ hard next term, he will fail the exam.",
    "options": [
      "try",
      "tries",
      "trying",
      "tried"
    ],
    "correctAnswer": "tries",
    "explanation": {
      "whyCorrectAr": "أداة الشرط Unless يتبعها مضارع بسيط مثبت (tries) مع الفاعل المفرد he.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_33",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "بمجرد أن تصل إلى المنزل غداً، ستتصل بوالدتها.",
    "sentenceWithBlank": "As soon as she _______ home tomorrow, she will call her mother.",
    "options": [
      "arrive",
      "arrives",
      "arriving",
      "arrived"
    ],
    "correctAnswer": "arrives",
    "explanation": {
      "whyCorrectAr": "الروابط الزمنية للمستقبل (As soon as) تتبعها جملة مضارع بسيط (arrives) وليس مستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_34",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "بشرط أن يكون الطقس جيداً السبت القادم، سنذهب في نزهة.",
    "sentenceWithBlank": "Provided that the weather _______ fine next Saturday, we will go for a picnic.",
    "options": [
      "be",
      "is",
      "were",
      "am"
    ],
    "correctAnswer": "is",
    "explanation": {
      "whyCorrectAr": "في جملة الشرط بـ Provided that نستخدم المضارع البسيط (is) مع المفرد the weather.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_35",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "في حال احتجت إلى أي مساعدة غداً، سأكون مستعداً.",
    "sentenceWithBlank": "In case you _______ any help tomorrow, I will be ready.",
    "options": [
      "needs",
      "need",
      "needing",
      "needed"
    ],
    "correctAnswer": "need",
    "explanation": {
      "whyCorrectAr": "في جملة الشرط الاحترازي بـ In case نستخدم المضارع البسيط (need) مع you.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_36",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "أينما تذهب، ستكوّن صداقات بسهولة أثناء رحلاتها.",
    "sentenceWithBlank": "Wherever she _______, she will make friends easily during her travels.",
    "options": [
      "go",
      "goes",
      "going",
      "went"
    ],
    "correctAnswer": "goes",
    "explanation": {
      "whyCorrectAr": "جملة المكان والشرط بـ Wherever تأخذ مضارعاً بسيطاً (goes) مع المفرد she.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_37",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "حتى يصل المدير غداً، لن يدخل أحد إلى المكتب.",
    "sentenceWithBlank": "Until the manager _______ tomorrow, no one will enter the office.",
    "options": [
      "arrive",
      "arrives",
      "arriving",
      "arrived"
    ],
    "correctAnswer": "arrives",
    "explanation": {
      "whyCorrectAr": "الرابط الزمني Until يتبعه مضارع بسيط (arrives) مع الفاعل المفرد.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_38",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سواء أمطرت أو سطعت الشمس عطلة نهاية الأسبوع القادمة، ستقام المباراة.",
    "sentenceWithBlank": "Whether it _______ or shines next weekend, the match will take place.",
    "options": [
      "rain",
      "rains",
      "raining",
      "rained"
    ],
    "correctAnswer": "rains",
    "explanation": {
      "whyCorrectAr": "التعبير الثابت Whether it rains or shines يستخدم المضارع البسيط مع it.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_39",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "مهما حدث غداً، سيظل مبتسماً.",
    "sentenceWithBlank": "No matter what _______ tomorrow, he will keep smiling.",
    "options": [
      "happen",
      "happens",
      "happening",
      "happened"
    ],
    "correctAnswer": "happens",
    "explanation": {
      "whyCorrectAr": "التعبير No matter what يتبعه فعل مضارع بسيط مفرد (happens).",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_40",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "بافتراض أن حركة المرور ستكون مزدحمة غداً، كيف ستصل إلى العمل؟",
    "sentenceWithBlank": "Supposing that traffic _______ heavy tomorrow, how will you get to work?",
    "options": [
      "be",
      "were",
      "is",
      "am"
    ],
    "correctAnswer": "is",
    "explanation": {
      "whyCorrectAr": "في جملة الافتراض الشرطي Supposing that نستخدم المضارع البسيط (is) مع الاسم غير المعدود traffic.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_41",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيتسلم كل من المشاركين شهادة تقدير الشهر القادم.",
    "sentenceWithBlank": "Each of the participants _______ receive a certificate of appreciation next month.",
    "options": [
      "receives",
      "will",
      "receiving",
      "received"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "في المستقبل البسيط مع next month نستخدم will متبوعة بالمصدر receive.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_42",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون أي من الخيارين مقبولاً لدى اللجنة العام القادم.",
    "sentenceWithBlank": "Either of the two options _______ be acceptable to the committee next year.",
    "options": [
      "are",
      "will",
      "am",
      "be"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will be للدلالة على المستقبل مع Either of the two options.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_43",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ستُنفق نسبة كبيرة من الميزانية على التعليم العام القادم.",
    "sentenceWithBlank": "A large percentage of the budget _______ be spent on education next year.",
    "options": [
      "were",
      "will",
      "am",
      "be"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "صيغة المبني للمجهول في المستقبل مع next year تتطلب will be spent.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_44",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ستكون عشرة كيلومترات مسافة طويلة للمشي أثناء رحلة الغد.",
    "sentenceWithBlank": "Ten kilometers _______ be a long distance to walk during tomorrow's hike.",
    "options": [
      "were",
      "will",
      "am",
      "be"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "المسافات تُعامل كوحدة واحدة وتأخذ will be في المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_45",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون علم الفيزياء معقداً للطلاب الذين لا يدرسون بانتظام.",
    "sentenceWithBlank": "Physics _______ be complicated for students who do not study regularly.",
    "options": [
      "were",
      "will",
      "am",
      "be"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "أسماء العلوم والفيزياء مفردة وتأخذ will be للتعبير عن النتيجة المستقبلية.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_46",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ستتخذ هيئة المحلفين قراراً غداً بعد المناقشة.",
    "sentenceWithBlank": "The jury _______ make a decision tomorrow after debate.",
    "options": [
      "makes",
      "will",
      "making",
      "made"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "هيئة المحلفين كوحدة واحدة ستتخذ قراراً في المستقبل مع will make.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_47",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون الخبز والزبدة ما أتناوله عادة في وجبة الإفطار.",
    "sentenceWithBlank": "Bread and butter _______ be what I usually have for breakfast.",
    "options": [
      "will",
      "were",
      "am",
      "be"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "الوجبة الواحدة المشتركة تأخذ will be في المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_48",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون أكثر من شخص مسؤولاً عن ذلك الخطأ في المرة القادمة.",
    "sentenceWithBlank": "More than one person _______ be responsible for that mistake next time.",
    "options": [
      "were",
      "will",
      "am",
      "be"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "التركيب More than one person يأخذ will be في المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_49",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيدرس العديد من الطلاب اللغة الإنجليزية كلغة ثانية في الفصل القادم.",
    "sentenceWithBlank": "Many a student _______ study English as a second language next term.",
    "options": [
      "study",
      "will",
      "studying",
      "studies"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "التعبير البلاغي Many a student يتبعه will study في المستقبل البسيط.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_hard_50",
    "tenseId": "future_simple",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ماذا ستقول الأخبار عن الانتخابات غداً؟",
    "sentenceWithBlank": "What _______ the news say about the election tomorrow?",
    "options": [
      "did",
      "does",
      "were",
      "will"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للسؤال عن الأخبار في المستقبل مع tomorrow.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  }
];
