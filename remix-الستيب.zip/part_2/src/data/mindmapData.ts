import { AspectCategory, TimeCategory } from '../types';

export interface AspectMindmapNode {
  aspect: AspectCategory;
  nameAr: string;
  nameEn: string;
  corePhilosophyAr: string;
  mentalKeywordAr: string;
  icon: string;
  color: string;
  timeVariants: {
    time: TimeCategory;
    tenseId: string;
    formulaShort: string;
    mentalAnchorAr: string;
    sampleSentence: string;
    sampleTranslationAr: string;
  }[];
}

export const MINDMAP_ASPECTS: AspectMindmapNode[] = [
  {
    aspect: 'simple',
    nameAr: 'البسيط (Simple)',
    nameEn: 'Simple Aspect',
    corePhilosophyAr: 'حدث ككتلة واحدة مكتملة، عادة، حقيقة، أو قرار.',
    mentalKeywordAr: 'حدث / عادة / حقيقة ثابته',
    icon: 'Zap',
    color: 'emerald',
    timeVariants: [
      {
        time: 'past',
        tenseId: 'past_simple',
        formulaShort: 'V2 (ed / irregular)',
        mentalAnchorAr: 'حدث وانتهى تماماً في نقطة ماضية مقفلة.',
        sampleSentence: 'I worked yesterday.',
        sampleTranslationAr: 'عملتُ أمس (وانتهى).',
      },
      {
        time: 'present',
        tenseId: 'present_simple',
        formulaShort: 'Verb(s/base)',
        mentalAnchorAr: 'عادة متكررة أو حقيقة ثابتة في الحياة.',
        sampleSentence: 'I work every day.',
        sampleTranslationAr: 'أنا أعمل كل يوم (عادة ثابتة).',
      },
      {
        time: 'future',
        tenseId: 'future_simple',
        formulaShort: 'will + base',
        mentalAnchorAr: 'قرار فوري، توقع، أو وعد قادم.',
        sampleSentence: 'I will work tomorrow.',
        sampleTranslationAr: 'سأعمل غداً (قرار أو وعد).',
      },
    ],
  },
  {
    aspect: 'continuous',
    nameAr: 'المستمر (Continuous)',
    nameEn: 'Continuous Aspect',
    corePhilosophyAr: 'نافذة زمنية مفتوحة: الحدث في منتصف الحدوث ولم يكتمل بعد.',
    mentalKeywordAr: 'نشاط جاري ومستمر',
    icon: 'Activity',
    color: 'cyan',
    timeVariants: [
      {
        time: 'past',
        tenseId: 'past_continuous',
        formulaShort: 'was / were + V-ing',
        mentalAnchorAr: 'كنت في منتصف الحدث عندما قاطعني شيء ماض.',
        sampleSentence: 'I was working at 4 PM.',
        sampleTranslationAr: 'كنت أعمل في الرابعة عصراً أمس (وسط العمل).',
      },
      {
        time: 'present',
        tenseId: 'present_continuous',
        formulaShort: 'am / is / are + V-ing',
        mentalAnchorAr: 'الحدث قيد الجريان الآن في هذه اللحظة.',
        sampleSentence: 'I am working right now.',
        sampleTranslationAr: 'أنا أعمل الآن في هذه اللحظة بالذات.',
      },
      {
        time: 'future',
        tenseId: 'future_continuous',
        formulaShort: 'will be + V-ing',
        mentalAnchorAr: 'سأكون في منتصف الحدث في تلك الساعة القادمة.',
        sampleSentence: 'I will be working at 4 PM tomorrow.',
        sampleTranslationAr: 'سأكون أعمل في الرابعة عصراً غداً (وسط النشاط).',
      },
    ],
  },
  {
    aspect: 'perfect',
    nameAr: 'التام (Perfect)',
    nameEn: 'Perfect Aspect',
    corePhilosophyAr: 'حدث مكتمل قبل نقطة مرجعية زمنية محددة (قبل الآن، قبل الماضي، أو قبل المستقبل).',
    mentalKeywordAr: 'حدث قبل نقطة زمنية',
    icon: 'Sparkles',
    color: 'amber',
    timeVariants: [
      {
        time: 'past',
        tenseId: 'past_perfect',
        formulaShort: 'had + V3',
        mentalAnchorAr: 'اكتمل قبل نقطة أو حدث ماضٍ آخر (ماضي الماضي).',
        sampleSentence: 'I had worked before he called.',
        sampleTranslationAr: 'كنت قد عملت قبل أن يتصل بي في الماضي.',
      },
      {
        time: 'present',
        tenseId: 'present_perfect',
        formulaShort: 'have / has + V3',
        mentalAnchorAr: 'اكتمل قبل نقطة الحاضر وأثره أو نتيجته ملموسة الآن.',
        sampleSentence: 'I have worked here for years.',
        sampleTranslationAr: 'لقد عملت هنا لسنوات (وتجربتي باقية في الحاضر).',
      },
      {
        time: 'future',
        tenseId: 'future_perfect',
        formulaShort: 'will have + V3',
        mentalAnchorAr: 'سيكتمل تماماً قبل حلول موعد نهائي قادم (By).',
        sampleSentence: 'I will have worked 8 hours by 5 PM.',
        sampleTranslationAr: 'سأكون قد أنهيت عمل 8 ساعات بحلول الخامسة مساء.',
      },
    ],
  },
  {
    aspect: 'perfect_continuous',
    nameAr: 'التام المستمر (Perfect Continuous)',
    nameEn: 'Perfect Continuous Aspect',
    corePhilosophyAr: 'مقياس عداد المدة الزمنية: استمرار نشاط متواصل طوال مدة محددة حتى نقطة زمنية.',
    mentalKeywordAr: 'استمرار لمدة حتى نقطة زمنية',
    icon: 'Hourglass',
    color: 'violet',
    timeVariants: [
      {
        time: 'past',
        tenseId: 'past_perfect_continuous',
        formulaShort: 'had been + V-ing',
        mentalAnchorAr: 'استمر طوال مدة محددة في الماضي قبل أن يقطعه حدث ماض.',
        sampleSentence: 'I had been working for 3 hours before dinner.',
        sampleTranslationAr: 'كنت أعمل لمدة 3 ساعات قبل العشاء في الماضي.',
      },
      {
        time: 'present',
        tenseId: 'present_perfect_continuous',
        formulaShort: 'have / has been + V-ing',
        mentalAnchorAr: 'استمر طوال مدة محددة من الماضي وما زال متواصلاً إلى الحاضر.',
        sampleSentence: 'I have been working for 3 hours.',
        sampleTranslationAr: 'أنا أعمل منذ 3 ساعات وما زلت أعمل حتى الآن.',
      },
      {
        time: 'future',
        tenseId: 'future_perfect_continuous',
        formulaShort: 'will have been + V-ing',
        mentalAnchorAr: 'سيصل مجموع مدة استمراره إلى قدر محدد عند موعد مستقبلي.',
        sampleSentence: 'By 5 PM, I will have been working for 8 hours.',
        sampleTranslationAr: 'بحلول الخامسة سأكون قد استمررت في العمل لـ 8 ساعات متواصلة.',
      },
    ],
  },
];

export interface ConfusingTenseDeepDive {
  tenseId: string;
  nameEn: string;
  nameAr: string;
  whyItConfusesAr: string;
  mentalShortcutAr: string;
  temporalVisualAr: string;
  formulaVisual: {
    auxiliary: string;
    mainVerb: string;
    logicAr: string;
  };
  matrixComparisons: {
    rivalTenseName: string;
    differentiatingClueAr: string;
    rivalSentence: string;
    targetSentence: string;
    theMindShiftAr: string;
  }[];
}

export const CONFUSING_TENSES_DEEP_DIVE: ConfusingTenseDeepDive[] = [
  {
    tenseId: 'present_perfect',
    nameEn: 'Present Perfect',
    nameAr: 'المضارع التام (have / has + V3)',
    whyItConfusesAr: 'يخلط الطلاب بينه وبين الماضي البسيط لأن كلاهما حدث في الماضي، فينسون أن المضارع التام عينه دائماً على الحاضر ونتائجه.',
    mentalShortcutAr: '«الماضي ذو الوجه الحاضر» — لا يهم متى وقع، بل يهم أثره وتجربته في هذه اللحظة!',
    temporalVisualAr: 'حدث في الماضي  ───────⚡──────>  النتيجة/الأثر في الحاضر',
    formulaVisual: {
      auxiliary: 'have / has (علامة الحاضر)',
      mainVerb: 'Past Participle V3 (علامة الإتمام)',
      logicAr: 'فعل اكتمل في الماضي (V3) مربوط بأداة مساعدة في الحاضر (have/has).',
    },
    matrixComparisons: [
      {
        rivalTenseName: 'Past Simple (الماضي البسيط)',
        differentiatingClueAr: 'هل الوقت ماضٍ محدد (yesterday, 2010) أم تجربة غير مؤرخة وأثر حاضر؟',
        rivalSentence: 'I lost my keys yesterday, but I found them. (Past Simple - منتهٍ)',
        targetSentence: 'I have lost my keys! I can’t open the door. (Present Perfect - الأثر حاضر الآن)',
        theMindShiftAr: 'إذا كنت لا تستطيع دخول البيت الآن بسبب الضياع، فهو Present Perfect. إذا وجدتها وانتهت القصة، فهو Past Simple.',
      },
    ],
  },
  {
    tenseId: 'past_perfect',
    nameEn: 'Past Perfect',
    nameAr: 'الماضي التام (had + V3)',
    whyItConfusesAr: 'يستخدمه البعض عشوائياً لأي شيء قديم جداً، بينما وظيفته الوحيدة هي "ترتيب أسبقية حدثين ماضيين".',
    mentalShortcutAr: '«ماضي الماضي» — لا وجود له بمفرده في الفضاء، بل يأتي ليقول: أنا وقعت أولاً قبل الحدث الماضي الآخر!',
    temporalVisualAr: 'الحدث 1 (had + V3)  ───>  الحدث 2 (V2 بسيط)  ───>  نقطة الحاضر (الآن)',
    formulaVisual: {
      auxiliary: 'had (ماضي have)',
      mainVerb: 'Past Participle V3',
      logicAr: 'إرجاع الزمن خطوة أبعد إلى الوراء قبل حدث ماضٍ آخر.',
    },
    matrixComparisons: [
      {
        rivalTenseName: 'Past Simple (الماضي البسيط المتتالي)',
        differentiatingClueAr: 'هل الأحداث وراء بعضها مباشرة أم أن أحدها كان منتهياً وجاهزاً قبل وصول الثاني؟',
        rivalSentence: 'When he arrived, the film started. (وصل ثم بدأ الفيلم فوراً - شاهده من أوله)',
        targetSentence: 'When he arrived, the film had started. (وصل وقد بدأ الفيلم مسبقاً - فاتته البداية)',
        theMindShiftAr: 'استخدم had فقط عندما تريد أن تقول: الحدث كان قد انتهى بالفعل قبل وقوع الحدث الثاني.',
      },
    ],
  },
  {
    tenseId: 'future_continuous',
    nameEn: 'Future Continuous',
    nameAr: 'المستقبل المستمر (will be + V-ing)',
    whyItConfusesAr: 'يخلط الطلاب بينه وبين المستقبل البسيط لأن كلاهما في الغد، ولا يتخيلون المشهد السينمائي للحدث في لحظة معينة.',
    mentalShortcutAr: '«كاميرا المراقبة في المستقبل» — في تمام الساعة كذا غداً، ماذا ستراك الكاميرا وأنت في منتصف فعله؟',
    temporalVisualAr: 'الآن  ───────>  [ ─── الحدث جاري ومستمر ─── ] عند الساعة 8 مساء غداً',
    formulaVisual: {
      auxiliary: 'will be',
      mainVerb: 'Verb-ing (علامة الحركة والاستمرار)',
      logicAr: 'تصوير نشاط حي سيكون قيد التنفيذ عند توقيت محدد.',
    },
    matrixComparisons: [
      {
        rivalTenseName: 'Future Perfect (المستقبل التام)',
        differentiatingClueAr: 'كلمة At (وسط الحدث) مقابل كلمة By (اكتمال قبل الموعد)',
        rivalSentence: 'By 8 PM, I will have finished my homework. (سأكون قد أنهيته تماماً)',
        targetSentence: 'At 8 PM, I will be doing my homework. (سأكون في منتصف حله)',
        theMindShiftAr: 'At تعني أنك وسط الفعل في تلك اللحظة؛ By تعني أنك ستنتهي منه قبل أن تدق تلك الساعة.',
      },
    ],
  },
  {
    tenseId: 'future_perfect_continuous',
    nameEn: 'Future Perfect Continuous',
    nameAr: 'المستقبل التام المستمر (will have been + V-ing)',
    whyItConfusesAr: 'تركيبه يبدو طويلاً ومرعباً للطلاب، لكن فكرته شديدة البساطة: "عداد الساعات والسنوات عند بلوغ محطة قادمة".',
    mentalShortcutAr: '«عداد المسافات الزمني» — عندما نصل لمحطة العام القادم، كم سيكون العداد قد سجل من ساعات أو سنوات؟',
    temporalVisualAr: 'بداية النشاط  ───────(عداد مستمر لسنوات)───────>  محطة 2030 (نقطة By المستقبلية)',
    formulaVisual: {
      auxiliary: 'will have been',
      mainVerb: 'Verb-ing',
      logicAr: 'By (المستقبل) + have been (التراكم) + ing (الاستمرار).',
    },
    matrixComparisons: [
      {
        rivalTenseName: 'Present Perfect Continuous (المضارع التام المستمر)',
        differentiatingClueAr: 'هل تقيس المدة حتى "الآن" أم حتى "موعد في المستقبل"؟',
        rivalSentence: 'I have been working here for 5 years. (المدة حتى هذه اللحظة الحالية = 5 سنوات)',
        targetSentence: 'By next year, I will have been working here for 6 years. (المدة المقاسة عند محطة العام القادم = 6 سنوات)',
        theMindShiftAr: 'إذا كانت نقطة القياس هي اليوم، استخدم have been؛ وإذا كنت تقيس العداد عند تاريخ مستقبلي مسبوق بـ By، استخدم will have been.',
      },
    ],
  },
];
