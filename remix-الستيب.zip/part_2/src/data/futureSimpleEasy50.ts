import { QuizQuestion } from '../types';

export const FUTURE_SIMPLE_EASY_50: QuizQuestion[] = [
  {
    "id": "fs_easy_1",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سأسافر إلى لندن غداً.",
    "sentenceWithBlank": "I _______ travel to London tomorrow.",
    "options": [
      "will",
      "will be",
      "am",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will متبوعة بالفعل في المصدر (travel) للتعبير عن قرار أو حدث مستقبلي بسيط.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_2",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستنهي مشروعها الأسبوع القادم.",
    "sentenceWithBlank": "She _______ finish her project next week.",
    "options": [
      "will to",
      "will",
      "is",
      "does"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "الفعل المساعد will يأتي متبوعاً بالمصدر مباشرة دون to.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_3",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيلعبون كرة القدم يوم الجمعة.",
    "sentenceWithBlank": "They _______ play football on Friday.",
    "options": [
      "wills",
      "will",
      "are",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "الفعل will لا يضاف له s مع أي ضمير.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_4",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيشتري سيارة جديدة قريباً.",
    "sentenceWithBlank": "He _______ buy a new car soon.",
    "options": [
      "will to",
      "will",
      "is",
      "does"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will متبوعة بالمصدر buy للتعبير عن المستقبل البسيط.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_5",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سنزور أجدادنا الشهر القادم.",
    "sentenceWithBlank": "We _______ visit our grandparents next month.",
    "options": [
      "wills",
      "will",
      "are",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "الفعل المساعد will يعبر عن نية أو تخطيط في المستقبل البسيط مع المصدر visit.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_6",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستجتاز الامتحان إذا درست.",
    "sentenceWithBlank": "You _______ pass the exam if you study.",
    "options": [
      "wills",
      "will",
      "are",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "في جواب الشرط البسيط نستخدم will + المصدر pass.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_7",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستشرق الشمس غداً في الساعة 6 صباحاً.",
    "sentenceWithBlank": "The sun _______ rise tomorrow at 6 AM.",
    "options": [
      "wills",
      "will",
      "is",
      "does"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "للتعبير عن حقائق وتوقعات مستقبلية نستخدم will + المصدر rise.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_8",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستطير الطيور جنوباً في فصل الشتاء.",
    "sentenceWithBlank": "Birds _______ fly south for the winter.",
    "options": [
      "wills",
      "will",
      "are",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للدلالة على حدث مستقبلي مع الفاعل الجمع birds.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_9",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستحب قطتي اللعبة الجديدة.",
    "sentenceWithBlank": "My cat _______ like the new toy.",
    "options": [
      "wills",
      "will",
      "is",
      "does"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للتنبؤ بالمستقبل مع المصدر like.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_10",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيتجمد الماء إذا انخفضت درجة الحرارة إلى ما دون الصفر.",
    "sentenceWithBlank": "Water _______ freeze if the temperature drops below zero.",
    "options": [
      "wills",
      "will",
      "is",
      "does"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للتعبير عن نتيجة مستقبلية متوقعة مع المصدر freeze.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_11",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لن أذهب إلى الحفلة غداً.",
    "sentenceWithBlank": "I _______ go to the party tomorrow.",
    "options": [
      "don't",
      "doesn't",
      "aren't",
      "won't"
    ],
    "correctAnswer": "won't",
    "explanation": {
      "whyCorrectAr": "نفي المستقبل البسيط هو will not واختصاره won't.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_12",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لن تلعب التنس غداً.",
    "sentenceWithBlank": "She _______ play tennis tomorrow.",
    "options": [
      "don't",
      "doesn't",
      "isn't",
      "won't"
    ],
    "correctAnswer": "won't",
    "explanation": {
      "whyCorrectAr": "نستخدم won't لنفي حدوث الفعل play في المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_13",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لن يشاهدوا التلفاز الليلة.",
    "sentenceWithBlank": "They _______ watch TV tonight.",
    "options": [
      "doesn't",
      "won't",
      "aren't",
      "isn't"
    ],
    "correctAnswer": "won't",
    "explanation": {
      "whyCorrectAr": "نستخدم won't لنفي المستقبل البسيط لجميع الضمائر.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_14",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لن يتحدث الفرنسية بطلاقة العام القادم.",
    "sentenceWithBlank": "He _______ speak French fluently next year.",
    "options": [
      "don't",
      "won't",
      "isn't",
      "aren't"
    ],
    "correctAnswer": "won't",
    "explanation": {
      "whyCorrectAr": "نستخدم won't لنفي المستقبل مع الفاعل المفرد he.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_15",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لن نذهب إلى المدرسة يوم السبت.",
    "sentenceWithBlank": "We _______ go to school on Saturday.",
    "options": [
      "doesn't",
      "won't",
      "aren't",
      "isn't"
    ],
    "correctAnswer": "won't",
    "explanation": {
      "whyCorrectAr": "نستخدم won't لنفي الحدث المستقبلي.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_16",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لن يعضك الكلب.",
    "sentenceWithBlank": "The dog _______ bite you.",
    "options": [
      "don't",
      "won't",
      "isn't",
      "aren't"
    ],
    "correctAnswer": "won't",
    "explanation": {
      "whyCorrectAr": "نستخدم won't للتعبير عن طمأنينة وتوقع عدم حدوث الفعل في المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_17",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لن تأكل كل ذلك الطعام.",
    "sentenceWithBlank": "You _______ eat all that food.",
    "options": [
      "doesn't",
      "won't",
      "aren't",
      "isn't"
    ],
    "correctAnswer": "won't",
    "explanation": {
      "whyCorrectAr": "نستخدم won't لنفي المستقبل البسيط.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_18",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "علي وأحمد لن يحضرا إلى الاجتماع.",
    "sentenceWithBlank": "Ali and Ahmed _______ come to the meeting.",
    "options": [
      "doesn't",
      "won't",
      "aren't",
      "isn't"
    ],
    "correctAnswer": "won't",
    "explanation": {
      "whyCorrectAr": "نستخدم won't لنفي المستقبل مع الفاعل الجمع.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_19",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لن تمطر غداً وفقاً للنشرة الجوية.",
    "sentenceWithBlank": "It _______ rain tomorrow according to the forecast.",
    "options": [
      "don't",
      "won't",
      "isn't",
      "aren't"
    ],
    "correctAnswer": "won't",
    "explanation": {
      "whyCorrectAr": "نستخدم won't لنفي التنبؤ الجوي في المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_20",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "أمي لن تعمل الأحد القادم.",
    "sentenceWithBlank": "My mother _______ work next Sunday.",
    "options": [
      "don't",
      "won't",
      "isn't",
      "aren't"
    ],
    "correctAnswer": "won't",
    "explanation": {
      "whyCorrectAr": "نستخدم won't لنفي الفعل المستقبلي.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_21",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "هل ستساعدني غداً؟",
    "sentenceWithBlank": "_______ you help me tomorrow?",
    "options": [
      "Do",
      "Does",
      "Are",
      "Will"
    ],
    "correctAnswer": "Will",
    "explanation": {
      "whyCorrectAr": "يبدأ السؤال في زمن المستقبل البسيط بـ Will متبوعاً بالفاعل والمصدر.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_22",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "هل ستجتاز اختبار القيادة؟",
    "sentenceWithBlank": "_______ she pass the driving test?",
    "options": [
      "Do",
      "Will",
      "Is",
      "Does"
    ],
    "correctAnswer": "Will",
    "explanation": {
      "whyCorrectAr": "نبدأ السؤال بـ Will للسؤال عن حدث مستقبلي.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_23",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "هل سيفوزون بالمباراة الأسبوع القادم؟",
    "sentenceWithBlank": "_______ they win the match next week?",
    "options": [
      "Does",
      "Will",
      "Are",
      "Do"
    ],
    "correctAnswer": "Will",
    "explanation": {
      "whyCorrectAr": "نستخدم Will للسؤال عن التوقع المستقبلي.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_24",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "هل سيصل في الوقت المحدد غداً؟",
    "sentenceWithBlank": "_______ he arrive on time tomorrow?",
    "options": [
      "Do",
      "Will",
      "Is",
      "Does"
    ],
    "correctAnswer": "Will",
    "explanation": {
      "whyCorrectAr": "نستخدم Will للسؤال في المستقبل البسيط مع الفاعل he.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_25",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "هل سنحتاج إلى مظلة لاحقاً؟",
    "sentenceWithBlank": "_______ we need an umbrella later?",
    "options": [
      "Does",
      "Will",
      "Are",
      "Do"
    ],
    "correctAnswer": "Will",
    "explanation": {
      "whyCorrectAr": "نستخدم Will للسؤال عن المستقبل البسيط.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_26",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "في أي وقت ستستيقظ غداً؟",
    "sentenceWithBlank": "What time _______ you wake up tomorrow?",
    "options": [
      "does",
      "will",
      "are",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "في السؤال بأداة استفهام (Wh-question) للمستقبل، نضع will بعد أداة الاستفهام.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_27",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "أين ستعيش عندما تنتقل إلى الخارج؟",
    "sentenceWithBlank": "Where _______ she live when she moves abroad?",
    "options": [
      "do",
      "will",
      "is",
      "does"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will بعد أداة الاستفهام للسؤال عن المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_28",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "كم مرة ستمطر في الموسم القادم؟",
    "sentenceWithBlank": "How often _______ it rain next season?",
    "options": [
      "do",
      "will",
      "is",
      "does"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will بعد How often للسؤال عن تكرار الحدث المستقبلي.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_29",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لماذا سيكونون متأخرين غداً؟",
    "sentenceWithBlank": "Why _______ they be late tomorrow?",
    "options": [
      "do",
      "does",
      "will",
      "are"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will بعد Why للسؤال عن سبب في المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_30",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "هل سيوصلك والدك بالسيارة إلى العمل غداً؟",
    "sentenceWithBlank": "_______ your father drive you to work tomorrow?",
    "options": [
      "Do",
      "Will",
      "Is",
      "Does"
    ],
    "correctAnswer": "Will",
    "explanation": {
      "whyCorrectAr": "نبدأ السؤال بـ Will للسؤال عن عمل مستقبلي.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_31",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سأكون طالباً العام القادم.",
    "sentenceWithBlank": "I will _______ a student next year.",
    "options": [
      "is",
      "am",
      "was",
      "be"
    ],
    "correctAnswer": "be",
    "explanation": {
      "whyCorrectAr": "بعد will يأتي فعل الكينونة في المصدر وهو be.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_32",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستكون طبيبة بعد التخرج.",
    "sentenceWithBlank": "She will _______ a doctor after graduation.",
    "options": [
      "am",
      "are",
      "be",
      "was"
    ],
    "correctAnswer": "be",
    "explanation": {
      "whyCorrectAr": "بعد will نستخدم المصدر be لجميع الضمائر.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_33",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيكونون سعداء لرؤيتك.",
    "sentenceWithBlank": "They will _______ happy to see you.",
    "options": [
      "is",
      "was",
      "be",
      "are"
    ],
    "correctAnswer": "be",
    "explanation": {
      "whyCorrectAr": "المصدر من أفعال الكينونة بعد will هو be.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_34",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سنكون في كندا الصيف القادم.",
    "sentenceWithBlank": "We will _______ in Canada next summer.",
    "options": [
      "was",
      "were",
      "be",
      "are"
    ],
    "correctAnswer": "be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be للدلالة على الوجود في المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_35",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيكون أعز أصدقائي إلى الأبد.",
    "sentenceWithBlank": "He will _______ my best friend forever.",
    "options": [
      "are",
      "were",
      "be",
      "is"
    ],
    "correctAnswer": "be",
    "explanation": {
      "whyCorrectAr": "بعد will يأتي المصدر المجرد be.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_36",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستكون الكتب على الطاولة غداً.",
    "sentenceWithBlank": "The books will _______ on the table tomorrow.",
    "options": [
      "was",
      "is",
      "be",
      "are"
    ],
    "correctAnswer": "be",
    "explanation": {
      "whyCorrectAr": "بعد will نضع المصدر be.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_37",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستكون ناجحاً جداً.",
    "sentenceWithBlank": "You will _______ very successful.",
    "options": [
      "was",
      "is",
      "be",
      "are"
    ],
    "correctAnswer": "be",
    "explanation": {
      "whyCorrectAr": "نستخدم be بعد will لوصف الحالة المستقبلية.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_38",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيكون يوماً حاراً غداً.",
    "sentenceWithBlank": "It will _______ a hot day tomorrow.",
    "options": [
      "were",
      "am",
      "be",
      "is"
    ],
    "correctAnswer": "be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be للتنبؤ بالطقس في المستقبل.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_39",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيكون معلمي القادم الأستاذ جون.",
    "sentenceWithBlank": "My next teacher will _______ Mr. John.",
    "options": [
      "were",
      "am",
      "be",
      "is"
    ],
    "correctAnswer": "be",
    "explanation": {
      "whyCorrectAr": "بعد will نستخدم المصدر be.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_40",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستكون كلاب الشارع هادئة الليلة.",
    "sentenceWithBlank": "The street dogs will _______ quiet tonight.",
    "options": [
      "was",
      "be",
      "is",
      "are"
    ],
    "correctAnswer": "be",
    "explanation": {
      "whyCorrectAr": "بعد will نستخدم المصدر be.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_41",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سأكتب رسالة إلى صديقي غداً.",
    "sentenceWithBlank": "I will _______ a letter to my friend tomorrow.",
    "options": [
      "write",
      "wrote",
      "writes",
      "writing"
    ],
    "correctAnswer": "write",
    "explanation": {
      "whyCorrectAr": "بعد will يأتي الفعل مجرداً في المصدر (write).",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_42",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستشتري فستاناً جديداً الأسبوع القادم.",
    "sentenceWithBlank": "She will _______ a new dress next week.",
    "options": [
      "buy",
      "bought",
      "buys",
      "buying"
    ],
    "correctAnswer": "buy",
    "explanation": {
      "whyCorrectAr": "بعد will نستخدم الفعل الأساسي المجرد (buy).",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_43",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيذهبون إلى فرنسا الصيف القادم.",
    "sentenceWithBlank": "They will _______ to France next summer.",
    "options": [
      "go",
      "went",
      "goes",
      "going"
    ],
    "correctAnswer": "go",
    "explanation": {
      "whyCorrectAr": "بعد will يأتي المصدر go.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_44",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيغسل سيارته غداً.",
    "sentenceWithBlank": "He will _______ his car tomorrow.",
    "options": [
      "wash",
      "washed",
      "washes",
      "washing"
    ],
    "correctAnswer": "wash",
    "explanation": {
      "whyCorrectAr": "بعد will نستخدم الفعل المجرد wash.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_45",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سنتناول عشاءنا خلال ساعة.",
    "sentenceWithBlank": "We will _______ our dinner in an hour.",
    "options": [
      "eat",
      "ate",
      "eats",
      "eating"
    ],
    "correctAnswer": "eat",
    "explanation": {
      "whyCorrectAr": "بعد will نستخدم المصدر eat.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_46",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيلعب الأطفال في الحديقة غداً.",
    "sentenceWithBlank": "The children will _______ in the garden tomorrow.",
    "options": [
      "play",
      "played",
      "plays",
      "playing"
    ],
    "correctAnswer": "play",
    "explanation": {
      "whyCorrectAr": "بعد will يأتي الفعل مجرداً play.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_47",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستركض بسرعة كبيرة خلال السباق الأسبوع القادم.",
    "sentenceWithBlank": "You will _______ very fast during the race next week.",
    "options": [
      "run",
      "ran",
      "runs",
      "running"
    ],
    "correctAnswer": "run",
    "explanation": {
      "whyCorrectAr": "بعد will نستخدم المصدر run.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_48",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيعد الطاهي وجبة لذيذة الليلة.",
    "sentenceWithBlank": "The chef will _______ a delicious meal tonight.",
    "options": [
      "make",
      "made",
      "makes",
      "making"
    ],
    "correctAnswer": "make",
    "explanation": {
      "whyCorrectAr": "بعد will يأتي الفعل في المصدر make.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_49",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيقطر الماء من الصنبور إذا لم نصلحه.",
    "sentenceWithBlank": "Water will _______ from the tap if we don't fix it.",
    "options": [
      "drip",
      "dripped",
      "drips",
      "dripping"
    ],
    "correctAnswer": "drip",
    "explanation": {
      "whyCorrectAr": "بعد will نستخدم الفعل مجرداً drip.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  },
  {
    "id": "fs_easy_50",
    "tenseId": "future_simple",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيعطيني أصدقائي هدية لطيفة في عيد ميلادي.",
    "sentenceWithBlank": "My friends will _______ me a nice gift on my birthday.",
    "options": [
      "give",
      "gave",
      "gives",
      "giving"
    ],
    "correctAnswer": "give",
    "explanation": {
      "whyCorrectAr": "بعد will نستخدم المصدر give.",
      "temporalRelationshipAr": "حدث يقع ويتحدد في المستقبل بعد لحظة التكلم الحالية.",
      "whyTenseFitsAr": "المستقبل البسيط (Future Simple) يُستخدم للتعبير عن القرارات الفورية، التنبؤات، والوعود المستقبلية (will + Base Verb).",
      "whyOthersWrongAr": "الخيارات الأخرى إما تشير إلى أزمنة ماضية/حاضرة أو لا تتطابق مع القواعد النحوية لصيغة المصدر بعد will.",
      "confusableTenseAr": "Present Simple / Future Continuous / be going to"
    }
  }
];
