import { QuizQuestion } from '../types';

export const GAUNTLET_12_TENSES_50_QUESTIONS: QuizQuestion[] = [
  {
    id: "gauntlet_50_1",
    tenseId: "present_simple",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "حقيقة وعادة: تشرق الشمس من الشرق كل صباح.",
    sentenceWithBlank: "The sun _______ in the east every morning.",
    options: ["rise", "rises", "rising", "risen"],
    correctAnswer: "rises",
    explanation: {
      whyCorrectAr: "حقيقة علمية وعادة كونية مع الفاعل المفرد (The sun)؛ نستخدم صيغة المضارع البسيط بإضافة s للفعل (rises).",
      temporalRelationshipAr: "حقيقة دائمة ومستمرة في الحاضر وكل وقت.",
      whyTenseFitsAr: "المضارع البسيط (Present Simple) يعبر عن الحقائق العلمية والعادات الثابتة."
    }
  },
  {
    id: "gauntlet_50_2",
    tenseId: "present_simple",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "نفي مع المفرد: هي لا تلعب التنس في أيام الجمعة.",
    sentenceWithBlank: "She _______ play tennis on Fridays.",
    options: ["don't", "doesn't", "isn't", "aren't"],
    correctAnswer: "doesn't",
    explanation: {
      whyCorrectAr: "لنفي المضارع البسيط مع الفاعل المفرد (She) نستخدم الفعل المساعد المنفي doesn't متبوعاً بالمصدر المجرد play.",
      temporalRelationshipAr: "عادة متكررة منفية في الحاضر.",
      whyTenseFitsAr: "صيغة النفي في المضارع البسيط مع المفرد هي doesn't + base verb."
    }
  },
  {
    id: "gauntlet_50_3",
    tenseId: "present_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "حدث حالي: انظر! الرضيع نائم الآن.",
    sentenceWithBlank: "Look! The baby _______ right now.",
    options: ["sleep", "is sleeping", "are sleeping", "sleeps"],
    correctAnswer: "is sleeping",
    explanation: {
      whyCorrectAr: "دلالة Look / right now تشير لحدث يقع في لحظة التكلم، ومع الفاعل المفرد نستخدم is + V-ing (is sleeping).",
      temporalRelationshipAr: "حدث مستمر يقع أثناء لحظة الكلام بالضبط.",
      whyTenseFitsAr: "المضارع المستمر (Present Continuous) يعبر عن الأحداث الجارية الآن."
    }
  },
  {
    id: "gauntlet_50_4",
    tenseId: "present_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "أفعال الحالة المخادعة: أنا أفهم ما تعنيه بتلك العبارة.",
    sentenceWithBlank: "I _______ what you mean by that statement.",
    options: ["know", "am knowing", "knows", "knowing"],
    correctAnswer: "know",
    explanation: {
      whyCorrectAr: "فعل know من أفعال الحالة العقلية (Stative Verbs) التي لا تقبل الاستمرار؛ نستخدم المضارع البسيط know.",
      temporalRelationshipAr: "حالة إدراكية عقلية حاضرة.",
      whyTenseFitsAr: "أفعال الإدراك والحالة لا تصاغ في الأزمنة المستمرة وتستخدم في المضارع البسيط."
    }
  },
  {
    id: "gauntlet_50_5",
    tenseId: "present_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "تجربة وربط بالماضي: لم أزر باريس أبداً في حياتي.",
    sentenceWithBlank: "I _______ never visited Paris in my life.",
    options: ["has", "have", "am", "do"],
    correctAnswer: "have",
    explanation: {
      whyCorrectAr: "مع الفاعل I والظرف never والتصريف الثالث visited، نستخدم الفعل المساعد have في المضارع التام.",
      temporalRelationshipAr: "تجربة وخبرة حياتية ممتدة حتى اللحظة الحالية.",
      whyTenseFitsAr: "المضارع التام (Present Perfect) يربط بين الماضي والحاضر للتعبير عن التجارب الحياتية."
    }
  },
  {
    id: "gauntlet_50_6",
    tenseId: "present_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "دلالة since / for: هي تعمل في هذه الشركة منذ عام 2020.",
    sentenceWithBlank: "She has worked in this company _______ 2020.",
    options: ["for", "since", "yet", "already"],
    correctAnswer: "since",
    explanation: {
      whyCorrectAr: "نستخدم since قبل نقطة البداية المحددة في الزمن (سنة 2020) في زمن المضارع التام.",
      temporalRelationshipAr: "حدث بدأ في نقطة زمنية محددة بالماضي ومستمر حتى الحاضر.",
      whyTenseFitsAr: "since تحدد نقطة انطلاق الحدث في المضارع التام."
    }
  },
  {
    id: "gauntlet_50_7",
    tenseId: "present_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "استمرار لمدة: لقد كنت في انتظارك لأكثر من ساعتين.",
    sentenceWithBlank: "I _______ waiting for you for over two hours.",
    options: ["have been", "has been", "am being", "had been"],
    correctAnswer: "have been",
    explanation: {
      whyCorrectAr: "مع الفاعل I والدلالة على استمرار الحدث لمدة معينة حتى الوقت الحاضر (for over two hours) نستخدم have been waiting.",
      temporalRelationshipAr: "فعل بدأ في الماضي واستمر لفترة وما زال مستمراً أو انتهى لتوه في الحاضر.",
      whyTenseFitsAr: "المضارع التام المستمر (have been + V-ing) يركز على استغراق ومدة الحدث حتى الحاضر."
    }
  },
  {
    id: "gauntlet_50_8",
    tenseId: "present_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سؤال متقدم: كم المدة التي قضيتها في تعلم الإنجليزية؟",
    sentenceWithBlank: "How long _______ you been learning English?",
    options: ["has", "have", "are", "do"],
    correctAnswer: "have",
    explanation: {
      whyCorrectAr: "في السؤال مع الفاعل you والتركيب been learning، نستخدم الفعل المساعد have (How long have you been...).",
      temporalRelationshipAr: "سؤال عن طول مدة استمرار نشاط التعلم حتى الآن.",
      whyTenseFitsAr: "صيغة السؤال في المضارع التام المستمر تبدأ بـ How long have you been + V-ing."
    }
  },
  {
    id: "gauntlet_50_9",
    tenseId: "past_simple",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "حدث منتهي في الماضي: ذهبت إلى المدرسة بالحافلة بالأمس.",
    sentenceWithBlank: "I _______ to school by bus yesterday.",
    options: ["went", "go", "goes", "going"],
    correctAnswer: "went",
    explanation: {
      whyCorrectAr: "وجود ظرف الماضي yesterday يوجب استخدام التصريف الثاني للفعل (went).",
      temporalRelationshipAr: "حدث وقع واكتمل بالكامل في الماضي وانتهى.",
      whyTenseFitsAr: "الماضي البسيط (Past Simple) يستخدم للأحداث المنتهية في وقت محدد في الماضي."
    }
  },
  {
    id: "gauntlet_50_10",
    tenseId: "past_simple",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سؤال في الماضي: أين قضوا إجازتهم في الصيف الماضي؟",
    sentenceWithBlank: "Where _______ they spend their vacation last summer?",
    options: ["do", "does", "did", "were"],
    correctAnswer: "did",
    explanation: {
      whyCorrectAr: "لتكوين سؤال في الماضي البسيط مع الفعل الرئيسي المجرد spend نستخدم الفعل المساعد did.",
      temporalRelationshipAr: "استفهام عن حدث منتهٍ في الصيف الماضي (last summer).",
      whyTenseFitsAr: "صيغة السؤال في الماضي البسيط هي Did + Subject + Base Verb."
    }
  },
  {
    id: "gauntlet_50_11",
    tenseId: "past_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "حدث طويل قاطعه حدث: بينما كنت أدرس، دخل أخي الغرفة.",
    sentenceWithBlank: "While I _______ studying, my brother entered the room.",
    options: ["was", "were", "am", "did"],
    correctAnswer: "was",
    explanation: {
      whyCorrectAr: "بعد While للحدث المستمر في الماضي مع الفاعل I نستخدم was studying.",
      temporalRelationshipAr: "حدث مستمر في الماضي قاطعه حدث مفاجئ في الماضي البسيط (entered).",
      whyTenseFitsAr: "الماضي المستمر مع While يعبر عن الخلفية المستمرة للأحداث."
    }
  },
  {
    id: "gauntlet_50_12",
    tenseId: "past_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "سلوك مزعج متكرر في الماضي: كان دائم الشكوى من وظيفته عندما كان يعمل هنا.",
    sentenceWithBlank: "He _______ always complaining about his job when he worked here.",
    options: ["always was", "was always", "always did", "did always"],
    correctAnswer: "was always",
    explanation: {
      whyCorrectAr: "في الماضي المستمر للتعبير عن التذمر المتكرر، يأتي ظرف التكرار always بعد الفعل المساعد was (was always complaining).",
      temporalRelationshipAr: "سلوك متكرر ومستمر ومزعج في فترة ماضية.",
      whyTenseFitsAr: "يستخدم الماضي المستمر مع always للتعبير عن الانزعاج من عادة ماضية متكررة."
    }
  },
  {
    id: "gauntlet_50_13",
    tenseId: "past_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "سبق ماضٍ آخر: بحلول وقت وصولي، كانت قد غادرت بالفعل.",
    sentenceWithBlank: "By the time I arrived, she _______ already left.",
    options: ["has", "had", "have", "did"],
    correctAnswer: "had",
    explanation: {
      whyCorrectAr: "الحدث الأسبق في الماضي (المغادرة قبل الوصول) يوضع في الماضي التام had + left.",
      temporalRelationshipAr: "حدث اكتمل وسبق حدثاً ماضياً آخر (arrived).",
      whyTenseFitsAr: "الماضي التام (Past Perfect) يعبر عن الحدث الأقدم في الماضي."
    }
  },
  {
    id: "gauntlet_50_14",
    tenseId: "past_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "قاعدة متقدمة بعد تفضيل: كان هذا أفضل فيلم رأيته في حياتي.",
    sentenceWithBlank: "This was the best movie I _______ ever seen.",
    options: ["has", "had", "have", "did"],
    correctAnswer: "had",
    explanation: {
      whyCorrectAr: "لأن الجملة الرئيسية في الماضي (This was...)، فإن جملة التفضيل المرتبطة بها تأتي في الماضي التام (had ever seen).",
      temporalRelationshipAr: "تفضيل وتقييم ماضٍ يسبق أو يوازي تلك النقطة في الماضي.",
      whyTenseFitsAr: "صيغة التفضيل في الماضي تتبع بالماضي التام (had ever + V3)."
    }
  },
  {
    id: "gauntlet_50_15",
    tenseId: "past_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "استمرار قبل حدث ماضٍ: كنت قد انتظرت لمدة ساعتين قبل أن تأتي في النهاية.",
    sentenceWithBlank: "I _______ waiting for two hours before you finally came.",
    options: ["had been", "have been", "has been", "was being"],
    correctAnswer: "had been",
    explanation: {
      whyCorrectAr: "استمرار الحدث لمدة ساعتين قبل وقوع حدث ماضٍ آخر (came) يتطلب الماضي التام المستمر (had been waiting).",
      temporalRelationshipAr: "استمرار حدث لمدة زمنية محددة قبل نقطة معينة في الماضي.",
      whyTenseFitsAr: "الماضي التام المستمر يركز على طول مدة الحدث الأقدم في الماضي."
    }
  },
  {
    id: "gauntlet_50_16",
    tenseId: "past_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "علامات الاستمرار المتقدمة: بدا متعباً جداً لأنه كان قد ركض لمدة ساعة.",
    sentenceWithBlank: "He looked very tired because he _______ running for an hour.",
    options: ["has been", "have been", "had been", "were being"],
    correctAnswer: "had been",
    explanation: {
      whyCorrectAr: "نتيجة التعب في الماضي (looked tired) سببها نشاط استمر لفترة قبله؛ نستخدم الماضي التام المستمر (had been running).",
      temporalRelationshipAr: "فعل استمر في الماضي وظهرت نتيجته أيضاً في الماضي.",
      whyTenseFitsAr: "يستخدم الماضي التام المستمر لتفسير سبب حالة ماضية ناجمة عن نشاط مستمر."
    }
  },
  {
    id: "gauntlet_50_17",
    tenseId: "future_simple",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "تنبؤ بـ will: أعتقد أنها ستمطر غداً.",
    sentenceWithBlank: "I think it _______ rain tomorrow.",
    options: ["rain", "rains", "will rain", "rained"],
    correctAnswer: "will rain",
    explanation: {
      whyCorrectAr: "بعد أفعال التخمين والرأي (I think) للتنبؤ المستقبلي، نستخدم will + المصدر (will rain).",
      temporalRelationshipAr: "توقع وتنبؤ بحدث سيحدث في المستقبل.",
      whyTenseFitsAr: "المستقبل البسيط بـ will يعبر عن التنبؤات والآراء الشخصية حول المستقبل."
    }
  },
  {
    id: "gauntlet_50_18",
    tenseId: "future_simple",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "وعود سريعة: هي تعد بأنها ستساعدني في واجبي.",
    sentenceWithBlank: "She promises she _______ help me with my homework.",
    options: ["help", "helps", "will help", "helped"],
    correctAnswer: "will help",
    explanation: {
      whyCorrectAr: "مع أفعال الوعد (promises) نستخدم will + المصدر (will help).",
      temporalRelationshipAr: "وعد بالتزام في المستقبل.",
      whyTenseFitsAr: "تستخدم will للتعبير عن الوعود والقرارات الفورية."
    }
  },
  {
    id: "gauntlet_50_19",
    tenseId: "future_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "حدث مستمر في وقت محدد بالمستقبل: في الساعة 8 مساء الغد، سأكون أقرأ كتاباً.",
    sentenceWithBlank: "At 8 PM tomorrow, I _______ reading a book.",
    options: ["will", "will be", "am", "was"],
    correctAnswer: "will be",
    explanation: {
      whyCorrectAr: "تحديد وقت دقيق في المستقبل (At 8 PM tomorrow) يدل على حدث سيكون مستمراً حينها، وصيغته will be + reading.",
      temporalRelationshipAr: "حدث سيكون في طور الحدوث والاستمرار في وقت محدد في المستقبل.",
      whyTenseFitsAr: "المستقبل المستمر (will be + V-ing) يعبر عن نشاط مستمر في لحظة مستقبلية."
    }
  },
  {
    id: "gauntlet_50_20",
    tenseId: "future_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "تساؤل مستمر: ماذا ستكون تفعل عندما أتصل بك الليلة؟",
    sentenceWithBlank: "What _______ you be doing when I call you tonight?",
    options: ["will", "would", "are", "do"],
    correctAnswer: "will",
    explanation: {
      whyCorrectAr: "تكوين السؤال في المستقبل المستمر يبدأ بـ What will you be doing.",
      temporalRelationshipAr: "استفهام عن نشاط مستمر في لحظة وقوع حدث مستقبلي آخر.",
      whyTenseFitsAr: "صيغة السؤال في المستقبل المستمر هي Will + Subject + be + V-ing."
    }
  },
  {
    id: "gauntlet_50_21",
    tenseId: "future_perfect",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "اكتمال قبل وقت مستقبلي: بحلول الغد، سأكون قد أنهيت واجبي المنزلي.",
    sentenceWithBlank: "By tomorrow, I _______ finished my homework.",
    options: ["will have", "will has", "am have", "had"],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "مع By + وقت مستقبلي، نستخدم المستقبل التام will have + V3 (finished).",
      temporalRelationshipAr: "حدث سيكتمل قبل حلول نقطة زمنية محددة في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (will have + V3) يعبر عن اكتمال الفعل قبل موعد مستقبلي."
    }
  },
  {
    id: "gauntlet_50_22",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "التميز المتقدم: بحلول الشهر القادم، سيكون هذا أفضل فيلم رأيته على الإطلاق.",
    sentenceWithBlank: "By next month, this will be the best movie I _______ ever seen.",
    options: ["will has", "will have", "has", "had"],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "السياق المستقبلي التام بعد صيغة التفضيل مع By next month يأخذ will have (will have ever seen).",
      temporalRelationshipAr: "تفضيل واكتمال تجربة مقاسة حتى نقطة مستقبلية.",
      whyTenseFitsAr: "صيغة التفضيل في سياق المستقبل التام تستخدم will have ever + V3."
    }
  },
  {
    id: "gauntlet_50_23",
    tenseId: "future_perfect_continuous",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "استمرار نحو المستقبل: بحلول العام القادم، سأكون قد عملت هنا لمدة خمس سنوات.",
    sentenceWithBlank: "By next year, I _______ working here for five years.",
    options: ["will have been", "will has been", "will be have", "had been"],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "الدلالة على مدة عمل مستمرة حتى نقطة مستقبلية (By next year + for five years) تتطلب will have been working.",
      temporalRelationshipAr: "استمرار الحدث لمدة زمنية محددة حتى الوصول إلى نقطة معينة في المستقبل.",
      whyTenseFitsAr: "المستقبل التام المستمر (will have been + V-ing) يركز على قياس مدة استمرار الحدث في المستقبل."
    }
  },
  {
    id: "gauntlet_50_24",
    tenseId: "future_perfect_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "التركيب المعقد: بحلول صباح الغد، ستكون قد نامت لمدة عشر ساعات.",
    sentenceWithBlank: "By tomorrow morning, she _______ sleeping for ten hours.",
    options: ["will has been", "will have been", "is been", "had been"],
    correctAnswer: "will have been",
    explanation: {
      whyCorrectAr: "صيغة المستقبل التام المستمر هي will have been + sleeping مع جميع الضمائر.",
      temporalRelationshipAr: "استمرار النوم لمدة 10 ساعات حتى صباح الغد.",
      whyTenseFitsAr: "التركيب الصحيح للمستقبل التام المستمر هو will have been متبوعاً بـ V-ing."
    }
  },
  {
    id: "gauntlet_50_25",
    tenseId: "present_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "المضارع البسيط مقابل المستمر: هي تستقل الحافلة دائماً، ولكنها اليوم تستقل سيارة أجرة.",
    sentenceWithBlank: "She always takes the bus, but today she _______ a taxi.",
    options: ["take", "takes", "is taking", "are taking"],
    correctAnswer: "is taking",
    explanation: {
      whyCorrectAr: "دلالة today تعبر عن استثناء مؤقت ومختلف عن العادة الدائمة، فيعبر عنه بالمضارع المستمر (is taking).",
      temporalRelationshipAr: "إجراء مؤقت وخاص باليوم فقط يخالف العادة الدائمة (always takes).",
      whyTenseFitsAr: "المضارع المستمر يستخدم للأنشطة المؤقتة التي تحدث بشكل استثنائي اليوم."
    }
  },
  {
    id: "gauntlet_50_26",
    tenseId: "past_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "الماضي البسيط مقابل المستمر: ماذا كنت تفعل عندما انطلق جرس إنذار الحريق؟",
    sentenceWithBlank: "What _______ you doing when the fire alarm went off?",
    options: ["was", "were", "are", "did"],
    correctAnswer: "were",
    explanation: {
      whyCorrectAr: "مع الفاعل you والفعل doing في حدث ماضٍ مستمر قاطعه جرس الإنذار، نستخدم were.",
      temporalRelationshipAr: "حدث مستمر في الماضي تمت مقاطعته بحدث مفاجئ (went off).",
      whyTenseFitsAr: "الماضي المستمر يعبر عن الحدث الذي كان قيد التنفيذ عند وقوع الحدث القاطع."
    }
  },
  {
    id: "gauntlet_50_27",
    tenseId: "present_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "المضارع التام مقابل الماضي البسيط: لقد فقد محفظته؛ إنه لا يستطيع العثور عليها الآن.",
    sentenceWithBlank: "He _______ lost his wallet; he cannot find it.",
    options: ["have", "has", "is", "did"],
    correctAnswer: "has",
    explanation: {
      whyCorrectAr: "حدث وقع في الماضي وله أثر مباشر في الحاضر (لا يجدها الآن) مع الفاعل He نستخدم has lost.",
      temporalRelationshipAr: "حدث ماضٍ أثره ونتيجته قائمة وملموسة في الحاضر.",
      whyTenseFitsAr: "المضارع التام يربط بين وقوع الفعل في الماضي وأثره في اللحظة الحالية."
    }
  },
  {
    id: "gauntlet_50_28",
    tenseId: "present_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "المضارع التام المستمر مقابل البسيط: كم المدة التي عشتها في هذه البلدة؟",
    sentenceWithBlank: "How long _______ you lived in this town?",
    options: ["has", "have", "are", "do"],
    correctAnswer: "have",
    explanation: {
      whyCorrectAr: "للسؤال عن مدة الإقامة المستمرة حتى الحاضر مع الفاعل you والتصريف الثالث lived نستخدم have.",
      temporalRelationshipAr: "سؤال عن مدة حالة سكنية مستمرة حتى الآن.",
      whyTenseFitsAr: "المضارع التام البسيط مع أفعال الإقامة مثل live يعبر عن مدة الإقامة الممتدة حتى الحاضر."
    }
  },
  {
    id: "gauntlet_50_29",
    tenseId: "present_simple",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "أفعال الملكية والحالة: هذا الحاسوب المحمول باهظ الثمن يعود لأخي.",
    sentenceWithBlank: "This expensive laptop _______ to my brother.",
    options: ["is belonging", "belong", "belongs", "belonging"],
    correctAnswer: "belongs",
    explanation: {
      whyCorrectAr: "فعل الملكية belong من أفعال الحالة التي لا تقبل الاستمرار، ومع الفاعل المفرد يأخذ s في المضارع البسيط (belongs).",
      temporalRelationshipAr: "ملكية وحقيقة ثابتة ومستمرة.",
      whyTenseFitsAr: "أفعال الملكية لا تصاغ في الأزمنة المستمرة وتستخدم في المضارع البسيط."
    }
  },
  {
    id: "gauntlet_50_30",
    tenseId: "past_simple",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "القلب النحوي في الماضي: نادراً ما أنهى أي شخص ذلك الاختبار الصعب بالأمس.",
    sentenceWithBlank: "Rarely _______ anyone finish that extremely difficult test yesterday.",
    options: ["do", "did", "was", "does"],
    correctAnswer: "did",
    explanation: {
      whyCorrectAr: "عند البدء بظرف النفي (Rarely) مع دلالة الماضي (yesterday)، يحدث قلب نحوي باستخدام الفعل المساعد did.",
      temporalRelationshipAr: "حدث ماضٍ منتهٍ (yesterday) مع توكيد نفي نادر.",
      whyTenseFitsAr: "القلب النحوي (Inversion) بعد ظروف النفي في الماضي البسيط يتطلب تقديم did على الفاعل."
    }
  },
  {
    id: "gauntlet_50_31",
    tenseId: "present_simple",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "موقع ظروف التكرار: هي نادراً ما تقرأ القصص الخيالية.",
    sentenceWithBlank: "She _______ reads fiction.",
    options: ["seldom is", "seldom", "does seldom", "is seldom"],
    correctAnswer: "seldom",
    explanation: {
      whyCorrectAr: "ظرف التكرار seldom يوضع مباشرة قبل الفعل الرئيسي reads في الجملة العادية بالمضارع البسيط.",
      temporalRelationshipAr: "عادة نادرة التكرار في الحاضر.",
      whyTenseFitsAr: "ظروف التكرار تأتي قبل الفعل الرئيسي في المضارع البسيط."
    }
  },
  {
    id: "gauntlet_50_32",
    tenseId: "present_continuous",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "توافق الفاعل مع الفعل: الشرطة تبحث في المنطقة عن أدلة الآن.",
    sentenceWithBlank: "The police _______ searching the area for clues right now.",
    options: ["is", "are", "am", "do"],
    correctAnswer: "are",
    explanation: {
      whyCorrectAr: "كلمة police اسم جمع دائماً في اللغة الإنجليزية، ومع دلالة الاستمرار right now تأخذ are searching.",
      temporalRelationshipAr: "حدث جمعي مستمر في اللحظة الراهنة.",
      whyTenseFitsAr: "The police تعامل معاملة الجمع وتأخذ are في المضارع المستمر."
    }
  },
  {
    id: "gauntlet_50_33",
    tenseId: "present_simple",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "توافق الفاعل مع الأسماء غير المعدودة: الرياضيات هي مادتي المفضلة في المدرسة.",
    sentenceWithBlank: "Mathematics _______ my favorite subject at school.",
    options: ["are", "is", "am", "be"],
    correctAnswer: "is",
    explanation: {
      whyCorrectAr: "أسماء العلوم والمواد المنتهية بـ s مثل Mathematics تعامل معاملة المفرد وتأخذ is.",
      temporalRelationshipAr: "حقيقة ورأي دائم وثابت.",
      whyTenseFitsAr: "أسماء المواد الدراسية والعلوم مفردة نحوياً وتأخذ فعل مفرد (is)."
    }
  },
  {
    id: "gauntlet_50_34",
    tenseId: "present_simple",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "الحالة الشرطية الصفرية: إذا وصل الماء إلى 100 درجة مئوية، فإنه يغلي.",
    sentenceWithBlank: "If water _______ 100 degrees Celsius, it boils.",
    options: ["reach", "reaches", "reaching", "reached"],
    correctAnswer: "reaches",
    explanation: {
      whyCorrectAr: "الحالة الشرطية الصفرية (حقائق علمية) تستخدم المضارع البسيط في كلا الشقين: reaches مع water.",
      temporalRelationshipAr: "حقيقة علمية عامة صالحة في كل الأوقات.",
      whyTenseFitsAr: "الشرطية الصفرية تعبر عن القوانين العلمية بصيغة المضارع البسيط في كلا الجزأين."
    }
  },
  {
    id: "gauntlet_50_35",
    tenseId: "future_simple",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "الحالة الشرطية الأولى: إذا أمطرت غداً، فسنبقى في المنزل.",
    sentenceWithBlank: "If it rains tomorrow, we _______ stay at home.",
    options: ["stay", "stayed", "will stay", "would stay"],
    correctAnswer: "will stay",
    explanation: {
      whyCorrectAr: "الحالة الشرطية الأولى (مضارع بسيط في جملة الشرط rains) يقابلها will + المصدر في جواب الشرط (will stay).",
      temporalRelationshipAr: "احتمال مستقبلي واقعي وممكن الحدوث.",
      whyTenseFitsAr: "الشرطية الأولى تربط بين شرط مضارع محتمل ونتيجة مستقبلية بـ will."
    }
  },
  {
    id: "gauntlet_50_36",
    tenseId: "future_simple",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "الحالة الشرطية الثانية: لو كان لدي المزيد من المال، لاشتريت سيارة.",
    sentenceWithBlank: "If I had more money, I _______ buy a car.",
    options: ["will", "would", "can", "shall"],
    correctAnswer: "would",
    explanation: {
      whyCorrectAr: "الحالة الشرطية الثانية (ماضي بسيط had) يقابلها would + المصدر (would buy) للتعبير عن افتراض غير واقعي.",
      temporalRelationshipAr: "موقف افتراضي غير حقيقي في الحاضر أو المستقبل.",
      whyTenseFitsAr: "الشرطية الثانية تستخدم الماضي البسيط للشرط و would للمستقبل الافتراضي."
    }
  },
  {
    id: "gauntlet_50_37",
    tenseId: "past_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "الحالة الشرطية الثالثة: لو أنها كانت قد درست بجد، لكانت قد اجتازت الامتحان.",
    sentenceWithBlank: "If she had studied hard, she _______ passed the exam.",
    options: ["will have", "would have", "had", "has"],
    correctAnswer: "would have",
    explanation: {
      whyCorrectAr: "الحالة الشرطية الثالثة (ماضي تام had studied) يقابلها would have + V3 (would have passed) للندم على ماضٍ لم يحدث.",
      temporalRelationshipAr: "موقف افتراضي مستحيل في الماضي وندم على ما فات.",
      whyTenseFitsAr: "الشرطية الثالثة تستخدم الماضي التام في الشرط و would have + V3 في جواب الشرط."
    }
  },
  {
    id: "gauntlet_50_38",
    tenseId: "past_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "الشرط المختلط: لو أنني ربحت اليانصيب بالأمس، لكنت غنياً اليوم.",
    sentenceWithBlank: "If I had won the lottery yesterday, I _______ rich today.",
    options: ["would be", "will be", "would have been", "am"],
    correctAnswer: "would be",
    explanation: {
      whyCorrectAr: "شرط مختلط: حدث شرطي في الماضي (had won yesterday) ينتج عنه أثر حالي في الحاضر (today)؛ نستخدم would be.",
      temporalRelationshipAr: "سبب ماضٍ افتراضي ينتج عنه أثر مستمر في الحاضر.",
      whyTenseFitsAr: "الشرط المختلط يجمع بين ماضٍ تام في الشرط و would + المصدر لأثر الحاضر."
    }
  },
  {
    id: "gauntlet_50_39",
    tenseId: "past_simple",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "التمني في الحاضر: أتمنى لو كنت أعرف كيف أسبح.",
    sentenceWithBlank: "I wish I _______ how to swim.",
    options: ["know", "knew", "known", "will know"],
    correctAnswer: "knew",
    explanation: {
      whyCorrectAr: "التمني لتغيير واقع في الحاضر بعد wish يأخذ صيغة الماضي البسيط (knew).",
      temporalRelationshipAr: "رغبة في تغيير حالة غير متوفرة في الحاضر.",
      whyTenseFitsAr: "قاعدة wish للحاضر تتطلب استخدام صيغة الماضي البسيط الافتراضي (Past Subjunctive)."
    }
  },
  {
    id: "gauntlet_50_40",
    tenseId: "past_perfect",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "التمني والندم على الماضي: يا ليتني لم أفقد مفاتيحي بالأمس!",
    sentenceWithBlank: "If only I _______ my keys yesterday!",
    options: ["didn't lose", "don't lose", "hadn't lost", "haven't lost"],
    correctAnswer: "hadn't lost",
    explanation: {
      whyCorrectAr: "التمني والندم على حدث وقع في الماضي بعد If only مع yesterday يأخذ الماضي التام (hadn't lost).",
      temporalRelationshipAr: "ندم على حدث اكتمل في الماضي ولا يمكن تغييره.",
      whyTenseFitsAr: "قاعدة If only للماضي تتطلب صيغة الماضي التام للتعبير عن الندم."
    }
  },
  {
    id: "gauntlet_50_41",
    tenseId: "present_simple",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "الجمل الزمنية المستقبلية: بمجرد أن تصل إلى المنزل غداً، ستتصل بوالدتها.",
    sentenceWithBlank: "As soon as she _______ home tomorrow, she will call her mother.",
    options: ["arrive", "arrives", "arrived", "will arrive"],
    correctAnswer: "arrives",
    explanation: {
      whyCorrectAr: "في الجمل الزمنية الدالة على المستقبل (بعد As soon as)، نستخدم المضارع البسيط (arrives) وليس will.",
      temporalRelationshipAr: "شرط زمني يقع أولاً في المستقبل قبل الاتصال.",
      whyTenseFitsAr: "الروابط الزمنية المستقبلية مثل As soon as تستخدم المضارع البسيط للدلالة على المستقبل."
    }
  },
  {
    id: "gauntlet_50_42",
    tenseId: "past_simple",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "الجمل الزمنية الماضية: بمجرد أن وصلت إلى المنزل بالأمس، اتصلت بوالدتها.",
    sentenceWithBlank: "As soon as she _______ home yesterday, she called her mother.",
    options: ["arrive", "arrived", "arriving", "arrives"],
    correctAnswer: "arrived",
    explanation: {
      whyCorrectAr: "تسلسل أحداث منتهية في الماضي بعد As soon as مع yesterday يتطلب الماضي البسيط (arrived).",
      temporalRelationshipAr: "حدثان متعاقبان في الماضي تم كلاهما بالأمس.",
      whyTenseFitsAr: "تستخدم صيغة الماضي البسيط لتوثيق الأحداث المتعاقبة في الماضي."
    }
  },
  {
    id: "gauntlet_50_43",
    tenseId: "present_simple",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "الأسماء الجمعية: تتناول عائلتي عشاءً كبيراً معاً كل جمعة.",
    sentenceWithBlank: "My family _______ a big dinner together every Friday.",
    options: ["eat", "eats", "eating", "eaten"],
    correctAnswer: "eats",
    explanation: {
      whyCorrectAr: "اسم الجمع family كوحدة واحدة في المضارع البسيط مع every Friday يأخذ فعلاً مفرداً (eats).",
      temporalRelationshipAr: "عادة أسرية متكررة كل يوم جمعة.",
      whyTenseFitsAr: "الأسماء الجمعية كوحدة واحدة تعامل كفاعل مفرد في المضارع البسيط."
    }
  },
  {
    id: "gauntlet_50_44",
    tenseId: "present_simple",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "قاعدة Neither / Nor: لا المعلم ولا الطلاب يعرفون الإجابة.",
    sentenceWithBlank: "Neither the teacher nor the students _______ the answer.",
    options: ["knows", "know", "knowing", "known"],
    correctAnswer: "know",
    explanation: {
      whyCorrectAr: "في قاعدة Neither... nor، يتبع الفعل الفاعل الأقرب له (the students) وهو جمع، فيأخذ know.",
      temporalRelationshipAr: "حالة معرفية في الحاضر.",
      whyTenseFitsAr: "الفعل بعد nor يتبع الفاعل الأقرب له في التذكير والإفراد والجمع."
    }
  },
  {
    id: "gauntlet_50_45",
    tenseId: "present_simple",
    difficulty: "medium",
    type: "multiple_choice",
    promptAr: "قاعدة Neither / Nor العكسية: لا الطلاب ولا المعلم يعرف الإجابة.",
    sentenceWithBlank: "Neither the students nor the teacher _______ the answer.",
    options: ["knows", "know", "knowing", "known"],
    correctAnswer: "knows",
    explanation: {
      whyCorrectAr: "الفاعل الأقرب للفعل هو المفرد (the teacher)، لذلك يأخذ الفعل s المفرد (knows).",
      temporalRelationshipAr: "حالة معرفية حاضرة.",
      whyTenseFitsAr: "الفعل يتبع الفاعل الأقرب (المعلم) بصيغة المفرد knows."
    }
  },
  {
    id: "gauntlet_50_46",
    tenseId: "present_simple",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "موقع ظروف التكرار: أنا لست متأخراً أبداً عن المدرسة.",
    sentenceWithBlank: "I am _______ late for school.",
    options: ["always", "never", "usually", "often"],
    correctAnswer: "never",
    explanation: {
      whyCorrectAr: "ظرف التكرار never يأتي بعد فعل to be (am) ويعطي المعنى المنفي السليم.",
      temporalRelationshipAr: "عادة وسلوك دائم في الحاضر.",
      whyTenseFitsAr: "تأتي ظروف التكرار بعد أفعال be مباشرة في المضارع البسيط."
    }
  },
  {
    id: "gauntlet_50_47",
    tenseId: "present_simple",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "موقع ظروف التكرار مع To Be: هم دائماً متأخرون عن درس الإنجليزية.",
    sentenceWithBlank: "They _______ late for their English class.",
    options: ["always are", "are always", "always", "do always"],
    correctAnswer: "are always",
    explanation: {
      whyCorrectAr: "يأتي ظرف التكرار always بعد فعل to be (are) وليس قبله (are always).",
      temporalRelationshipAr: "سلوك دائم التكرار في الحاضر.",
      whyTenseFitsAr: "الترتيب الصحيح هو فعل be أولاً ثم ظرف التكرار."
    }
  },
  {
    id: "gauntlet_50_48",
    tenseId: "present_simple",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "المبني للمجهول في المضارع البسيط: تُتحدث الإنجليزية في جميع أنحاء العالم.",
    sentenceWithBlank: "English _______ all over the world.",
    options: ["speak", "speaks", "is spoken", "spoke"],
    correctAnswer: "is spoken",
    explanation: {
      whyCorrectAr: "المبني للمجهول في المضارع البسيط مع الفاعل غير العاقل English يتكون من is + V3 (is spoken).",
      temporalRelationshipAr: "حقيقة عامة قائمة في كل مكان.",
      whyTenseFitsAr: "المبني للمجهول في المضارع البسيط يصاغ بـ is/are + التصريف الثالث."
    }
  },
  {
    id: "gauntlet_50_49",
    tenseId: "past_simple",
    difficulty: "easy",
    type: "multiple_choice",
    promptAr: "المبني للمجهول في الماضي البسيط: تم إصلاح السيارة بواسطة والدي بالأمس.",
    sentenceWithBlank: "The car _______ by my father yesterday.",
    options: ["repaired", "is repaired", "was repaired", "repairs"],
    correctAnswer: "was repaired",
    explanation: {
      whyCorrectAr: "المبني للمجهول في الماضي البسيط مع دلالة yesterday والمفرد The car يتكون من was + V3 (was repaired).",
      temporalRelationshipAr: "حدث تم على المفعول به وانتهى في الماضي بالأمس.",
      whyTenseFitsAr: "صيغة المبني للمجهول في الماضي البسيط هي was/were + التصريف الثالث."
    }
  },
  {
    id: "gauntlet_50_50",
    tenseId: "past_simple",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "استنتاج الأفعال الناقصة: من المستحيل أنه أقفل الباب، فالمفتاح هنا على الطاولة بالداخل!",
    sentenceWithBlank: "He _______ have locked the door; I see the key right here on the table inside!",
    options: ["must", "can't", "should", "might"],
    correctAnswer: "can't",
    explanation: {
      whyCorrectAr: "الاستنتاج القاطع بالنفي في الماضي (مستحيل أن يكون قد حدث بناءً على دليل قاطع) نستخدم معه can't have + V3.",
      temporalRelationshipAr: "استنتاج ونفي قاطع لحدث ماضٍ بناء على دليل حاضر.",
      whyTenseFitsAr: "تستخدم can't have + V3 للاستنتاج المنفي المؤكد حول حدث ماضٍ."
    }
  }
];
