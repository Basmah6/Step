import { QuizQuestion } from '../types';

export const FUTURE_CONTINUOUS_EASY_50: QuizQuestion[] = [
  {
    "id": "fc_easy_1",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "في الساعة 8 مساءً غداً، سأكون أقرأ كتاباً.",
    "sentenceWithBlank": "At 8 PM tomorrow, I _______ reading a book.",
    "options": [
      "will",
      "will be",
      "am",
      "was"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "نستخدم المستقبل المستمر (will be + V-ing) للتعبير عن حدث سيكون مستمراً في وقت محدد بالمستقبل.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_2",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستكون تطبخ العشاء عندما تصل.",
    "sentenceWithBlank": "She _______ cooking dinner when you arrive.",
    "options": [
      "will",
      "will be",
      "is",
      "was"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be متبوعة بـ cooking للتعبير عن حدث مستمر يقطعه وصولك في المستقبل.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_3",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيكونون يلعبون كرة القدم طوال فترة بعد ظهر الغد.",
    "sentenceWithBlank": "They _______ playing football all afternoon tomorrow.",
    "options": [
      "will",
      "will be",
      "are",
      "were"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "العبارة الزمنية all afternoon tomorrow تدل على الاستمرارية في المستقبل (will be playing).",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_4",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيكون نائماً عندما تتصل به.",
    "sentenceWithBlank": "He _______ sleeping when you call him.",
    "options": [
      "will",
      "will be",
      "is",
      "was"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "صيغة المستقبل المستمر will be + sleeping تدل على حدث سيكون مستمراً في لحظة الاتصال.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_5",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سنكون نعيش في منزلنا الجديد الشهر القادم.",
    "sentenceWithBlank": "We _______ living in our new house next month.",
    "options": [
      "will",
      "will be",
      "are",
      "were"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be living للتعبير عن نشاط مستمر في فترة مستقبلية محددة.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_6",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستكون تدرس اللغة الإنجليزية في مثل هذا الوقت غداً.",
    "sentenceWithBlank": "You _______ studying English at this time tomorrow.",
    "options": [
      "will",
      "will be",
      "are",
      "were"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "العبارة at this time tomorrow من أهم علامات المستقبل المستمر (will be studying).",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_7",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستكون الشمس مشرقة ببراعة صباح الغد.",
    "sentenceWithBlank": "The sun _______ shining brightly tomorrow morning.",
    "options": [
      "will",
      "will be",
      "is",
      "was"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be shining للتعبير عن حالة استمرارية متوقعة في الصباح.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_8",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستكون الطيور تطير جنوباً عندما يحل الشتاء.",
    "sentenceWithBlank": "Birds _______ flying south when winter arrives.",
    "options": [
      "will",
      "will be",
      "are",
      "were"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be flying مع الفاعل الجمع birds للتعبير عن استمرار الطيران.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_9",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستكون قطتي نائمة على الأريكة طوال اليوم غداً.",
    "sentenceWithBlank": "My cat _______ sleeping on the sofa all day tomorrow.",
    "options": [
      "will",
      "will be",
      "is",
      "was"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "العبارة all day tomorrow تدل على استغراق الوقت المستقبلي، فنستخدم will be sleeping.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_10",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيكون الماء يقطر من الصنبور حتى نقوم بإصلاحه.",
    "sentenceWithBlank": "Water _______ dripping from the tap until we fix it.",
    "options": [
      "will",
      "will be",
      "is",
      "was"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be dripping للتعبير عن استمرار قطرات الماء في المستقبل حتى الإصلاح.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_11",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لن أكون أشاهد التلفاز في منتصف الليل.",
    "sentenceWithBlank": "I _______ watching TV at midnight.",
    "options": [
      "don't",
      "won't",
      "won't be",
      "aren't be"
    ],
    "correctAnswer": "won't be",
    "explanation": {
      "whyCorrectAr": "نفي المستقبل المستمر يكون باستخدام won't be متبوعاً بالفعل المضاف له ing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_12",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لن تكون تلعب التنس في مثل هذا الوقت غداً.",
    "sentenceWithBlank": "She _______ playing tennis at this time tomorrow.",
    "options": [
      "won't",
      "won't be",
      "isn't",
      "didn't"
    ],
    "correctAnswer": "won't be",
    "explanation": {
      "whyCorrectAr": "نستخدم won't be لنفي المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_13",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لن يكونوا يستمعون إلى المعلم أثناء الحصة.",
    "sentenceWithBlank": "They _______ listening to the teacher during the class.",
    "options": [
      "won't",
      "won't be",
      "aren't",
      "didn't"
    ],
    "correctAnswer": "won't be",
    "explanation": {
      "whyCorrectAr": "نستخدم won't be مع الفاعل الجمع they لنفي الاستمرار في المستقبل.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_14",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لن يكون يدرس عندما تدخل الغرفة.",
    "sentenceWithBlank": "He _______ studying when you enter the room.",
    "options": [
      "won't",
      "won't be",
      "isn't",
      "didn't"
    ],
    "correctAnswer": "won't be",
    "explanation": {
      "whyCorrectAr": "صيغة النفي في المستقبل المستمر هي won't be + studying.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_15",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لن نكون نعمل على المشروع في تلك الساعة.",
    "sentenceWithBlank": "We _______ working on the project at that hour.",
    "options": [
      "won't",
      "won't be",
      "aren't",
      "didn't"
    ],
    "correctAnswer": "won't be",
    "explanation": {
      "whyCorrectAr": "نستخدم won't be مع الضمير we للتعبير عن نفي الاستمرارية.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_16",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لن يكون الكلب ينبح طوال الليل.",
    "sentenceWithBlank": "The dog _______ barking all night.",
    "options": [
      "won't",
      "won't be",
      "isn't",
      "didn't"
    ],
    "correctAnswer": "won't be",
    "explanation": {
      "whyCorrectAr": "نستخدم won't be barking لنفي الاستمرار طوال الليل.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_17",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لن تكون تتناول غداءك عند الظهيرة غداً.",
    "sentenceWithBlank": "You _______ eating your lunch at noon tomorrow.",
    "options": [
      "won't",
      "won't be",
      "aren't",
      "didn't"
    ],
    "correctAnswer": "won't be",
    "explanation": {
      "whyCorrectAr": "نستخدم won't be لنفي المستقبل المستمر مع الضمير you.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_18",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "علي وأحمد لن يكونا يدرسان معاً الليلة.",
    "sentenceWithBlank": "Ali and Ahmed _______ studying together tonight.",
    "options": [
      "won't",
      "won't be",
      "aren't",
      "didn't"
    ],
    "correctAnswer": "won't be",
    "explanation": {
      "whyCorrectAr": "نستخدم won't be لنفي المستقبل المستمر للفاعل الجمع.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_19",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لن تكون السماء تمطر عندما تهبط الطائرة.",
    "sentenceWithBlank": "It _______ raining when you land.",
    "options": [
      "won't",
      "won't be",
      "isn't",
      "didn't"
    ],
    "correctAnswer": "won't be",
    "explanation": {
      "whyCorrectAr": "نستخدم won't be raining لنفي المطر المستمر في لحظة الهبوط.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_20",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "أمي لن تكون تطبخ السمك في الساعة 5 مساءً.",
    "sentenceWithBlank": "My mother _______ cooking fish at 5 PM.",
    "options": [
      "won't",
      "won't be",
      "isn't",
      "didn't"
    ],
    "correctAnswer": "won't be",
    "explanation": {
      "whyCorrectAr": "نستخدم won't be لنفي الاستمرار في وقت محدد بالمستقبل.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_21",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "هل ستكون تقرأ كتاباً في الساعة 9 مساءً غداً؟",
    "sentenceWithBlank": "_______ you be reading a book at 9 PM tomorrow?",
    "options": [
      "Will",
      "Are",
      "Did",
      "Do"
    ],
    "correctAnswer": "Will",
    "explanation": {
      "whyCorrectAr": "يبدأ السؤال في المستقبل المستمر بـ Will متبوعاً بالفاعل ثم be ثم الفعل مع ing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_22",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "هل ستكون نائمة عندما تتصل بها؟",
    "sentenceWithBlank": "_______ she be sleeping when you call?",
    "options": [
      "Will",
      "Is",
      "Did",
      "Does"
    ],
    "correctAnswer": "Will",
    "explanation": {
      "whyCorrectAr": "نستخدم Will في بداية السؤال عن المستقبل المستمر مع الفاعل المفرد she.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_23",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "هل سيكونون يلعبون كرة القدم مساء الغد؟",
    "sentenceWithBlank": "_______ they be playing football tomorrow evening?",
    "options": [
      "Will",
      "Are",
      "Did",
      "Do"
    ],
    "correctAnswer": "Will",
    "explanation": {
      "whyCorrectAr": "نبدأ السؤال بـ Will للسؤال عن نشاط مستمر في المستقبل.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_24",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "هل سيكون يقود بتلك السرعة لاحقاً؟",
    "sentenceWithBlank": "_______ he be driving at that speed later?",
    "options": [
      "Will",
      "Is",
      "Did",
      "Does"
    ],
    "correctAnswer": "Will",
    "explanation": {
      "whyCorrectAr": "نستخدم Will لتكوين سؤال المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_25",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "هل سنكون ننتظر لفترة طويلة جداً غداً؟",
    "sentenceWithBlank": "_______ we be waiting for too long tomorrow?",
    "options": [
      "Will",
      "Are",
      "Did",
      "Do"
    ],
    "correctAnswer": "Will",
    "explanation": {
      "whyCorrectAr": "نستخدم Will للسؤال مع الضمير we.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_26",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ماذا ستكون تفعل في الساعة 10 صباح الغد؟",
    "sentenceWithBlank": "What _______ you be doing at 10 AM tomorrow?",
    "options": [
      "will",
      "are",
      "did",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "في السؤال بأداة استفهام، يأتي الفعل المساعد will بعد أداة الاستفهام وقبل الفاعل.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_27",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "إلى أين ستكون ذاهبة عندما تقابلها؟",
    "sentenceWithBlank": "Where _______ she be going when you meet her?",
    "options": [
      "will",
      "is",
      "did",
      "does"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نضع will بعد Where لتكوين سؤال المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_28",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "لماذا سيكونون يضحكون أثناء الحصة؟",
    "sentenceWithBlank": "Why _______ they be laughing during the class?",
    "options": [
      "will",
      "are",
      "did",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will بعد أداة الاستفهام للسؤال عن سبب في المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_29",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "مع من سيكون يتحدث على الهاتف؟",
    "sentenceWithBlank": "Who _______ he be talking to on the phone?",
    "options": [
      "will",
      "is",
      "did",
      "does"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will بعد Who للسؤال عن الشخص في المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_30",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ماذا سيكون يأكل عندما تراه؟",
    "sentenceWithBlank": "What _______ it be eating when you see it?",
    "options": [
      "will",
      "is",
      "did",
      "does"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will لتكوين السؤال في المستقبل المستمر مع الفاعل it.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_31",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سأكون أحل واجبي في تلك اللحظة.",
    "sentenceWithBlank": "I will be _______ my homework at that moment.",
    "options": [
      "doing",
      "do",
      "did",
      "done"
    ],
    "correctAnswer": "doing",
    "explanation": {
      "whyCorrectAr": "بعد will be يأتي الفعل مضافاً إليه ing (doing).",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_32",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستكون ترتدي فستاناً جديداً للحفلة.",
    "sentenceWithBlank": "She will be _______ a new dress for the party.",
    "options": [
      "wear",
      "wearing",
      "wore",
      "worn"
    ],
    "correctAnswer": "wearing",
    "explanation": {
      "whyCorrectAr": "في زمن المستقبل المستمر بعد will be نستخدم wearing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_33",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيكونون يستمعون إلى الموسيقى في غرفتهم.",
    "sentenceWithBlank": "They will be _______ to music in their room.",
    "options": [
      "listen",
      "listening",
      "listened",
      "listens"
    ],
    "correctAnswer": "listening",
    "explanation": {
      "whyCorrectAr": "نستخدم الفعل المنتهي بـ ing بعد will be (listening).",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_34",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيكون يكتب رسالة إلى صديقه.",
    "sentenceWithBlank": "He will be _______ a letter to his friend.",
    "options": [
      "write",
      "writing",
      "wrote",
      "written"
    ],
    "correctAnswer": "writing",
    "explanation": {
      "whyCorrectAr": "بعد will be نستخدم writing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_35",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سنكون نستعد لامتحاناتنا طوال الأسبوع.",
    "sentenceWithBlank": "We will be _______ for our exams all week.",
    "options": [
      "prepare",
      "preparing",
      "prepared",
      "prepares"
    ],
    "correctAnswer": "preparing",
    "explanation": {
      "whyCorrectAr": "نستخدم صيغة ing (preparing) بعد will be.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_36",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيكون الأطفال يركضون في الحديقة.",
    "sentenceWithBlank": "The children will be _______ in the garden.",
    "options": [
      "run",
      "running",
      "ran",
      "runs"
    ],
    "correctAnswer": "running",
    "explanation": {
      "whyCorrectAr": "بعد will be يأتي الفعل مضافاً إليه ing مع مضاعفة حرف n (running).",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_37",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستكون تتحدث بصوت عالٍ جداً أثناء الفيلم.",
    "sentenceWithBlank": "You will be _______ too loud during the movie.",
    "options": [
      "speak",
      "speaking",
      "spoke",
      "speaks"
    ],
    "correctAnswer": "speaking",
    "explanation": {
      "whyCorrectAr": "نستخدم speaking بعد will be.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_38",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيكون الطاهي يعد وجبة لذيذة.",
    "sentenceWithBlank": "The chef will be _______ a delicious meal.",
    "options": [
      "make",
      "making",
      "made",
      "makes"
    ],
    "correctAnswer": "making",
    "explanation": {
      "whyCorrectAr": "بعد will be نستخدم making.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_39",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيكون الماء يقطر من السقف إذا تسرب.",
    "sentenceWithBlank": "Water will be _______ from the ceiling if it leaks.",
    "options": [
      "drip",
      "dripping",
      "dripped",
      "drips"
    ],
    "correctAnswer": "dripping",
    "explanation": {
      "whyCorrectAr": "نستخدم dripping بعد will be.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_40",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سيكون أصدقائي ذاهبين إلى السينما.",
    "sentenceWithBlank": "My friends will be _______ to the cinema.",
    "options": [
      "go",
      "going",
      "went",
      "gone"
    ],
    "correctAnswer": "going",
    "explanation": {
      "whyCorrectAr": "بعد will be نستخدم going.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_41",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "في مثل هذا الوقت غداً، سأكون أقرأ.",
    "sentenceWithBlank": "At this time tomorrow, I _______ reading.",
    "options": [
      "will",
      "will be",
      "am",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "العبارة At this time tomorrow تتطلب المستقبل المستمر (will be reading).",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_42",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "في الساعة 8 مساءً، ستكون تطبخ.",
    "sentenceWithBlank": "At 8 PM, she _______ cooking.",
    "options": [
      "will",
      "will be",
      "is",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "تحديد ساعة دقيقة في المستقبل يتطلب will be + V-ing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_43",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "في مثل هذا الوقت الأسبوع القادم، سيكونون يلعبون.",
    "sentenceWithBlank": "This time next week, they _______ playing.",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be للتعبير عن حدث مستمر في موعد محدد الأسبوع القادم.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_44",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "صباح الغد في الساعة 9، سأكون أدرس.",
    "sentenceWithBlank": "Tomorrow morning at 9, I _______ studying.",
    "options": [
      "will",
      "will be",
      "am",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be مع الفعل المنتهي بـ ing لوصف نشاط مستمر في الصباح.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_45",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "في منتصف الليل، سيكونون نائمين.",
    "sentenceWithBlank": "At midnight, they _______ sleeping.",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be sleeping للتعبير عن استمرار النوم عند منتصف الليل.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_46",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستكون الشمس مشرقة عندما نستيقظ غداً.",
    "sentenceWithBlank": "The sun _______ shining when we wake up tomorrow.",
    "options": [
      "will",
      "will be",
      "is",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be shining للتعبير عن حدث مستمر لحظة الاستيقاظ.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_47",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستكون الرياح تهب طوال الليل غداً.",
    "sentenceWithBlank": "The wind _______ blowing all night tomorrow.",
    "options": [
      "will",
      "will be",
      "is",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "العبارة all night tomorrow تدل على استمرار هبوب الرياح، فنستخدم will be blowing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_48",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "سنكون نتناول العشاء في الساعة 7 مساءً.",
    "sentenceWithBlank": "We _______ having dinner at 7 PM.",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be having للتعبير عن تناول العشاء المستمر في الساعة السابعة.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_49",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستكون ترتدي معطفاً أحمر غداً.",
    "sentenceWithBlank": "She _______ wearing a red coat tomorrow.",
    "options": [
      "will",
      "will be",
      "is",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be wearing للدلالة على استمرار ارتداء المعطف.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_easy_50",
    "tenseId": "future_continuous",
    "difficulty": "easy",
    "type": "multiple_choice",
    "promptAr": "ستكون تقود بسرعة كبيرة عندما تعبر الجسر.",
    "sentenceWithBlank": "You _______ driving too fast when you cross the bridge.",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be driving للتعبير عن قيادة مستمرة أثناء عبور الجسر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  }
];
