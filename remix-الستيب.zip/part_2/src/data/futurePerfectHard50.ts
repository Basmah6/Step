import { QuizQuestion } from '../types';

export const FUTURE_PERFECT_HARD_50: QuizQuestion[] = [
  {
    id: "fp_hard_1",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "بحلول هذا الوقت من العام القادم، سيكون هذا أفضل فيلم سأكون قد رأيته على الإطلاق.",
    sentenceWithBlank: "By this time next year, this will be the best movie I _______ ever seen.",
    options: [
      "will has",
      "will have",
      "am have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "في التركيب المستقبلي بعد صيغة التفضيل العليا (the best movie...) يتبعها المستقبل التام (will have seen).",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_2",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون هذه المرة الأولى التي ستكون قد زارت فيها بلدنا بحلول الشهر القادم.",
    sentenceWithBlank: "It will be the first time she _______ visited our country by next month.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "التركيب (It will be the first time) في المستقبل يتبعه مستقبل تام (will have visited).",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_3",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "لا أحد من العمال سيكون قد أنهى مهامه بحلول الموعد النهائي غداً.",
    sentenceWithBlank: "Neither of the workers _______ finished their tasks by the deadline tomorrow.",
    options: [
      "will has",
      "will have",
      "have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "التركيب مع Neither يأخذ will have finished في زمن المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_4",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون عدد السياح الذين يزورون المتحف قد ازداد بشكل كبير بحلول العام القادم.",
    sentenceWithBlank: "The number of tourists visiting the museum _______ increased significantly by next year.",
    options: [
      "will have",
      "will has",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "عبارة (The number of) تعبر عن رقم إحصائي وتأخذ (will have increased).",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_5",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون عدد من العمال قد اشتكوا بحلول الغد.",
    sentenceWithBlank: "A number of workers _______ have complained by tomorrow.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "عبارة (A number of) تعني 'العديد من' وتأخذ الفعل المساعد will have.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_6",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون الرياضيات قد لعبت دوراً حاسماً في العلوم بحلول نهاية الدورة.",
    sentenceWithBlank: "Mathematics _______ played a crucial role in science by the end of the course.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "اسم المادة الدراسية (Mathematics) مفرد ويأخذ will have played في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_7",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون خمسون دولاراً قد أُنفقت على المشروع بحلول الغد.",
    sentenceWithBlank: "Fifty dollars _______ been spent on the project by tomorrow.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "المبالغ المالية كوحدة واحدة تأخذ will have been spent في المستقبل التام المبني للمجهول.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_8",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون كل واحد من الطلاب قد سلم تقريره بحلول الغد.",
    sentenceWithBlank: "Each of the students _______ submitted their report by tomorrow.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "الفاعل المسبوق بـ Each يأخذ will have submitted في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_9",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون أكثر من شخص واحد قد أعرب عن اهتمامه بحلول الغد.",
    sentenceWithBlank: "More than one person _______ expressed interest by tomorrow.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "التركيب (More than one) يأخذ will have expressed في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_10",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون الفيزياء قد أسرت أجيالاً من العلماء بحلول القرن القادم.",
    sentenceWithBlank: "Physics _______ fascinated generations of scientists by next century.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "أسماء العلوم والمواد (Physics) تأخذ will have fascinated.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_11",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون الخبز والزبدة فطوري المفضل لسنوات بحلول الشهر القادم.",
    sentenceWithBlank: "Bread and butter _______ been my favorite breakfast for years by next month.",
    options: [
      "will have",
      "will has",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "الوجبة المشتركة كوحدة واحدة تأخذ will have been.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_12",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون الشرطة قد اعتقلت المشتبه به بحلول صباح الغد.",
    sentenceWithBlank: "The police _______ arrested the suspect by tomorrow morning.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "كلمة Police تعامل دائماً كجمع وتأخذ will have arrested.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_13",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون عائلتي قد دعمت أهدافي دائماً بحلول وقت تخرجي.",
    sentenceWithBlank: "My family _______ always supported my goals by the time I graduate.",
    options: [
      "will have",
      "will has",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have supported للدلالة على استمرار دعم العائلة حتى التخرج.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_14",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون اللجنة قد توصلت إلى قرار نهائي بحلول اجتماع الغد.",
    sentenceWithBlank: "The committee _______ reached a final decision by tomorrow's meeting.",
    options: [
      "will have",
      "will has",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "اللجنة ككيان موحد تأخذ will have reached.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_15",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "لا المعلم ولا الطلاب سيكونون قد وصلوا بحلول رنين الجرس غداً.",
    sentenceWithBlank: "Neither the teacher nor the students _______ arrived by the bell tomorrow.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "في تركيب Neither... nor يأخذ المستقبل التام will have arrived.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_16",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "لا الطلاب ولا المعلم سيكون قد وصل بحلول رنين الجرس غداً.",
    sentenceWithBlank: "Neither the students nor the teacher _______ arrived by the bell tomorrow.",
    options: [
      "will have",
      "will has",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "صيغة المستقبل التام لجميع حالات الفاعل هي will have + V3.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_17",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "نادراً ما سيكون أي شخص قد حقق مثل هذه الدرجة العالية بحلول نهاية العام.",
    sentenceWithBlank: "Rarely _______ achieved such a high score by the end of the year.",
    options: [
      "will have anyone",
      "will anyone have",
      "have anyone will",
      "anyone will have"
],
    correctAnswer: "will anyone have",
    explanation: {
      whyCorrectAr: "عند البدء بظرف نفي (Rarely)، يقلب الفعل المساعد والفاعل في المستقبل (Rarely will anyone have achieved).",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_18",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "لن أكون قد رأيت مهنياً مخلصاً بهذا الشكل قط بحلول وقت تقاعدي.",
    sentenceWithBlank: "Never _______ seen such a dedicated professional by the time I retire.",
    options: [
      "will have I",
      "will I have",
      "have I will",
      "I will have"
],
    correctAnswer: "will I have",
    explanation: {
      whyCorrectAr: "تقديم ظرف النفي (Never) يولد قلباً نحوياً (Inversion): will I have seen.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_19",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "مرتين فقط ستكون قد سافرت إلى الخارج بحلول تخرجها.",
    sentenceWithBlank: "Only twice _______ traveled abroad by her graduation.",
    options: [
      "will have she",
      "will she have",
      "have she will",
      "she will have"
],
    correctAnswer: "will she have",
    explanation: {
      whyCorrectAr: "تقديم الظرف (Only twice) يتطلب قلباً نحوياً: will she have traveled.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_20",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "قليلاً ما ستكون قد علمت بشأن المفاجأة بحلول الغد.",
    sentenceWithBlank: "Little _______ known about the surprise by tomorrow.",
    options: [
      "will have she",
      "will she have",
      "have she will",
      "she will have"
],
    correctAnswer: "will she have",
    explanation: {
      whyCorrectAr: "البدء بـ Little النافية يولد قلباً نحوياً: will she have known.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_21",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون هذه المرة الثانية التي سيكون قد نسي فيها مفاتيحه.",
    sentenceWithBlank: "This will be the second time he _______ forgotten his keys.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "التركيب (This will be the second time) يتبعه مستقبل تام (will have forgotten).",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_22",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون المهمة الأكثر تحدياً التي سأكون قد خضتها على الإطلاق بحلول الأسبوع القادم.",
    sentenceWithBlank: "It will be the most challenging task I _______ ever undertaken by next week.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "بعد صيغة التفضيل العليا في المستقبل نستخدم المستقبل التام (will have undertaken).",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_23",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "إنه يتحدث كما لو أنه سيكون قد سافر حول العالم بأكمله بحلول العام القادم.",
    sentenceWithBlank: "He talks as if he _______ traveled all over the world by next year.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "بعد (as if) في السياق المستقبلي الافتراضي نستخدم المستقبل التام (will have traveled).",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_24",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "بحلول الوقت الذي أغادر فيه، ستكون قد وصلت.",
    sentenceWithBlank: "By the time I leave, she _______ arrived.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "الروابط الزمنية للدلالة على اكتمال حدث مستقبلي أسبق تتطلب المستقبل التام (will have arrived).",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_25",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "بمجرد أن يكون العقد قد تم توقيعه، سنبدأ المشروع.",
    sentenceWithBlank: "Once the contract _______ been signed, we will start the project.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "المبني للمجهول في المستقبل التام يأخذ will have been signed.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_26",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "على افتراض أن الجميع سيكونون قد وافقوا على الشروط بحلول الغد، ما هي خطوتنا التالية؟",
    sentenceWithBlank: "Supposing that everyone _______ agreed to the terms by tomorrow, what is our next step?",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "الضمير everyone يأخذ will have agreed في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_27",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سواء كانت الخطة قد نجحت أو فشلت بحلول الأسبوع القادم، يجب أن نمضي قدماً.",
    sentenceWithBlank: "Whether the plan _______ succeeded or failed by next week, we must move on.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have succeeded للتعبير عن اكتمال النتيجة بحلول الأسبوع القادم.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_28",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "مهما كان ما سيكون قد حدث بحلول الغد، سنظل متفائلين.",
    sentenceWithBlank: "No matter what _______ happened by tomorrow, we will remain optimistic.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "نستخدم will have happened مع الضمير الموصول what في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_29",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون البيانات قد أظهرت اتجاهات مثيرة للاهتمام بحلول نهاية الدراسة.",
    sentenceWithBlank: "The data _______ shown interesting trends by the end of the study.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "كلمة Data تأخذ will have shown في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_30",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون المقص قد وُضع على الرف العلوي بحلول الغد.",
    sentenceWithBlank: "The scissors _______ been placed on the top shelf by tomorrow.",
    options: [
      "will has",
      "will have",
      "have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "الاسم الثنائي scissors يأخذ will have been placed في صيغة المبني للمجهول.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_31",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون بنطالي قد تم غسله بحلول الغد.",
    sentenceWithBlank: "My trousers _______ been washed by tomorrow.",
    options: [
      "will has",
      "will have",
      "have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "كلمة trousers جمع دائماً وتأخذ will have been washed.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_32",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون مرض الحصبة قد تفشى في عدة مدارس بحلول الشتاء القادم.",
    sentenceWithBlank: "Measles _______ broken out in several schools by next winter.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "اسم المرض المفرد Measles يأخذ will have broken out.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_33",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون الولايات المتحدة قد وقعت اتفاقية تجارية جديدة بحلول الشهر القادم.",
    sentenceWithBlank: "The United States _______ signed a new trade agreement by next month.",
    options: [
      "will have",
      "will has",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "اسم الدولة المفرد (The United States) يأخذ will have signed.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_34",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون علم الاقتصاد قد أصبح تخصصاً ذا شعبية واسعة بحلول وقت تخرجه.",
    sentenceWithBlank: "Economics _______ become a very popular major by the time he graduates.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "اسم العلم المفرد Economics يأخذ will have become.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_35",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون طاقم الطائرة قد أنهى فحص جميع المعدات بحلول الإقلاع غداً.",
    sentenceWithBlank: "The crew _______ finished checking all equipment by takeoff tomorrow.",
    options: [
      "will have",
      "will has",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "طاقم العمل يأخذ will have finished في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_36",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون الجمهور قد أبدى اهتماماً كبيراً بحلول وقت افتتاح العرض.",
    sentenceWithBlank: "The public _______ shown great interest by the time the show opens.",
    options: [
      "will have",
      "will has",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "الجمهور كوحدة واحدة يأخذ will have shown.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_37",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "بحلول عام 2030، ستكون عشر سنوات قد انقضت.",
    sentenceWithBlank: "By 2030, ten years _______ passed.",
    options: [
      "will has",
      "will have",
      "have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "الفترات الزمنية المحددة في نقطة بالمستقبل تأخذ will have passed.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_38",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "ستكون ثلاثة أميال قد قُطعت من قبل العدائين بحلول ظهر الغد.",
    sentenceWithBlank: "Three miles _______ been covered by the runners by noon tomorrow.",
    options: [
      "will has",
      "will have",
      "have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "المسافات كوحدة قياس في المبني للمجهول تأخذ will have been covered.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_39",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون أي من المقترحين قد تم اعتماده بحلول بعد ظهر الغد.",
    sentenceWithBlank: "Either of the proposals _______ been approved by tomorrow afternoon.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "كلمة Either تأخذ will have been approved.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_40",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "لا أي من الخطتين ستكون قد أثمرت كما هو متوقع بحلول الأسبوع القادم.",
    sentenceWithBlank: "Neither of the two plans _______ worked as expected by next week.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "التركيب مع Neither يأخذ will have worked.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_41",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "لن يكون المدير قد استقال فحسب، بل سيكون قد فوّت الاجتماع أيضاً.",
    sentenceWithBlank: "The manager will not only have resigned, but he _______ also missed the meeting.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "العطف بـ not only... but also في المستقبل التام يقتضي استخدام will have.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_42",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "نادراً ما سأكون قد جربت مثل هذا الدفء بحلول نهاية رحلتي.",
    sentenceWithBlank: "Seldom _______ experienced such warmth by the end of my journey.",
    options: [
      "will have I",
      "will I have",
      "have I will",
      "I will have"
],
    correctAnswer: "will I have",
    explanation: {
      whyCorrectAr: "تقديم ظرف النفي Seldom يتطلب قلباً نحوياً (will I have experienced).",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_43",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "مهما حاولوا جاهدين، فلن يكونوا قد نجحوا بحلول الموعد النهائي.",
    sentenceWithBlank: "Try as they _______, they will not have succeeded by the deadline.",
    options: [
      "will has",
      "will have",
      "have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "في هذا التركيب الشرطي المستقبلي نستخدم will have.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_44",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون الكثير من التقدم قد أُحرز في العلوم بحلول نهاية العقد.",
    sentenceWithBlank: "Much progress _______ been made in science by the end of the decade.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "كلمة progress غير المعدودة تأخذ will have been made في المبني للمجهول.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_45",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون قدر كبير من المال قد تم استثماره بحلول وقت انهيار السوق.",
    sentenceWithBlank: "A great deal of money _______ been invested by the time the market crashes.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "عبارة A great deal of تتبعها كلمة غير معدودة وتأخذ will have been invested.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_46",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون الكثير من الوقت قد أُعطي بحلول وقت بدء الاختبار غداً.",
    sentenceWithBlank: "Plenty of time _______ been given by the time the test begins tomorrow.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "كلمة time غير المعدودة تأخذ will have been given.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_47",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون معظم الكعك قد أُكل بحلول وقت وصولي.",
    sentenceWithBlank: "Most of the cake _______ been eaten by the time I arrive.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "عبارة Most of متبوعة باسم مفرد cake تأخذ will have been eaten.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_48",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون معظم التفاح قد أُكل بحلول وقت وصولي.",
    sentenceWithBlank: "Most of the apples _______ been eaten by the time I arrive.",
    options: [
      "will has",
      "will have",
      "have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "عبارة Most of متبوعة باسم جمع apples تأخذ will have been eaten في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_49",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون نصف المال قد أُنفق بحلول وقت التدقيق الأسبوع القادم.",
    sentenceWithBlank: "Half of the money _______ been spent by the time of the audit next week.",
    options: [
      "will has",
      "will have",
      "has",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "عبارة Half of مع اسم غير معدود money تأخذ will have been spent.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  },
  {
    id: "fp_hard_50",
    tenseId: "future_perfect",
    difficulty: "hard",
    type: "multiple_choice",
    promptAr: "سيكون نصف الطلاب قد اجتازوا الامتحان بحلول مراجعة الغد.",
    sentenceWithBlank: "Half of the students _______ passed the exam by tomorrow's revision.",
    options: [
      "will has",
      "will have",
      "have",
      "had"
],
    correctAnswer: "will have",
    explanation: {
      whyCorrectAr: "عبارة Half of مع اسم جمع students تأخذ will have passed في المستقبل التام.",
      temporalRelationshipAr: "حدث سيكتمل ويتحقق قبل نقطة زمنية محددة أو قبل حدث آخر في المستقبل.",
      whyTenseFitsAr: "المستقبل التام (Future Perfect) يُستخدم للتعبير عن اكتمال وقوع الفعل قبل موعد مستقبلي محدد (will have + V3).",
      whyOthersWrongAr: "الخيارات الأخرى غير صحيحة لأنها لا تطابق قاعدة المستقبل التام (will have + past participle).",
      confusableTenseAr: "Future Simple / Present Perfect"
    }
  }
];
