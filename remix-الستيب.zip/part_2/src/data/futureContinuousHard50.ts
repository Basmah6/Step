import { QuizQuestion } from '../types';

export const FUTURE_CONTINUOUS_HARD_50: QuizQuestion[] = [
  {
    "id": "fc_hard_1",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "في مثل هذا الوقت غداً، سأكون أفكر في المشكلة.",
    "sentenceWithBlank": "At this time tomorrow, I _______ thinking about the problem.",
    "options": [
      "will be",
      "will",
      "am",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "فعل التفكير عندما يكون نشاطاً عقلياً مستمراً في وقت محدد بالمستقبل يأخذ المستقبل المستمر (will be thinking).",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_2",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ستكون تقضي وقتاً رائعاً خلال رحلتها الأسبوع القادم.",
    "sentenceWithBlank": "She _______ having a wonderful time during her trip next week.",
    "options": [
      "will be",
      "will",
      "is",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "الفعل have بمعنى الاستمتاع يقبل الاستمرار، ومع المستقبل المستمر نستخدم will be having.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_3",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "لماذا ستكون تتصرف بهذه الصعوبة أثناء اجتماع الغد؟",
    "sentenceWithBlank": "Why _______ you be being so difficult during tomorrow's meeting?",
    "options": [
      "will",
      "are",
      "did",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "استخدام being مع صفة يعبر عن سلوك مؤقت متوقع، ونستخدم will لتكوين السؤال في المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_4",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ستكون الشرطة تبحث في المبنى في الساعة 8 صباح الغد.",
    "sentenceWithBlank": "The police _______ be searching the building at 8 AM tomorrow.",
    "options": [
      "will",
      "is",
      "did",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "كلمة Police تعامل دائماً كاسم جمع وتأخذ will be searching في المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_5",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ستكون مادة الرياضيات تتحدى الطلاب الفصل الدراسي القادم.",
    "sentenceWithBlank": "Mathematics _______ be challenging students next term.",
    "options": [
      "will",
      "are",
      "did",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "أسماء المواد الدراسية (Mathematics) مفردة دائماً وتأخذ will be challenging.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_6",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ستكون خمسون دولاراً تتراكم في الحساب بحلول الشهر القادم.",
    "sentenceWithBlank": "Fifty dollars _______ be accumulating in the account by next month.",
    "options": [
      "will",
      "are",
      "did",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "المبالغ المالية كوحدة واحدة تأخذ will be في المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_7",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ستكون عائلتي تتناول العشاء معاً في الساعة 7 مساء غد.",
    "sentenceWithBlank": "My family _______ having dinner together at 7 PM tomorrow.",
    "options": [
      "will be",
      "will",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "عند التركيز على أفراد العائلة كنشاط مستمر في وقت محدد نستخدم will be having.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_8",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيتم تقديم الأرز والفاصولياء في وليمة الغد.",
    "sentenceWithBlank": "Rice and beans _______ be served at tomorrow's feast.",
    "options": [
      "will",
      "am",
      "did",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "الفعل المساعد في المستقبل مع الأسماء المعطوفة بـ and هو will.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_9",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون كل طالب وكل معلم يعمل بجد على المعرض غداً.",
    "sentenceWithBlank": "Every student and every teacher _______ working hard on the exhibition tomorrow.",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "الفاعل المسبوق بـ Every يأخذ will be working في المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_10",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "لا المعلم ولا الطلاب سيكونون منتبهين غداً.",
    "sentenceWithBlank": "Neither the teacher nor the students _______ paying attention tomorrow.",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "في تركيب Neither... nor للمستقبل المستمر نستخدم will be paying.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_11",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "لا الطلاب ولا المعلم سيكون منتبهاً غداً.",
    "sentenceWithBlank": "Neither the students nor the teacher _______ paying attention tomorrow.",
    "options": [
      "will be",
      "will",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "صيغة المستقبل المستمر لجميع حالات الفاعل هي will be + V-ing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_12",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون طاقم العمل يعقد مؤتمراً في الساعة 10 صباح الغد.",
    "sentenceWithBlank": "The staff _______ holding a conference at 10 AM tomorrow.",
    "options": [
      "will be",
      "will",
      "is",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "طاقم العمل كأفراد يعقدون اجتماعاً في وقت محدد يأخذون will be holding.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_13",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون عدد من الطلاب يحتجون ضد القرار غداً.",
    "sentenceWithBlank": "A number of students _______ protesting against the decision tomorrow.",
    "options": [
      "will",
      "will be",
      "am",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "عبارة A number of تعني العديد من وتأخذ will be protesting.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_14",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون عدد السياح الذين يزورون المدينة يتزايد بسرعة العام القادم.",
    "sentenceWithBlank": "The number of tourists visiting the city _______ increasing rapidly next year.",
    "options": [
      "will be",
      "will",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "عبارة The number of تعبر عن المعدل الإحصائي وتأخذ will be increasing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_15",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون كل واحد من المشاركين يقدم ملاحظاته أثناء ندوة الغد.",
    "sentenceWithBlank": "Each of the participants _______ giving feedback during tomorrow's seminar.",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "الكلمة المفتاحية Each تأخذ will be giving في المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_16",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون أي من الخيارين تحت الدراسة من قبل مجلس الإدارة غداً.",
    "sentenceWithBlank": "Either of the options _______ be considered by the board tomorrow.",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be considered مع Either.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_17",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون أكثر من شخص واحد ينتظر بالخارج عندما تبدأ السماء بالمطر غداً.",
    "sentenceWithBlank": "More than one person _______ waiting outside when it starts to rain tomorrow.",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "التركيب More than one person يأخذ will be waiting في المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_18",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ستتم دراسة الفيزياء من قبل الباحثين في ذلك المختبر الفصل القادم.",
    "sentenceWithBlank": "Physics _______ be studied by researchers in that lab next term.",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "اسم العلم المفرد Physics يأخذ will be.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_19",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيتم تقديم الخبز والزبدة في إفطار الغد.",
    "sentenceWithBlank": "Bread and butter _______ be served at tomorrow's breakfast.",
    "options": [
      "will be",
      "will",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "الوجبة المشتركة تعامل كوحدة واحدة وتأخذ will be.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_20",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "لماذا لن يكون أحد يستمع عندما يتحدث المدير غداً؟",
    "sentenceWithBlank": "Why _______ nobody listening when the director speaks tomorrow?",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "مع nobody نستخدم will be listening في المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_21",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "انظر! سيكون الجميع ينتظرون الإعلان عند ظهيرة الغد.",
    "sentenceWithBlank": "Look! Everybody _______ waiting for the announcement at noon tomorrow.",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "الضمير Everybody يأخذ will be waiting.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_22",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ماذا ستكون الأخبار تنقله عن العاصفة مساء الغد؟",
    "sentenceWithBlank": "What _______ the news reporting about the storm tomorrow evening?",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be reporting مع اسم الأخبار المفرد news.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_23",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ستكون البيانات تظهر اتجاهات مثيرة للاهتمام أثناء تحليل الغد.",
    "sentenceWithBlank": "The data _______ showing interesting trends during tomorrow's analysis.",
    "options": [
      "will be",
      "will",
      "is",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "نستخدم will be showing في المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_24",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون المقص مستخدماً من قبل الخياط بعد ظهر الغد.",
    "sentenceWithBlank": "The scissors _______ be used by the tailor tomorrow afternoon.",
    "options": [
      "will",
      "will be",
      "is",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "الأدوات الثنائية مثل scissors تعامل كجمع وتأخذ will be.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_25",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون بنطالي يتبلل في المطر الغزير غداً.",
    "sentenceWithBlank": "My trousers _______ be getting wet in the heavy rain tomorrow.",
    "options": [
      "will",
      "will be",
      "is",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "الاسم الجمع trousers يأخذ will be getting.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_26",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون الحصبة ينتشر بسرعة بين الأطفال في الشتاء القادم.",
    "sentenceWithBlank": "Measles _______ be spreading rapidly among children next winter.",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "اسم المرض المفرد Measles يأخذ will be spreading.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_27",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ستكون الولايات المتحدة ترسل مساعدات إلى مناطق الكوارث في ذلك الوقت.",
    "sentenceWithBlank": "The United States _______ be sending aid to disaster zones at that time.",
    "options": [
      "will be",
      "will",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "اسم الدولة المفرد The United States يأخذ will be sending.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_28",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون علم الاقتصاد يكتسب شعبية بين الطلاب العام القادم.",
    "sentenceWithBlank": "Economics _______ be gaining popularity among students next year.",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "اسم العلم المفرد Economics يأخذ will be gaining.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_29",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون طاقم الطائرة يجهز الطائرة في الساعة 5 مساء غد.",
    "sentenceWithBlank": "The crew _______ be preparing the aircraft at 5 PM tomorrow.",
    "options": [
      "will be",
      "will",
      "is",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "طاقم العمل كأفراد يعملون معاً يأخذون will be preparing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_30",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون الجمهور يظهر اهتماماً كبيراً بالمحاكمة غداً.",
    "sentenceWithBlank": "The public _______ showing great interest in the trial tomorrow.",
    "options": [
      "will be",
      "will",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "الجمهور كوحدة واحدة يأخذ will be showing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_31",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون دائماً يتذمر من وظيفته العام القادم.",
    "sentenceWithBlank": "He _______ complaining about his job next year.",
    "options": [
      "will always",
      "will always be",
      "always will",
      "did always"
    ],
    "correctAnswer": "will always be",
    "explanation": {
      "whyCorrectAr": "للتعبير عن عادة مزعجة مستمرة في المستقبل نستخدم will always be + V-ing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_32",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "لماذا ستكون دائماً تقاطعني غداً؟",
    "sentenceWithBlank": "Why _______ you always be interrupting me tomorrow?",
    "options": [
      "will",
      "are",
      "did",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "في صيغة التذمر المستمر في المستقبل، نستخدم will قبل الفاعل you.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_33",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون قطيع الماشية يرعى في الحقل غداً.",
    "sentenceWithBlank": "The herd of cattle _______ be grazing in the field tomorrow.",
    "options": [
      "will be",
      "will",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "اسم الجمع كوحدة واحدة herd يأخذ will be grazing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_34",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ستكون عشر سنوات تنقضي بسرعة كبيرة خلال تلك الأيام الرائعة.",
    "sentenceWithBlank": "Ten years _______ be passing very quickly during those wonderful days.",
    "options": [
      "will",
      "will be",
      "is",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "الفترة الزمنية كوحدة متتابعة تأخذ will be passing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_35",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون العداؤون يقطعون ثلاثة أميال غداً.",
    "sentenceWithBlank": "The runners _______ be covering three miles tomorrow.",
    "options": [
      "will",
      "will be",
      "is",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "الفاعل الجمع runners يأخذ will be covering.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_36",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "نادراً ما سأكون أختبر مثل هذا التركيز الشديد خلال شبابي.",
    "sentenceWithBlank": "Seldom _______ experiencing such intense focus during my youth.",
    "options": [
      "will I be",
      "I will be",
      "will be I",
      "be will I"
    ],
    "correctAnswer": "will I be",
    "explanation": {
      "whyCorrectAr": "تقديم ظرف النفي Seldom يتطلب قلباً نحوياً (Inversion): will + الفاعل I + be.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_37",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "لن يكون أبداً يستمع إلى النصيحة غداً.",
    "sentenceWithBlank": "Never _______ he be listening to advice tomorrow.",
    "options": [
      "will",
      "will be",
      "did",
      "is"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "تقديم ظرف النفي Never يولد قلباً باستخدام will قبل الفاعل he.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_38",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "حينها فقط ستكون تدرك الحقيقة.",
    "sentenceWithBlank": "Only then _______ she be realizing the truth.",
    "options": [
      "will",
      "would",
      "did",
      "is"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "البدء بـ Only then يتطلب قلباً في المستقبل بـ will قبل she.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_39",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "قليلاً ما سيكون منتبهاً غداً.",
    "sentenceWithBlank": "Little _______ he be paying attention tomorrow.",
    "options": [
      "will",
      "would",
      "did",
      "is"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "البدء بـ Little النافية يولد قلباً بتقديم will على الفاعل he.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_40",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "سيكون نصف الطلاب يتدربون طوال الصباح غداً.",
    "sentenceWithBlank": "Half of the students _______ be practicing all morning tomorrow.",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will be",
    "explanation": {
      "whyCorrectAr": "Half of متبوعة باسم معدود جمع تأخذ will be practicing.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_41",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "في ماذا ستكون تفكر أثناء محاضرة الغد؟",
    "sentenceWithBlank": "What _______ you be thinking about during tomorrow's lecture?",
    "options": [
      "will",
      "are",
      "did",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will بعد أداة الاستفهام لتكوين سؤال المستقبل المستمر مع you.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_42",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "لماذا ستكون تتجنبني طوال اليوم الثلاثاء القادم؟",
    "sentenceWithBlank": "Why _______ she be avoiding me all day next Tuesday?",
    "options": [
      "will",
      "are",
      "did",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "الفاعل المفرد she يأخذ will للسؤال عن المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_43",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "من سيكون يسرب معلومات سرية في ذلك الوقت غداً؟",
    "sentenceWithBlank": "Who _______ be leaking confidential information at that time tomorrow?",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نضع will بعد أداة الاستفهام Who وقبل be leaking.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_44",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كم من الوقت سيكونون واقفين تحت المطر غداً؟",
    "sentenceWithBlank": "How long _______ they be standing in the rain tomorrow?",
    "options": [
      "will",
      "are",
      "did",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will لتكوين السؤال في المستقبل المستمر مع they.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_45",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "أين سيكون يقيم أثناء تواجده في المدينة الشهر القادم؟",
    "sentenceWithBlank": "Where _______ he be staying while in town next month?",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will بعد Where وقبل he be staying.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_46",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "مع أي شركة ستكون تتعاون الشهر القادم؟",
    "sentenceWithBlank": "Which company _______ you be collaborating with next month?",
    "options": [
      "will",
      "are",
      "did",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will لتكوين السؤال مع you في المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_47",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كم فصلاً ستكون تحرر بعد ظهر الغد؟",
    "sentenceWithBlank": "How many chapters _______ she be editing tomorrow afternoon?",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will بعد العبارة الاستفهامية وقبل she.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_48",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "لماذا ستكون الطابعة تصدر ذلك الصوت الغريب عندما تستخدمها غداً؟",
    "sentenceWithBlank": "Why _______ the printer be making that weird noise when you use it tomorrow?",
    "options": [
      "will",
      "will be",
      "are",
      "did"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "الفاعل المفرد the printer يأخذ will للسؤال في المستقبل المستمر.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_49",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "كم من الجهد ستكون تبذله في تلك المهمة الأسبوع القادم؟",
    "sentenceWithBlank": "How much effort _______ you be putting into that task next week?",
    "options": [
      "will",
      "are",
      "did",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will لتكوين السؤال مع you.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  },
  {
    "id": "fc_hard_50",
    "tenseId": "future_continuous",
    "difficulty": "hard",
    "type": "multiple_choice",
    "promptAr": "ماذا ستكون تحقق في مسيرتك المهنية بحلول العام القادم؟",
    "sentenceWithBlank": "What _______ you be achieving in your career by next year?",
    "options": [
      "will",
      "are",
      "did",
      "do"
    ],
    "correctAnswer": "will",
    "explanation": {
      "whyCorrectAr": "نستخدم will للسؤال عن المستقبل المستمر مع you.",
      "temporalRelationshipAr": "حدث سيكون في طور الاستمرار في وقت محدد أو متزامن مع حدث آخر في المستقبل.",
      "whyTenseFitsAr": "المستقبل المستمر (Future Continuous) يُستخدم للتعبير عن حدث مستمر في لحظة مستقبلية محددة (will be + V-ing).",
      "whyOthersWrongAr": "الخيارات الأخرى غير صحيحة لأنها لا تتطابق مع زمن المستقبل المستمر أو تخالف قواعد التركيب النحوي.",
      "confusableTenseAr": "Future Simple / Present Continuous"
    }
  }
];
