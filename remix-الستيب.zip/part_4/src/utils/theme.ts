export type AppTheme =
  | 'dark'
  | 'light'
  | 'pink'
  | 'purple'
  | 'yellow'
  | 'orange'
  | 'green'
  | 'red';

export interface ThemeOption {
  id: AppTheme;
  nameAr: string;
  colorName: string;
  iconColor: string;
  bgPreview: string;
  borderPreview: string;
  dotBg: string;
}

export const THEME_OPTIONS: ThemeOption[] = [
  {
    id: 'dark',
    nameAr: 'الوضع الليلي (Dark)',
    colorName: 'ليلي',
    iconColor: '#6366f1',
    bgPreview: '#020617',
    borderPreview: '#1e293b',
    dotBg: 'bg-slate-900 border-slate-700',
  },
  {
    id: 'light',
    nameAr: 'الوضع الأبيض (Light)',
    colorName: 'أبيض',
    iconColor: '#4f46e5',
    bgPreview: '#f8fafc',
    borderPreview: '#cbd5e1',
    dotBg: 'bg-white border-slate-300',
  },
  {
    id: 'pink',
    nameAr: 'الوضع الوردي (Pink)',
    colorName: 'وردي',
    iconColor: '#ec4899',
    bgPreview: '#190614',
    borderPreview: '#3b1230',
    dotBg: 'bg-pink-500 border-pink-400',
  },
  {
    id: 'purple',
    nameAr: 'الوضع البنفسجي (Purple)',
    colorName: 'بنفسجي',
    iconColor: '#a855f7',
    bgPreview: '#100720',
    borderPreview: '#2e1250',
    dotBg: 'bg-purple-500 border-purple-400',
  },
  {
    id: 'yellow',
    nameAr: 'الوضع الأصفر (Yellow)',
    colorName: 'أصفر',
    iconColor: '#eab308',
    bgPreview: '#161204',
    borderPreview: '#3a2f0a',
    dotBg: 'bg-yellow-500 border-yellow-400',
  },
  {
    id: 'orange',
    nameAr: 'الوضع البرتقالي (Orange)',
    colorName: 'برتقالي',
    iconColor: '#f97316',
    bgPreview: '#180a04',
    borderPreview: '#3e1a0a',
    dotBg: 'bg-orange-500 border-orange-400',
  },
  {
    id: 'green',
    nameAr: 'الوضع الأخضر (Green)',
    colorName: 'أخضر',
    iconColor: '#10b981',
    bgPreview: '#04160e',
    borderPreview: '#0d3b27',
    dotBg: 'bg-emerald-500 border-emerald-400',
  },
  {
    id: 'red',
    nameAr: 'الوضع الأحمر (Red)',
    colorName: 'أحمر',
    iconColor: '#ef4444',
    bgPreview: '#180505',
    borderPreview: '#3d0f0f',
    dotBg: 'bg-rose-500 border-rose-400',
  },
];

const THEME_STORAGE_KEY = 'tense_master_theme_v1';

export function getSavedTheme(): AppTheme {
  try {
    const saved = localStorage.getItem(THEME_STORAGE_KEY) as AppTheme;
    if (saved && THEME_OPTIONS.some(t => t.id === saved)) {
      return saved;
    }
  } catch {}
  return 'light';
}

export function saveTheme(theme: AppTheme): void {
  try {
    localStorage.setItem(THEME_STORAGE_KEY, theme);
    applyThemeToDocument(theme);
  } catch {}
}

export function applyThemeToDocument(theme: AppTheme): void {
  const root = document.documentElement;
  // Remove existing theme classes
  THEME_OPTIONS.forEach(t => {
    root.classList.remove(`theme-${t.id}`);
  });
  // Add new theme class
  root.classList.add(`theme-${theme}`);
  root.setAttribute('data-theme', theme);
}
