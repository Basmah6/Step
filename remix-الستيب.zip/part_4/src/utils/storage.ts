import { ErrorRecord, QuizQuestion, TenseId, UserStats } from '../types';

const STORAGE_KEY = 'tense_master_user_stats_v1';

export function getLocalDateString(d: Date = new Date()): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getDaysDifference(lastDateStr: string, currentDateStr: string): number {
  if (!lastDateStr || !currentDateStr) return 999;
  const parts1 = lastDateStr.split('-').map(Number);
  const parts2 = currentDateStr.split('-').map(Number);
  if (parts1.length !== 3 || parts2.length !== 3) return 999;
  const d1 = new Date(parts1[0], parts1[1] - 1, parts1[2]);
  const d2 = new Date(parts2[0], parts2[1] - 1, parts2[2]);
  const msDiff = d2.getTime() - d1.getTime();
  return Math.round(msDiff / (1000 * 60 * 60 * 24));
}

const INITIAL_STATS: UserStats = {
  xp: 0,
  streak: 1,
  lastActiveDate: getLocalDateString(),
  totalQuestionsAnswered: 0,
  totalCorrect: 0,
  tenseMastery: {
    // 12 Tenses
    present_simple: { attempted: 0, correct: 0, mastered: false },
    present_continuous: { attempted: 0, correct: 0, mastered: false },
    present_perfect: { attempted: 0, correct: 0, mastered: false },
    present_perfect_continuous: { attempted: 0, correct: 0, mastered: false },
    past_simple: { attempted: 0, correct: 0, mastered: false },
    past_continuous: { attempted: 0, correct: 0, mastered: false },
    past_perfect: { attempted: 0, correct: 0, mastered: false },
    past_perfect_continuous: { attempted: 0, correct: 0, mastered: false },
    future_simple: { attempted: 0, correct: 0, mastered: false },
    future_continuous: { attempted: 0, correct: 0, mastered: false },
    future_perfect: { attempted: 0, correct: 0, mastered: false },
    future_perfect_continuous: { attempted: 0, correct: 0, mastered: false },
    // 15 Grammar Rules
    modal_verbs: { attempted: 0, correct: 0, mastered: false },
    passive_voice: { attempted: 0, correct: 0, mastered: false },
    active_voice: { attempted: 0, correct: 0, mastered: false },
    conditionals_zero_first_second_third: { attempted: 0, correct: 0, mastered: false },
    mixed_conditionals: { attempted: 0, correct: 0, mastered: false },
    wish_if_only: { attempted: 0, correct: 0, mastered: false },
    reported_speech: { attempted: 0, correct: 0, mastered: false },
    direct_speech: { attempted: 0, correct: 0, mastered: false },
    questions_and_tags: { attempted: 0, correct: 0, mastered: false },
    subject_verb_agreement: { attempted: 0, correct: 0, mastered: false },
    articles_a_an_the_zero: { attempted: 0, correct: 0, mastered: false },
    countable_uncountable_nouns: { attempted: 0, correct: 0, mastered: false },
    quantifiers: { attempted: 0, correct: 0, mastered: false },
    comparatives_superlatives: { attempted: 0, correct: 0, mastered: false },
    adjectives_adverbs: { attempted: 0, correct: 0, mastered: false },
    // 28 Additional Comprehensive Grammar Topics
    prepositions: { attempted: 0, correct: 0, mastered: false },
    conjunctions_linking_words: { attempted: 0, correct: 0, mastered: false },
    gerunds_infinitives: { attempted: 0, correct: 0, mastered: false },
    participles: { attempted: 0, correct: 0, mastered: false },
    relative_clauses: { attempted: 0, correct: 0, mastered: false },
    noun_clauses: { attempted: 0, correct: 0, mastered: false },
    adverb_clauses: { attempted: 0, correct: 0, mastered: false },
    phrasal_verbs: { attempted: 0, correct: 0, mastered: false },
    subject_object_pronouns: { attempted: 0, correct: 0, mastered: false },
    possessives: { attempted: 0, correct: 0, mastered: false },
    demonstratives: { attempted: 0, correct: 0, mastered: false },
    indefinite_pronouns: { attempted: 0, correct: 0, mastered: false },
    determiners: { attempted: 0, correct: 0, mastered: false },
    negation: { attempted: 0, correct: 0, mastered: false },
    imperatives: { attempted: 0, correct: 0, mastered: false },
    there_is_there_are: { attempted: 0, correct: 0, mastered: false },
    used_to_be_used_to_get_used_to: { attempted: 0, correct: 0, mastered: false },
    have_have_got: { attempted: 0, correct: 0, mastered: false },
    causative_verbs: { attempted: 0, correct: 0, mastered: false },
    so_neither_either_too: { attempted: 0, correct: 0, mastered: false },
    ellipsis_substitution: { attempted: 0, correct: 0, mastered: false },
    parallel_structure: { attempted: 0, correct: 0, mastered: false },
    word_order: { attempted: 0, correct: 0, mastered: false },
    inversion: { attempted: 0, correct: 0, mastered: false },
    cleft_sentences: { attempted: 0, correct: 0, mastered: false },
    emphasis: { attempted: 0, correct: 0, mastered: false },
    punctuation_capitalization: { attempted: 0, correct: 0, mastered: false },
    common_grammar_errors: { attempted: 0, correct: 0, mastered: false },
  },
  placementTaken: false,
  errorHistory: [],
  achievements: ['first_step'],
};

export function loadUserStats(): UserStats {
  if (typeof window === 'undefined') return INITIAL_STATS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return checkAndUpdateStreak(INITIAL_STATS);
    const parsed = JSON.parse(raw) as UserStats;
    // Merge with INITIAL_STATS to guarantee all mastery keys exist
    const merged: UserStats = {
      ...INITIAL_STATS,
      ...parsed,
      tenseMastery: {
        ...INITIAL_STATS.tenseMastery,
        ...(parsed.tenseMastery || {}),
      },
    };
    return checkAndUpdateStreak(merged);
  } catch (e) {
    console.error('Failed to load stats:', e);
    return INITIAL_STATS;
  }
}

export function saveUserStats(stats: UserStats): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stats));
  } catch (e) {
    console.error('Failed to save stats:', e);
  }
}

export function resetUserStats(): UserStats {
  const today = getLocalDateString();
  const resetMastery: Record<TenseId, { attempted: number; correct: number; mastered: boolean }> = {} as any;
  
  (Object.keys(INITIAL_STATS.tenseMastery) as TenseId[]).forEach(id => {
    resetMastery[id] = { attempted: 0, correct: 0, mastered: false };
  });

  const freshStats: UserStats = {
    ...INITIAL_STATS,
    xp: 0,
    streak: 1,
    lastActiveDate: today,
    totalQuestionsAnswered: 0,
    totalCorrect: 0,
    tenseMastery: resetMastery,
    placementTaken: false,
    placementScore: undefined,
    suggestedFocusTenses: undefined,
    errorHistory: [],
    achievements: ['first_step'],
  };

  saveUserStats(freshStats);
  return freshStats;
}

export function checkAndUpdateStreak(stats: UserStats): UserStats {
  const today = getLocalDateString();
  if (!stats.lastActiveDate) {
    const updated: UserStats = {
      ...stats,
      streak: 1,
      lastActiveDate: today,
    };
    saveUserStats(updated);
    return updated;
  }

  if (stats.lastActiveDate === today) {
    // Already visited today
    return stats;
  }

  const diffDays = getDaysDifference(stats.lastActiveDate, today);

  let newStreak = stats.streak || 0;
  if (diffDays === 1) {
    // Consecutive daily visit!
    newStreak = Math.max(1, newStreak + 1);
  } else if (diffDays > 1) {
    // Missed one or more days: reset to 1
    newStreak = 1;
  } else {
    newStreak = Math.max(1, newStreak);
  }

  const updated: UserStats = {
    ...stats,
    streak: newStreak,
    lastActiveDate: today,
  };
  saveUserStats(updated);
  return updated;
}

export function recordAnswerResult(
  currentStats: UserStats,
  question: QuizQuestion,
  userAnswer: string,
  isCorrect: boolean
): { updatedStats: UserStats; earnedXp: number } {
  const baseScore = isCorrect ? 25 : 5;
  const multiplier = question.difficulty === 'expert' ? 2.5 : question.difficulty === 'hard' ? 2 : question.difficulty === 'medium' ? 1.5 : 1;
  const earnedXp = Math.round(baseScore * multiplier);

  const tenseStats = currentStats.tenseMastery[question.tenseId] || {
    attempted: 0,
    correct: 0,
    mastered: false,
  };

  const newAttempted = tenseStats.attempted + 1;
  const newCorrect = tenseStats.correct + (isCorrect ? 1 : 0);
  const isMastered = newAttempted >= 5 && (newCorrect / newAttempted) >= 0.8;

  let newErrors = [...currentStats.errorHistory];
  if (!isCorrect) {
    // Add to error notebook if not already pending
    const existingIndex = newErrors.findIndex(e => e.question.id === question.id);
    if (existingIndex >= 0) {
      newErrors[existingIndex] = {
        ...newErrors[existingIndex],
        userAnswer,
        timestamp: Date.now(),
        timesRetried: newErrors[existingIndex].timesRetried + 1,
      };
    } else {
      const newRecord: ErrorRecord = {
        id: `err_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        question,
        userAnswer,
        timestamp: Date.now(),
        reviewed: false,
        timesRetried: 0,
        timesCorrect: 0,
      };
      newErrors.unshift(newRecord);
    }
  } else {
    // If it was in errors and answered correctly during review
    const errIdx = newErrors.findIndex(e => e.question.id === question.id);
    if (errIdx >= 0) {
      newErrors[errIdx] = {
        ...newErrors[errIdx],
        timesCorrect: (newErrors[errIdx].timesCorrect || 0) + 1,
        reviewed: true,
      };
    }
  }

  // Check milestones / achievements
  const newTotalAnswered = currentStats.totalQuestionsAnswered + 1;
  const newTotalCorrect = currentStats.totalCorrect + (isCorrect ? 1 : 0);
  const achievements = [...currentStats.achievements];

  if (newTotalAnswered >= 10 && !achievements.includes('ten_questions')) achievements.push('ten_questions');
  if (newTotalAnswered >= 50 && !achievements.includes('half_hundred')) achievements.push('half_hundred');
  if (currentStats.streak >= 3 && !achievements.includes('streak_3')) achievements.push('streak_3');
  if (currentStats.streak >= 7 && !achievements.includes('streak_7')) achievements.push('streak_7');

  const updatedStats: UserStats = {
    ...currentStats,
    xp: currentStats.xp + earnedXp,
    totalQuestionsAnswered: newTotalAnswered,
    totalCorrect: newTotalCorrect,
    tenseMastery: {
      ...currentStats.tenseMastery,
      [question.tenseId]: {
        attempted: newAttempted,
        correct: newCorrect,
        mastered: isMastered,
      },
    },
    errorHistory: newErrors,
    achievements,
  };

  saveUserStats(updatedStats);
  return { updatedStats, earnedXp };
}

export function getUserLevelInfo(xp: number): { level: number; titleAr: string; titleEn: string; nextLevelXp: number; progressPercent: number } {
  const levels = [
    { level: 1, minXp: 0, titleAr: 'مستكشف مبتدئ', titleEn: 'Novice Explorer' },
    { level: 2, minXp: 250, titleAr: 'ممارس واعد', titleEn: 'Promising Apprentice' },
    { level: 3, minXp: 600, titleAr: 'محلل الأزمنة', titleEn: 'Tense Analyst' },
    { level: 4, minXp: 1200, titleAr: 'متحكم بالعلاقات الزمنية', titleEn: 'Time Strategist' },
    { level: 5, minXp: 2200, titleAr: 'خبير القواعد والتراكيب', titleEn: 'Grammar Expert' },
    { level: 6, minXp: 3800, titleAr: 'فارس الزمن الإنجليزي', titleEn: 'Master of Tenses' },
    { level: 7, minXp: 6000, titleAr: 'أسطورة الأزمنة الـ12', titleEn: 'Grand Time Lord' },
  ];

  for (let i = levels.length - 1; i >= 0; i--) {
    if (xp >= levels[i].minXp) {
      const cur = levels[i];
      const next = levels[i + 1] || { minXp: cur.minXp + 3000 };
      const currentLevelBase = cur.minXp;
      const range = next.minXp - currentLevelBase;
      const progressInLevel = xp - currentLevelBase;
      const progressPercent = Math.min(100, Math.max(0, Math.round((progressInLevel / range) * 100)));
      return {
        level: cur.level,
        titleAr: cur.titleAr,
        titleEn: cur.titleEn,
        nextLevelXp: next.minXp,
        progressPercent,
      };
    }
  }

  return {
    level: 1,
    titleAr: 'مستكشف مبتدئ',
    titleEn: 'Novice Explorer',
    nextLevelXp: 250,
    progressPercent: 0,
  };
}
