export type TenseId =
  // 12 English Tenses
  | 'present_simple'
  | 'present_continuous'
  | 'present_perfect'
  | 'present_perfect_continuous'
  | 'past_simple'
  | 'past_continuous'
  | 'past_perfect'
  | 'past_perfect_continuous'
  | 'future_simple'
  | 'future_continuous'
  | 'future_perfect'
  | 'future_perfect_continuous'
  // Comprehensive Grammar Rules (43 Total Grammar Master Topics)
  | 'modal_verbs'
  | 'passive_voice'
  | 'active_voice'
  | 'conditionals_zero_first_second_third'
  | 'mixed_conditionals'
  | 'wish_if_only'
  | 'reported_speech'
  | 'direct_speech'
  | 'questions_and_tags'
  | 'subject_verb_agreement'
  | 'articles_a_an_the_zero'
  | 'countable_uncountable_nouns'
  | 'quantifiers'
  | 'comparatives_superlatives'
  | 'adjectives_adverbs'
  // New Requested Grammar Rules:
  | 'prepositions'
  | 'conjunctions_linking_words'
  | 'gerunds_infinitives'
  | 'participles'
  | 'relative_clauses'
  | 'noun_clauses'
  | 'adverb_clauses'
  | 'phrasal_verbs'
  | 'subject_object_pronouns'
  | 'possessives'
  | 'demonstratives'
  | 'indefinite_pronouns'
  | 'determiners'
  | 'negation'
  | 'imperatives'
  | 'there_is_there_are'
  | 'used_to_be_used_to_get_used_to'
  | 'have_have_got'
  | 'causative_verbs'
  | 'so_neither_either_too'
  | 'ellipsis_substitution'
  | 'parallel_structure'
  | 'word_order'
  | 'inversion'
  | 'cleft_sentences'
  | 'emphasis'
  | 'punctuation_capitalization'
  | 'common_grammar_errors';

export type TimeCategory = 'past' | 'present' | 'future' | 'general' | 'general_rules';
export type AspectCategory = 'simple' | 'continuous' | 'perfect' | 'perfect_continuous' | 'rule';
export type TopicCategoryGroup = 
  | 'tenses'
  | 'modals_and_voice'
  | 'conditionals_and_speech'
  | 'clauses_and_connectors'
  | 'verbs_and_structures'
  | 'nouns_and_pronouns'
  | 'modifiers_and_syntax'
  | 'advanced_grammar_mastery';
export type Difficulty = 'easy' | 'medium' | 'hard' | 'expert';

export type QuestionType =
  | 'multiple_choice'
  | 'fill_blank'
  | 'choose_tense'
  | 'ar_to_en'
  | 'en_to_ar'
  | 'word_order'
  | 'error_spotting'
  | 'right_reason'
  | 'timeline_challenge'
  | 'situation_challenge'
  | 'two_events_challenge'
  | 'duration_challenge'
  | 'contrast_challenge'
  | 'no_clues';

export interface SignalWord {
  word: string;
  noteAr: string;
}

export interface Formula {
  affirmative: string;
  negative: string;
  question: string;
  rulesNotesAr: string[];
}

export interface ExampleSentence {
  id: string;
  en: string;
  ar: string;
  type: 'affirmative' | 'negative' | 'question';
  contextNoteAr?: string;
  highlightWords?: string[];
}

export interface VsComparison {
  targetTenseId: TenseId;
  targetTenseName: string;
  coreDifferenceAr: string;
  exampleA: { en: string; ar: string; tenseName: string };
  exampleB: { en: string; ar: string; tenseName: string };
  keyRuleAr: string;
}

export interface CommonMistake {
  mistakeEn: string;
  correctionEn: string;
  explanationAr: string;
  whyPeopleFailAr: string;
}

export interface TimelineData {
  pastState: string;
  presentState: string;
  futureState: string;
  eventMarker: 'point' | 'duration' | 'completed_before' | 'ongoing_until';
  eventPosition: number; // 0 to 100 on the timeline scale
  eventEndPosition?: number; // for duration
  referencePoint?: number; // for perfect tenses (the reference point in time)
  labelAr: string;
  temporalMeaningAr: string;
}

export interface TenseInfo {
  id: TenseId;
  nameEn: string;
  nameAr: string;
  categoryGroup?: TopicCategoryGroup;
  timeCategory: TimeCategory;
  aspectCategory: AspectCategory;
  icon: string;
  badgeColor: string;
  shortSummaryAr: string;
  goldenQuestionAr: string;
  detailedExplanationAr: string;
  formula: Formula;
  timeline: TimelineData;
  signalWords: SignalWord[];
  examples: ExampleSentence[];
  vsComparisons: VsComparison[];
  commonMistakes: CommonMistake[];
  tags: string[];
}

export interface AnswerExplanation {
  whyCorrectAr: string;
  temporalRelationshipAr: string;
  whyTenseFitsAr: string;
  whyOthersWrongAr?: string;
  confusableTenseAr?: string;
}

export interface QuizQuestion {
  id: string;
  tenseId: TenseId;
  difficulty: Difficulty;
  type: QuestionType;
  promptAr: string;
  questionEn?: string;
  questionAr?: string;
  sentenceWithBlank?: string; // e.g. "She ___ (study) for three hours when I arrived."
  options?: string[]; // for MC, choose tense, right reason
  correctAnswer: string; // The correct string choice
  orderedWords?: string[]; // For word ordering
  sentenceWithMistake?: string; // For error spotting
  mistakeWord?: string; // The erroneous word
  correctedWord?: string; // The correction
  scenarioContextAr?: string; // For situation challenges
  twoEventsData?: {
    firstEventEn: string;
    secondEventEn: string;
    firstEventAr?: string;
    secondEventAr?: string;
    sequenceAr: string;
  };
  translationAr?: string;
  timelineVisualTarget?: {
    point: number;
    reference: number;
    descriptionAr: string;
  };
  explanation: AnswerExplanation;
  hasNoSignalWords?: boolean;
}

export interface ErrorRecord {
  id: string;
  question: QuizQuestion;
  userAnswer: string;
  timestamp: number;
  reviewed: boolean;
  timesRetried: number;
  timesCorrect: number;
}

export interface UserStats {
  xp: number;
  streak: number;
  lastActiveDate: string;
  totalQuestionsAnswered: number;
  totalCorrect: number;
  tenseMastery: Record<TenseId, { attempted: number; correct: number; mastered: boolean }>;
  placementTaken: boolean;
  placementScore?: number;
  suggestedFocusTenses?: TenseId[];
  errorHistory: ErrorRecord[];
  achievements: string[];
}

export type AppView =
  | 'dashboard'
  | 'learn'
  | 'mindmap'
  | 'practice'
  | 'battle'
  | '12challenge'
  | 'rush60'
  | 'detective'
  | 'story'
  | 'noclues'
  | 'errors'
  | 'placement';

export interface DetectiveCase {
  id: string;
  titleAr: string;
  settingAr: string;
  mysteryAr: string;
  clues: {
    clueId: string;
    witnessStatementEn: string;
    translationAr: string;
    timestampAr: string;
    temporalClueAr: string;
  }[];
  questions: QuizQuestion[];
  conclusionAr: string;
}

export interface StoryChapter {
  id: string;
  titleAr: string;
  chapterNumber: number;
  introductionAr: string;
  narrativeSegments: {
    segmentId: string;
    paragraphBeforeEn: string;
    missingTenseChallenge: QuizQuestion;
    paragraphAfterEn: string;
    narrativeArabicTranslation: string;
  }[];
  chapterRecapAr: string;
}
