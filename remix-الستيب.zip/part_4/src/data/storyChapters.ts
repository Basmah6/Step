import { StoryChapter } from '../types';

export const STORY_CHAPTERS: StoryChapter[] = [
  {
    id: 'ch_01',
    titleAr: 'الفصل الأول: نداء الآثار المنسية 🗺️',
    chapterNumber: 1,
    introductionAr: 'عالم الآثار الشاب "طارق" يقف أمام مدخل معبد غارق في الصحراء، حاملاً خريطة قديمة ويستعد لأعظم استكشاف في حياته.',
    narrativeSegments: [
      {
        segmentId: 'seg_1',
        paragraphBeforeEn: 'For over a decade, historians believed this temple was completely lost. However, Tariq',
        missingTenseChallenge: {
          id: 'story_q1',
          tenseId: 'present_perfect',
          difficulty: 'medium',
          type: 'multiple_choice',
          promptAr: 'اختر الزمن المناسب لإنجاز طارق الذي تحقق مؤخراً ونتيجته واضحة أمام المعبد الآن:',
          sentenceWithBlank: 'Tariq ___ the secret entrance after months of searching.',
          options: ['has discovered', 'discovered', 'is discovering', 'had discovered'],
          correctAnswer: 'has discovered',
          explanation: {
            whyCorrectAr: 'المضارع التام يربط الاكتشاف باللحظة الراهنة حيث يقف طارق أمام الباب الآن والنتيجة حية.',
            temporalRelationshipAr: 'إنجاز ماضٍ بدون تاريخ مقفل مرتبط بالواقع الحاضر.',
            whyTenseFitsAr: 'has discovered.',
          },
        },
        paragraphAfterEn: 'and now the heavy stone doors are opening slowly before his eyes.',
        narrativeArabicTranslation: 'لأكثر من عقد، اعتقد المؤرخون أن المعبد مفقود تماماً، لكن طارق اكتشف المدخل السري بعد شهور من البحث، والآن تنفتح الأبواب الحجرية الثقيلة أمامه ببطء.',
      },
      {
        segmentId: 'seg_2',
        paragraphBeforeEn: 'As he stepped into the dark hallway, dust filled the air. Ancient hieroglyphs covered the walls. He realized that ancient priests',
        missingTenseChallenge: {
          id: 'story_q2',
          tenseId: 'past_perfect',
          difficulty: 'hard',
          type: 'two_events_challenge',
          promptAr: 'اختر الزمن المناسب لما فعله الكهنة قبل آلاف السنين من دخول طارق:',
          sentenceWithBlank: 'Ancient priests ___ these mysterious symbols thousands of years before his arrival.',
          options: ['had carved', 'have carved', 'were carving', 'carve'],
          correctAnswer: 'had carved',
          explanation: {
            whyCorrectAr: 'نقش الرموز حدث أولاً في الماضي السحيق قبل وصول طارق، لذلك هو ماضي الماضي (Past Perfect).',
            temporalRelationshipAr: 'الحدث الأسبق بين حدثين في الماضي.',
            whyTenseFitsAr: 'had carved.',
          },
        },
        paragraphAfterEn: 'to warn future explorers about the dangers hidden inside.',
        narrativeArabicTranslation: 'بينما خطا إلى الرواق المظلم، أدرك أن الكهنة القدماء كانوا قد نقشوا هذه الرموز الغامضة قبل آلاف السنين من وصوله لتحذير المستكشفين في المستقبل.',
      },
    ],
    chapterRecapAr: 'نجحت في توجيه طارق عبر المعبد باستخدام الأزمنة الصحيحة! كل زمن كشف فصلاً من تاريخ المعبد الغامض.',
  },
  {
    id: 'ch_02',
    titleAr: 'الفصل الثاني: رحلة نحو النجوم 🚀',
    chapterNumber: 2,
    introductionAr: 'في عام 2085، تنطلق أول رحلة استكشافية مأهولة نحو كوكب المريخ. طاقم المركبة "أوريون" يستعد لدخول المدار الحاسم.',
    narrativeSegments: [
      {
        segmentId: 'seg_3',
        paragraphBeforeEn: 'Captain Rayan looked at the digital navigation dashboard. The mission clock showed 180 days of travel.',
        missingTenseChallenge: {
          id: 'story_q3',
          tenseId: 'future_perfect_continuous',
          difficulty: 'hard',
          type: 'duration_challenge',
          promptAr: 'اختر الصيغة التي تعبر عن اكتمال مدة 200 يوم سفر عند وصول الكبسولة غداً:',
          sentenceWithBlank: 'By tomorrow noon, the crew ___ through deep space for 200 consecutive days.',
          options: ['will have been travelling', 'will be travelling', 'will travel', 'have been travelling'],
          correctAnswer: 'will have been travelling',
          explanation: {
            whyCorrectAr: 'الجملة تقيس العداد التراكمي للمدة (200 يوم متواصل) عند نقطة الغد ظهراً (By tomorrow noon).',
            temporalRelationshipAr: 'المستقبل التام المستمر للربط بين نقطة By والمدة for.',
            whyTenseFitsAr: 'will have been travelling.',
          },
        },
        paragraphAfterEn: 'and the red surface of Mars was growing larger on every monitor.',
        narrativeArabicTranslation: 'نظر القبطان ريان إلى لوحة الملاحة الرقمية. بحلول ظهر الغد، سيكون الطاقم قد استمر في السفر عبر الفضاء السحيق لـ 200 يوم متواصل.',
      },
    ],
    chapterRecapAr: 'اكتملت المناورة الفضائية بنجاح باهر بفضل ضبط التوقيتات والأزمنة بدقة هندسية!',
  },
];
