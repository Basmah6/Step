import { QuizQuestion, TenseId, Difficulty } from '../types';
import { ALL_TENSES } from './tensesData';

export interface SentenceBlueprint {
  promptAr: string;
  template: (subject: string, verbObj: any) => {
    sentenceWithBlank: string;
    correct: string;
    distractors: string[];
    whyCorrectAr: string;
    temporalAr: string;
    scenarioAr?: string;
  };
}

// 1. Dedicated Procedural Generators for 12 Tenses (Guaranteeing 50+ unique questions per tense per level)
export interface TenseLevelBank {
  tenseId: TenseId;
  easy: {
    promptAr: string;
    sentenceWithBlank: string;
    correct: string;
    distractors: string[];
    whyCorrectAr: string;
    temporalAr: string;
  }[];
  medium: {
    promptAr: string;
    sentenceWithBlank: string;
    correct: string;
    distractors: string[];
    whyCorrectAr: string;
    temporalAr: string;
  }[];
  hard: {
    promptAr: string;
    sentenceWithBlank: string;
    correct: string;
    distractors: string[];
    whyCorrectAr: string;
    temporalAr: string;
  }[];
}

export const TENSE_QUESTIONS_DATA: Partial<Record<TenseId, { easy: any[]; medium: any[]; hard: any[] }>> = {
  // ==========================================
  // 1. PRESENT SIMPLE
  // ==========================================
  present_simple: {
    easy: [
      {
        promptAr: 'اختر الفعل المناسب مع الفاعل المفرد الغائب (He):',
        sentenceWithBlank: 'He ___ a fresh glass of orange juice every morning.',
        correct: 'drinks',
        distractors: ['drink', 'is drinking', 'drank'],
        whyCorrectAr: 'الفاعل المفرد الغائب (He) يتطلب إضافة s للفعل في المضارع البسيط للتعبير عن عادة يومية.',
        temporalAr: 'عادة صباحية متكررة بانتظام.',
      },
      {
        promptAr: 'اختر الفعل المناسب مع ضمير الجمع (They) للتعبير عن روتين:',
        sentenceWithBlank: 'They ___ to the local library every weekend.',
        correct: 'go',
        distractors: ['goes', 'are going', 'went'],
        whyCorrectAr: 'مع ضمائر الجمع نستخدم صيغة المصدر المجردة (Base Form) بدون إضافات.',
        temporalAr: 'روتين أسبوعي منتظم.',
      },
      {
        promptAr: 'اختر تصريف الفعل مع الفاعل المفرد (She):',
        sentenceWithBlank: 'My sister ___ French fluently and reads literature.',
        correct: 'speaks',
        distractors: ['speak', 'is speaking', 'spoke'],
        whyCorrectAr: 'الفاعل المفرد (My sister = She) يأخذ s مع الفعل في المضارع البسيط.',
        temporalAr: 'قدرة ومعرفة دائمة ومستمرة.',
      },
      {
        promptAr: 'اختر الفعل المعبر عن حقيقة علمية فيزيائية ثابتة:',
        sentenceWithBlank: 'Pure water ___ at 100 degrees Celsius under normal pressure.',
        correct: 'boils',
        distractors: ['is boiling', 'boiled', 'has boiled'],
        whyCorrectAr: 'غليان الماء عند 100 درجة مئوية حقيقة علمية ثابتة تتطلب المضارع البسيط.',
        temporalAr: 'حقيقة فيزيائية كونية تنطبق في كل زمان.',
      },
      {
        promptAr: 'اختر صيغة النفي الصحيحة مع الفاعل المفرد:',
        sentenceWithBlank: 'He ___ consume sugar or artificial sweeteners.',
        correct: "doesn't",
        distractors: ["don't", "isn't", "hasn't"],
        whyCorrectAr: 'في المضارع البسيط، ننفي الفاعل المفرد باستخدام (doesn’t) متبوعاً بالمصدر المجرد.',
        temporalAr: 'نمط حياة دائم وعادة مستقرة.',
      },
      {
        promptAr: 'اختر صيغة السؤال المناسبة مع الفاعل الجمع:',
        sentenceWithBlank: '___ you practice speaking English on a daily basis?',
        correct: 'Do',
        distractors: ['Does', 'Are', 'Have'],
        whyCorrectAr: 'السؤال في المضارع البسيط مع الضمير You يبدأ بالفعل المساعد (Do).',
        temporalAr: 'استفسار عن عادة متكررة.',
      },
      {
        promptAr: 'اختر التصريف المناسب للفعل المنتهي بـ -ch مع المفرد:',
        sentenceWithBlank: 'The professor ___ complex mathematical theories in his lectures.',
        correct: 'teaches',
        distractors: ['teach', 'is teaching', 'taught'],
        whyCorrectAr: 'الأفعال المنتهية بـ ch نضيف لها (es) مع الفاعل المفرد (The professor).',
        temporalAr: 'نشاط أكاديمي روتيني.',
      },
      {
        promptAr: 'اختر الفعل المناسب للتعبير عن حقيقة فلكية:',
        sentenceWithBlank: 'The Moon ___ light from the Sun to illuminate our night sky.',
        correct: 'reflects',
        distractors: ['is reflecting', 'reflected', 'has reflected'],
        whyCorrectAr: 'انعكاس ضوء الشمس على القمر حقيقة فلكية دائمة.',
        temporalAr: 'قانون طبيعي كوني ثابت.',
      },
      {
        promptAr: 'اختر صيغة الفعل المنتهي بـ -y بعد حرف ساكن مع المفرد:',
        sentenceWithBlank: 'The determined student ___ hard before every major exam.',
        correct: 'studies',
        distractors: ['studys', 'study', 'is studying'],
        whyCorrectAr: 'الفعل study ينتهي بـ y بعد ساكن، فتتحول إلى ies مع الفاعل المفرد في المضارع البسيط.',
        temporalAr: 'سلوك دراسي معتاد.',
      },
      {
        promptAr: 'اختر الفعل المناسب مع فاعل الجمع للتعبير عن حقيقة عامة:',
        sentenceWithBlank: 'Trees ___ carbon dioxide and produce oxygen during photosynthesis.',
        correct: 'absorb',
        distractors: ['absorbs', 'are absorbing', 'absorbed'],
        whyCorrectAr: 'الفاعل جمع (Trees) فيأخذ الفعل في صيغة المصدر (absorb) للتعبير عن حقيقة بيولوجية.',
        temporalAr: 'حقيقة علمية بيولوجية ثابتة.',
      },
      {
        promptAr: 'اختر الفعل المناسب مع ظرف التكرار always:',
        sentenceWithBlank: 'My mother always ___ delicious meals on Friday afternoons.',
        correct: 'cooks',
        distractors: ['cook', 'is cooking', 'cooked'],
        whyCorrectAr: 'مع ظرف التكرار always والفاعل المفرد (My mother) نضيف s للفعل.',
        temporalAr: 'عادة أسبوعية متكررة.',
      },
      {
        promptAr: 'اختر الفعل المناسب مع ضمير المتكلم (I):',
        sentenceWithBlank: 'I ___ in the city center near the central train station.',
        correct: 'live',
        distractors: ['lives', 'am living', 'lived'],
        whyCorrectAr: 'مع الضمير (I) يبقى الفعل في المصدر للتعبير عن السكن الدائم.',
        temporalAr: 'إقامة دائمة ومستقرة.',
      },
      {
        promptAr: 'اختر الفعل المنتهي بـ -sh مع الفاعل المفرد:',
        sentenceWithBlank: 'The dentist ___ her teeth after every meal.',
        correct: 'brushes',
        distractors: ['brush', 'is brushing', 'brushed'],
        whyCorrectAr: 'الأفعال المنتهية بـ sh تأخذ es مع الفاعل المفرد الغائب.',
        temporalAr: 'عادة صحية يومية منتظمة.',
      },
      {
        promptAr: 'اختر صيغة النفي الصحيحة مع ضمائر الجمع:',
        sentenceWithBlank: 'Vegetarians ___ eat meat or poultry products.',
        correct: "don't",
        distractors: ["doesn't", "aren't", "haven't"],
        whyCorrectAr: 'الفاعل جمع (Vegetarians) فيتم النفي بـ don’t متبوعة بالمصدر.',
        temporalAr: 'مبدأ ونمط غذائي دائم.',
      },
      {
        promptAr: 'اختر الفعل المناسب لحقيقة جغرافية:',
        sentenceWithBlank: 'The Nile River ___ through eleven northeastern African countries.',
        correct: 'flows',
        distractors: ['is flowing', 'flowed', 'has flowed'],
        whyCorrectAr: 'جريان نهر النيل حقيقة جغرافية دائمة تتطلب المضارع البسيط.',
        temporalAr: 'حقيقة جغرافية مستمرة.',
      },
    ],
    medium: [
      {
        promptAr: 'اختر الفعل المناسب لجدول مواعيد رسمي ثابت (Official Timetable):',
        sentenceWithBlank: 'The express train to Manchester ___ at precisely 07:30 tomorrow morning.',
        correct: 'departs',
        distractors: ['is departing', 'will depart', 'has departed'],
        whyCorrectAr: 'جداول المواعيد الرسمية ووسائل النقل تصاغ بالمضارع البسيط حتى لو كانت في المستقبل.',
        temporalAr: 'موعد رسمي مجدول بدقة.',
      },
      {
        promptAr: 'اختر التصريف الصحيح مع الأفعال التقريرية (Stative Verbs):',
        sentenceWithBlank: 'I ___ completely what you mean by that explanation.',
        correct: 'understand',
        distractors: ['am understanding', 'have understood', 'was understanding'],
        whyCorrectAr: 'فعل (understand) فعل إدراكي تقريري لا يأتي في صيغة الاستمرار -ing.',
        temporalAr: 'حالة إدراك ذهني فورية ومستمرة.',
      },
      {
        promptAr: 'اختر الفعل المعبر عن مهنة ووظيفة دائمة مستقرة:',
        sentenceWithBlank: 'Dr. Zaid ___ pediatric cardiology at the university teaching hospital.',
        correct: 'teaches',
        distractors: ['is teaching', 'has taught', 'was teaching'],
        whyCorrectAr: 'المهنة والوظيفة الثابتة تعامل كحقيقة مستمرة في حياة الإنسان وتأخذ المضارع البسيط.',
        temporalAr: 'عمل وظيفي دائم.',
      },
      {
        promptAr: 'اختر الفعل التقريري المعبر عن الملكية (Possession):',
        sentenceWithBlank: 'This magnificent historical library ___ over 50,000 ancient manuscripts.',
        correct: 'contains',
        distractors: ['is containing', 'contained', 'has contained'],
        whyCorrectAr: 'فعل (contain) فعل تقريري يعبر عن الاحتواء والملكية ولا يقبل -ing.',
        temporalAr: 'حالة دائمة للمكتبة.',
      },
      {
        promptAr: 'اختر الفعل المناسب لبداية العام الدراسي وفق تقويم رسمي:',
        sentenceWithBlank: 'The new academic semester ___ on the first of September.',
        correct: 'begins',
        distractors: ['is beginning', 'will begin', 'began'],
        whyCorrectAr: 'المواعيد المقررة وفق تقويم رسمي تُصاغ بالمضارع البسيط.',
        temporalAr: 'جدول زمني رسمي محدد.',
      },
      {
        promptAr: 'اختر الفعل التقريري المعبر عن الرأي والاعتقاد:',
        sentenceWithBlank: 'She ___ that renewable energy is the most important investment for our future.',
        correct: 'believes',
        distractors: ['is believing', 'has believed', 'was believing'],
        whyCorrectAr: 'فعل believe فعل قلبي تقريري لا يقبل صيغ الاستمرار.',
        temporalAr: 'قناعة واعتقاد راسخ.',
      },
      {
        promptAr: 'اختر الفعل المناسب لوصف مذاق دائم لشيء:',
        sentenceWithBlank: 'This traditional dark chocolate ___ rich and slightly bitter.',
        correct: 'tastes',
        distractors: ['is tasting', 'tasted', 'has tasted'],
        whyCorrectAr: 'أفعال الحواس عندما تصف صفة الشيء نفسه تأتي في المضارع البسيط.',
        temporalAr: 'خاصية ومذاق ملازم للشيء.',
      },
      {
        promptAr: 'اختر الفعل المناسب لموعد إغلاق منشأة عامة:',
        sentenceWithBlank: 'The national museum ___ its doors to visitors at 6:00 PM every evening.',
        correct: 'closes',
        distractors: ['is closing', 'will close', 'closed'],
        whyCorrectAr: 'مواعيد فتح وإغلاق المتاحف والمتاجر جداول زمنية رسمية.',
        temporalAr: 'جدول مواعيد عمل رسمي.',
      },
      {
        promptAr: 'اختر الفعل التقريري الدال على الاحتياج والرغبة:',
        sentenceWithBlank: 'The patient ___ urgent medical attention and complete bed rest.',
        correct: 'needs',
        distractors: ['is needing', 'has needed', 'was needing'],
        whyCorrectAr: 'فعل need فعل تقريري لا يأتي في صيغة المستمر.',
        temporalAr: 'حالة احتياج راهنة.',
      },
      {
        promptAr: 'اختر الفعل المعبر عن حقيقة موطن كائن حي:',
        sentenceWithBlank: 'Emperor penguins ___ primarily in the freezing climate of Antarctica.',
        correct: 'live',
        distractors: ['are living', 'lived', 'have lived'],
        whyCorrectAr: 'الموطن الطبيعي للكائنات الحية حقيقة بيئية دائمة.',
        temporalAr: 'حقيقة بيولوجية ثابتة.',
      },
    ],
    hard: [
      {
        promptAr: 'تحدي بدون كلمات دلالية: اختر الزمن المعبر عن الشرطية الصفرية (Zero Conditional):',
        sentenceWithBlank: 'If atmospheric pressure drops rapidly, storm clouds ___ in the sky.',
        correct: 'form',
        distractors: ['will form', 'are forming', 'formed'],
        whyCorrectAr: 'الشرطية الصفرية التي تصف علاقة سببية علمية حتمية تستخدم المضارع البسيط في الشقين.',
        temporalAr: 'علاقة سببية علمية حتمية.',
      },
      {
        promptAr: 'اختر الفعل المناسب في جملة ظرفية زمنية مستقبلية بعد (as soon as):',
        sentenceWithBlank: 'Please send me the final report as soon as the auditor ___ at the office.',
        correct: 'arrives',
        distractors: ['will arrive', 'is arriving', 'arrived'],
        whyCorrectAr: 'بعد الروابط الزمنية (as soon as, when, before, after) نستخدم المضارع البسيط للدلالة على المستقبل.',
        temporalAr: 'شرط زمني مسبق للحدث المستقبلي.',
      },
      {
        promptAr: 'اختر الفعل التقريري الدال على التبعية والملكية في سياق قانوني:',
        sentenceWithBlank: 'Under international maritime law, this territorial water ___ to the coastal nation.',
        correct: 'belongs',
        distractors: ['is belonging', 'belonged', 'has belonged'],
        whyCorrectAr: 'فعل belong فعل تقريري قانوني دائم لا يقبل الاستمرار.',
        temporalAr: 'وضع قانوني مستقر وثابت.',
      },
      {
        promptAr: 'اختر الفعل المناسب في أسلوب التعليق السردي الدرامي أو الرياضي (Live Commentary):',
        sentenceWithBlank: 'The striker controls the ball, bypasses the defender, and ___ a powerful shot into the goal.',
        correct: 'fires',
        distractors: ['is firing', 'fired', 'has fired'],
        whyCorrectAr: 'في التعليق الرياضي المباشر والسرد الدرامي الحاضر نستخدم المضارع البسيط لنقل الحدث بسرعة.',
        temporalAr: 'سرد حركي فوري متعاقب.',
      },
      {
        promptAr: 'اختر الفعل التقريري الذي يصف المظهر الخارجي الثابت (Look / Appear):',
        sentenceWithBlank: 'This newly synthesized material ___ identical to natural silk under the microscope.',
        correct: 'appears',
        distractors: ['is appearing', 'appeared', 'has appeared'],
        whyCorrectAr: 'appear بمعنى يبدو هو فعل تقريري يصف سمة ملازمة للمادة.',
        temporalAr: 'خاصية بصرية مجهرية ثابتة.',
      },
      {
        promptAr: 'اختر الفعل بعد أداة الربط الزمني (until) المشيرة للمستقبل:',
        sentenceWithBlank: 'We cannot finalize the contract until the legal team ___ the revised clauses.',
        correct: 'approves',
        distractors: ['will approve', 'is approving', 'approved'],
        whyCorrectAr: 'في الجمل الظرفية الزمنية بعد until نستخدم المضارع البسيط حتى لو كان المعنى مستقبلياً.',
        temporalAr: 'محطة زمنية سابقة لإتمام العقد.',
      },
      {
        promptAr: 'اختر الفعل المناسب في عنوان إخباري صحفي (Newspaper Headline style):',
        sentenceWithBlank: 'Supreme Court ___ historic ruling on digital privacy and artificial intelligence.',
        correct: 'issues',
        distractors: ['is issuing', 'issued', 'has been issuing'],
        whyCorrectAr: 'العناوين الإخبارية الصحفية تصاغ في المضارع البسيط لإعطاء انطباع بالفورية والأهمية.',
        temporalAr: 'إعلان خبري رسمي.',
      },
      {
        promptAr: 'اختر الفعل المناسب للتعريف العلمي الرياضي (Mathematical Definition):',
        sentenceWithBlank: 'A prime number is a positive integer that ___ only two distinct positive divisors.',
        correct: 'has',
        distractors: ['is having', 'had', 'will have'],
        whyCorrectAr: 'التعريفات الرياضية والعلمية ثوابت مطلقة تتطلب المضارع البسيط.',
        temporalAr: 'تعريف رياضي أبدي.',
      },
    ],
  },

  // ==========================================
  // 2. PRESENT CONTINUOUS
  // ==========================================
  present_continuous: {
    easy: [
      {
        promptAr: 'اختر الفعل المعبر عن حدث يقع أمام العين في هذه اللحظة (Look!):',
        sentenceWithBlank: 'Look! The majestic eagles ___ high above the mountain peak right now.',
        correct: 'are soaring',
        distractors: ['soar', 'soared', 'have soared'],
        whyCorrectAr: 'وجود (Look!) و (right now) يوجه الانتباه لحدث حركي جاري أمام العين في هذه اللحظة.',
        temporalAr: 'حدث مستمر في نقطة الحاضر الآن.',
      },
      {
        promptAr: 'اختر التصريف الصحيح مع ضمير المفرد المتكلم (I) للحدث الجاري:',
        sentenceWithBlank: 'I ___ an important research proposal at the moment.',
        correct: 'am writing',
        distractors: ['write', 'is writing', 'was writing'],
        whyCorrectAr: 'مع الضمير I نستخدم am + verb-ing للحدث المستمر الآن.',
        temporalAr: 'نشاط مستمر أثناء لحظة الكلام.',
      },
      {
        promptAr: 'اختر الفعل المعبر عن صوت يُسمع في نفس اللحظة (Listen!):',
        sentenceWithBlank: 'Listen! Someone ___ softly on the front door.',
        correct: 'is knocking',
        distractors: ['knocks', 'knocked', 'has knocked'],
        whyCorrectAr: 'تنبيه الاستماع (Listen!) يؤكد أن الحدث يقع الآن في هذه اللحظة.',
        temporalAr: 'فعل يحدث في اللحظة الراهنة.',
      },
      {
        promptAr: 'اختر الفعل المناسب مع ضمير المفرد الغائب (She):',
        sentenceWithBlank: 'She ___ for her international certification exam this afternoon.',
        correct: 'is studying',
        distractors: ['studies', 'study', 'are studying'],
        whyCorrectAr: 'مع الفاعل المفرد (She) نستخدم is + verb-ing للنشاط الجاري في هذه الفترة.',
        temporalAr: 'نشاط دراسي جاري اليوم.',
      },
      {
        promptAr: 'اختر صيغة النفي الصحيحة للمضارع المستمر مع الجمع:',
        sentenceWithBlank: 'The students ___ playing outside right now; they are in the lab.',
        correct: "aren't",
        distractors: ["don't", "didn't", "haven't"],
        whyCorrectAr: 'نفي المضارع المستمر مع الفاعل الجمع يكون باستخدام (aren’t + verb-ing).',
        temporalAr: 'نفي لحدث في اللحظة الحالية.',
      },
      {
        promptAr: 'اختر الفعل المناسب لسؤال يبدأ بـ (What):',
        sentenceWithBlank: 'What ___ you doing on the computer right now?',
        correct: 'are',
        distractors: ['do', 'did', 'have'],
        whyCorrectAr: 'السؤال في المضارع المستمر مع you يبدأ بـ What are you doing.',
        temporalAr: 'سؤال عن نشاط اللحظة الحالية.',
      },
      {
        promptAr: 'اختر الفعل المناسب لحدث مؤقت هذا الأسبوع:',
        sentenceWithBlank: 'Our team ___ on a brand new software project this week.',
        correct: 'is working',
        distractors: ['works', 'worked', 'has worked'],
        whyCorrectAr: 'العمل في مشروع مخصص لهذا الأسبوع (this week) يعبر عن نشاط مؤقت جاري.',
        temporalAr: 'مشروع جاري ومؤقت.',
      },
      {
        promptAr: 'اختر الفعل المناسب مع الجمع في هذه اللحظة:',
        sentenceWithBlank: 'The construction workers ___ the foundation of the new tower.',
        correct: 'are building',
        distractors: ['build', 'built', 'builds'],
        whyCorrectAr: 'الفاعل جمع (The workers) والنشاط جاري حالياً فيأخذ are building.',
        temporalAr: 'بناء مستمر في الحاضر.',
      },
      {
        promptAr: 'اختر التصريف الصحيح لمضاعفة الحرف الأخير قبل -ing:',
        sentenceWithBlank: 'Look at the athlete! He ___ faster than all his competitors.',
        correct: 'is running',
        distractors: ['is runing', 'runs', 'ran'],
        whyCorrectAr: 'الفعل run ينتهي بساكن قبله علة قصير فتضاعف الـ n لتصبح running.',
        temporalAr: 'سباق جاري أمام العين.',
      },
      {
        promptAr: 'اختر الفعل المعبر عن طقس اللحظة الراهنة:',
        sentenceWithBlank: 'Take your umbrella with you; it ___ heavily outside.',
        correct: 'is raining',
        distractors: ['rains', 'rained', 'has rained'],
        whyCorrectAr: 'النصيحة بأخذ المظلة مبنية على أن المطر يهطل الآن في هذه اللحظة.',
        temporalAr: 'هطول مطر جاري الآن.',
      },
    ],
    medium: [
      {
        promptAr: 'اختر الفعل المعبر عن ترتيبات وخطط مستقبلية مؤكدة مع حجز مسبق:',
        sentenceWithBlank: 'We ___ to Tokyo next Monday; our flight tickets and hotel are fully booked.',
        correct: 'are flying',
        distractors: ['fly', 'will fly', 'have flown'],
        whyCorrectAr: 'الترتيبات المستقبلية المؤكدة مع وجود حجز وتجهيز مسبق تُصاغ بـ Present Continuous.',
        temporalAr: 'ترتيب مستقبلي محجوز ومؤكد.',
      },
      {
        promptAr: 'اختر الفعل المعبر عن حالة أو إقامة مؤقتة تختلف عن العادة (Temporary Situation):',
        sentenceWithBlank: 'I usually live in Cairo, but this semester I ___ with my uncle in Alexandria.',
        correct: 'am staying',
        distractors: ['stay', 'stayed', 'have stayed'],
        whyCorrectAr: 'الإقامة المؤقتة لهذا الفصل الدراسي فقط تتطلب المضارع المستمر لتمييزها عن الإقامة الدائمة.',
        temporalAr: 'وضع استثنائي مؤقت ومحدد بوقت.',
      },
      {
        promptAr: 'اختر الفعل المعبر عن تغير وتطور تدريجي مستمر (Changing Situation):',
        sentenceWithBlank: 'Renewable energy technology ___ more affordable and efficient every year.',
        correct: 'is becoming',
        distractors: ['becomes', 'became', 'has become'],
        whyCorrectAr: 'التغيرات والاتجاهات المتطورة تدريجياً تصاغ بالمضارع المستمر.',
        temporalAr: 'عملية تحول وتطور تدريجي مستمرة.',
      },
      {
        promptAr: 'اختر الفعل المعبر عن لقاء رسمي مجدول في المستقبل القريب:',
        sentenceWithBlank: 'The CEO ___ with the prospective investors tomorrow morning at 10:00 AM.',
        correct: 'is meeting',
        distractors: ['meets', 'met', 'will have met'],
        whyCorrectAr: 'المواعيد واللقاءات الشخصية المنسقة مسبقاً تصاغ بالمضارع المستمر.',
        temporalAr: 'موعد شخصي متفق عليه في المستقبل.',
      },
      {
        promptAr: 'اختر المعنى الديناميكي المؤقت لفعل have بمعنى (يتناول / يقضي وقتاً):',
        sentenceWithBlank: 'Please do not disturb the manager right now; he ___ an important lunch meeting.',
        correct: 'is having',
        distractors: ['has', 'had', 'was having'],
        whyCorrectAr: 'فعل have عندما يأتي بمعنى (يتناول طعاماً أو يقضي وقتاً) يتحول لفعل حركي ديناميكي يقبل -ing.',
        temporalAr: 'نشاط حركي جاري في هذه اللحظة.',
      },
      {
        promptAr: 'اختر الفعل المعبر عن انخفاض وتراجع تدريجي في البيانات:',
        sentenceWithBlank: 'According to economic data, the unemployment rate ___ steadily across the region.',
        correct: 'is decreasing',
        distractors: ['decreases', 'decreased', 'has decreased'],
        whyCorrectAr: 'التغيرات والاتجاهات الإحصائية المتدرجة تصاغ بالمضارع المستمر.',
        temporalAr: 'اتجاه إحصائي تدريجي متحرك.',
      },
      {
        promptAr: 'اختر الفعل المعبر عن كورس أو تدريب مؤقت في الحاضر:',
        sentenceWithBlank: 'Karim ___ an advanced cyber security training program this month.',
        correct: 'is taking',
        distractors: ['takes', 'took', 'has taken'],
        whyCorrectAr: 'الدورة التدريبية المقيدة بهذا الشهر تمثل نشاطاً مؤقتاً.',
        temporalAr: 'تدريب مؤقت جاري.',
      },
    ],
    hard: [
      {
        promptAr: 'اختر الصيغة المعبرة عن الانزعاج والضيق من عادة متكررة مزعجة مع (always):',
        sentenceWithBlank: 'Why ___ you always ___ your dirty coffee cups in the conference room?!',
        correct: 'are / leaving',
        distractors: ['do / leave', 'did / leave', 'have / left'],
        whyCorrectAr: 'استخدام always مع المضارع المستمر (are leaving) يعبر عن الاستياء والضيق من تصرف متكرر.',
        temporalAr: 'سلوك متكرر يثير الانزعاج في الحاضر.',
      },
      {
        promptAr: 'تحدي التفريق بين المعنى التقريري والديناميكي لفعل (think):',
        sentenceWithBlank: 'I ___ about pursuing my master’s degree in artificial intelligence in Germany.',
        correct: 'am thinking',
        distractors: ['think', 'thought', 'have thought'],
        whyCorrectAr: 'فعل think هنا يعني (أفكر ملياً / أدرس الفكرة بعقلي) وهو نشاط ذهني ديناميكي يقبل -ing.',
        temporalAr: 'تفكير وتدبر ذهني جاري الآن.',
      },
      {
        promptAr: 'تحدي التفريق بين المعنى التقريري والديناميكي لفعل (taste):',
        sentenceWithBlank: 'The head chef ___ the soup right now to adjust the seasoning before serving.',
        correct: 'is tasting',
        distractors: ['tastes', 'tasted', 'has tasted'],
        whyCorrectAr: 'الشيف يقوم بفعل حركي إرادي وهو (تذوق الحساء بملعقة)، لذلك يأخذ المضارع المستمر.',
        temporalAr: 'فعل حركي إرادي جاري.',
      },
      {
        promptAr: 'اختر المعنى الديناميكي لفعل (see) بمعنى يقابل شخصاً أو يواعده:',
        sentenceWithBlank: 'Dr. Layla ___ her final medical specialist at 4:00 PM today.',
        correct: 'is seeing',
        distractors: ['sees', 'saw', 'has seen'],
        whyCorrectAr: 'فعل see هنا يعني (يقابل / يستشير / يلتقي) وهو استخدام ديناميكي يقبل -ing.',
        temporalAr: 'موعد ومقابلة مرتبة.',
      },
      {
        promptAr: 'اختر التعبير عن تغير مناخي عالمي متسارع بدون كلمات دلالية:',
        sentenceWithBlank: 'Polar ice caps ___ at an unprecedented rate due to global temperature increases.',
        correct: 'are melting',
        distractors: ['melt', 'melted', 'have melted'],
        whyCorrectAr: 'ذوبان الجليد يوصف كعملية مستمرة ومتغيرة تصاغ بالمضارع المستمر.',
        temporalAr: 'عملية تغير وتحول طبيعي جارية.',
      },
    ],
  },

  // ==========================================
  // 3. PRESENT PERFECT
  // ==========================================
  present_perfect: {
    easy: [
      {
        promptAr: 'اختر التصريف الثالث المناسب للتعبير عن تجربة حياة مع (never):',
        sentenceWithBlank: 'I have never ___ such an extraordinary architectural monument before.',
        correct: 'seen',
        distractors: ['see', 'saw', 'seeing'],
        whyCorrectAr: 'بعد have / has نستخدم التصريف الثالث (V3) للتعبير عن تجارب الحياة حتى اللحظة.',
        temporalAr: 'خبرة حياتية ممتدة حتى الحاضر.',
      },
      {
        promptAr: 'اختر الفعل المعبر عن إنجاز مكتمل للتو مع (just):',
        sentenceWithBlank: 'The scientific panel has just ___ the breakthrough discovery.',
        correct: 'announced',
        distractors: ['announce', 'announcing', 'announces'],
        whyCorrectAr: 'has just + V3 تدل على اكتمال الفعل قبل لحظات معدودة.',
        temporalAr: 'فعل تم للتو ونتيجته حاضرة بقوة.',
      },
      {
        promptAr: 'اختر الأداة المناسبة للسؤال عن التجارب الحياتية السابقة مع (ever):',
        sentenceWithBlank: '___ you ever traveled to the Scandinavian countries?',
        correct: 'Have',
        distractors: ['Did', 'Do', 'Are'],
        whyCorrectAr: 'السؤال عن تجارب الحياة في أي وقت حتى الآن يبدأ بـ Have you ever + V3.',
        temporalAr: 'استفسار عن رصيد التجارب حتى اللحظة.',
      },
      {
        promptAr: 'اختر الفعل المساعد المناسب مع الفاعل المفرد (He):',
        sentenceWithBlank: 'Dr. Hani ___ published five research papers this year.',
        correct: 'has',
        distractors: ['have', 'is', 'did'],
        whyCorrectAr: 'مع الفاعل المفرد الغائب نستخدم has + V3 في المضارع التام.',
        temporalAr: 'إنجازات محققة في فترة لم تنتهِ بعد.',
      },
      {
        promptAr: 'اختر الكلمة المناسبة في نهاية الجملة المنفية مع المضارع التام:',
        sentenceWithBlank: 'I have not received the official confirmation email ___.',
        correct: 'yet',
        distractors: ['already', 'since', 'just'],
        whyCorrectAr: 'تأتي (yet) في نهاية الجمل المنفية والأسئلة في المضارع التام.',
        temporalAr: 'عدم حدوث الفعل حتى هذه اللحظة مع توقعه.',
      },
      {
        promptAr: 'اختر الكلمة الدالة على اكتمال الفعل بالفعل قبل الموعد المتوقع:',
        sentenceWithBlank: 'They have ___ submitted their final graduation project ahead of schedule.',
        correct: 'already',
        distractors: ['yet', 'ever', 'ago'],
        whyCorrectAr: 'تستخدم already للتأكيد على اكتمال الحدث بالفعل وقبل التوقع.',
        temporalAr: 'إنجاز منتهي بالفعل.',
      },
      {
        promptAr: 'اختر التصريف الثالث الشاذ للفعل (write):',
        sentenceWithBlank: 'She has ___ an inspiring book about sustainable architecture.',
        correct: 'written',
        distractors: ['wrote', 'write', 'writing'],
        whyCorrectAr: 'التصريف الثالث للفعل write هو written.',
        temporalAr: 'كتاب تم تأليفه ونتيجته موجودة في الحاضر.',
      },
      {
        promptAr: 'اختر التصريف الثالث الشاذ للفعل (lose):',
        sentenceWithBlank: 'Omar cannot open his car because he has ___ his car keys.',
        correct: 'lost',
        distractors: ['losed', 'lose', 'losing'],
        whyCorrectAr: 'التصريف الثالث للفعل lose هو lost.',
        temporalAr: 'فقدان حدث في الماضي ونتيجته عدم القدرة على الدخول الآن.',
      },
    ],
    medium: [
      {
        promptAr: 'اختر الرابط الزمني المناسب مع نقطة بداية محددة بالاسم أو التاريخ:',
        sentenceWithBlank: 'Eng. Nadia has worked as a senior software architect ___ 2019.',
        correct: 'since',
        distractors: ['for', 'in', 'ago'],
        whyCorrectAr: 'نستخدم (since) لتحديد نقطة انطلاق وبداية الحدث في الماضي واستمراره حتى اليوم.',
        temporalAr: 'بداية نقطية في الماضي ممتدة للحاضر.',
      },
      {
        promptAr: 'اختر الرابط الزمني المناسب مع طول المدة الإجمالية (Duration):',
        sentenceWithBlank: 'They have lived in this modern residential district ___ more than a decade.',
        correct: 'for',
        distractors: ['since', 'during', 'ago'],
        whyCorrectAr: 'نستخدم (for) مع مقدار وطول المدة الزمنية الإجمالية.',
        temporalAr: 'فترة زمنية ممتدة حتى الحاضر.',
      },
      {
        promptAr: 'اختر الفعل المعبر عن حدث ماضٍ له أثر ونتيجة مباشرة وحاضرة في هذه اللحظة:',
        sentenceWithBlank: 'I cannot participate in the marathon because I ___ my ankle.',
        correct: 'have sprained',
        distractors: ['sprained', 'am spraining', 'had sprained'],
        whyCorrectAr: 'التواء الكاحل حدث في الماضي لكن أثره ونتيجته (عدم القدرة على الجري) قائمة الآن.',
        temporalAr: 'حدث ماضٍ مرتبط بنتيجة حاضرة وملموسة.',
      },
      {
        promptAr: 'اختر الرابط الزمني مع جملة ماضية بسيطة تحدد نقطة البداية:',
        sentenceWithBlank: 'He has not visited his hometown ___ he graduated from college.',
        correct: 'since',
        distractors: ['for', 'when', 'until'],
        whyCorrectAr: 'since يأتي بعدها نقطة زمنية أو جملة ماضٍ بسيط (he graduated) تحدد بداية الامتناع.',
        temporalAr: 'نقطة انطلاق زمنية منذ التخرج.',
      },
      {
        promptAr: 'اختر الفعل المعبر عن فترة زمنية لم تنتهِ بعد (this morning):',
        sentenceWithBlank: 'I ___ three cups of green tea this morning, and it is still only 10:00 AM.',
        correct: 'have drunk',
        distractors: ['drank', 'was drinking', 'had drunk'],
        whyCorrectAr: 'بما أن فترة الصباح لم تنتهِ بعد، نستخدم المضارع التام للتعبير عن الإنجاز المتراكم.',
        temporalAr: 'إنجازات مجمعة في فترة زمنية مفتوحة.',
      },
    ],
    hard: [
      {
        promptAr: 'تحدي التفريق بين been to و gone to: اختر الصيغة التي تعني "ذهب وعاد إلى موطنه":',
        sentenceWithBlank: 'Tariq is back in Cairo now; he has ___ to Germany for an international summit.',
        correct: 'been',
        distractors: ['gone', 'went', 'being'],
        whyCorrectAr: 'has been to تعني ذهب إلى مكان وعاد منه، بينما has gone to تعني ذهب ولم يعد بعد.',
        temporalAr: 'رحلة مكتملة مع الرجوع للحاضر.',
      },
      {
        promptAr: 'تحدي التفريق بين been to و gone to: اختر الصيغة التي تعني "ذهب وما زال هناك حتى الآن":',
        sentenceWithBlank: 'Where is Dr. Layla? She is not in her clinic; she has ___ to London for surgery.',
        correct: 'gone',
        distractors: ['been', 'went', 'goes'],
        whyCorrectAr: 'has gone to تدل على أنه غادر وما زال في وجهته أو في الطريق ولم يعد بعد.',
        temporalAr: 'سفر مستمر وما زال الشخص هناك.',
      },
      {
        promptAr: 'اختر التركيب مع صيغ التفضيل العليا (It is the first / best time):',
        sentenceWithBlank: 'This is the most compelling documentary film I ___ ever ___.',
        correct: 'have / watched',
        distractors: ['did / watch', 'had / watched', 'was / watching'],
        whyCorrectAr: 'بعد صيغ التفضيل العليا (the most / the best / the first time) نستخدم المضارع التام حصراً.',
        temporalAr: 'تقييم لتجربة حياة حتى اللحظة.',
      },
      {
        promptAr: 'اختر التركيب الصحيح المعبر عن تغير وتطور تم عبر التاريخ حتى اللحظة الراهنة:',
        sentenceWithBlank: 'Over the last two decades, renewable technology ___ dramatically.',
        correct: 'has advanced',
        distractors: ['advanced', 'was advancing', 'had advanced'],
        whyCorrectAr: 'العبارة (over the last two decades) تشير لفترة ممتدة حتى الحاضر تتطلب المضارع التام.',
        temporalAr: 'تطور تراكمي ممتد حتى الحاضر.',
      },
    ],
  },

  // ==========================================
  // 4. PRESENT PERFECT CONTINUOUS
  // ==========================================
  present_perfect_continuous: {
    easy: [
      {
        promptAr: 'اختر التركيب الصحيح للمضارع التام المستمر مع ضمير المفرد (He):',
        sentenceWithBlank: 'He ___ on this computer code for five straight hours.',
        correct: 'has been working',
        distractors: ['has worked', 'is working', 'was working'],
        whyCorrectAr: 'has been + V-ing يركز على استغراق المدة الزمنية المتواصلة لنشاط بدأ في الماضي ومستمر.',
        temporalAr: 'نشاط استغرق مدة طويلة ومستمر حتى الآن.',
      },
      {
        promptAr: 'اختر التركيب الصحيح مع ضمير المتكلم الجمع (We):',
        sentenceWithBlank: 'We ___ for the high-speed train since 8:30 AM.',
        correct: 'have been waiting',
        distractors: ['are waiting', 'have waited', 'were waiting'],
        whyCorrectAr: 'have been waiting يركز على استغراق الانتظار المستمر والمتصل منذ نقطة البداية.',
        temporalAr: 'مدة انتظار متصلة حتى اللحظة.',
      },
      {
        promptAr: 'اختر الفعل المساعد المناسب مع الفاعل المفرد (She):',
        sentenceWithBlank: 'She ___ been practicing the piano all afternoon.',
        correct: 'has',
        distractors: ['have', 'is', 'was'],
        whyCorrectAr: 'مع الفاعل المفرد (She) نستخدم has been + V-ing.',
        temporalAr: 'نشاط متصل استغرق كل فترة بعد الظهر.',
      },
      {
        promptAr: 'اختر صيغة السؤال عن المدة المستمرة حتى الحاضر:',
        sentenceWithBlank: 'How long ___ you been learning English?',
        correct: 'have',
        distractors: ['did', 'do', 'are'],
        whyCorrectAr: 'السؤال النموذجي عن المدة المستمرة: How long have you been + V-ing.',
        temporalAr: 'قياس مدة نشاط متواصل.',
      },
    ],
    medium: [
      {
        promptAr: 'اختر الزمن المناسب لتفسير سبب حالة حسية ملموسة ومرئية الآن في الحاضر:',
        sentenceWithBlank: 'The garden soil is very damp because it ___ all night long.',
        correct: 'has been raining',
        distractors: ['is raining', 'had rained', 'rained'],
        whyCorrectAr: 'استمرار هطول المطر كنشاط استغرق مدة هو التفسير المباشر لبلل التربة المرئي الآن.',
        temporalAr: 'نشاط استمر طوال الليل ونتيجته واضحة في الحاضر.',
      },
      {
        promptAr: 'اختر الفعل الذي يفسر الإرهاق البدني الظاهر على الشخص الآن:',
        sentenceWithBlank: 'Youssef is out of breath because he ___ up the mountain trail.',
        correct: 'has been running',
        distractors: ['ran', 'had run', 'was running'],
        whyCorrectAr: 'اللهاث وضيق التنفس في الحاضر يفسره نشاط بدني مستمر انتهى قبل لحظات معدودة.',
        temporalAr: 'نشاط بدني مجهد له أثر جسدي مباشر.',
      },
      {
        promptAr: 'اختر الفعل المناسب مع العبارة الدالة على الاستمرار المؤقت مؤخراً (lately / recently):',
        sentenceWithBlank: 'I ___ feeling unusually exhausted lately due to intensive project deadlines.',
        correct: 'have been',
        distractors: ['was', 'had been', 'am'],
        whyCorrectAr: 'have been feeling يعبر عن حالة شعورية مستمرة طوال الأيام الأخيرة (lately).',
        temporalAr: 'حالة مستمرة عبر الأيام الماضية وحتى الآن.',
      },
    ],
    hard: [
      {
        promptAr: 'تحدي التفريق بين الإنجاز والاستمرار: اختر الفعل الذي يركز على المشقة والجهد المبذول:',
        sentenceWithBlank: 'Look at my oil-stained hands! I ___ the vintage car engine all afternoon.',
        correct: 'have been repairing',
        distractors: ['have repaired', 'repaired', 'had repaired'],
        whyCorrectAr: 'التركيز هنا على عملية العمل الشاقة ذاتها والأثر المرئي وليس عدد السيارات التي أصلحها.',
        temporalAr: 'نشاط طويل ومستمر ذو أثر بدني مرئي.',
      },
      {
        promptAr: 'تحدي التمييز: اختر التعبير عن نشاط مستمر مقارنة بإنجاز رقمي مكتمل:',
        sentenceWithBlank: 'Salma ___ articles for medical journals for five years, and she has published twenty so far.',
        correct: 'has been writing',
        distractors: ['has written', 'wrote', 'had written'],
        whyCorrectAr: 'الشق الأول يصف ممارسة النشاط المستمرة عبر 5 سنوات (has been writing).',
        temporalAr: 'استمرارية العمل عبر الزمن.',
      },
    ],
  },

  // ==========================================
  // 5. PAST SIMPLE
  // ==========================================
  past_simple: {
    easy: [
      {
        promptAr: 'اختر التصريف الثاني المنتظم لحدث وقع وانتهى في وقت محدد في الماضي:',
        sentenceWithBlank: 'We ___ the ancient historical citadel yesterday afternoon.',
        correct: 'visited',
        distractors: ['visit', 'have visited', 'were visiting'],
        whyCorrectAr: 'وجود ظرف زمان ماضٍ ومحدد مثل (yesterday) يوجب استخدام الماضي البسيط (V2).',
        temporalAr: 'حدث مكتمل تماماً في نقطة ماضية منتهية.',
      },
      {
        promptAr: 'اختر الفعل الشاذ الماضي المناسب مع (two days ago):',
        sentenceWithBlank: 'She ___ a high-performance laptop two days ago.',
        correct: 'bought',
        distractors: ['buys', 'has bought', 'was buying'],
        whyCorrectAr: 'التصريف الثاني للفعل الشاذ buy هو (bought) مع وجود ago.',
        temporalAr: 'حدث وقع وانقطع في الماضي.',
      },
      {
        promptAr: 'اختر الفعل المساعد لنفي الجملة في الماضي البسيط:',
        sentenceWithBlank: 'They ___ attend the international summit last Friday.',
        correct: "didn't",
        distractors: ["don't", "weren't", "haven't"],
        whyCorrectAr: 'نفي الماضي البسيط يكون باستخدام didn’t متبوعة بمصدر الفعل.',
        temporalAr: 'نفي لحدث في نقطة ماضية.',
      },
      {
        promptAr: 'اختر صيغة السؤال في الماضي البسيط:',
        sentenceWithBlank: '___ you receive the official invitation letter last week?',
        correct: 'Did',
        distractors: ['Do', 'Have', 'Were'],
        whyCorrectAr: 'السؤال عن حدث ماضٍ محدد يبدأ بـ Did متبوعاً بالفاعل ومصدر الفعل.',
        temporalAr: 'سؤال عن نقطة ماضية محددة.',
      },
      {
        promptAr: 'اختر التصريف الثاني الشاذ للفعل (go):',
        sentenceWithBlank: 'Last summer, our entire family ___ on a road trip through Spain.',
        correct: 'went',
        distractors: ['go', 'gone', 'has gone'],
        whyCorrectAr: 'التصريف الثاني للماضي البسيط من go هو went.',
        temporalAr: 'عطلة صيفية ماضية مكتملة.',
      },
      {
        promptAr: 'اختر التصريف الثاني الشاذ للفعل (find):',
        sentenceWithBlank: 'The archaeologists ___ rare gold coins in the excavation site.',
        correct: 'found',
        distractors: ['finded', 'find', 'finding'],
        whyCorrectAr: 'التصريف الثاني الشاذ لـ find هو found.',
        temporalAr: 'اكتشاف أثري ماضٍ.',
      },
      {
        promptAr: 'اختر الفعل المناسب مع تاريخ ماضٍ محدد (In 1995):',
        sentenceWithBlank: 'The revolutionary company was founded in 1995 and ___ its first product.',
        correct: 'launched',
        distractors: ['launches', 'has launched', 'is launching'],
        whyCorrectAr: 'تحديد سنة ماضية (1995) يربط الحدث بالماضي البسيط.',
        temporalAr: 'حدث تاريخي في سنة محددة.',
      },
      {
        promptAr: 'اختر الفعل الماضي لفعل الكينونة (to be) مع الفاعل المفرد (He / She / It):',
        sentenceWithBlank: 'The medical conference ___ extremely informative and well organized.',
        correct: 'was',
        distractors: ['were', 'is', 'has been'],
        whyCorrectAr: 'مع الفاعل المفرد (The conference = It) نستخدم was في الماضي.',
        temporalAr: 'حالة ماضية مكتملة.',
      },
    ],
    medium: [
      {
        promptAr: 'اختر تسلسل الأحداث المتتالية السريعة في قصة ماضية (Sequential Actions):',
        sentenceWithBlank: 'He unlocked the wooden door, stepped inside, and ___ the desk lamp.',
        correct: 'switched on',
        distractors: ['switches on', 'was switching on', 'had switched on'],
        whyCorrectAr: 'سلسلة الأحداث السريعة المتتالية في الماضي تأتي كلها بصيغة الماضي البسيط.',
        temporalAr: 'تتابع خطي لأفعال ماضية متتالية.',
      },
      {
        promptAr: 'اختر التعبير عن عادة قديمة كانت تحدث في الماضي وانقطعت تماماً:',
        sentenceWithBlank: 'My grandfather ___ walk five miles across the countryside to school.',
        correct: 'used to',
        distractors: ['is used to', 'was using to', 'uses to'],
        whyCorrectAr: 'used to + مصدر تعبر عن عادة أو حالة كانت تحدث في الماضي وتوقفت.',
        temporalAr: 'عادة ماضية منتهية تماماً.',
      },
      {
        promptAr: 'اختر الفعل المعبر عن فترة زمنية أغلقت تماماً في حياة شخص:',
        sentenceWithBlank: 'She ___ as a research assistant for three years before changing careers.',
        correct: 'worked',
        distractors: ['has worked', 'is working', 'works'],
        whyCorrectAr: 'بما أن الوظيفة انتهت تماماً وغيرت مسارها المهني، فإن الفترة ماضية مغلقة تأخذ Past Simple.',
        temporalAr: 'فترة عمل ماضية انتهت وانغلقت.',
      },
      {
        promptAr: 'اختر الفعل المعبر عن إجابة على سؤال يبدأ بـ (When):',
        sentenceWithBlank: 'When ___ you complete your civil engineering degree?',
        correct: 'did',
        distractors: ['have', 'do', 'were'],
        whyCorrectAr: 'السؤال بـ When يسأل عن نقطة زمنية ماضية محددة ويأخذ did دائماً.',
        temporalAr: 'استفسار عن نقطة زمنية محددة.',
      },
    ],
    hard: [
      {
        promptAr: 'تحدي بدون كلمات دلالية: اختر الزمن المعبر عن إنجاز لشخصية تاريخية توفيت:',
        sentenceWithBlank: 'Leonardo da Vinci ___ masterpieces that influenced generations of artists.',
        correct: 'painted',
        distractors: ['has painted', 'had painted', 'was painting'],
        whyCorrectAr: 'الأحداث المتعلقة بأشخاص متوفين تصاغ حصراً في الماضي البسيط لأن حياتهم فترة ماضية مغلقة.',
        temporalAr: 'حدث في فترة زمنية ماضية منتهية كلياً.',
      },
      {
        promptAr: 'اختر التركيب الصحيح مع العبارة التمنية الافتراضية (It is high time):',
        sentenceWithBlank: 'It is high time we ___ taking decisive measures to protect our climate.',
        correct: 'started',
        distractors: ['start', 'have started', 'will start'],
        whyCorrectAr: 'التركيب (It is high time / It is time) يتبعه ماضٍ بسيط للدلالة على وجوب التصرف الفوري.',
        temporalAr: 'صيغة ماضٍ افتراضي تعبر عن الاستعجال.',
      },
      {
        promptAr: 'اختر الفعل الماضي المعبر عن نتيجة مباشرة في قصة بوليسية:',
        sentenceWithBlank: 'The moment the detective found the missing diary, he ___ the suspect’s true motive.',
        correct: 'realized',
        distractors: ['was realizing', 'has realized', 'had realized'],
        whyCorrectAr: 'لحظة العثور على المذكرات تبعها إدراك فوري مباشر، فالحدثان متتاليان في الماضي البسيط.',
        temporalAr: 'حدثان متتاليان فوراً في الماضي.',
      },
    ],
  },

  // ==========================================
  // 6. PAST CONTINUOUS
  // ==========================================
  past_continuous: {
    easy: [
      {
        promptAr: 'اختر الفعل المعبر عن حدث كان مستمراً في لحظة محددة بالضبط في الماضي:',
        sentenceWithBlank: 'At precisely 8:30 PM last night, I ___ an international scientific webinar.',
        correct: 'was watching',
        distractors: ['watched', 'have watched', 'am watching'],
        whyCorrectAr: 'تحديد ساعة ودقيقة معينة في الماضي يركز على استمرار الفعل في تلك اللحظة بالذات.',
        temporalAr: 'حدث كان جارياً في نقطة زمنية ماضية.',
      },
      {
        promptAr: 'اختر الفعل المساعد المناسب مع فاعل الجمع (They):',
        sentenceWithBlank: 'They ___ preparing the laboratory experiments when the power failed.',
        correct: 'were',
        distractors: ['was', 'are', 'have been'],
        whyCorrectAr: 'مع ضمائر الجمع (They) نستخدم were + V-ing في الماضي المستمر.',
        temporalAr: 'فعل مستمر في الماضي قاطعه حدث آخر.',
      },
      {
        promptAr: 'اختر صيغة النفي الصحيحة للمفرد في الماضي المستمر:',
        sentenceWithBlank: 'He ___ paying attention to the road signs when the incident occurred.',
        correct: "wasn't",
        distractors: ["weren't", "didn't", "isn't"],
        whyCorrectAr: 'مع الفاعل المفرد (He) نستخدم wasn’t + verb-ing.',
        temporalAr: 'نفي الاستمرار أثناء وقوع الحدث.',
      },
      {
        promptAr: 'اختر صيغة السؤال في الماضي المستمر مع (you):',
        sentenceWithBlank: 'What ___ you doing when the fire alarm sounded?',
        correct: 'were',
        distractors: ['did', 'was', 'have'],
        whyCorrectAr: 'السؤال عن نشاط مستمر في الماضي مع you يبدأ بـ What were you doing.',
        temporalAr: 'سؤال عن النشاط الجاري أثناء المقاطعة.',
      },
    ],
    medium: [
      {
        promptAr: 'اختر التركيب الصحيح عند تقاطع حدثين (حدث طويل مستمر قاطعه حدث مفاجئ قصير):',
        sentenceWithBlank: 'While she ___ home through the park, a sudden thunderstorm began.',
        correct: 'was walking',
        distractors: ['walked', 'is walking', 'has walked'],
        whyCorrectAr: 'الحدث الطويل المستمر في الخلفية (was walking) يأتي بعد While ويقطعه الحدث القصير (began).',
        temporalAr: 'حدث طويل مستمر قوطع بحدث مفاجئ.',
      },
      {
        promptAr: 'اختر الفعل المعبر عن حدثين كانا مستمرين في نفس الوقت بالتوازي (Parallel Actions):',
        sentenceWithBlank: 'While the lead researcher was presenting the data, the assistants ___ notes.',
        correct: 'were taking',
        distractors: ['took', 'are taking', 'had taken'],
        whyCorrectAr: 'الحدثان كانا مستمرين في نفس الفترة الزمنية بالتوازي في الماضي بعد While.',
        temporalAr: 'استمرارية متزامنة في الماضي.',
      },
      {
        promptAr: 'اختر التركيب المناسب بعد أداة الربط (When) للحدث الذي قاطع الاستمرار:',
        sentenceWithBlank: 'We were discussing the contract terms when the unexpected email ___.',
        correct: 'arrived',
        distractors: ['was arriving', 'has arrived', 'had arrived'],
        whyCorrectAr: 'الحدث القاطع المفاجئ بعد When يأتي في صيغة الماضي البسيط (arrived).',
        temporalAr: 'حدث مفاجئ قاطع حدثاً مستمراً.',
      },
    ],
    hard: [
      {
        promptAr: 'اختر الصيغة المناسبة لوصف الأجواء والخلفية المشهدية في القصص (Setting the Scene):',
        sentenceWithBlank: 'The gentle wind ___ through the pines and birds were singing as the dawn broke.',
        correct: 'was whispering',
        distractors: ['whispered', 'had whispered', 'whispers'],
        whyCorrectAr: 'وصف خلفية وأجواء المشهد في القصص والروايات يصاغ بالماضي المستمر لإعطاء إحساس بالمشهد.',
        temporalAr: 'أجواء ومناظر مستمرة في خلفية القصة.',
      },
      {
        promptAr: 'اختر الصيغة المعبرة عن طلب أو استفسار مهذب جداً في الماضي المستمر:',
        sentenceWithBlank: 'I ___ wondering if you might have a few minutes to review my resume.',
        correct: 'was',
        distractors: ['am', 'have been', 'had been'],
        whyCorrectAr: 'الماضي المستمر (I was wondering) يستخدم كصيغة أدبية بالغة اللباقة والتهذيب في الطلب.',
        temporalAr: 'صيغة أدبية مهذبة.',
      },
    ],
  },

  // ==========================================
  // 7. PAST PERFECT
  // ==========================================
  past_perfect: {
    easy: [
      {
        promptAr: 'اختر التركيب الصحيح للماضي التام (الحدث الأقدم والأسبق في الماضي):',
        sentenceWithBlank: 'When we arrived at the airport terminal, the flight had already ___.',
        correct: 'departed',
        distractors: ['depart', 'departing', 'departs'],
        whyCorrectAr: 'صيغة الماضي التام هي had + التصريف الثالث (departed).',
        temporalAr: 'الحدث الأسبق زمنياً قبل وصولنا.',
      },
      {
        promptAr: 'اختر الفعل المساعد الدال على الحدث الأسبق في الماضي:',
        sentenceWithBlank: 'She could not enter her apartment because she ___ lost her keys earlier.',
        correct: 'had',
        distractors: ['has', 'was', 'did'],
        whyCorrectAr: 'فقدان المفتاح حدث أولاً في الماضي (had lost) قبل محاولة الدخول.',
        temporalAr: 'حدث أسبق مهد لنتيجة تالية.',
      },
      {
        promptAr: 'اختر التصريف الثالث الشاذ للفعل (eat) في الماضي التام:',
        sentenceWithBlank: 'They were not hungry because they had already ___ a large lunch.',
        correct: 'eaten',
        distractors: ['ate', 'eating', 'eat'],
        whyCorrectAr: 'التصريف الثالث لـ eat هو eaten بعد had.',
        temporalAr: 'تناول الطعام تم قبل ذلك.',
      },
    ],
    medium: [
      {
        promptAr: 'اختر الربط الصحيح بين حدثين في الماضي مع الرابط (Before):',
        sentenceWithBlank: 'Before he purchased the property, he ___ all legal documents thoroughly.',
        correct: 'had examined',
        distractors: ['examined', 'has examined', 'was examining'],
        whyCorrectAr: 'فحص المستندات حدث أولاً (had examined)، ثم شراء العقار حدث ثانياً (purchased).',
        temporalAr: 'الحدث 1: had + V3، الحدث 2: Past Simple.',
      },
      {
        promptAr: 'اختر الترتيب الصحيح مع الرابط (After):',
        sentenceWithBlank: 'After the engineering team ___ the safety audit, the factory reopened.',
        correct: 'had completed',
        distractors: ['completed', 'have completed', 'were completing'],
        whyCorrectAr: 'إكمال فحص السلامة تم أولاً (had completed) قبل إعادة فتح المصنع.',
        temporalAr: 'الحدث الأسبق يأتي بعد After.',
      },
      {
        promptAr: 'اختر التعبير الدقيق مع الرابط الزمني (By the time):',
        sentenceWithBlank: 'By the time the ambulance arrived, the paramedics ___ first aid.',
        correct: 'had administered',
        distractors: ['administered', 'have administered', 'administer'],
        whyCorrectAr: 'By the time + Past Simple يتبعها Past Perfect للحدث الذي تم واكتمل قبل تلك النقطة.',
        temporalAr: 'اكتمال تام قبل لحظة وصول معينة في الماضي.',
      },
    ],
    hard: [
      {
        promptAr: 'اختر التركيب الصحيح مع عبارات النفي المقلوبة التوكيدية (Hardly / Scarcely had):',
        sentenceWithBlank: 'Hardly ___ the presentation started when the fire alarm interrupted us.',
        correct: 'had',
        distractors: ['has', 'was', 'did'],
        whyCorrectAr: 'التركيب المقلوب: Hardly had + Subject + V3 ... when + Past Simple.',
        temporalAr: 'وقوع حدث فور اكتمال حدث أسبق مباشرة.',
      },
      {
        promptAr: 'اختر التركيب الصحيح مع الشرطية الثالثة (Third Conditional):',
        sentenceWithBlank: 'If they ___ about the road closure, they would have taken the highway.',
        correct: 'had known',
        distractors: ['knew', 'have known', 'would know'],
        whyCorrectAr: 'في جملة شرط (If) في الشرطية الثالثة نستخدم Past Perfect (had known).',
        temporalAr: 'افتراض ماضٍ مستحيل لم يحدث.',
      },
    ],
  },

  // ==========================================
  // 8. PAST PERFECT CONTINUOUS
  // ==========================================
  past_perfect_continuous: {
    easy: [
      {
        promptAr: 'اختر التركيب الصحيح للماضي التام المستمر:',
        sentenceWithBlank: 'They were exhausted because they ___ running for three hours.',
        correct: 'had been',
        distractors: ['have been', 'were', 'had'],
        whyCorrectAr: 'had been + V-ing يصف مدة نشاط استمرت قبل نقطة معينة في الماضي وسببت التعب.',
        temporalAr: 'استمرارية نشاط قبل حدث ماضٍ آخر.',
      },
      {
        promptAr: 'اختر الفعل المساعد المناسب للماضي التام المستمر:',
        sentenceWithBlank: 'She ___ been studying Japanese for years before she moved to Tokyo.',
        correct: 'had',
        distractors: ['has', 'was', 'would'],
        whyCorrectAr: 'had been studying يعبر عن استمرار دراسة اللغة طوال سنوات قبل خطوة الانتقال.',
        temporalAr: 'نشاط استمر طويلاً وانتهى عند محطة ماضية.',
      },
    ],
    medium: [
      {
        promptAr: 'اختر الفعل المعبر عن استمرار نشاط طويل قبل حدث ماضٍ آخر:',
        sentenceWithBlank: 'Eng. Faris ___ at the software firm for ten years before he founded his startup.',
        correct: 'had been working',
        distractors: ['was working', 'worked', 'has been working'],
        whyCorrectAr: 'التركيز على طول فترة العمل (10 years) واستمرارها حتى لحظة تأسيس الشركة في الماضي.',
        temporalAr: 'مدة مستمرة حتى محطة ماضية.',
      },
      {
        promptAr: 'اختر الفعل الذي يفسر سبب حالة الأرض والطقس في الماضي:',
        sentenceWithBlank: 'The roads were dangerously slippery because it ___ all night long.',
        correct: 'had been snowing',
        distractors: ['snowed', 'was snowing', 'has been snowing'],
        whyCorrectAr: 'استمرار تساقط الثلج طوال الليل هو السبب المستمر للانزلاق في الصباح الماضي.',
        temporalAr: 'نشاط متواصل كان سبباً لحالة ماضية.',
      },
    ],
    hard: [
      {
        promptAr: 'تحدي التفريق بين الماضي المستمر والماضي التام المستمر في تحديد المدة:',
        sentenceWithBlank: 'When the teacher entered, the students ___ noise for twenty minutes.',
        correct: 'had been making',
        distractors: ['were making', 'made', 'have been making'],
        whyCorrectAr: 'وجود ذكر صريح للمدة (for twenty minutes) قبل دخول المعلم يوجب Past Perfect Continuous.',
        temporalAr: 'مدة استمرارية ممتدة ومحسوبة قبل لحظة الدخول.',
      },
    ],
  },

  // ==========================================
  // 9. FUTURE SIMPLE
  // ==========================================
  future_simple: {
    easy: [
      {
        promptAr: 'اختر الفعل المعبر عن قرار عفوي فوري وليد اللحظة (Instant Decision):',
        sentenceWithBlank: 'The landline phone is ringing in the other room. I ___ answer it.',
        correct: 'will',
        distractors: ['am going to', 'am', 'have'],
        whyCorrectAr: 'القرارات العفوية الفورية المتخذة في نفس لحظة الكلام تصاغ بـ (will + مصدر).',
        temporalAr: 'قرار مستقبلي فوري وليد اللحظة.',
      },
      {
        promptAr: 'اختر الفعل المعبر عن وعد في المستقبل (Promise):',
        sentenceWithBlank: 'Do not worry about your confidential files; I ___ protect them.',
        correct: 'will',
        distractors: ['am going to', 'am', 'did'],
        whyCorrectAr: 'الوعود والعروض والالتزامات تصاغ بـ (will).',
        temporalAr: 'التزام ووعد مستقبلي.',
      },
      {
        promptAr: 'اختر الفعل المعبر عن عرض مساعدة تطوعي (Offer):',
        sentenceWithBlank: 'That heavy suitcase looks difficult. I ___ carry it for you.',
        correct: 'will',
        distractors: ['am going to', 'shall be', 'am carrying'],
        whyCorrectAr: 'عروض المساعدة التلقائية تصاغ بـ will.',
        temporalAr: 'عرض مساعدة فوري.',
      },
      {
        promptAr: 'اختر صيغة النفي المختصرة للفعل will:',
        sentenceWithBlank: 'I promise I ___ reveal your secret password to anyone.',
        correct: "won't",
        distractors: ["willn't", "don't", "aren't"],
        whyCorrectAr: 'نفي will هو will not وتختصر دائماً إلى won’t.',
        temporalAr: 'نفي قاطع لوعد مستقبلي.',
      },
    ],
    medium: [
      {
        promptAr: 'اختر الصيغة المعبرة عن تنبؤ قائم على دليل حسي مرئي حاضر أمام العين (Evidence):',
        sentenceWithBlank: 'Look at those dense black storm clouds! It ___ rain very heavily.',
        correct: 'is going to',
        distractors: ['will', 'shall', 'is raining'],
        whyCorrectAr: 'وجود دليل مادي حاضر ملموس (dense storm clouds) يوجب استخدام (be going to) للتنبؤ.',
        temporalAr: 'تنبؤ وشيك بدليل مادي قائم.',
      },
      {
        promptAr: 'اختر الصيغة المعبرة عن نية وقرار مسبق قبل لحظة التحدث (Prior Intention):',
        sentenceWithBlank: 'I have finalized my plan. I ___ enroll in the cybersecurity master program.',
        correct: 'am going to',
        distractors: ['will', 'shall', 'did'],
        whyCorrectAr: 'النية والقرار المتخذ مسبقاً بعد تفكير يعبر عنهما بـ (be going to).',
        temporalAr: 'قصد ونية سابقة.',
      },
      {
        promptAr: 'اختر الصيغة بعد أفعال الظن والاعتقاد الشخصي (I think, I believe, I doubt):',
        sentenceWithBlank: 'I think that artificial intelligence ___ transform medical diagnostics.',
        correct: 'will',
        distractors: ['is going to', 'is transforming', 'transforms'],
        whyCorrectAr: 'التنبؤات المبنية على الرأي والحدس والتوقع الشخصي تأخذ (will).',
        temporalAr: 'توقع مستقبلي مبني على الرأي.',
      },
    ],
    hard: [
      {
        promptAr: 'اختر التركيب الصحيح في جملة جواب الشرطية الأولى (First Conditional):',
        sentenceWithBlank: 'If the team maintains this consistent performance, they ___ the championship.',
        correct: 'will win',
        distractors: ['win', 'would win', 'are winning'],
        whyCorrectAr: 'في الشرطية الأولى، جواب الشرط يكون: will + Verb(base).',
        temporalAr: 'نتيجة مستقبلية متوقعة لشرط حاضر.',
      },
      {
        promptAr: 'اختر الصيغة المناسبة لحقيقة مستقبلية حتمية لا يملك الإنسان تغييرها (Future Fact):',
        sentenceWithBlank: 'The current President ___ fifty years old on his upcoming birthday next month.',
        correct: 'will be',
        distractors: ['is going to be', 'is being', 'is'],
        whyCorrectAr: 'الحقائق العمرية والزمنية الحتمية التي لا تخضع للنية تصاغ بـ (will be).',
        temporalAr: 'حقيقة عمرية حتمية في المستقبل.',
      },
    ],
  },

  // ==========================================
  // 10. FUTURE CONTINUOUS
  // ==========================================
  future_continuous: {
    easy: [
      {
        promptAr: 'اختر التركيب الصحيح للمستقبل المستمر:',
        sentenceWithBlank: 'This time next week, we will be ___ across the Mediterranean Sea.',
        correct: 'sailing',
        distractors: ['sail', 'sailed', 'sails'],
        whyCorrectAr: 'تركيب المستقبل المستمر هو (will be + V-ing).',
        temporalAr: 'حدث سيكون في قمة استمراره في نقطة مستقبلية محددة.',
      },
      {
        promptAr: 'اختر الفعل المساعد المناسب للمستقبل المستمر:',
        sentenceWithBlank: 'At 9:00 PM tomorrow, I ___ be flying to London.',
        correct: 'will',
        distractors: ['am', 'have', 'was'],
        whyCorrectAr: 'صيغة المستقبل المستمر: will be + V-ing.',
        temporalAr: 'فعل مستمر في ساعة محددة غداً.',
      },
    ],
    medium: [
      {
        promptAr: 'اختر الفعل المعبر عن حدث سيكون جارياً في ساعة معينة في المستقبل:',
        sentenceWithBlank: 'At 10:00 AM tomorrow, the committee ___ the keynote speeches.',
        correct: 'will be attending',
        distractors: ['will attend', 'attend', 'is attending'],
        whyCorrectAr: 'تحديد وقت دقيق في المستقبل (At 10:00 AM tomorrow) يعبر عن نشاط سيكون مستمراً خلاله.',
        temporalAr: 'استمرارية في نقطة زمنية مستقبلية.',
      },
      {
        promptAr: 'اختر الفعل المعبر عن حدث روتيني سيحدث بشكل طبيعي وتلقائي كجزء من المعتاد:',
        sentenceWithBlank: 'I ___ seeing Dr. Mona tomorrow anyway at the faculty meeting.',
        correct: 'will be',
        distractors: ['am', 'will', 'have been'],
        whyCorrectAr: 'will be seeing تعبر عن لقاء روتيني سيحدث طبيعياً بحكم مسار الأحداث المعتاد.',
        temporalAr: 'سريان طبيعي للأحداث الروتينية.',
      },
    ],
    hard: [
      {
        promptAr: 'اختر الصيغة المستخدمة للسؤال المهذب وغير الضاغط عن خطط الآخرين:',
        sentenceWithBlank: '___ you ___ using the laboratory equipment during tomorrow morning’s session?',
        correct: 'Will / be',
        distractors: ['Do / use', 'Are / going to', 'Did / use'],
        whyCorrectAr: 'المستقبل المستمر يستخدم كصيغة مهذبة وغير متطفلة للاستفسار عن خطط الآخرين.',
        temporalAr: 'استفسار مهذب عن سريان المستقبل.',
      },
    ],
  },

  // ==========================================
  // 11. FUTURE PERFECT
  // ==========================================
  future_perfect: {
    easy: [
      {
        promptAr: 'اختر التركيب الصحيح للمستقبل التام:',
        sentenceWithBlank: 'By next December, the contractors will have ___ the residential bridge.',
        correct: 'completed',
        distractors: ['complete', 'completing', 'completes'],
        whyCorrectAr: 'المستقبل التام يتكون من (will have + التصريف الثالث V3).',
        temporalAr: 'اكتمال الفعل قبل موعد مستقبلي محدد.',
      },
      {
        promptAr: 'اختر الفعل المساعد المناسب للمستقبل التام:',
        sentenceWithBlank: 'By 2030, scientists will ___ found cures for several diseases.',
        correct: 'have',
        distractors: ['be', 'had', 'been'],
        whyCorrectAr: 'صيغة المستقبل التام دائماً هي will have + V3.',
        temporalAr: 'إنجاز مكتمل بحلول سنة قادمة.',
      },
    ],
    medium: [
      {
        promptAr: 'اختر الفعل المناسب مع الرابط الدال على الحد الزمني الأقصى (By 2035):',
        sentenceWithBlank: 'By the year 2035, the municipal government ___ a 100% green transit network.',
        correct: 'will have established',
        distractors: ['will establish', 'establishes', 'is establishing'],
        whyCorrectAr: 'By + تاريخ مستقبلي تعني بحلول ذلك الوقت سيكون المشروع قد اكتمل وأُنجز.',
        temporalAr: 'إنجاز مكتمل قبل محطة زمنية قادمة.',
      },
      {
        promptAr: 'اختر التركيب مع الرابط الزمني (By the end of this month):',
        sentenceWithBlank: 'By the end of this month, she ___ her extensive medical training course.',
        correct: 'will have finished',
        distractors: ['will finish', 'finishes', 'is finishing'],
        whyCorrectAr: 'الإنهاء سيكون قد تم واكتمل قبل حلول نهاية هذا الشهر.',
        temporalAr: 'اكتمال إنجاز قبل موعد محدد.',
      },
    ],
    hard: [
      {
        promptAr: 'اختر التركيب الدقيق عند اقتران جملة شرطية زمنية بالمستقبل التام:',
        sentenceWithBlank: 'By the time you wake up tomorrow morning, our flight ___ in Tokyo.',
        correct: 'will have landed',
        distractors: ['will land', 'lands', 'landed'],
        whyCorrectAr: 'الهبوط سيكون قد تحقق واكتمل قبل لحظة استيقاظك في المستقبل.',
        temporalAr: 'اكتمال أسبق في المستقبل قبل حدث مستقبلي آخر.',
      },
      {
        promptAr: 'اختر الفعل المناسب للتعبير عن ادخار مبلغ محدد بحلول وقت معين:',
        sentenceWithBlank: 'In two years’ time, they ___ enough capital to launch their technology startup.',
        correct: 'will have saved',
        distractors: ['will save', 'save', 'are saving'],
        whyCorrectAr: 'العبارة (In two years’ time) تشير إلى اكتمال الإنجاز والتوفير عند حلول تلك المدة.',
        temporalAr: 'اكتمال تراكمي بحلول موعد مقبل.',
      },
    ],
  },

  // ==========================================
  // 12. FUTURE PERFECT CONTINUOUS
  // ==========================================
  future_perfect_continuous: {
    easy: [
      {
        promptAr: 'اختر التركيب الصحيح للمستقبل التام المستمر:',
        sentenceWithBlank: 'By midnight, she will have been ___ for 8 continuous hours.',
        correct: 'studying',
        distractors: ['studied', 'study', 'studies'],
        whyCorrectAr: 'المستقبل التام المستمر يتكون من (will have been + V-ing).',
        temporalAr: 'قياس استمرارية المدة حتى لحظة مستقبلية.',
      },
      {
        promptAr: 'اختر الفعل المساعد المناسب للمستقبل التام المستمر:',
        sentenceWithBlank: 'By next year, I will ___ been working here for a decade.',
        correct: 'have',
        distractors: ['had', 'be', 'has'],
        whyCorrectAr: 'التركيب دائماً هو: will have been + V-ing.',
        temporalAr: 'حساب مدة متراكمة في المستقبل.',
      },
    ],
    medium: [
      {
        promptAr: 'اختر الفعل المعبر عن طول مدة الاستمرار بحلول محطة قادمة (Next October):',
        sentenceWithBlank: 'Next October, we ___ living in this historical house for exactly twenty years.',
        correct: 'will have been',
        distractors: ['will be', 'have been', 'are'],
        whyCorrectAr: 'التركيز على حساب واستعراض مدة العيش (for 20 years) عند حلول أكتوبر القادم.',
        temporalAr: 'استمرار مدة متراكمة حتى نقطة مستقبلية.',
      },
      {
        promptAr: 'اختر الفعل المعبر عن قياس مدة القيادة المستمرة بحلول وقت معين:',
        sentenceWithBlank: 'By 6:00 PM, the driver ___ for ten hours without a significant break.',
        correct: 'will have been driving',
        distractors: ['will drive', 'will be driving', 'drives'],
        whyCorrectAr: 'قياس مدة القيادة المستمرة والمتواصلة (for ten hours) حتى الساعة السادسة مساءً.',
        temporalAr: 'استمرار نشاط متواصل حتى محطة زمنية.',
      },
    ],
    hard: [
      {
        promptAr: 'تحدي المعنى الدقيق: اختر الزمن الذي يقيس استمرارية العمل حتى لحظة تقاعد مستقبلية:',
        sentenceWithBlank: 'When Professor Robert retires next June, he ___ at the university for 40 years.',
        correct: 'will have been teaching',
        distractors: ['will teach', 'will be teaching', 'is teaching'],
        whyCorrectAr: 'قياس المدة الإجمالية للتدريس المستمر (40 years) حتى تاريخ التقاعد المستقبلي.',
        temporalAr: 'تراكم استمرارية نشاط حتى محطة مستقبلية.',
      },
      {
        promptAr: 'اختر التركيب الذي يربط بين حدث مستقبلي واستمرارية المدة التراكمية:',
        sentenceWithBlank: 'By the time the championship concludes, the athletes ___ for six consecutive months.',
        correct: 'will have been training',
        distractors: ['will train', 'will have trained', 'are training'],
        whyCorrectAr: 'التركيز على استغراق ومدة التدريب المتواصل طوال 6 أشهر بحلول ختام البطولة.',
        temporalAr: 'استغراق مدة تدريب متواصلة حتى موعد قادم.',
      },
    ],
  },
};
