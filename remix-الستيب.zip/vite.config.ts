import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import path from 'path';
import { defineConfig, Plugin } from 'vite';

function multiPartSrcPlugin(): Plugin {
  const srcParts = ['src_part_1', 'src_part_2', 'src_part_3', 'src_part_4'];
  const extensions = ['', '.tsx', '.ts', '.jsx', '.js', '.json', '.css'];

  function findInParts(relPath: string): string | null {
    const cleanRel = relPath.replace(/^[/\\]+/, '').replace(/^src[/\\]+/, '');
    for (const part of srcParts) {
      for (const ext of extensions) {
        const candidate = path.resolve(__dirname, part, cleanRel + ext);
        if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) {
          return candidate;
        }
      }
    }
    return null;
  }

  return {
    name: 'multi-part-src-resolver',
    enforce: 'pre',
    resolveId(source, importer) {
      if (source.startsWith('/src/') || source.startsWith('src/') || source === '/src/main.tsx' || source === 'src/main.tsx') {
        const match = findInParts(source);
        if (match) return match;
      }
      if (importer && (importer.includes('src_part_') || importer.includes('/src/'))) {
        if (source.startsWith('.')) {
          const directTarget = path.resolve(path.dirname(importer), source);
          for (const ext of extensions) {
            if (fs.existsSync(directTarget + ext) && fs.statSync(directTarget + ext).isFile()) {
              return directTarget + ext;
            }
          }
          for (const part of srcParts) {
            if (importer.includes(part)) {
              const relToPart = path.relative(path.resolve(__dirname, part), path.dirname(importer));
              const crossRel = path.join(relToPart, source);
              const match = findInParts(crossRel);
              if (match) return match;
            }
          }
        }
      }
      return null;
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [multiPartSrcPlugin(), react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
